#!/usr/bin/env python3
"""
Test SoulLoop module
"""

import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

print("Testing SoulLoop...")

# Test 1: Import
try:
    from core.soul_loop import SoulLoop
    print("✓ Import successful")
except Exception as e:
    print(f"✗ Import failed: {e}")
    exit(1)

# Test 2: Create object
try:
    soul = SoulLoop(sleep_minutes=1)
    print("✓ Object created")
except Exception as e:
    print(f"✗ Object creation failed: {e}")
    exit(1)

# Test 3: Get status
try:
    status = soul.get_status()
    print(f"✓ get_status() works: cycle={status['cycle_count']}")
except Exception as e:
    print(f"✗ get_status() failed: {e}")
    exit(1)

# Test 4: Run one cycle
try:
    result = soul.run()
    if result['success']:
        print(f"✓ run() works: cycle {result['cycle']} completed")
    else:
        print(f"⚠ run() returned success=False: {result.get('error')}")
except Exception as e:
    print(f"✗ run() failed: {e}")
    exit(1)

# Test 5: Check state was updated
try:
    status_after = soul.get_status()
    if status_after['cycle_count'] > 0:
        print(f"✓ State updated: cycle_count={status_after['cycle_count']}")
    else:
        print(f"⚠ State not updated: cycle_count still 0")
except Exception as e:
    print(f"✗ Status check failed: {e}")
    exit(1)

print("\n✅ All SoulLoop tests passed!")
