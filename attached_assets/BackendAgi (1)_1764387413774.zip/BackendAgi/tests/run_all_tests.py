#!/usr/bin/env python3
"""
Run all tests
"""

import subprocess
import sys

tests = [
    'tests/test_state.py',
    'tests/test_analyzer.py',
    'tests/test_strategist.py',
    'tests/test_loop.py'
]

print("=" * 60)
print("Running all Soul Loop tests...")
print("=" * 60)

failed = []

for test in tests:
    print(f"\n{'=' * 60}")
    print(f"Running {test}")
    print("=" * 60)
    
    result = subprocess.run([sys.executable, test], capture_output=False)
    
    if result.returncode != 0:
        failed.append(test)

print("\n" + "=" * 60)
print("TEST SUMMARY")
print("=" * 60)
print(f"Total tests: {len(tests)}")
print(f"Passed: {len(tests) - len(failed)}")
print(f"Failed: {len(failed)}")

if failed:
    print("\nFailed tests:")
    for test in failed:
        print(f"  ✗ {test}")
    sys.exit(1)
else:
    print("\n✅ All tests passed!")
    sys.exit(0)
