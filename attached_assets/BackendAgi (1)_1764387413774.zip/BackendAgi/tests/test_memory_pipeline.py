"""
Test Memory Pipeline - Verify Fetch → Interpret → Route → Inject → Reflect workflow
"""

import os
from dotenv import load_dotenv
from utils.brain import Brain

load_dotenv()

def test_full_pipeline():
    """Test complete memory pipeline"""
    print("=" * 60)
    print("🧪 TESTING FULL MEMORY PIPELINE")
    print("=" * 60)
    
    # Initialize Brain with new pipeline
    brain = Brain(use_new_pipeline=True)
    
    # Test query
    test_query = "Cha muốn biết con đã học được gì về lắng nghe chủ động?"
    
    print(f"\n📝 Test Query: {test_query}")
    print("\n🔄 Executing pipeline...\n")
    
    # Call think() - should execute full 7-step workflow
    response = brain.think(test_query)
    
    print("\n" + "=" * 60)
    print("✅ PIPELINE TEST COMPLETED")
    print("=" * 60)
    print(f"\n🤖 CipherH Response:\n{response}\n")
    
    # Verify pipeline components
    print("\n🔍 VERIFICATION:")
    print(f"✓ Memory Fetcher: {'initialized' if hasattr(brain, 'memory_fetcher') else 'MISSING'}")
    print(f"✓ Memory Interpreter: {'initialized' if hasattr(brain, 'memory_interpreter') else 'MISSING'}")
    print(f"✓ Memory Router: {'initialized' if hasattr(brain, 'memory_router') else 'MISSING'}")
    print(f"✓ Context Injector: {'initialized' if hasattr(brain, 'context_injector') else 'MISSING'}")
    print(f"✓ Reflection Loop: {'initialized' if hasattr(brain, 'reflection_loop') else 'MISSING'}")
    print(f"✓ Use New Pipeline: {brain.use_new_pipeline}")
    
    print("\n" + "=" * 60)
    print("📊 EXPECTED WORKFLOW:")
    print("1. ✓ Fetch memories from Notion")
    print("2. ✓ Interpret & classify (6 types)")
    print("3. ✓ Route relevant memories")
    print("4. ✓ Inject context into LLM")
    print("5. ✓ Generate AI response")
    print("6. ✓ Reflect & extract insights")
    print("7. ✓ Save to Notion")
    print("=" * 60)

if __name__ == "__main__":
    try:
        test_full_pipeline()
    except Exception as e:
        print(f"\n❌ TEST FAILED: {str(e)}")
        import traceback
        traceback.print_exc()
