import os
import re
import json
from typing import Dict, Any, List, Tuple, Optional
from datetime import datetime
from collections import Counter, defaultdict
import logging

logger = logging.getLogger(__name__)

class LogAnalyzer:
    """
    Đọc log → phân tích → rút quy luật → tìm bất thường.
    
    Sử dụng regex + heuristic rule-based, không dùng AI.
    """
    
    def __init__(self, logs_dir: str = "logs"):
        self.logs_dir = logs_dir
        self.system_log_path = os.path.join(logs_dir, "system.log")
        self.memory_logs_dir = os.path.join(logs_dir, "memory")
        
        os.makedirs(self.memory_logs_dir, exist_ok=True)
        
        self.log_lines: List[str] = []
        self.patterns: Dict[str, int] = {}
        self.anomalies: List[Dict[str, Any]] = []
        self.error_counts: Counter = Counter()
        self.warning_counts: Counter = Counter()
    
    def read_logs(self) -> List[str]:
        """
        Đọc logs/system.log.
        
        Returns:
            Danh sách các dòng log
        """
        if not os.path.exists(self.system_log_path):
            logger.warning(f"Log file not found: {self.system_log_path}")
            return []
        
        try:
            with open(self.system_log_path, 'r') as f:
                self.log_lines = f.readlines()
            
            logger.info(f"Read {len(self.log_lines)} log lines")
            return self.log_lines
        
        except Exception as e:
            logger.error(f"Error reading logs: {str(e)}")
            return []
    
    def detect_patterns(self) -> Dict[str, Any]:
        """
        Dùng regex + heuristic để tìm:
        - Hành vi lặp lại
        - Lỗi thường gặp
        - Xu hướng tốt/xấu
        
        Returns:
            Dictionary chứa pattern analysis
        """
        if not self.log_lines:
            self.read_logs()
        
        error_pattern = re.compile(r'ERROR|Error|error|CRITICAL|Critical')
        warning_pattern = re.compile(r'WARNING|Warning|warning|WARN')
        success_pattern = re.compile(r'success|completed|SUCCESS|Completed')
        cycle_pattern = re.compile(r'Cycle (\d+)')
        
        errors = []
        warnings = []
        successes = []
        cycles = []
        
        for line in self.log_lines:
            if error_pattern.search(line):
                errors.append(line)
                error_msg = self._extract_error_message(line)
                if error_msg:
                    self.error_counts[error_msg] += 1
            
            if warning_pattern.search(line):
                warnings.append(line)
                warning_msg = self._extract_warning_message(line)
                if warning_msg:
                    self.warning_counts[warning_msg] += 1
            
            if success_pattern.search(line):
                successes.append(line)
            
            cycle_match = cycle_pattern.search(line)
            if cycle_match:
                cycles.append(int(cycle_match.group(1)))
        
        repeated_errors = [err for err, count in self.error_counts.items() if count > 3]
        repeated_warnings = [warn for warn, count in self.warning_counts.items() if count > 5]
        
        trend = "improving" if len(successes) > len(errors) else "declining"
        if len(errors) == 0 and len(warnings) == 0:
            trend = "stable"
        
        pattern_summary = {
            "total_lines": len(self.log_lines),
            "error_count": len(errors),
            "warning_count": len(warnings),
            "success_count": len(successes),
            "cycles_detected": len(cycles),
            "repeated_errors": repeated_errors,
            "repeated_warnings": repeated_warnings,
            "trend": trend,
            "most_common_error": self.error_counts.most_common(1)[0] if self.error_counts else None,
            "most_common_warning": self.warning_counts.most_common(1)[0] if self.warning_counts else None
        }
        
        logger.info(f"Pattern detection complete: {pattern_summary['trend']} trend")
        
        return pattern_summary
    
    def detect_anomalies(self) -> Tuple[List[Dict[str, Any]], float]:
        """
        Tính anomaly_score (0-100) dựa trên:
        - Tần suất lỗi bất thường
        - Hành vi khác thường
        - Thay đổi đột ngột
        
        Returns:
            Tuple của (danh sách anomalies, anomaly_score)
        """
        if not self.log_lines:
            self.read_logs()
        
        self.anomalies = []
        anomaly_score = 0.0
        
        patterns = self.detect_patterns()
        
        if patterns['error_count'] > 10:
            self.anomalies.append({
                "type": "high_error_rate",
                "severity": "high",
                "description": f"Phát hiện {patterns['error_count']} lỗi",
                "score_impact": 30
            })
            anomaly_score += 30
        
        if patterns['repeated_errors']:
            self.anomalies.append({
                "type": "repeated_errors",
                "severity": "medium",
                "description": f"Lỗi lặp lại: {patterns['repeated_errors'][:3]}",
                "score_impact": 20
            })
            anomaly_score += 20
        
        if patterns['warning_count'] > 20:
            self.anomalies.append({
                "type": "excessive_warnings",
                "severity": "medium",
                "description": f"Quá nhiều cảnh báo: {patterns['warning_count']}",
                "score_impact": 15
            })
            anomaly_score += 15
        
        if patterns['trend'] == "declining":
            self.anomalies.append({
                "type": "declining_trend",
                "severity": "medium",
                "description": "Xu hướng giảm sút: lỗi > thành công",
                "score_impact": 25
            })
            anomaly_score += 25
        
        error_rate = patterns['error_count'] / max(patterns['total_lines'], 1) * 100
        if error_rate > 10:
            self.anomalies.append({
                "type": "high_error_percentage",
                "severity": "high",
                "description": f"Tỷ lệ lỗi cao: {error_rate:.1f}%",
                "score_impact": 20
            })
            anomaly_score += 20
        
        anomaly_score = min(100, anomaly_score)
        
        logger.info(f"Anomaly detection complete: score={anomaly_score}, found={len(self.anomalies)}")
        
        return self.anomalies, anomaly_score
    
    def summarize_day(self) -> str:
        """
        Tạo text: "Bài học rút ra hôm nay: ..."
        
        Returns:
            Chuỗi tóm tắt bài học
        """
        if not self.log_lines:
            self.read_logs()
        
        patterns = self.detect_patterns()
        anomalies, score = self.detect_anomalies()
        
        summary = "Bài học rút ra hôm nay:\n"
        
        if patterns['trend'] == "stable" and patterns['error_count'] == 0:
            summary += "- Hệ thống hoạt động ổn định, không có lỗi nghiêm trọng.\n"
        elif patterns['trend'] == "improving":
            summary += "- Hệ thống đang cải thiện, tỷ lệ thành công tăng.\n"
        else:
            summary += "- Hệ thống cần chú ý, xu hướng đang giảm sút.\n"
        
        if patterns['repeated_errors']:
            summary += f"- Phát hiện lỗi lặp lại: {patterns['repeated_errors'][0][:50]}... (cần xử lý).\n"
        
        if score > 50:
            summary += f"- Mức độ bất thường cao ({score:.0f}/100), cần điều tra ngay.\n"
        elif score > 20:
            summary += f"- Có một số bất thường nhỏ ({score:.0f}/100), nên kiểm tra.\n"
        
        if patterns['cycles_detected'] > 0:
            summary += f"- Đã hoàn thành {patterns['cycles_detected']} chu kỳ.\n"
        
        if patterns['success_count'] > 0:
            summary += f"- Ghi nhận {patterns['success_count']} thao tác thành công.\n"
        
        return summary.strip()
    
    def extract_questions(self) -> List[str]:
        """
        Tự đặt câu hỏi dựa trên bất thường:
        "Tại sao tần suất lỗi X tăng?"
        
        Returns:
            Danh sách câu hỏi
        """
        if not self.anomalies:
            self.detect_anomalies()
        
        questions = []
        
        patterns = self.detect_patterns()
        
        if patterns['error_count'] > 5:
            questions.append(f"Tại sao có {patterns['error_count']} lỗi trong log gần đây?")
        
        if patterns['repeated_errors']:
            for error in patterns['repeated_errors'][:2]:
                questions.append(f"Tại sao lỗi '{error[:50]}...' lặp lại nhiều lần?")
        
        if patterns['trend'] == "declining":
            questions.append("Tại sao xu hướng hệ thống đang giảm sút?")
        
        for anomaly in self.anomalies[:3]:
            if anomaly['severity'] == 'high':
                questions.append(f"Làm thế nào để khắc phục: {anomaly['description']}?")
        
        if patterns['warning_count'] > 10:
            questions.append(f"Cảnh báo nào đang xuất hiện thường xuyên nhất?")
        
        if not questions:
            questions.append("Hệ thống có hoạt động tối ưu không?")
        
        logger.info(f"Generated {len(questions)} questions")
        
        return questions
    
    def return_analysis(self) -> Dict[str, Any]:
        """
        Trả về object chứa:
        - pattern_summary
        - anomalies
        - suggested_questions
        
        Returns:
            Dictionary chứa toàn bộ phân tích
        """
        pattern_summary = self.detect_patterns()
        anomalies, anomaly_score = self.detect_anomalies()
        suggested_questions = self.extract_questions()
        day_summary = self.summarize_day()
        
        analysis = {
            "timestamp": datetime.now().isoformat(),
            "pattern_summary": pattern_summary,
            "anomalies": anomalies,
            "anomaly_score": anomaly_score,
            "suggested_questions": suggested_questions,
            "day_summary": day_summary,
            "total_anomalies": len(anomalies),
            "severity_breakdown": {
                "high": sum(1 for a in anomalies if a['severity'] == 'high'),
                "medium": sum(1 for a in anomalies if a['severity'] == 'medium'),
                "low": sum(1 for a in anomalies if a['severity'] == 'low')
            }
        }
        
        logger.info("Full analysis complete")
        
        return analysis
    
    def save_analysis(self, analysis: Dict[str, Any], filename: Optional[str] = None):
        """
        Lưu phân tích vào file JSON.
        
        Args:
            analysis: Kết quả phân tích
            filename: Tên file (auto-generate nếu None)
        """
        if filename is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"analysis_{timestamp}.json"
        
        filepath = os.path.join(self.memory_logs_dir, filename)
        
        with open(filepath, 'w') as f:
            json.dump(analysis, f, indent=2)
        
        logger.info(f"Analysis saved to {filepath}")
    
    def _extract_error_message(self, line: str) -> str:
        """Extract error message từ log line."""
        parts = line.split(' - ')
        if len(parts) >= 4:
            return parts[-1].strip()[:100]
        return line.strip()[:100]
    
    def _extract_warning_message(self, line: str) -> str:
        """Extract warning message từ log line."""
        parts = line.split(' - ')
        if len(parts) >= 4:
            return parts[-1].strip()[:100]
        return line.strip()[:100]
