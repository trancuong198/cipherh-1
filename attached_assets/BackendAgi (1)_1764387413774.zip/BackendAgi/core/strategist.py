from typing import Dict, Any, List, Optional
from datetime import datetime
import logging

logger = logging.getLogger(__name__)

class Strategist:
    """
    Hệ thống tự đề xuất hướng đi, chính sách, mục tiêu mới.
    
    Logic heuristic:
    - Bất thường ↑ → tăng nghiêm ngặt
    - Xu hướng tốt → mở rộng mục tiêu
    """
    
    def __init__(self):
        self.long_term_goals: List[str] = []
        self.strategies: List[Dict[str, Any]] = []
        self.priorities: List[str] = []
        self.weekly_tasks: List[Dict[str, Any]] = []
        self.monthly_plan: Dict[str, Any] = {}
    
    def propose_weekly_tasks(self, state: Dict[str, Any], analysis_result: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Đề xuất tasks cho tuần dựa trên state và analysis.
        
        Args:
            state: SoulState exported data
            analysis_result: Kết quả phân tích từ LogAnalyzer
            
        Returns:
            Danh sách tasks được đề xuất
        """
        tasks = []
        
        anomaly_score = analysis_result.get('anomaly_score', 0)
        trend = analysis_result.get('pattern_summary', {}).get('trend', 'stable')
        doubts = state.get('doubts', 0)
        confidence = state.get('confidence', 75)
        
        if anomaly_score > 50:
            tasks.append({
                "task": "Điều tra và khắc phục bất thường nghiêm trọng",
                "priority": "critical",
                "reason": f"Anomaly score cao: {anomaly_score}",
                "estimated_time": "2-3 days",
                "suggested_actions": [
                    "Phân tích chi tiết logs",
                    "Xác định root cause",
                    "Implement fixes"
                ]
            })
        
        if trend == "declining":
            tasks.append({
                "task": "Cải thiện xu hướng hệ thống đang giảm sút",
                "priority": "high",
                "reason": "Trend declining phát hiện",
                "estimated_time": "3-4 days",
                "suggested_actions": [
                    "Review recent changes",
                    "Optimize performance",
                    "Strengthen error handling"
                ]
            })
        
        if doubts > 50:
            tasks.append({
                "task": "Xây dựng lại confidence và giảm doubts",
                "priority": "high",
                "reason": f"Doubts level cao: {doubts}",
                "estimated_time": "1-2 days",
                "suggested_actions": [
                    "Validate current assumptions",
                    "Run comprehensive tests",
                    "Review decision logic"
                ]
            })
        
        if trend == "improving" and confidence > 80:
            tasks.append({
                "task": "Mở rộng khả năng và thử nghiệm tính năng mới",
                "priority": "medium",
                "reason": "Hệ thống ổn định, có thể mở rộng",
                "estimated_time": "4-5 days",
                "suggested_actions": [
                    "Identify new opportunities",
                    "Prototype new features",
                    "Gradual rollout"
                ]
            })
        
        if len(state.get('goals_long_term', [])) == 0:
            tasks.append({
                "task": "Định nghĩa mục tiêu dài hạn",
                "priority": "high",
                "reason": "Chưa có long-term goals",
                "estimated_time": "1 day",
                "suggested_actions": [
                    "Analyze current capabilities",
                    "Set SMART goals",
                    "Create roadmap"
                ]
            })
        
        if not tasks:
            tasks.append({
                "task": "Duy trì và giám sát hệ thống",
                "priority": "low",
                "reason": "Hệ thống hoạt động ổn định",
                "estimated_time": "ongoing",
                "suggested_actions": [
                    "Monitor metrics",
                    "Regular health checks",
                    "Documentation updates"
                ]
            })
        
        self.weekly_tasks = tasks
        logger.info(f"Proposed {len(tasks)} weekly tasks")
        
        return tasks
    
    def propose_monthly_plan(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """
        Đề xuất kế hoạch tháng dựa trên state.
        
        Args:
            state: SoulState exported data
            
        Returns:
            Monthly plan dictionary
        """
        confidence = state.get('confidence', 75)
        doubts = state.get('doubts', 0)
        goals = state.get('goals_long_term', [])
        lessons_count = len(state.get('lessons_learned', []))
        
        plan = {
            "month": datetime.now().strftime("%Y-%m"),
            "created_at": datetime.now().isoformat(),
            "focus_areas": [],
            "milestones": [],
            "risk_mitigation": [],
            "growth_targets": {}
        }
        
        if doubts > 30:
            plan['focus_areas'].append({
                "area": "Stability & Trust Building",
                "objective": "Giảm doubts xuống dưới 20",
                "approach": "Strengthen validation and testing"
            })
            plan['risk_mitigation'].append("Implement additional safeguards against anomalies")
        
        if confidence < 70:
            plan['focus_areas'].append({
                "area": "Confidence Enhancement",
                "objective": "Tăng confidence lên trên 80",
                "approach": "Improve success rate and reduce errors"
            })
        
        if confidence >= 80 and doubts < 20:
            plan['focus_areas'].append({
                "area": "Capability Expansion",
                "objective": "Mở rộng khả năng và học hỏi mới",
                "approach": "Experiment with new strategies and techniques"
            })
            plan['growth_targets']['new_skills'] = 2
            plan['growth_targets']['new_features'] = 3
        
        if goals:
            for i, goal in enumerate(goals[:3], 1):
                plan['milestones'].append({
                    f"milestone_{i}": f"Progress on: {goal}",
                    "target_completion": "30%"
                })
        else:
            plan['milestones'].append({
                "milestone_1": "Define 3 long-term goals",
                "target_completion": "100%"
            })
        
        plan['milestones'].append({
            "milestone_lessons": f"Learn {max(5, lessons_count + 5)} new lessons",
            "target_completion": "80%"
        })
        
        self.monthly_plan = plan
        logger.info(f"Proposed monthly plan with {len(plan['focus_areas'])} focus areas")
        
        return plan
    
    def align_with_goals(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """
        Kiểm tra alignment giữa current state và goals.
        
        Args:
            state: SoulState exported data
            
        Returns:
            Alignment analysis
        """
        goals = state.get('goals_long_term', [])
        current_focus = state.get('current_focus')
        actions = state.get('last_actions', [])
        
        alignment = {
            "timestamp": datetime.now().isoformat(),
            "is_aligned": False,
            "alignment_score": 0,
            "gaps": [],
            "recommendations": []
        }
        
        if not goals:
            alignment['gaps'].append("No long-term goals defined")
            alignment['recommendations'].append("Define at least 3 long-term goals")
            alignment['alignment_score'] = 0
            return alignment
        
        if not current_focus:
            alignment['gaps'].append("No current focus set")
            alignment['recommendations'].append(f"Set focus to one of: {goals[0]}")
            alignment['alignment_score'] = 30
        elif current_focus in goals:
            alignment['alignment_score'] += 40
        
        if actions:
            recent_actions_aligned = any(
                goal.lower() in str(action).lower() 
                for action in actions[-5:] 
                for goal in goals
            )
            if recent_actions_aligned:
                alignment['alignment_score'] += 30
            else:
                alignment['gaps'].append("Recent actions not aligned with goals")
                alignment['recommendations'].append("Refocus actions towards current goals")
        
        if len(goals) > 5:
            alignment['gaps'].append("Too many goals, may lose focus")
            alignment['recommendations'].append("Prioritize top 3 goals")
        
        alignment['is_aligned'] = alignment['alignment_score'] >= 70
        
        logger.info(f"Goal alignment score: {alignment['alignment_score']}")
        
        return alignment
    
    def generate_strategy_prompt(self, state: Dict[str, Any], analysis: Dict[str, Any]) -> str:
        """
        Tạo prompt để gọi OpenAI (không gọi, chỉ tạo prompt).
        
        Args:
            state: SoulState exported data
            analysis: LogAnalyzer results
            
        Returns:
            Prompt string cho OpenAI
        """
        anomaly_score = analysis.get('anomaly_score', 0)
        trend = analysis.get('pattern_summary', {}).get('trend', 'stable')
        questions = analysis.get('suggested_questions', [])
        day_summary = analysis.get('day_summary', '')
        
        doubts = state.get('doubts', 0)
        confidence = state.get('confidence', 75)
        goals = state.get('goals_long_term', [])
        current_focus = state.get('current_focus', 'none')
        reflection = state.get('reflection', '')
        
        prompt = f"""Bạn là strategist AI cho hệ thống tự trị.

**Current State:**
- Doubts: {doubts}/100
- Confidence: {confidence}/100
- Current Focus: {current_focus}
- Long-term Goals: {', '.join(goals) if goals else 'chưa định nghĩa'}

**Recent Analysis:**
- Anomaly Score: {anomaly_score}/100
- Trend: {trend}
- Summary: {day_summary}

**Self-Reflection:**
{reflection}

**Pending Questions:**
{chr(10).join(f'- {q}' for q in questions[:5])}

**Your Task:**
1. Đánh giá tình trạng hiện tại (tốt/xấu/trung bình)
2. Đề xuất 3-5 hành động cụ thể cho tuần tới
3. Đề xuất điều chỉnh mục tiêu (nếu cần)
4. Trả lời các câu hỏi pending (nếu có đủ context)

**Strategic Logic:**
- Nếu anomaly_score > 50: Tập trung vào stability và investigation
- Nếu trend = declining: Tăng cường quality control và testing
- Nếu doubts > 50: Xây dựng lại trust thông qua validation
- Nếu trend = improving và confidence > 80: Mở rộng capabilities

Hãy trả lời dưới dạng JSON:
{{
  "assessment": "...",
  "weekly_actions": ["...", "..."],
  "goal_adjustments": ["...", "..."],
  "answers_to_questions": {{"question": "answer", ...}}
}}"""
        
        logger.info("Generated strategy prompt")
        
        return prompt
    
    def integrate_openai_response(self, response: Dict[str, Any]) -> Dict[str, Any]:
        """
        Cập nhật state từ OpenAI response (giả sử đã parse JSON).
        
        Args:
            response: Parsed JSON từ OpenAI
            
        Returns:
            Integration result
        """
        integration = {
            "timestamp": datetime.now().isoformat(),
            "actions_integrated": [],
            "goals_updated": [],
            "insights_captured": []
        }
        
        if 'weekly_actions' in response:
            for action in response['weekly_actions']:
                self.strategies.append({
                    "type": "weekly_action",
                    "content": action,
                    "source": "openai_strategist",
                    "created_at": datetime.now().isoformat(),
                    "status": "pending"
                })
                integration['actions_integrated'].append(action)
        
        if 'goal_adjustments' in response:
            for adjustment in response['goal_adjustments']:
                integration['goals_updated'].append(adjustment)
        
        if 'assessment' in response:
            integration['insights_captured'].append({
                "type": "assessment",
                "content": response['assessment']
            })
        
        if 'answers_to_questions' in response:
            for question, answer in response['answers_to_questions'].items():
                integration['insights_captured'].append({
                    "type": "question_answer",
                    "question": question,
                    "answer": answer
                })
        
        logger.info(f"Integrated OpenAI response: {len(integration['actions_integrated'])} actions")
        
        return integration
    
    def set_long_term_goals(self, goals: List[str]):
        """Set long-term goals."""
        logger.info(f"Setting long-term goals: {goals}")
        self.long_term_goals = goals
    
    def add_goal(self, goal: str):
        """Add một goal."""
        if goal not in self.long_term_goals:
            self.long_term_goals.append(goal)
            logger.info(f"Added goal: {goal}")
    
    def create_strategy(self, goal: str) -> Dict[str, Any]:
        """Tạo strategy cho một goal."""
        logger.info(f"Creating strategy for goal: {goal}")
        
        strategy = {
            "goal": goal,
            "created_at": datetime.now().isoformat(),
            "steps": [],
            "status": "pending",
            "priority": "medium"
        }
        
        self.strategies.append(strategy)
        
        return strategy
    
    def evaluate_progress(self) -> Dict[str, Any]:
        """Đánh giá progress."""
        logger.info("Evaluating progress on strategies...")
        
        evaluation = {
            "timestamp": datetime.now().isoformat(),
            "total_goals": len(self.long_term_goals),
            "total_strategies": len(self.strategies),
            "completed": sum(1 for s in self.strategies if s.get('status') == 'completed'),
            "in_progress": sum(1 for s in self.strategies if s.get('status') == 'in_progress'),
            "pending": sum(1 for s in self.strategies if s.get('status') == 'pending')
        }
        
        return evaluation
    
    def prioritize(self, analysis: Dict[str, Any]) -> List[str]:
        """Prioritize goals dựa trên analysis."""
        logger.info("Prioritizing goals based on analysis...")
        
        self.priorities = self.long_term_goals.copy()
        
        return self.priorities
    
    def get_next_action(self) -> Dict[str, Any]:
        """Determine next action."""
        logger.info("Determining next action...")
        
        if not self.strategies:
            return {"action": "idle", "reason": "no_strategies"}
        
        next_action = {
            "action": "continue",
            "strategy": self.strategies[0] if self.strategies else None,
            "timestamp": datetime.now().isoformat()
        }
        
        return next_action
