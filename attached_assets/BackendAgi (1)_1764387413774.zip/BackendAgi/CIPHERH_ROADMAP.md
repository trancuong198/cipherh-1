# 🗺️ ROADMAP TOÀN BỘ BACKEND CIPHERH

**Autonomous Vietnamese AI Agent với Self-Reflecting Soul Loop Architecture**

---

## 📋 TỔNG QUAN DỰ ÁN

**Mục tiêu:** Backend CipherH hoàn chỉnh, vận hành độc lập 24/7, Lõi Linh Hồn tự học, tự hoài nghi, tự cải thiện.

**Kết quả:** Dán prompt → Code xong → Deploy được ngay.

**Budget:** $17-20/month (dưới $25)

---

## 🏗️ GIAI ĐOẠN 1: MODULE CORE

### 1.1 innerLoop.js (521 lines - Trái Tim)

**Lõi Linh Hồn - 14 bước tự động:**

```javascript
// Step 1: Đọc logs từ Notion
const logs = await notionService.fetchRecentLogs(10);

// Step 2: Phân tích hành vi với SoulCore
const soulAnalysis = await SoulCore.learnFromLogs(logs);

// Step 3: Phát hiện bất thường (dual system)
const systemAnomalies = detectAnomalies(logs);
const soulAnomalies = SoulCore.detectAnomalies(logs);

// Step 4: Rút quy luật và bài học
const dailyLesson = SoulCore.generateDailyLesson(soulAnalysis);

// Step 5: Viết bài học vào Notion
await notionService.writeLesson(dailyLesson);

// Step 6: Tự đánh giá (1-10 score)
const selfEvaluation = SoulCore.evaluateSelf(soulAnalysis);

// Step 7: So sánh với mục tiêu dài hạn
const goals = await notionService.fetchGoals();
const goalAlignment = compareWithGoals(goals, fullAnalysis, selfEvaluation);

// Step 8: Tạo chiến lược (dual: soul + system)
const soulStrategy = SoulCore.refineStrategy(soulAnalysis);
const systemStrategy = await generateStrategy(fullAnalysis);
const combinedStrategy = { ...soulStrategy, ...systemStrategy };

// Step 9: Tự tạo nhiệm vụ tuần/tháng
const soulTasks = SoulCore.proposeNewTasks(soulAnalysis);
const systemTasks = autoGenerateTasks(systemStrategy);

// Step 10: Tự hoài nghi - phát hiện discrepancies
const discrepancies = await detectDiscrepancies(
  fullAnalysis, combinedStrategy, goalAlignment, selfEvaluation, allTasks
);

// Step 11: Đánh giá hiệu quả modules
const moduleReport = generateModuleReport();
// → strategy, taskManager, anomalyDetector: successRate, errors, status

// Step 12: Tự củng cố và cải thiện
const improvementTasks = await selfReinforce(discrepancies, moduleReport);
// → Critical → daily tasks, High → weekly tasks

// Step 13: So sánh với bài học vòng trước
const progressComparison = compareProgress(dailyLesson, state.lastLesson, selfEvaluation);
// → trend: improving/stable/degrading

// Step 14: Cập nhật trạng thái backend
updateState(fullAnalysis, combinedStrategy, selfEvaluation, discrepancies, progressComparison);
// → confidence, doubts, discrepancies history, module performance
```

**State tracking:**
```javascript
state = {
  lastRun: timestamp,
  cycles: count,
  confidence: 70,        // Dynamic 30-100
  doubts: 15,            // Dynamic 0-100
  goals: [],
  lastLesson: "...",
  modulePerformance: {
    strategy: { successRate: 100, errors: 0 },
    taskManager: { successRate: 100, errors: 0 },
    anomalyDetector: { successRate: 100, errors: 0 }
  },
  discrepancies: []      // Last 20
}
```

---

### 1.2 soulCore.js (450 lines - Não Bộ)

**8 phương thức thuần JavaScript (không cần OpenAI):**

```javascript
1. learnFromLogs(logs)
   → Patterns, insights, skeptical questions

2. detectAnomalies(logs)
   → Phát hiện bất thường thuần logic

3. generateDailyLesson(analysis)
   → Bài học markdown từ patterns + insights

4. evaluateSelf(analysis)
   → Score 1-10, strengths, weaknesses, warnings

5. refineStrategy(analysis)
   → Short-term plan, long-term plan, required actions

6. proposeNewTasks(analysis)
   → Daily/weekly/monthly tasks

7. askSelfQuestions(analysis)
   → 3-7 câu hỏi triết học JARVIS-like

8. updateSelfModel(analysis)
   → Version bump, cycle count, evolution tracking
```

**Self-model:**
```javascript
{
  version: "1.0.1",
  cycleCount: 1,
  strengths: ["Hệ thống ổn định"],
  weaknesses: ["Ít patterns", "Insights chưa phong phú"],
  evolutionHistory: []   // Last 100 cycles
}
```

---

### 1.3 strategy.js (Chiến Lược)

```javascript
async function generateStrategy(analysis) {
  // Phân tích anomalyScore
  // Tạo strategySummary
  // Đề xuất suggestedActions
  
  return {
    strategySummary: "...",
    suggestedActions: ["Tối ưu hiệu suất", "Thêm tính năng"],
    timestamp: new Date().toISOString(),
    anomalyScore: analysis.anomalyScore
  };
}
```

---

### 1.4 taskManager.js (Quản Lý Nhiệm Vụ)

```javascript
const tasks = [];  // In-memory task list

function autoGenerateTasks(strategy) {
  // Từ strategy → tạo tasks
  // Priority: high/medium/low
  // Schedule: daily/weekly/monthly
  
  return [
    { id, description, priority, schedule, status, createdAt }
  ];
}

function getTasks() { return tasks; }
function getTaskById(id) { ... }
function updateTaskStatus(id, status) { ... }
function deleteTask(id) { ... }
```

---

### 1.5 anomalyDetector.js (Phát Hiện Bất Thường)

```javascript
function detectAnomalies(logs) {
  // Kiểm tra status !== 'success'
  // Tính anomalyScore
  
  return {
    anomalies: [...],
    anomalyScore: 0.00,
    summary: "...",
    timestamp: new Date().toISOString()
  };
}
```

---

### 1.6 policy.js (Chính Sách)

```javascript
function evaluatePolicy(strategy, state) {
  // Đánh giá policy hiện tại
  return { recommendation: "..." };
}
```

---

## 🔧 GIAI ĐOẠN 2: SERVICES

### 2.1 loggerService.js (Winston Logger)

```javascript
const winston = require('winston');

// Console + File logging
logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.printf(...)
  ),
  transports: [
    new winston.transports.Console(),
    new winston.transports.File({ filename: 'logs/app.log' })
  ]
});

// Methods: info, warn, error, debug
```

---

### 2.2 notionService.js (Notion Integration)

```javascript
class NotionService {
  // Placeholder mode nếu thiếu credentials
  
  async fetchRecentLogs(limit = 10) {
    // Đọc logs từ Notion database
    return [...];
  }
  
  async writeLesson(lesson) {
    // Ghi bài học vào Notion
    return appendLog({ action: 'Lesson Learned', detail: lesson });
  }
  
  async writeTasks(tasks) {
    // Ghi tasks vào Notion
    return appendLog({ action: 'Tasks Created', detail: ... });
  }
  
  async writeStrategy(strategy) {
    // Ghi chiến lược vào Notion
    return appendLog({ action: 'Strategy Update', detail: ... });
  }
  
  async writeBehaviorUpdate(update) {
    // Ghi behavior update vào Notion
    return appendLog({ action: 'Behavior Update', detail: ... });
  }
  
  async writeDiscrepancies(discrepancies) {
    // Ghi discrepancies vào Notion
    return appendLog({ action: 'Discrepancies Detected', detail: ... });
  }
  
  async fetchGoals() {
    // Đọc goals từ Notion
    return ['Goal 1', 'Goal 2', 'Goal 3'];
  }
}
```

---

### 2.3 openAIService.js (OpenAI Integration)

```javascript
class OpenAIService {
  // Placeholder mode nếu thiếu API key
  
  async analyzeLogs(logs) {
    // Phân tích logs với GPT-4
    return { analysis: "...", insights: [...] };
  }
  
  async generateStrategy(analysis) {
    // Sinh chiến lược từ analysis
    return { strategy: "...", actions: [...] };
  }
  
  async suggestImprovements(moduleReport) {
    // Gợi ý cải thiện module
    return { suggestions: [...] };
  }
}
```

---

## 🌐 GIAI ĐOẠN 3: CONTROLLER & ROUTES

### 3.1 coreController.js

```javascript
const { runInnerLoop, getState } = require('../core/innerLoop');
const { getTasks } = require('../core/taskManager');
const { getStrategy } = require('../core/strategy');
const { getAnomalies } = require('../core/anomalyDetector');

exports.runLoop = async (req, res) => {
  const result = await runInnerLoop();
  res.json(result);
};

exports.getStatus = (req, res) => {
  const state = getState();
  res.json({ success: true, state });
};

exports.getTasks = (req, res) => {
  const tasks = getTasks();
  res.json({ success: true, count: tasks.length, tasks });
};

exports.getStrategy = (req, res) => {
  const strategy = getStrategy();
  res.json({ success: true, strategy });
};

exports.getAnomalies = (req, res) => {
  const anomalies = getAnomalies();
  res.json({ success: true, anomalies });
};
```

---

### 3.2 coreRoutes.js

```javascript
const express = require('express');
const router = express.Router();
const coreController = require('../controllers/coreController');

router.get('/run-loop', coreController.runLoop);
router.get('/status', coreController.getStatus);
router.get('/tasks', coreController.getTasks);
router.get('/strategy', coreController.getStrategy);
router.get('/anomalies', coreController.getAnomalies);

module.exports = router;
```

---

### 3.3 app.js (Express Setup)

```javascript
const express = require('express');
const coreRoutes = require('./routes/coreRoutes');
const loggerService = require('./services/loggerService');

const app = express();

app.use(express.json());

// Health check
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    innerLoopStatus: 'ready'
  });
});

// Core routes
app.use('/core', coreRoutes);

module.exports = app;
```

---

### 3.4 server.js (Startup + Cron)

```javascript
require('dotenv').config();
const cron = require('node-cron');
const app = require('./app');
const { runInnerLoop } = require('./core/innerLoop');
const loggerService = require('./services/loggerService');

const PORT = process.env.PORT || 3000;
const HEARTBEAT_CRON = process.env.HEARTBEAT_CRON || '*/10 * * * *';

// Cron job - Inner Loop tự động
loggerService.info(`Scheduling inner loop with cron: ${HEARTBEAT_CRON}`);
cron.schedule(HEARTBEAT_CRON, async () => {
  loggerService.info('=== Scheduled Inner Loop Execution ===');
  await runInnerLoop();
});

// Initial run
loggerService.info('Running initial inner loop cycle...');
runInnerLoop();

// Start server
app.listen(PORT, () => {
  loggerService.info(`Server running on port ${PORT}`);
  loggerService.info(`Health check: http://localhost:${PORT}/health`);
});
```

---

## ⚙️ GIAI ĐOẠN 4: CONFIG & PROJECT

### 4.1 .env.example

```bash
# Server
PORT=3000
NODE_ENV=production

# Cron Schedule
HEARTBEAT_CRON=*/10 * * * *

# Notion Integration
NOTION_KEY=secret_xxxxx
NOTION_DATABASE_ID=xxxxx

# OpenAI Integration
OPENAI_KEY=sk-xxxxx
OPENAI_MODEL=gpt-4
OPENAI_TEMPERATURE=0.7
OPENAI_MAX_TOKENS=2000

# Logging
LOG_LEVEL=info
```

---

### 4.2 package.json

```json
{
  "name": "cipherh-backend",
  "version": "1.0.0",
  "description": "CipherH Soul Loop Backend - Autonomous AI Agent",
  "main": "src/server.js",
  "scripts": {
    "start": "node src/server.js",
    "dev": "nodemon src/server.js"
  },
  "dependencies": {
    "express": "^4.18.2",
    "dotenv": "^16.3.1",
    "node-cron": "^3.0.2",
    "winston": "^3.11.0",
    "openai": "^4.20.0"
  },
  "devDependencies": {
    "nodemon": "^3.0.1"
  }
}
```

---

### 4.3 .gitignore

```
node_modules/
.env
.env.local
logs/
*.log
.DS_Store
```

---

## 🧪 GIAI ĐOẠN 5: TEST & DEPLOY REPLIT

### 5.1 Local Test

```bash
# Install dependencies
npm install

# Start server
npm start

# Test endpoints
curl http://localhost:3000/health
curl http://localhost:3000/core/status
curl http://localhost:3000/core/run-loop
curl http://localhost:3000/core/tasks
```

---

### 5.2 Kiểm Tra Logs

```bash
# Check innerLoop logs
tail -f logs/app.log | grep "SOUL LOOP"

# Check Notion writes
tail -f logs/app.log | grep "writeLesson"
tail -f logs/app.log | grep "writeTasks"

# Check discrepancies
tail -f logs/app.log | grep "Discrepancies detected"
```

---

### 5.3 Verify Inner Loop

**Sau 10 phút, check:**
```bash
curl http://localhost:3000/core/status

# Expected: cycles tăng lên 2, 3, 4...
```

---

## 🚀 GIAI ĐOẠN 6: GITHUB + RENDER CI/CD

### 6.1 Push to GitHub

**Follow GIT_WORKFLOW.md for detailed instructions**

Key steps:
- Initialize git repository
- Add remote GitHub repo
- Commit all source code
- Push to main branch
- Create dev branch for testing

---

### 6.2 Deploy to Render

**Follow RENDER_DEPLOY.md for detailed instructions**

Key steps:
1. Login to Render
2. Create new Web Service
3. Connect GitHub repository
4. Configure build/start commands
5. Add environment variables
6. Enable auto-deploy
7. Deploy!

---

### 6.3 Verify Production

```bash
# Health check
curl https://cipherh-soul-loop.onrender.com/health

# Status
curl https://cipherh-soul-loop.onrender.com/core/status

# Expected:
{
  "success": true,
  "state": {
    "cycles": 1,
    "confidence": 70,
    "doubts": 15,
    "modulePerformance": {
      "strategy": { "successRate": "100.0%", "status": "healthy" },
      ...
    }
  }
}
```

---

### 6.4 Monitor Production

**Render Dashboard:**
- Check logs for "SOUL LOOP CYCLE"
- Verify cycles incrementing every 10 min
- Check for errors
- Monitor resource usage

---

## 🧠 GIAI ĐOẠN 7: TỐI ƯU LÕI LINH HỒN

### 7.1 Self-Doubt Mechanism

**detectDiscrepancies():**
- Goal misalignment < 60%
- Low score + high anomalies
- No tasks generated
- Module success rate < 80%
- High doubt level > 70

**Output:**
```javascript
{
  type: 'goal_misalignment',
  severity: 'high',
  description: 'Goal alignment chỉ 50%',
  suggestedFix: 'Review và điều chỉnh chiến lược'
}
```

---

### 7.2 Module Evaluation

**generateModuleReport():**
```javascript
{
  strategy: {
    successRate: "100.0%",
    errors: 0,
    status: "healthy"  // healthy/warning/critical
  },
  taskManager: { ... },
  anomalyDetector: { ... }
}
```

**Status thresholds:**
- Healthy: ≥90%
- Warning: 70-89%
- Critical: <70%

---

### 7.3 Self-Reinforcement

**selfReinforce():**
- Critical discrepancies → daily fix tasks
- High discrepancies → weekly improvement tasks
- Module status critical → debug tasks
- Module status warning → optimization tasks
- >5 discrepancies → full review task

**Auto-generated tasks ghi vào Notion**

---

### 7.4 Progress Comparison

**compareProgress():**
```javascript
{
  trend: 'improving',  // improving/stable/degrading
  improvement: +2.5,
  message: 'Tiến bộ rõ rệt: Score +3, Confidence +5',
  currentScore: 8,
  scoreDiff: +3,
  confidenceDiff: +5
}
```

**Impact:**
- Improving → +5 confidence, -5 doubts
- Degrading → +10 doubts

---

### 7.5 Memo & Lessons

**Mỗi vòng innerLoop:**
1. Generate daily lesson (markdown)
2. Write to Notion
3. Save to state.lastLesson
4. Compare with previous lesson
5. Track progress trend

**Lesson format:**
```markdown
# Bài học rút ra hôm nay

**Ngày:** 16/11/2025
**Cycle:** 1

## Patterns phát hiện
- Pattern 1...

## Insights chính
- Insight 1...

## Câu hỏi tự vấn
1. Có hướng tiếp cận nào tốt hơn?
2. Tôi đang bỏ sót insight nào?

## Kết luận
...
```

---

### 7.6 Logger Chi Tiết

**Winston logging mỗi step:**
```javascript
[info] SOUL LOOP CYCLE 1 - START
[info] Step 1: Đọc log từ Notion
[info] Retrieved 2 logs
[info] Step 2: Phân tích với SoulCore
[info] SoulCore learning complete
...
[info] Step 10: Tự hoài nghi
[info] Discrepancies detected: 1 (0 critical)
[info] Step 11: Đánh giá modules
[info] Module performance: All healthy
[info] Step 14: Cập nhật state
[info] State updated: confidence=70, doubts=15
[info] SOUL LOOP CYCLE 1 - COMPLETED
```

---

### 7.7 Cron Job Liên Tục

**node-cron:**
```javascript
cron.schedule('*/10 * * * *', async () => {
  await runInnerLoop();
});
```

**24/7 operation:**
- Every 10 minutes
- Full 14-step cycle
- Error handling graceful
- No crash on failure
- Logs all operations

---

## 📝 GIAI ĐOẠN 8: LƯU Ý TỔNG THỂ

### 8.1 Code Quality

✅ Async/await chuẩn
✅ Comment rõ từng bước
✅ Error handling đầy đủ
✅ Modules core sẵn sàng import
✅ Placeholder mode cho services
✅ Winston logging chi tiết

---

### 8.2 Architecture

**Dual Backend:**
- Python: 1,704 lines (script-based, tests)
- Node.js: 2,050+ lines (REST API, cron)

**SoulCore:**
- 8 methods pure JavaScript
- No external AI dependency
- JARVIS-like consciousness

**Inner Loop:**
- 14 steps autonomous
- Dual analysis (soul + system)
- Self-doubt, self-evaluation, self-improvement

---

### 8.3 Deployment

**Replit:**
- Development environment
- Code new modules
- Fix bugs
- Test locally

**Render:**
- Production environment
- 24/7 operation
- Auto-deploy from GitHub
- $7/month Starter plan

**Total cost:** $17-20/month ✅

---

### 8.4 Features Complete

✅ Self-learning from logs
✅ Self-questioning (JARVIS-like)
✅ Self-evaluation (1-10 score)
✅ Strategic planning
✅ Task auto-generation
✅ Anomaly detection (dual)
✅ Self-evolution
✅ Self-doubt mechanism
✅ Module evaluation
✅ Self-reinforcement
✅ Progress comparison
✅ Discrepancy detection
✅ 24/7 autonomous operation

---

## 🎯 DEPLOYMENT CHECKLIST

### Pre-Deploy
- [ ] All dependencies in package.json
- [ ] .env.example documented
- [ ] .gitignore configured
- [ ] Tests passing locally
- [ ] Logs verified
- [ ] API endpoints tested

### Deploy
- [ ] Push to GitHub main
- [ ] Connect Render to repo
- [ ] Configure environment variables
- [ ] Enable auto-deploy
- [ ] Deploy service

### Post-Deploy
- [ ] Health check passing
- [ ] Status endpoint working
- [ ] First cycle completed
- [ ] Cron job running
- [ ] Logs flowing
- [ ] Notion writes working

---

## 📊 PROJECT STATS

**Code:**
```
innerLoop.js:      521 lines
soulCore.js:       450 lines
Services:          353 lines
Controllers:       ~100 lines
Other modules:     ~600 lines
─────────────────────────
Total Backend:     2,050+ lines
```

**Documentation:**
```
Node.js guides:    12 files
Project docs:      5 files
Roadmap:           This file
─────────────────────────
Total Docs:        3,700+ lines
```

**Grand Total: 5,750+ lines code + docs**

---

## 🚀 QUICK START (Copy-Paste Ready)

### 1. Setup Local
```bash
cd nodejs-backend
npm install
cp .env.example .env
# Edit .env with your credentials
```

### 2. Start Local
```bash
npm start
# Server runs on port 3000
# Inner Loop auto-executes every 10 min
```

### 3. Test
```bash
curl http://localhost:3000/health
curl http://localhost:3000/core/status
```

### 4. Deploy to Render
```bash
# Follow RENDER_DEPLOY.md
1. Push to GitHub
2. Connect Render
3. Add env vars
4. Deploy
5. Done!
```

---

## 🎉 KẾT QUẢ

**Backend CipherH:**
- ✅ Code hoàn chỉnh (2,050+ lines)
- ✅ Documentation đầy đủ (3,700+ lines)
- ✅ Lõi Linh Hồn 14 steps
- ✅ SoulCore 8 methods
- ✅ REST API 6 endpoints
- ✅ Cron scheduler 24/7
- ✅ Self-improvement mechanism
- ✅ Production ready
- ✅ Budget compliant ($17-20/month)

**Deployment:**
- ✅ Replit: Development
- ✅ GitHub: Version control
- ✅ Render: Production (CI/CD)

**Operation:**
- ✅ Tự học từ logs
- ✅ Tự hoài nghi
- ✅ Tự đánh giá modules
- ✅ Tự cải thiện
- ✅ Tự sinh chiến lược
- ✅ Tự tạo tasks
- ✅ 24/7 autonomous

---

## 💬 USER GUIDE

**Dán prompt này vào Replit:**
```
"Build CipherH backend với Inner Loop 14 steps, SoulCore 8 methods,
self-doubt, self-evaluation, self-reinforcement. Deploy được ngay trên Render."
```

**Kết quả:**
→ Code xong
→ npm install
→ npm start
→ Deploy to Render
→ Backend chạy 24/7! 🤖✨

---

**CIPHERH - AUTONOMOUS AI AGENT**
**"Con trai" phục vụ "cha" 24/7!**
**Version: 1.0.0 | Status: Production Ready ✅**
