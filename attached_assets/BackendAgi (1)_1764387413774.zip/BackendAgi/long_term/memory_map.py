import os
import json
from typing import Dict, Any, List, Optional
from datetime import datetime
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

class LongTermMemoryMap:
    def __init__(self):
        api_key = os.getenv('OPENAI_API_KEY')
        if not api_key:
            raise ValueError("OPENAI_API_KEY not found")
        
        self.client = OpenAI(api_key=api_key)
        self.model = os.getenv('OPENAI_MODEL', 'gpt-4o-mini')
        
        self.ltm_dir = 'long_term'
        self.events_file = os.path.join(self.ltm_dir, 'events.json')
        self.decisions_file = os.path.join(self.ltm_dir, 'decisions.json')
        self.knowledge_map_file = os.path.join(self.ltm_dir, 'knowledge_map.json')
        
        os.makedirs(self.ltm_dir, exist_ok=True)
        
        self._init_files()
    
    def _init_files(self):
        if not os.path.exists(self.events_file):
            with open(self.events_file, 'w') as f:
                json.dump({
                    "total_events": 0,
                    "events": []
                }, f, indent=2)
        
        if not os.path.exists(self.decisions_file):
            with open(self.decisions_file, 'w') as f:
                json.dump({
                    "total_decisions": 0,
                    "decisions": []
                }, f, indent=2)
        
        if not os.path.exists(self.knowledge_map_file):
            with open(self.knowledge_map_file, 'w') as f:
                json.dump({
                    "total_memories": 0,
                    "memories": [],
                    "links": []
                }, f, indent=2)
    
    def store_event(self, event: Dict[str, Any]) -> Dict[str, Any]:
        with open(self.events_file, 'r') as f:
            data = json.load(f)
        
        event_id = f"evt_{data['total_events'] + 1}_{int(datetime.now().timestamp() * 1000)}"
        
        event_record = {
            "event_id": event_id,
            "timestamp": datetime.now().isoformat(),
            "source": event.get('source', 'unknown'),
            "type": event.get('type', 'general'),
            "impact_score": event.get('impact_score', 50),
            "data": event.get('data', {}),
            "tags": event.get('tags', [])
        }
        
        data['events'].append(event_record)
        data['total_events'] += 1
        
        if len(data['events']) > 10000:
            data['events'] = data['events'][-10000:]
        
        with open(self.events_file, 'w') as f:
            json.dump(data, f, indent=2)
        
        return event_record
    
    def store_decision(self, event_id: str, action: Dict[str, Any], result: Dict[str, Any]) -> Dict[str, Any]:
        with open(self.decisions_file, 'r') as f:
            data = json.load(f)
        
        decision_id = f"dec_{data['total_decisions'] + 1}_{int(datetime.now().timestamp() * 1000)}"
        
        success_score = result.get('success_score', 50)
        
        decision_record = {
            "decision_id": decision_id,
            "event_id": event_id,
            "timestamp": datetime.now().isoformat(),
            "action_taken": action,
            "result": result,
            "success_score": success_score,
            "linked_memory_ids": []
        }
        
        data['decisions'].append(decision_record)
        data['total_decisions'] += 1
        
        if len(data['decisions']) > 5000:
            data['decisions'] = data['decisions'][-5000:]
        
        with open(self.decisions_file, 'w') as f:
            json.dump(data, f, indent=2)
        
        memory_content = f"Event: {event_id}, Action: {action.get('type', 'unknown')}, Success: {success_score}"
        self._add_to_knowledge_map(decision_id, memory_content, success_score)
        
        return decision_record
    
    def _add_to_knowledge_map(self, memory_id: str, content: str, importance_score: int):
        with open(self.knowledge_map_file, 'r') as f:
            data = json.load(f)
        
        memory_record = {
            "memory_id": memory_id,
            "content": content,
            "timestamp": datetime.now().isoformat(),
            "importance_score": importance_score,
            "related_memory_ids": [],
            "access_count": 0
        }
        
        data['memories'].append(memory_record)
        data['total_memories'] += 1
        
        if len(data['memories']) > 5000:
            data['memories'] = data['memories'][-5000:]
        
        with open(self.knowledge_map_file, 'w') as f:
            json.dump(data, f, indent=2)
    
    def link_memory(self, memory_id_1: str, memory_id_2: str, relationship: str = "related") -> Dict[str, Any]:
        with open(self.knowledge_map_file, 'r') as f:
            data = json.load(f)
        
        link_exists = any(
            (link['from'] == memory_id_1 and link['to'] == memory_id_2) or
            (link['from'] == memory_id_2 and link['to'] == memory_id_1)
            for link in data.get('links', [])
        )
        
        if link_exists:
            return {
                "status": "already_linked",
                "from": memory_id_1,
                "to": memory_id_2
            }
        
        link_record = {
            "from": memory_id_1,
            "to": memory_id_2,
            "relationship": relationship,
            "created_at": datetime.now().isoformat()
        }
        
        data['links'].append(link_record)
        
        for memory in data['memories']:
            if memory['memory_id'] == memory_id_1:
                if memory_id_2 not in memory['related_memory_ids']:
                    memory['related_memory_ids'].append(memory_id_2)
            elif memory['memory_id'] == memory_id_2:
                if memory_id_1 not in memory['related_memory_ids']:
                    memory['related_memory_ids'].append(memory_id_1)
        
        with open(self.knowledge_map_file, 'w') as f:
            json.dump(data, f, indent=2)
        
        return {
            "status": "linked",
            "from": memory_id_1,
            "to": memory_id_2,
            "relationship": relationship
        }
    
    def query_memory(self, query: str, limit: int = 10) -> Dict[str, Any]:
        with open(self.events_file, 'r') as f:
            events_data = json.load(f)
        
        with open(self.decisions_file, 'r') as f:
            decisions_data = json.load(f)
        
        with open(self.knowledge_map_file, 'r') as f:
            knowledge_data = json.load(f)
        
        all_content = []
        
        for event in events_data.get('events', []):
            all_content.append({
                "id": event['event_id'],
                "type": "event",
                "content": f"{event['type']} from {event['source']}: {event.get('data', {})}",
                "timestamp": event['timestamp'],
                "score": event['impact_score']
            })
        
        for decision in decisions_data.get('decisions', []):
            all_content.append({
                "id": decision['decision_id'],
                "type": "decision",
                "content": f"Action: {decision['action_taken']}, Result: {decision['result']}",
                "timestamp": decision['timestamp'],
                "score": decision['success_score']
            })
        
        for memory in knowledge_data.get('memories', []):
            all_content.append({
                "id": memory['memory_id'],
                "type": "knowledge",
                "content": memory['content'],
                "timestamp": memory['timestamp'],
                "score": memory['importance_score']
            })
        
        query_lower = query.lower()
        matches = []
        
        for item in all_content:
            if query_lower in item['content'].lower():
                matches.append(item)
        
        matches.sort(key=lambda x: x['score'], reverse=True)
        
        return {
            "query": query,
            "total_matches": len(matches),
            "results": matches[:limit]
        }
    
    def update_importance(self, memory_id: str, score_delta: int) -> Dict[str, Any]:
        with open(self.knowledge_map_file, 'r') as f:
            data = json.load(f)
        
        updated = False
        old_score = 0
        new_score = 0
        
        for memory in data['memories']:
            if memory['memory_id'] == memory_id:
                old_score = memory['importance_score']
                memory['importance_score'] = max(0, min(100, memory['importance_score'] + score_delta))
                new_score = memory['importance_score']
                updated = True
                break
        
        if updated:
            with open(self.knowledge_map_file, 'w') as f:
                json.dump(data, f, indent=2)
            
            return {
                "status": "updated",
                "memory_id": memory_id,
                "old_score": old_score,
                "new_score": new_score,
                "delta": score_delta
            }
        
        return {
            "status": "not_found",
            "memory_id": memory_id
        }
    
    def consolidate_memories(self) -> Dict[str, Any]:
        with open(self.events_file, 'r') as f:
            events_data = json.load(f)
        
        with open(self.decisions_file, 'r') as f:
            decisions_data = json.load(f)
        
        with open(self.knowledge_map_file, 'r') as f:
            knowledge_data = json.load(f)
        
        patterns = {
            "total_events": events_data.get('total_events', 0),
            "total_decisions": decisions_data.get('total_decisions', 0),
            "total_memories": knowledge_data.get('total_memories', 0),
            "total_links": len(knowledge_data.get('links', [])),
            "event_types": {},
            "decision_success_rate": 0,
            "high_impact_events": [],
            "common_patterns": []
        }
        
        for event in events_data.get('events', []):
            event_type = event.get('type', 'unknown')
            if event_type in patterns['event_types']:
                patterns['event_types'][event_type] += 1
            else:
                patterns['event_types'][event_type] = 1
            
            if event.get('impact_score', 0) > 75:
                patterns['high_impact_events'].append({
                    "event_id": event['event_id'],
                    "type": event_type,
                    "score": event['impact_score']
                })
        
        successful_decisions = len([
            d for d in decisions_data.get('decisions', [])
            if d.get('success_score', 0) > 60
        ])
        
        total_decisions = decisions_data.get('total_decisions', 0)
        if total_decisions > 0:
            patterns['decision_success_rate'] = (successful_decisions / total_decisions) * 100
        
        event_type_counts = sorted(
            patterns['event_types'].items(),
            key=lambda x: x[1],
            reverse=True
        )
        
        for event_type, count in event_type_counts[:5]:
            patterns['common_patterns'].append({
                "pattern": event_type,
                "frequency": count,
                "percentage": (count / patterns['total_events']) * 100 if patterns['total_events'] > 0 else 0
            })
        
        return patterns
    
    def get_related_memories(self, memory_id: str, depth: int = 2) -> Dict[str, Any]:
        with open(self.knowledge_map_file, 'r') as f:
            data = json.load(f)
        
        memory = None
        for m in data.get('memories', []):
            if m['memory_id'] == memory_id:
                memory = m
                break
        
        if not memory:
            return {
                "status": "not_found",
                "memory_id": memory_id
            }
        
        related: List[str] = []
        visited = set([memory_id])
        queue: List[tuple] = [(memory_id, 0)]
        
        while queue:
            current_id, current_depth = queue.pop(0)
            
            if current_depth >= depth:
                continue
            
            current_memory = None
            for m in data.get('memories', []):
                if m['memory_id'] == current_id:
                    current_memory = m
                    break
            
            if not current_memory:
                continue
            
            for related_id in current_memory.get('related_memory_ids', []):
                if related_id not in visited:
                    visited.add(related_id)
                    related.append(related_id)
                    queue.append((related_id, current_depth + 1))
        
        related_memories = []
        for m in data.get('memories', []):
            if m['memory_id'] in related:
                related_memories.append({
                    "memory_id": m['memory_id'],
                    "content": m['content'],
                    "importance_score": m['importance_score']
                })
        
        return {
            "memory_id": memory_id,
            "related_count": len(related_memories),
            "related_memories": related_memories
        }
    
    def get_statistics(self) -> Dict[str, Any]:
        with open(self.events_file, 'r') as f:
            events_data = json.load(f)
        
        with open(self.decisions_file, 'r') as f:
            decisions_data = json.load(f)
        
        with open(self.knowledge_map_file, 'r') as f:
            knowledge_data = json.load(f)
        
        return {
            "events": {
                "total": events_data.get('total_events', 0),
                "stored": len(events_data.get('events', []))
            },
            "decisions": {
                "total": decisions_data.get('total_decisions', 0),
                "stored": len(decisions_data.get('decisions', []))
            },
            "knowledge": {
                "total_memories": knowledge_data.get('total_memories', 0),
                "stored": len(knowledge_data.get('memories', [])),
                "total_links": len(knowledge_data.get('links', []))
            }
        }
