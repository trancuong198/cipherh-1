import os
from flask import Flask
from routes.main import main_bp, init_routes
from routes.admin import admin_bp
from routes.code_gen import code_gen_bp
from routes.template_api import template_api_bp
from routes.hacker_api import hacker_bp
from routes.evolution_api import evolution_bp
from routes.brain_api import brain_bp
from routes.memory_api import memory_bp
from routes.world_api import world_bp
from routes.emotion_api import emotion_bp
from routes.task_api import task_bp
from routes.defense_api import defense_bp
from routes.ltm_api import ltm_bp
from routes.personality_api import personality_bp
from routes.metacognition_api import metacog_bp
from routes.auto_evolution_api import auto_evo_bp
from routes.social_api import social_bp
from routes.hacker_security_api import hacker_security_bp
from routes.metacognition2_api import metacog2_bp
from routes.task_chain_api import task_chain_bp
from routes.realtime_api import realtime_bp
from routes.ltm_insight_api import ltm_insight_bp
from routes.emergency_api import emergency_bp
from routes.automation_api import automation_bp
from routes.hacker_super_api import hacker_super_bp
from dotenv import load_dotenv
import json

load_dotenv()

app = Flask(__name__)
app.secret_key = os.getenv('SESSION_SECRET', 'cipherh-dev-secret-key-change-in-production')

app.config['JSON_AS_ASCII'] = False

app.register_blueprint(main_bp)
app.register_blueprint(admin_bp)
app.register_blueprint(code_gen_bp)
app.register_blueprint(template_api_bp)
app.register_blueprint(hacker_bp)
app.register_blueprint(evolution_bp)
app.register_blueprint(brain_bp)
app.register_blueprint(memory_bp)
app.register_blueprint(world_bp)
app.register_blueprint(emotion_bp)
app.register_blueprint(task_bp)
app.register_blueprint(defense_bp)
app.register_blueprint(ltm_bp)
app.register_blueprint(personality_bp)
app.register_blueprint(metacog_bp)
app.register_blueprint(auto_evo_bp)
app.register_blueprint(social_bp)
app.register_blueprint(hacker_security_bp)
app.register_blueprint(metacog2_bp)
app.register_blueprint(task_chain_bp)
app.register_blueprint(realtime_bp)
app.register_blueprint(ltm_insight_bp)
app.register_blueprint(emergency_bp)
app.register_blueprint(automation_bp)
app.register_blueprint(hacker_super_bp)

init_routes(app)

@app.context_processor
def inject_manifest():
    try:
        with open('cipherh_manifest.json', 'r', encoding='utf-8') as f:
            manifest = json.load(f)
            return {'manifest': manifest}
    except Exception as e:
        return {'manifest': {'name': 'CipherH', 'version': 'unknown'}}

if __name__ == '__main__':
    print("=" * 50)
    print("🧠 CipherH Autonomous Agent")
    print("=" * 50)
    print(f"Environment: {os.getenv('FLASK_ENV', 'development')}")
    print(f"OpenAI API Key: {'✓ Configured' if os.getenv('OPENAI_API_KEY') else '✗ Missing'}")
    print(f"Notion Token: {'✓ Configured' if os.getenv('NOTION_TOKEN') else '✗ Missing'}")
    print(f"Notion Database: {'✓ Configured' if os.getenv('NOTION_DATABASE_ID') else '✗ Missing'}")
    print("=" * 50)
    
    app.run(host='0.0.0.0', port=5000, debug=True)
