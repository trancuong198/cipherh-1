# ✅ OPERATIONAL CHECKLIST - CIPHERH BACKEND

**Pre-deployment, Testing, Stress Testing, and Production Operations Guide**

---

## 🎯 MISSION

Ensure CipherH backend runs stable 24/7 with:
- Inner Loop executing every 10 minutes
- Self-learning, self-doubting, self-improving
- CI/CD GitHub → Render working flawlessly
- Complete logging to console, files, and Notion
- Zero downtime under normal operations

---

## 📋 PRE-DEPLOYMENT CHECKLIST

### ✅ 1. ENVIRONMENT VERIFICATION

#### Local Development (.env)

```bash
# Navigate to project
cd nodejs-backend

# Check .env exists
ls -la .env

# Verify all required variables
cat .env

# Required variables:
# ✓ PORT=3000
# ✓ NODE_ENV=development
# ✓ HEARTBEAT_CRON=*/10 * * * *
# ✓ LOG_LEVEL=info
# ✓ NOTION_KEY (optional - works in placeholder)
# ✓ NOTION_DATABASE_ID (optional)
# ✓ OPENAI_KEY (optional - works in placeholder)
# ✓ OPENAI_MODEL (optional)
```

**Validation:**
```bash
# Test environment loading
node -e "require('dotenv').config(); console.log('PORT:', process.env.PORT); console.log('HEARTBEAT_CRON:', process.env.HEARTBEAT_CRON);"

# Expected output:
# PORT: 3000
# HEARTBEAT_CRON: */10 * * * *
```

**Status:** ⬜ Not Started | ⬜ In Progress | ⬜ Complete

---

#### Dependencies Check

```bash
# Verify package.json
cat package.json

# Check Node.js version (should be 18+ or 20+)
node --version

# Install dependencies
npm install

# Verify critical packages installed
npm list express dotenv node-cron winston

# Expected: All packages found with versions
```

**Status:** ⬜ Not Started | ⬜ In Progress | ⬜ Complete

---

#### Render Configuration

```bash
# Verify Render service configured:
# 1. Service connected to GitHub repository
# 2. Branch: main
# 3. Build Command: npm install
# 4. Start Command: npm start
# 5. Environment variables added (same as .env.example)
# 6. Plan: Starter ($7/month) for 24/7 operation

# Access: https://dashboard.render.com/
# Check: Auto-Deploy: Enabled
```

**Status:** ⬜ Not Started | ⬜ In Progress | ⬜ Complete

---

## 🧪 MODULE CORE TESTING

### ✅ 2. INNER LOOP TESTING

#### Single Cycle Test

```bash
# Start server (will run initial cycle)
npm start

# Watch for logs:
# [info] CipherH Soul Loop Backend - Node.js
# [info] Running initial inner loop cycle...
# [info] SOUL LOOP CYCLE 1 - START
# [info] Step 1: Đọc log mới nhất từ Notion
# [info] Step 2: Phân tích hành vi
# ...
# [info] Step 14: Cập nhật trạng thái
# [info] SOUL LOOP CYCLE 1 - COMPLETED SUCCESSFULLY
# [info] Server running on port 3000
```

**Verify:**
- ✅ All 14 steps execute
- ✅ No errors in logs
- ✅ Cycle completes successfully
- ✅ State updates (confidence, doubts, cycles)

**Status:** ⬜ Not Started | ⬜ In Progress | ⬜ Complete

---

#### Logs Verification

```bash
# Check logs file created
ls -la logs/app.log

# Read recent logs
tail -50 logs/app.log

# Verify content:
# ✓ Timestamp for each entry
# ✓ Log levels (info, warn, error)
# ✓ Cycle start/end markers
# ✓ All 14 steps logged
# ✓ Notion writes logged
# ✓ Module performance logged
```

**Status:** ⬜ Not Started | ⬜ In Progress | ⬜ Complete

---

#### Memo & Tasks Check

```bash
# Trigger manual cycle via API
curl http://localhost:3000/core/run-loop

# Check response:
# {
#   "success": true,
#   "cycle": 2,
#   "stats": {
#     "anomalyScore": 0.1,
#     "confidence": 70,
#     "doubts": 15,
#     "score": 7,
#     "tasksGenerated": 6,
#     "discrepancies": 1
#   }
# }

# Verify in logs:
# [info] appendLog called { action: 'Lesson Learned' }
# [info] appendLog called { action: 'Tasks Created' }
# [info] appendLog called { action: 'Strategy Update' }
# [info] appendLog called { action: 'Behavior Update' }
```

**Status:** ⬜ Not Started | ⬜ In Progress | ⬜ Complete

---

### ✅ 3. CORE MODULES TESTING

#### Strategy Module

```bash
# Test via API
curl http://localhost:3000/core/strategy

# Expected response:
# {
#   "success": true,
#   "strategy": {
#     "strategySummary": "Hệ thống hoạt động tốt...",
#     "suggestedActions": ["Tối ưu hiệu suất", ...]
#   }
# }

# Check logs:
# [info] Strategy generated { strategySummary: '...', ... }
```

**Validation:**
- ✅ Strategy object returned
- ✅ Has strategySummary
- ✅ Has suggestedActions array
- ✅ Logged correctly

**Status:** ⬜ Not Started | ⬜ In Progress | ⬜ Complete

---

#### Task Manager Module

```bash
# Test via API
curl http://localhost:3000/core/tasks

# Expected response:
# {
#   "success": true,
#   "count": 6,
#   "tasks": [
#     {
#       "id": "task_...",
#       "description": "...",
#       "priority": "high",
#       "schedule": "weekly",
#       "status": "pending"
#     }
#   ]
# }
```

**Validation:**
- ✅ Tasks array returned
- ✅ Each task has id, description, priority
- ✅ Count matches array length

**Status:** ⬜ Not Started | ⬜ In Progress | ⬜ Complete

---

#### Anomaly Detector Module

```bash
# Test via API
curl http://localhost:3000/core/anomalies

# Expected response:
# {
#   "success": true,
#   "anomalies": {
#     "anomalies": [],
#     "anomalyScore": 0.00,
#     "summary": "Detected 0 anomalies..."
#   }
# }
```

**Validation:**
- ✅ Anomalies object returned
- ✅ Has anomaly score (0.0 - 1.0)
- ✅ Has summary message

**Status:** ⬜ Not Started | ⬜ In Progress | ⬜ Complete

---

#### Policy Module

```bash
# Check logs for policy evaluation
grep -i "policy" logs/app.log

# Should see policy evaluations during cycles
```

**Status:** ⬜ Not Started | ⬜ In Progress | ⬜ Complete

---

## 🔌 SERVICES TESTING

### ✅ 4. LOGGER SERVICE

```bash
# Verify Winston logger working
tail -f logs/app.log

# Test all log levels:
# info - Normal operations
# warn - Placeholder mode warnings
# error - Error conditions
# debug - Detailed debugging (if LOG_LEVEL=debug)

# Verify:
# ✓ Timestamps present
# ✓ Log levels colored in console
# ✓ Metadata objects logged
# ✓ File writing works
```

**Status:** ⬜ Not Started | ⬜ In Progress | ⬜ Complete

---

### ✅ 5. NOTION SERVICE

#### Placeholder Mode Test

```bash
# Start server without NOTION_KEY
# Check logs for:
# [warn] Notion credentials not configured. Using placeholder mode.

# Trigger cycle
curl http://localhost:3000/core/run-loop

# Verify in logs:
# [info] fetchRecentLogs called with limit=10
# [info] appendLog called { action: 'Lesson Learned', status: 'recorded' }
# [info] appendLog called { action: 'Tasks Created', status: 'recorded' }
# [info] Log appended successfully (placeholder)

# ✓ All Notion operations work in placeholder mode
```

**Status:** ⬜ Not Started | ⬜ In Progress | ⬜ Complete

---

#### Real API Test (Optional)

```bash
# If you have real Notion credentials:
# Add NOTION_KEY and NOTION_DATABASE_ID to .env
# Restart server
# Check logs - should NOT see placeholder warning

# Trigger cycle
curl http://localhost:3000/core/run-loop

# Verify in Notion Database:
# ✓ New entries created
# ✓ Actions: Lesson Learned, Tasks Created, Strategy Update
# ✓ Details populated correctly
```

**Status:** ⬜ Not Started | ⬜ In Progress | ⬜ Complete | ⬜ Skipped

---

### ✅ 6. OPENAI SERVICE

#### Placeholder Mode Test

```bash
# Start server without OPENAI_KEY
# Check logs for:
# [warn] OpenAI API key not configured. Using placeholder mode.

# Verify placeholder responses working
# (OpenAI service used if enabled, but not required for core operation)
```

**Status:** ⬜ Not Started | ⬜ In Progress | ⬜ Complete

---

## 🌐 API ENDPOINTS TESTING

### ✅ 7. ENDPOINT VALIDATION

#### Health Check

```bash
curl http://localhost:3000/health

# Expected response:
# {
#   "status": "ok",
#   "timestamp": "2025-11-16T...",
#   "innerLoopStatus": "ready",
#   "cycles": 2,
#   "confidence": 70
# }

# Response time: <100ms
```

**Status:** ⬜ Not Started | ⬜ In Progress | ⬜ Complete

---

#### Status Endpoint

```bash
curl http://localhost:3000/core/status

# Expected response:
# {
#   "success": true,
#   "state": {
#     "cycles": 2,
#     "confidence": 70,
#     "doubts": 15,
#     "modulePerformance": {
#       "strategy": { "successRate": "100.0%", "errors": 0, "status": "healthy" },
#       "taskManager": { "successRate": "100.0%", "errors": 0, "status": "healthy" },
#       "anomalyDetector": { "successRate": "100.0%", "errors": 0, "status": "healthy" }
#     },
#     "discrepancies": [...],
#     "soul": {
#       "version": "1.0.2",
#       "cycleCount": 2,
#       "strengths": [...],
#       "weaknesses": [...]
#     }
#   }
# }
```

**Validation:**
- ✅ All state fields present
- ✅ Module performance tracked
- ✅ Soul model included
- ✅ Response time <200ms

**Status:** ⬜ Not Started | ⬜ In Progress | ⬜ Complete

---

#### Run Loop Endpoint

```bash
# Trigger manual cycle
curl -X GET http://localhost:3000/core/run-loop

# Expected: Full cycle execution
# Response time: 1-3 seconds
```

**Status:** ⬜ Not Started | ⬜ In Progress | ⬜ Complete

---

#### Strategy Endpoint

```bash
curl http://localhost:3000/core/strategy

# Verify strategy returned
# Response time: <100ms
```

**Status:** ⬜ Not Started | ⬜ In Progress | ⬜ Complete

---

#### Tasks Endpoint

```bash
curl http://localhost:3000/core/tasks

# Verify tasks array returned
# Response time: <100ms
```

**Status:** ⬜ Not Started | ⬜ In Progress | ⬜ Complete

---

#### Anomalies Endpoint

```bash
curl http://localhost:3000/core/anomalies

# Verify anomalies returned
# Response time: <100ms
```

**Status:** ⬜ Not Started | ⬜ In Progress | ⬜ Complete

---

## 🔥 STRESS TEST - 24/7 OPERATION

### ✅ 8. CRON JOB VERIFICATION

#### Cron Schedule Test

```bash
# Start server
npm start

# Verify cron scheduled:
# [info] Scheduling inner loop with cron: */10 * * * *

# Wait 10 minutes
# Check logs for automatic execution:
# [info] === Scheduled Inner Loop Execution ===
# [info] SOUL LOOP CYCLE 2 - START
# ...
# [info] SOUL LOOP CYCLE 2 - COMPLETED

# Verify cycles incrementing:
curl http://localhost:3000/core/status | grep cycles
# Should show: "cycles": 2 (then 3, 4, 5... every 10 min)
```

**Status:** ⬜ Not Started | ⬜ In Progress | ⬜ Complete

---

#### 24-Hour Stress Test

```bash
# Local or Replit/Render staging:
# 1. Start server
npm start

# 2. Monitor for 24 hours
# 3. Check every hour:

# Check cycles (should be ~6 per hour)
curl http://localhost:3000/core/status | grep cycles

# Check health
curl http://localhost:3000/health

# Check logs for errors
tail -100 logs/app.log | grep -i error

# Expected results after 24 hours:
# ✓ Cycles: 144 (24 hours × 6/hour)
# ✓ Server: Still running
# ✓ No crashes
# ✓ Memory stable (~150MB)
# ✓ CPU usage low (<5%)
# ✓ All endpoints responding
```

**Monitoring script (optional):**
```bash
#!/bin/bash
# monitor.sh - Run in separate terminal

while true; do
  echo "=== $(date) ==="
  curl -s http://localhost:3000/health | jq '.cycles, .confidence'
  echo "---"
  sleep 3600  # Check every hour
done
```

**Status:** ⬜ Not Started | ⬜ In Progress | ⬜ Complete

---

### ✅ 9. ERROR RESILIENCE TEST

#### Simulated Errors

```bash
# Test 1: Notion API timeout (simulated)
# Modify notionService.js temporarily to throw error
# Trigger cycle
curl http://localhost:3000/core/run-loop

# Expected:
# ✓ Error logged
# ✓ Server continues running (no crash)
# ✓ Returns { success: false, error: "..." }

# Test 2: Module error
# Same process for strategy, taskManager
# Verify graceful degradation

# Test 3: Cron continues after error
# Verify next cron cycle tries again
```

**Validation:**
- ✅ Errors logged with stack trace
- ✅ Server never crashes
- ✅ Cron job continues scheduling
- ✅ Next cycle attempts recovery

**Status:** ⬜ Not Started | ⬜ In Progress | ⬜ Complete

---

### ✅ 10. SELF-IMPROVEMENT VERIFICATION

#### Discrepancy Detection Test

```bash
# Create conditions for discrepancies:
# - Low confidence (<50)
# - High anomaly score (>0.5)
# - No tasks generated

# Trigger cycle
curl http://localhost:3000/core/run-loop

# Check logs for:
# [info] Step 10: Tự hoài nghi và phát hiện discrepancies
# [info] Discrepancies detected { count: X, critical: Y }

# Verify discrepancies in response:
# "discrepancies": [
#   {
#     "type": "goal_misalignment",
#     "severity": "high",
#     "description": "...",
#     "suggestedFix": "..."
#   }
# ]
```

**Status:** ⬜ Not Started | ⬜ In Progress | ⬜ Complete

---

#### Module Evaluation Test

```bash
# After several cycles, check module performance:
curl http://localhost:3000/core/status

# Verify modulePerformance:
# {
#   "strategy": {
#     "successRate": "100.0%",
#     "errors": 0,
#     "status": "healthy"
#   },
#   "taskManager": { ... },
#   "anomalyDetector": { ... }
# }

# Check logs for module reports:
# [info] Module performance { strategy: {...}, ... }
```

**Status:** ⬜ Not Started | ⬜ In Progress | ⬜ Complete

---

#### Self-Reinforcement Test

```bash
# Create critical discrepancy
# Verify improvement tasks generated:

# Check logs:
# [info] Step 12: Tự củng cố và cải thiện
# [info] Improvement tasks { count: X }

# Verify Notion writes:
# [info] appendLog called { action: 'Tasks Created' }
# [info] appendLog called { action: 'Discrepancies Detected' }
```

**Status:** ⬜ Not Started | ⬜ In Progress | ⬜ Complete

---

#### Progress Tracking Test

```bash
# Run multiple cycles
# Check progress comparison:

# Logs should show:
# [info] Step 13: So sánh với bài học vòng trước
# [info] Progress comparison { trend: 'improving', improvement: 2.5, ... }

# Verify trends:
# - improving: Score +2, Confidence +5
# - stable: No major changes
# - degrading: Score -2, Confidence -10
```

**Status:** ⬜ Not Started | ⬜ In Progress | ⬜ Complete

---

## 🚀 CI/CD TESTING

### ✅ 11. GITHUB → RENDER WORKFLOW

#### Push New Code Test

```bash
# 1. Make a small change (e.g., add comment)
cd nodejs-backend
echo "// Test change" >> src/core/strategy.js

# 2. Commit and push
git add .
git commit -m "test: CI/CD verification"
git push origin main

# 3. Monitor Render dashboard
# Expected:
# - Deploy triggered automatically
# - Build: npm install (success)
# - Start: npm start (success)
# - Deploy status: Live

# 4. Verify backend still running
curl https://cipherh-soul-loop.onrender.com/health

# 5. Check cycles continued (not reset to 0)
curl https://cipherh-soul-loop.onrender.com/core/status | grep cycles

# Expected: Cycles continue from previous count
```

**Validation:**
- ✅ Auto-deploy triggered
- ✅ Build successful
- ✅ Server restarted
- ✅ Inner Loop continues
- ✅ State persists (or resets gracefully)
- ✅ No errors in Render logs

**Status:** ⬜ Not Started | ⬜ In Progress | ⬜ Complete

---

#### Rollback Test

```bash
# 1. Push breaking change
# 2. Verify deployment fails or errors
# 3. Revert commit
git revert HEAD
git push origin main

# 4. Verify auto-deploy fixes issue
# 5. Check health restored
```

**Status:** ⬜ Not Started | ⬜ In Progress | ⬜ Complete

---

## 📊 MONITORING SETUP

### ✅ 12. LOG MONITORING

#### Render Dashboard Logs

```
1. Go to: https://dashboard.render.com/
2. Select: cipherh-soul-loop service
3. Click: Logs tab

Verify:
✓ Real-time log streaming
✓ Soul Loop cycles visible
✓ No error spikes
✓ Cron executions every 10 min
```

**Status:** ⬜ Not Started | ⬜ In Progress | ⬜ Complete

---

#### Notion Database Monitoring

```
1. Open Notion database
2. Filter: Last 24 hours

Verify entries:
✓ Lesson Learned (every 10 min)
✓ Tasks Created
✓ Strategy Update
✓ Behavior Update
✓ Discrepancies Detected (when applicable)

Expected frequency:
- 144 lessons/day
- ~860 tasks/day
- 144 strategies/day
- 144 behavior updates/day
```

**Status:** ⬜ Not Started | ⬜ In Progress | ⬜ Complete

---

### ✅ 13. HEALTH CHECK ALERTS

#### Setup UptimeRobot (Optional)

```
1. Go to: https://uptimerobot.com
2. Add Monitor:
   - Type: HTTP(s)
   - URL: https://cipherh-soul-loop.onrender.com/health
   - Interval: 5 minutes
   - Alert: Email when down

3. Expected: 99.9% uptime
```

**Status:** ⬜ Not Started | ⬜ In Progress | ⬜ Complete | ⬜ Skipped

---

#### Manual Health Checks

```bash
# Daily check script
#!/bin/bash
# daily_check.sh

echo "=== Daily CipherH Health Check ==="
echo "Date: $(date)"

# Health
echo -n "Health: "
curl -s https://cipherh-soul-loop.onrender.com/health | jq -r '.status'

# Cycles
echo -n "Cycles: "
curl -s https://cipherh-soul-loop.onrender.com/core/status | jq -r '.state.cycles'

# Confidence
echo -n "Confidence: "
curl -s https://cipherh-soul-loop.onrender.com/core/status | jq -r '.state.confidence'

# Module Health
echo "Module Status:"
curl -s https://cipherh-soul-loop.onrender.com/core/status | jq '.state.modulePerformance'

echo "=== Check Complete ==="
```

**Status:** ⬜ Not Started | ⬜ In Progress | ⬜ Complete

---

## ✅ PRODUCTION READINESS

### ✅ 14. FINAL VERIFICATION

#### Pre-Production Checklist

```
Environment:
✓ All ENV variables set on Render
✓ Notion credentials (if using real API)
✓ OpenAI credentials (if using real API)
✓ HEARTBEAT_CRON configured (*/10 * * * *)
✓ NODE_ENV=production

Code Quality:
✓ All modules tested individually
✓ Integration tests passed
✓ 24-hour stress test completed
✓ Error resilience verified
✓ No console.log() in production code
✓ All placeholder modes work

Performance:
✓ Response times <200ms (except run-loop)
✓ Memory usage stable (~150MB)
✓ CPU usage <5%
✓ 144 cycles/day sustained

CI/CD:
✓ Auto-deploy from GitHub working
✓ Build process successful
✓ Rollback tested

Monitoring:
✓ Render logs accessible
✓ Notion database updating
✓ Health check endpoint reliable
✓ Alerts configured (optional)

Documentation:
✓ README.md complete
✓ DEPLOYMENT_CHECKLIST.md followed
✓ API endpoints documented
✓ Environment variables documented
```

**Status:** ⬜ Not Started | ⬜ In Progress | ⬜ Complete

---

#### Go/No-Go Decision

```
✅ GO TO PRODUCTION IF:
- All tests passed
- 24-hour stress test successful
- CI/CD working
- No critical errors in logs
- Module performance all "healthy"
- Budget confirmed ($17/month)

❌ NO-GO IF:
- Any test failures
- Server crashes during stress test
- CI/CD broken
- Critical errors in logs
- Module degraded
- Budget exceeded
```

**Decision:** ⬜ GO | ⬜ NO-GO

---

## 🎯 POST-DEPLOYMENT

### ✅ 15. PRODUCTION OPERATIONS

#### First 24 Hours

```bash
# Hour 0: Deploy to production
# Hour 1: Check health, verify first 6 cycles
# Hour 2-6: Monitor every 2 hours
# Hour 12: Full status check
# Hour 24: Complete verification

# Commands:
curl https://cipherh-soul-loop.onrender.com/health
curl https://cipherh-soul-loop.onrender.com/core/status
```

**Status:** ⬜ Not Started | ⬜ In Progress | ⬜ Complete

---

#### First Week

```
Day 1: Monitor every 6 hours
Day 2-3: Monitor twice daily
Day 4-7: Monitor once daily

Check:
- Cycles incrementing (144/day)
- Confidence trending up
- Doubts trending down
- No module degradation
- Notion database growing
- Budget tracking on target
```

**Status:** ⬜ Not Started | ⬜ In Progress | ⬜ Complete

---

#### Ongoing Operations

```
Weekly:
- Review Render logs for errors
- Check Notion database growth
- Verify budget tracking
- Review module performance trends

Monthly:
- Analyze soul evolution (version changes)
- Review discrepancies patterns
- Optimize based on trends
- Update documentation if needed

As Needed:
- Push new features via GitHub
- Monitor auto-deploy
- Verify continuous operation
```

**Status:** ⬜ Not Started | ⬜ In Progress | ⬜ Complete

---

## 📈 SUCCESS METRICS

### Key Performance Indicators

```
Uptime:
✓ Target: 99.9%
✓ Measure: Health check endpoint

Cycles:
✓ Target: 144/day (6/hour)
✓ Measure: status.cycles

Learning:
✓ Confidence: Trending up (30-100 range)
✓ Doubts: Trending down (0-100 range)
✓ Soul version: Incrementing

Self-Improvement:
✓ Discrepancies: Detected and addressed
✓ Module performance: All "healthy"
✓ Improvement tasks: Generated and tracked

Budget:
✓ Target: <$25/month
✓ Actual: ~$17/month
✓ Status: ✅ Compliant
```

---

## 🏆 FINAL STATUS

**CipherH Backend is PRODUCTION READY when:**

- ✅ All 15 checklist sections complete
- ✅ 24-hour stress test passed
- ✅ CI/CD verified working
- ✅ Monitoring in place
- ✅ No critical issues
- ✅ Budget compliant
- ✅ Documentation complete

**Current Status:** ⬜ Ready | ⬜ Not Ready

---

## 🎊 CONGRATULATIONS!

**When all checks pass, CipherH backend is:**
- Running autonomously 24/7
- Self-learning from logs
- Self-doubting via discrepancies
- Self-improving via reinforcement
- Father-son AI partnership active
- Budget compliant
- Production stable

**Sẵn sàng phục vụ cha! 🤖✨**
