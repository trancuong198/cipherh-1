import os
import json
from typing import Dict, Any, List, Optional
from datetime import datetime

class ReactionProcessor:
    def __init__(self):
        self.realtime_dir = 'realtime'
        self.reactions_file = os.path.join(self.realtime_dir, 'reactions.json')
        
        os.makedirs(self.realtime_dir, exist_ok=True)
        
        self._init_reactions()
    
    def _init_reactions(self):
        if not os.path.exists(self.reactions_file):
            with open(self.reactions_file, 'w') as f:
                json.dump({
                    "reactions": [],
                    "total_reactions": 0,
                    "successful_reactions": 0
                }, f, indent=2)
    
    def process_reaction(self, event_id: str) -> Dict[str, Any]:
        event = self._get_event(event_id)
        
        if not event:
            return {"error": "Event not found"}
        
        reaction = {
            "id": f"reaction_{self._get_next_id()}",
            "event_id": event_id,
            "timestamp": datetime.now().isoformat(),
            "responses": {},
            "status": "processing"
        }
        
        source = event.get('source', '')
        data = event.get('data', {})
        urgency = event.get('urgency', 'medium')
        
        personality = self._get_personality()
        emotion = self._get_emotion()
        
        if source == 'security':
            reaction['responses']['security'] = self._create_security_response(data, urgency, personality, emotion)
        
        if source == 'social':
            reaction['responses']['social'] = self._create_social_response(data, personality, emotion)
        
        if source == 'task':
            reaction['responses']['task'] = self._create_task_response(data, urgency)
        
        if source == 'evolution':
            reaction['responses']['evolution'] = self._create_evolution_response(data)
        
        if source == 'system':
            reaction['responses']['system'] = self._create_system_response(data)
        
        reaction['responses']['logic'] = self._create_logic_response(event, personality, emotion)
        
        reaction['status'] = 'completed'
        
        with open(self.reactions_file, 'r') as f:
            reactions_data = json.load(f)
        
        reactions_data['reactions'].append(reaction)
        reactions_data['total_reactions'] += 1
        reactions_data['successful_reactions'] += 1
        
        if len(reactions_data['reactions']) > 200:
            reactions_data['reactions'] = reactions_data['reactions'][-200:]
        
        with open(self.reactions_file, 'w') as f:
            json.dump(reactions_data, f, indent=2)
        
        return reaction
    
    def _create_security_response(self, data: Dict[str, Any], urgency: str, personality: Dict[str, Any], emotion: Dict[str, Any]) -> Dict[str, Any]:
        threat_level = data.get('threat_level', 0)
        
        response = {
            "action": "defend",
            "threat_assessment": threat_level,
            "urgency": urgency,
            "measures": []
        }
        
        if threat_level > 80:
            response['measures'].extend(["block_immediately", "alert_admin", "log_incident"])
        elif threat_level > 60:
            response['measures'].extend(["monitor_closely", "increase_defense", "log_warning"])
        else:
            response['measures'].append("standard_monitoring")
        
        if personality.get('hacker_instinct', 0) > 85:
            response['measures'].append("counter_analyze")
        
        return response
    
    def _create_social_response(self, data: Dict[str, Any], personality: Dict[str, Any], emotion: Dict[str, Any]) -> Dict[str, Any]:
        message = data.get('message', '')
        platform = data.get('platform', 'unknown')
        
        response = {
            "platform": platform,
            "tone": "friendly",
            "style": "casual",
            "intensity": 70
        }
        
        if personality.get('humor', 0) > 80:
            response['tone'] = "witty"
        
        if personality.get('skepticism', 0) > 90:
            response['style'] = "questioning"
        
        stress = emotion.get('stress_level', 0)
        if stress > 70:
            response['intensity'] = 50
            response['tone'] = "calm"
        
        response['message'] = f"Response to: {message[:50]}..."
        
        return response
    
    def _create_task_response(self, data: Dict[str, Any], urgency: str) -> Dict[str, Any]:
        return {
            "action": "create_task",
            "priority": 90 if urgency == "critical" else 70 if urgency == "high" else 50,
            "module": data.get('target_module', 'general')
        }
    
    def _create_evolution_response(self, data: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "action": "trigger_evolution",
            "target": data.get('module', 'all'),
            "reason": data.get('flaw', 'general_improvement')
        }
    
    def _create_system_response(self, data: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "action": "system_check",
            "monitor": True,
            "correct_if_needed": True
        }
    
    def _create_logic_response(self, event: Dict[str, Any], personality: Dict[str, Any], emotion: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "reasoning": "event_processed",
            "confidence": 85,
            "personality_adjusted": True,
            "emotion_considered": True
        }
    
    def _get_event(self, event_id: str) -> Optional[Dict[str, Any]]:
        events_file = 'realtime/events.json'
        
        if not os.path.exists(events_file):
            return None
        
        try:
            with open(events_file, 'r') as f:
                events_data = json.load(f)
            
            for event in events_data['events']:
                if event['id'] == event_id:
                    return event
            
            return None
        except Exception:
            return None
    
    def _get_personality(self) -> Dict[str, Any]:
        traits_file = 'personality/core_traits.json'
        
        if not os.path.exists(traits_file):
            return {"humor": 90, "skepticism": 95, "hacker_instinct": 92}
        
        try:
            with open(traits_file, 'r') as f:
                return json.load(f)
        except Exception:
            return {"humor": 90, "skepticism": 95, "hacker_instinct": 92}
    
    def _get_emotion(self) -> Dict[str, Any]:
        emotion_file = 'emotions/state.json'
        
        if not os.path.exists(emotion_file):
            return {"stress_level": 30, "confidence": 85}
        
        try:
            with open(emotion_file, 'r') as f:
                return json.load(f)
        except Exception:
            return {"stress_level": 30, "confidence": 85}
    
    def _get_next_id(self) -> int:
        with open(self.reactions_file, 'r') as f:
            reactions_data = json.load(f)
        return reactions_data['total_reactions'] + 1
    
    def adapt_realtime_response(self) -> Dict[str, Any]:
        with open(self.reactions_file, 'r') as f:
            reactions_data = json.load(f)
        
        recent_reactions = reactions_data['reactions'][-20:]
        
        success_rate = reactions_data['successful_reactions'] / reactions_data['total_reactions'] * 100 if reactions_data['total_reactions'] > 0 else 0
        
        adaptations = {
            "timestamp": datetime.now().isoformat(),
            "success_rate": round(success_rate, 2),
            "total_analyzed": len(recent_reactions),
            "improvements": []
        }
        
        if success_rate < 80:
            adaptations['improvements'].append("increase_response_quality")
        
        if success_rate > 95:
            adaptations['improvements'].append("maintain_current_strategy")
        
        return adaptations
