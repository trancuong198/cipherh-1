import os
import json
from typing import Dict, Any, List, Optional
from datetime import datetime

class EventListener:
    def __init__(self):
        self.realtime_dir = 'realtime'
        self.events_file = os.path.join(self.realtime_dir, 'events.json')
        
        os.makedirs(self.realtime_dir, exist_ok=True)
        
        self._init_events()
    
    def _init_events(self):
        if not os.path.exists(self.events_file):
            with open(self.events_file, 'w') as f:
                json.dump({
                    "events": [],
                    "total_events": 0,
                    "active_events": 0
                }, f, indent=2)
    
    def listen_event(self, source: str, data: Dict[str, Any]) -> Dict[str, Any]:
        with open(self.events_file, 'r') as f:
            events_data = json.load(f)
        
        event_id = f"event_{events_data['total_events'] + 1}"
        
        event = {
            "id": event_id,
            "source": source,
            "data": data,
            "timestamp": datetime.now().isoformat(),
            "status": "active",
            "priority": self._calculate_priority(source, data),
            "urgency": self._calculate_urgency(source, data),
            "processed": False
        }
        
        events_data['events'].append(event)
        events_data['total_events'] += 1
        events_data['active_events'] += 1
        
        if len(events_data['events']) > 500:
            events_data['events'] = events_data['events'][-500:]
        
        with open(self.events_file, 'w') as f:
            json.dump(events_data, f, indent=2)
        
        return event
    
    def _calculate_priority(self, source: str, data: Dict[str, Any]) -> int:
        priority = 50
        
        if source == 'security':
            priority = 95
        elif source == 'social':
            priority = 70
        elif source == 'task':
            priority = 60
        elif source == 'evolution':
            priority = 55
        elif source == 'system':
            priority = 80
        
        if data.get('urgent'):
            priority = min(100, priority + 20)
        
        if data.get('threat_level', 0) > 70:
            priority = 98
        
        return priority
    
    def _calculate_urgency(self, source: str, data: Dict[str, Any]) -> str:
        priority = self._calculate_priority(source, data)
        
        if priority >= 90:
            return "critical"
        elif priority >= 70:
            return "high"
        elif priority >= 50:
            return "medium"
        else:
            return "low"
    
    def get_event(self, event_id: str) -> Optional[Dict[str, Any]]:
        with open(self.events_file, 'r') as f:
            events_data = json.load(f)
        
        for event in events_data['events']:
            if event['id'] == event_id:
                return event
        
        return None
    
    def get_active_events(self) -> List[Dict[str, Any]]:
        with open(self.events_file, 'r') as f:
            events_data = json.load(f)
        
        active = [e for e in events_data['events'] if e['status'] == 'active']
        
        return sorted(active, key=lambda e: e['priority'], reverse=True)
    
    def mark_processed(self, event_id: str) -> Dict[str, Any]:
        with open(self.events_file, 'r') as f:
            events_data = json.load(f)
        
        for event in events_data['events']:
            if event['id'] == event_id and event['status'] == 'active':
                event['status'] = 'processed'
                event['processed'] = True
                event['processed_at'] = datetime.now().isoformat()
                events_data['active_events'] -= 1
                break
        
        with open(self.events_file, 'w') as f:
            json.dump(events_data, f, indent=2)
        
        return self.get_event(event_id) or {}
