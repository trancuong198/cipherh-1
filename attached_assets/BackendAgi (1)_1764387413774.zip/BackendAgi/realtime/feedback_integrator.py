import os
import json
from typing import Dict, Any, List, Optional
from datetime import datetime

class FeedbackIntegrator:
    def __init__(self):
        self.realtime_dir = 'realtime'
        self.feedback_file = os.path.join(self.realtime_dir, 'feedback_integration.json')
        
        os.makedirs(self.realtime_dir, exist_ok=True)
        
        self._init_feedback()
    
    def _init_feedback(self):
        if not os.path.exists(self.feedback_file):
            with open(self.feedback_file, 'w') as f:
                json.dump({
                    "integrations": [],
                    "total_integrations": 0
                }, f, indent=2)
    
    def log_feedback(self, event_id: str, outcome: str) -> Dict[str, Any]:
        event = self._get_event(event_id)
        reaction = self._get_reaction(event_id)
        
        integration = {
            "id": f"integration_{self._get_next_id()}",
            "event_id": event_id,
            "outcome": outcome,
            "timestamp": datetime.now().isoformat(),
            "stored_to": [],
            "learning_applied": False
        }
        
        if event:
            if self._store_to_memory(event, outcome):
                integration['stored_to'].append("memory_engine")
            
            if self._store_to_ltm(event, outcome):
                integration['stored_to'].append("ltm_map")
            
            if self._store_to_metacognition(event, reaction, outcome):
                integration['stored_to'].append("metacognition")
            
            integration['learning_applied'] = True
        
        with open(self.feedback_file, 'r') as f:
            feedback_data = json.load(f)
        
        feedback_data['integrations'].append(integration)
        feedback_data['total_integrations'] += 1
        
        if len(feedback_data['integrations']) > 200:
            feedback_data['integrations'] = feedback_data['integrations'][-200:]
        
        with open(self.feedback_file, 'w') as f:
            json.dump(feedback_data, f, indent=2)
        
        return integration
    
    def _store_to_memory(self, event: Dict[str, Any], outcome: str) -> bool:
        stm_file = 'memory/stm.json'
        
        if not os.path.exists(stm_file):
            return False
        
        try:
            with open(stm_file, 'r') as f:
                stm = json.load(f)
            
            stm['memories'].append({
                "timestamp": datetime.now().isoformat(),
                "type": "realtime_event",
                "source": event.get('source', 'unknown'),
                "content": f"Event {event['id']} from {event['source']} - {outcome}",
                "importance": 70 if event.get('urgency') == 'critical' else 50
            })
            
            if len(stm['memories']) > 100:
                stm['memories'] = stm['memories'][-100:]
            
            with open(stm_file, 'w') as f:
                json.dump(stm, f, indent=2)
            
            return True
        except Exception:
            return False
    
    def _store_to_ltm(self, event: Dict[str, Any], outcome: str) -> bool:
        ltm_file = 'long_term/events.json'
        
        if not os.path.exists(ltm_file):
            return False
        
        try:
            with open(ltm_file, 'r') as f:
                ltm = json.load(f)
            
            ltm['events'].append({
                "timestamp": datetime.now().isoformat(),
                "type": "realtime_event",
                "event_id": event['id'],
                "source": event['source'],
                "urgency": event.get('urgency', 'medium'),
                "outcome": outcome,
                "importance": 75
            })
            
            if len(ltm['events']) > 100:
                ltm['events'] = ltm['events'][-100:]
            
            with open(ltm_file, 'w') as f:
                json.dump(ltm, f, indent=2)
            
            return True
        except Exception:
            return False
    
    def _store_to_metacognition(self, event: Dict[str, Any], reaction: Optional[Dict[str, Any]], outcome: str) -> bool:
        metacog_file = 'metacognition/self_analysis.json'
        
        if not os.path.exists(metacog_file):
            return False
        
        try:
            with open(metacog_file, 'r') as f:
                metacog = json.load(f)
            
            if outcome == 'success':
                if 'realtime_patterns' not in metacog:
                    metacog['realtime_patterns'] = []
                
                metacog['realtime_patterns'].append({
                    "timestamp": datetime.now().isoformat(),
                    "source": event['source'],
                    "urgency": event.get('urgency'),
                    "success": True,
                    "response_quality": "good"
                })
                
                if len(metacog['realtime_patterns']) > 50:
                    metacog['realtime_patterns'] = metacog['realtime_patterns'][-50:]
            
            with open(metacog_file, 'w') as f:
                json.dump(metacog, f, indent=2)
            
            return True
        except Exception:
            return False
    
    def _get_event(self, event_id: str) -> Optional[Dict[str, Any]]:
        events_file = 'realtime/events.json'
        
        if not os.path.exists(events_file):
            return None
        
        try:
            with open(events_file, 'r') as f:
                events_data = json.load(f)
            
            for event in events_data['events']:
                if event['id'] == event_id:
                    return event
            
            return None
        except Exception:
            return None
    
    def _get_reaction(self, event_id: str) -> Optional[Dict[str, Any]]:
        reactions_file = 'realtime/reactions.json'
        
        if not os.path.exists(reactions_file):
            return None
        
        try:
            with open(reactions_file, 'r') as f:
                reactions_data = json.load(f)
            
            for reaction in reactions_data['reactions']:
                if reaction['event_id'] == event_id:
                    return reaction
            
            return None
        except Exception:
            return None
    
    def _get_next_id(self) -> int:
        with open(self.feedback_file, 'r') as f:
            feedback_data = json.load(f)
        return feedback_data['total_integrations'] + 1
    
    def get_integration_stats(self) -> Dict[str, Any]:
        with open(self.feedback_file, 'r') as f:
            feedback_data = json.load(f)
        
        return {
            "total_integrations": feedback_data['total_integrations'],
            "recent_count": len(feedback_data['integrations'][-20:])
        }
