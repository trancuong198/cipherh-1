import os
import json
import psutil
from typing import Dict, Any, List
from datetime import datetime

class SelfMonitor:
    def __init__(self):
        self.auto_evo_dir = 'auto_evolution'
        self.metrics_file = os.path.join(self.auto_evo_dir, 'system_metrics.json')
        
        os.makedirs(self.auto_evo_dir, exist_ok=True)
        
        self._init_metrics()
    
    def _init_metrics(self):
        if not os.path.exists(self.metrics_file):
            with open(self.metrics_file, 'w') as f:
                json.dump({
                    "metrics_history": [],
                    "alerts": [],
                    "total_checks": 0
                }, f, indent=2)
    
    def monitor_cpu_memory(self) -> Dict[str, Any]:
        try:
            cpu_percent = psutil.cpu_percent(interval=1)
            memory = psutil.virtual_memory()
            memory_percent = memory.percent
            
            metrics = {
                "timestamp": datetime.now().isoformat(),
                "cpu_usage": cpu_percent,
                "memory_usage": memory_percent,
                "memory_available_mb": memory.available / (1024 * 1024),
                "status": "healthy"
            }
            
            if cpu_percent > 80:
                metrics['status'] = "cpu_high"
                self.alert_if_critical("CPU usage high", cpu_percent)
            
            if memory_percent > 85:
                metrics['status'] = "memory_high"
                self.alert_if_critical("Memory usage high", memory_percent)
            
            self.record_metrics(metrics)
            
            return metrics
        
        except Exception as e:
            return {
                "timestamp": datetime.now().isoformat(),
                "cpu_usage": 0,
                "memory_usage": 0,
                "status": "error",
                "error": str(e)
            }
    
    def detect_module_failure(self) -> Dict[str, Any]:
        failed_modules = []
        
        modules_to_check = [
            'memory_engine',
            'emotional_model',
            'task_chain',
            'metacognition2',
            'realtime',
            'emergency'
        ]
        
        for module in modules_to_check:
            if self._check_module_health(module) < 50:
                failed_modules.append({
                    "module": module,
                    "health": self._check_module_health(module),
                    "status": "failed"
                })
        
        if failed_modules:
            self.alert_if_critical("Module failures detected", failed_modules)
        
        return {
            "timestamp": datetime.now().isoformat(),
            "failed_modules": failed_modules,
            "total_failures": len(failed_modules)
        }
    
    def _check_module_health(self, module: str) -> int:
        health_scores = {
            'memory_engine': 85,
            'emotional_model': 80,
            'task_chain': 78,
            'metacognition2': 82,
            'realtime': 88,
            'emergency': 90
        }
        
        return health_scores.get(module, 75)
    
    def alert_if_critical(self, alert_type: str, data: Any) -> Dict[str, Any]:
        with open(self.metrics_file, 'r') as f:
            metrics_data = json.load(f)
        
        alert = {
            "timestamp": datetime.now().isoformat(),
            "type": alert_type,
            "severity": "critical",
            "data": str(data)
        }
        
        metrics_data['alerts'].append(alert)
        
        if len(metrics_data['alerts']) > 100:
            metrics_data['alerts'] = metrics_data['alerts'][-100:]
        
        with open(self.metrics_file, 'w') as f:
            json.dump(metrics_data, f, indent=2)
        
        return alert
    
    def record_metrics(self, metrics: Dict[str, Any]) -> Dict[str, Any]:
        with open(self.metrics_file, 'r') as f:
            metrics_data = json.load(f)
        
        metrics_data['metrics_history'].append(metrics)
        metrics_data['total_checks'] += 1
        
        if len(metrics_data['metrics_history']) > 200:
            metrics_data['metrics_history'] = metrics_data['metrics_history'][-200:]
        
        with open(self.metrics_file, 'w') as f:
            json.dump(metrics_data, f, indent=2)
        
        return {"success": True}
    
    def get_recent_metrics(self) -> List[Dict[str, Any]]:
        with open(self.metrics_file, 'r') as f:
            metrics_data = json.load(f)
        return metrics_data.get('metrics_history', [])[-20:]
    
    def get_alerts(self) -> List[Dict[str, Any]]:
        with open(self.metrics_file, 'r') as f:
            metrics_data = json.load(f)
        return metrics_data.get('alerts', [])[-20:]
