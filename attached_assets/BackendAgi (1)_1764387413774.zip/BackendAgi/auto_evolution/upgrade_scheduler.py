import os
import json
from typing import Dict, Any, List, Optional
from datetime import datetime

class UpgradeScheduler:
    def __init__(self):
        self.auto_evo_dir = 'auto_evolution'
        self.schedule_file = os.path.join(self.auto_evo_dir, 'upgrade_schedule.json')
        
        os.makedirs(self.auto_evo_dir, exist_ok=True)
        
        self._init_schedule()
    
    def _init_schedule(self):
        if not os.path.exists(self.schedule_file):
            with open(self.schedule_file, 'w') as f:
                json.dump({
                    "scheduled_upgrades": [],
                    "completed_upgrades": [],
                    "total_scheduled": 0
                }, f, indent=2)
    
    def schedule_upgrade(self, task: Dict[str, Any]) -> Dict[str, Any]:
        with open(self.schedule_file, 'r') as f:
            schedule_data = json.load(f)
        
        upgrade_task = {
            "id": f"upgrade_task_{schedule_data['total_scheduled'] + 1}",
            "module": task.get('module', 'unknown'),
            "action": task.get('action', 'optimize'),
            "priority": task.get('priority', 'medium'),
            "dependencies": task.get('dependencies', []),
            "scheduled_at": datetime.now().isoformat(),
            "status": "scheduled",
            "estimated_time": task.get('estimated_time', '30m')
        }
        
        schedule_data['scheduled_upgrades'].append(upgrade_task)
        schedule_data['total_scheduled'] += 1
        
        with open(self.schedule_file, 'w') as f:
            json.dump(schedule_data, f, indent=2)
        
        return {
            "success": True,
            "upgrade_task": upgrade_task
        }
    
    def prioritize_upgrade_tasks(self) -> List[Dict[str, Any]]:
        with open(self.schedule_file, 'r') as f:
            schedule_data = json.load(f)
        
        scheduled_tasks = [
            t for t in schedule_data['scheduled_upgrades']
            if t['status'] == 'scheduled'
        ]
        
        priority_order = {'critical': 0, 'high': 1, 'medium': 2, 'low': 3}
        
        prioritized = sorted(
            scheduled_tasks,
            key=lambda t: (priority_order.get(t['priority'], 3), t['scheduled_at'])
        )
        
        return prioritized
    
    def optimize_upgrade_workflow(self) -> Dict[str, Any]:
        prioritized_tasks = self.prioritize_upgrade_tasks()
        
        optimized_workflow = {
            "timestamp": datetime.now().isoformat(),
            "total_tasks": len(prioritized_tasks),
            "task_groups": [],
            "estimated_total_time": 0
        }
        
        independent_tasks = []
        dependent_tasks = []
        
        for task in prioritized_tasks:
            if not task.get('dependencies'):
                independent_tasks.append(task)
            else:
                dependent_tasks.append(task)
        
        if independent_tasks:
            optimized_workflow['task_groups'].append({
                "group": "parallel_execution",
                "tasks": independent_tasks[:3],
                "can_run_parallel": True
            })
        
        if dependent_tasks:
            optimized_workflow['task_groups'].append({
                "group": "sequential_execution",
                "tasks": dependent_tasks,
                "can_run_parallel": False
            })
        
        return optimized_workflow
    
    def execute_upgrade_task(self, task_id: str) -> Dict[str, Any]:
        with open(self.schedule_file, 'r') as f:
            schedule_data = json.load(f)
        
        task = None
        for t in schedule_data['scheduled_upgrades']:
            if t['id'] == task_id:
                task = t
                break
        
        if not task:
            return {"success": False, "error": "Task not found"}
        
        task['status'] = 'executing'
        task['execution_started'] = datetime.now().isoformat()
        
        with open(self.schedule_file, 'w') as f:
            json.dump(schedule_data, f, indent=2)
        
        result = self._execute_task(task)
        
        with open(self.schedule_file, 'r') as f:
            schedule_data = json.load(f)
        
        for t in schedule_data['scheduled_upgrades']:
            if t['id'] == task_id:
                t['status'] = 'completed'
                t['execution_completed'] = datetime.now().isoformat()
                t['result'] = result
                
                schedule_data['completed_upgrades'].append(t)
                break
        
        schedule_data['scheduled_upgrades'] = [
            t for t in schedule_data['scheduled_upgrades']
            if t['id'] != task_id
        ]
        
        with open(self.schedule_file, 'w') as f:
            json.dump(schedule_data, f, indent=2)
        
        return {
            "success": True,
            "task_id": task_id,
            "result": result
        }
    
    def _execute_task(self, task: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "module": task['module'],
            "action": task['action'],
            "status": "completed",
            "improvements": ["performance_optimized", "code_refactored"]
        }
    
    def get_scheduled_tasks(self) -> List[Dict[str, Any]]:
        with open(self.schedule_file, 'r') as f:
            schedule_data = json.load(f)
        return schedule_data.get('scheduled_upgrades', [])
    
    def get_completed_upgrades(self) -> List[Dict[str, Any]]:
        with open(self.schedule_file, 'r') as f:
            schedule_data = json.load(f)
        return schedule_data.get('completed_upgrades', [])[-20:]
