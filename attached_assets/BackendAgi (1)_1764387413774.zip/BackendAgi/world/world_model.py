import os
import json
import psutil
import time
from typing import Dict, Any, List, Optional
from datetime import datetime
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

class WorldModel:
    def __init__(self):
        api_key = os.getenv('OPENAI_API_KEY')
        if not api_key:
            raise ValueError("OPENAI_API_KEY not found")
        
        self.client = OpenAI(api_key=api_key)
        self.model = os.getenv('OPENAI_MODEL', 'gpt-4o-mini')
        
        self.world_dir = 'world'
        self.system_state_file = os.path.join(self.world_dir, 'system_state.json')
        self.actors_file = os.path.join(self.world_dir, 'actors.json')
        self.predictions_file = os.path.join(self.world_dir, 'predictions.json')
        
        os.makedirs(self.world_dir, exist_ok=True)
        
        self._init_world_files()
    
    def _init_world_files(self):
        if not os.path.exists(self.system_state_file):
            with open(self.system_state_file, 'w') as f:
                json.dump({
                    "initialized": datetime.now().isoformat(),
                    "snapshots": []
                }, f, indent=2)
        
        if not os.path.exists(self.actors_file):
            with open(self.actors_file, 'w') as f:
                json.dump({
                    "initialized": datetime.now().isoformat(),
                    "actors": {}
                }, f, indent=2)
        
        if not os.path.exists(self.predictions_file):
            with open(self.predictions_file, 'w') as f:
                json.dump({
                    "initialized": datetime.now().isoformat(),
                    "predictions": []
                }, f, indent=2)
    
    def scan_system_state(self) -> Dict[str, Any]:
        cpu_percent = psutil.cpu_percent(interval=1)
        memory = psutil.virtual_memory()
        disk = psutil.disk_usage('/')
        
        try:
            network = psutil.net_io_counters()
            network_stats = {
                "bytes_sent": network.bytes_sent,
                "bytes_recv": network.bytes_recv,
                "packets_sent": network.packets_sent,
                "packets_recv": network.packets_recv
            }
        except:
            network_stats = None
        
        snapshot = {
            "timestamp": datetime.now().isoformat(),
            "cpu": {
                "percent": cpu_percent,
                "status": "critical" if cpu_percent > 90 else "warning" if cpu_percent > 70 else "normal"
            },
            "memory": {
                "total": memory.total,
                "available": memory.available,
                "percent": memory.percent,
                "status": "critical" if memory.percent > 90 else "warning" if memory.percent > 70 else "normal"
            },
            "disk": {
                "total": disk.total,
                "used": disk.used,
                "free": disk.free,
                "percent": disk.percent,
                "status": "critical" if disk.percent > 90 else "warning" if disk.percent > 70 else "normal"
            },
            "network": network_stats,
            "processes": len(psutil.pids()),
            "health_score": self._calculate_health_score(cpu_percent, memory.percent, disk.percent)
        }
        
        with open(self.system_state_file, 'r') as f:
            data = json.load(f)
        
        data["snapshots"].append(snapshot)
        
        if len(data["snapshots"]) > 100:
            data["snapshots"] = data["snapshots"][-100:]
        
        with open(self.system_state_file, 'w') as f:
            json.dump(data, f, indent=2)
        
        return snapshot
    
    def _calculate_health_score(self, cpu: float, memory: float, disk: float) -> int:
        score = 100
        
        score -= min(cpu, 100) * 0.3
        score -= min(memory, 100) * 0.4
        score -= min(disk, 100) * 0.3
        
        return max(0, int(score))
    
    def analyze_actors(self, event: Dict[str, Any]) -> Dict[str, Any]:
        actor_id = event.get('actor_id', 'unknown')
        actor_type = event.get('actor_type', 'user')
        source = event.get('source', 'unknown')
        
        with open(self.actors_file, 'r') as f:
            data = json.load(f)
        
        if actor_id not in data["actors"]:
            data["actors"][actor_id] = {
                "id": actor_id,
                "type": actor_type,
                "first_seen": datetime.now().isoformat(),
                "last_seen": datetime.now().isoformat(),
                "interaction_count": 0,
                "trust_score": 50,
                "permission": "read",
                "source": source,
                "risk_events": 0,
                "good_events": 0
            }
        
        actor = data["actors"][actor_id]
        actor["last_seen"] = datetime.now().isoformat()
        actor["interaction_count"] += 1
        
        trust_score = self._calculate_trust_score(actor, event)
        actor["trust_score"] = trust_score
        
        event_risk = event.get('risk_level', 0)
        if event_risk > 50:
            actor["risk_events"] += 1
        else:
            actor["good_events"] += 1
        
        if actor["trust_score"] >= 80:
            actor["permission"] = "admin"
        elif actor["trust_score"] >= 60:
            actor["permission"] = "write"
        else:
            actor["permission"] = "read"
        
        with open(self.actors_file, 'w') as f:
            json.dump(data, f, indent=2)
        
        return actor
    
    def _calculate_trust_score(self, actor: Dict[str, Any], event: Dict[str, Any]) -> int:
        score = actor.get("trust_score", 50)
        
        good_events = actor.get("good_events", 0)
        risk_events = actor.get("risk_events", 0)
        
        if good_events > 0:
            score += min(good_events * 2, 20)
        
        if risk_events > 0:
            score -= min(risk_events * 5, 30)
        
        interaction_count = actor.get("interaction_count", 0)
        if interaction_count > 100:
            score += 10
        elif interaction_count > 50:
            score += 5
        
        event_risk = event.get('risk_level', 0)
        if event_risk > 70:
            score -= 10
        elif event_risk < 20:
            score += 5
        
        return max(0, min(100, score))
    
    def predict_risk(self, context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        system_state = self.scan_system_state()
        
        risk_factors = []
        risk_score = 0
        
        if system_state["cpu"]["status"] == "critical":
            risk_factors.append("CPU overload")
            risk_score += 30
        elif system_state["cpu"]["status"] == "warning":
            risk_factors.append("CPU high")
            risk_score += 15
        
        if system_state["memory"]["status"] == "critical":
            risk_factors.append("Memory critical")
            risk_score += 35
        elif system_state["memory"]["status"] == "warning":
            risk_factors.append("Memory high")
            risk_score += 20
        
        if system_state["disk"]["status"] == "critical":
            risk_factors.append("Disk full")
            risk_score += 25
        elif system_state["disk"]["status"] == "warning":
            risk_factors.append("Disk high")
            risk_score += 10
        
        if context:
            actor_trust = context.get('actor_trust', 50)
            if actor_trust < 30:
                risk_factors.append("Low trust actor")
                risk_score += 20
            
            event_type = context.get('event_type', '')
            if event_type in ['SECURITY_ALERT', 'ERROR']:
                risk_factors.append(f"High risk event: {event_type}")
                risk_score += 15
        
        prediction = {
            "timestamp": datetime.now().isoformat(),
            "risk_score": min(100, risk_score),
            "risk_level": "critical" if risk_score > 70 else "high" if risk_score > 50 else "medium" if risk_score > 30 else "low",
            "risk_factors": risk_factors,
            "system_health": system_state["health_score"],
            "recommendations": self._generate_recommendations(risk_score, risk_factors)
        }
        
        with open(self.predictions_file, 'r') as f:
            data = json.load(f)
        
        data["predictions"].append(prediction)
        
        if len(data["predictions"]) > 50:
            data["predictions"] = data["predictions"][-50:]
        
        with open(self.predictions_file, 'w') as f:
            json.dump(data, f, indent=2)
        
        return prediction
    
    def _generate_recommendations(self, risk_score: int, risk_factors: List[str]) -> List[str]:
        recommendations = []
        
        if risk_score > 70:
            recommendations.append("CRITICAL: Immediate action required")
            recommendations.append("Trigger auto-evolution cycle")
            recommendations.append("Enable enhanced monitoring")
        elif risk_score > 50:
            recommendations.append("WARNING: Monitor closely")
            recommendations.append("Consider optimization")
        
        for factor in risk_factors:
            if "CPU" in factor:
                recommendations.append("Optimize CPU-intensive tasks")
            if "Memory" in factor:
                recommendations.append("Run memory cleanup")
            if "Disk" in factor:
                recommendations.append("Clean old logs and backups")
            if "trust" in factor.lower():
                recommendations.append("Increase security checks")
        
        return recommendations
    
    def decide_action(self, event: Dict[str, Any]) -> Dict[str, Any]:
        actor = self.analyze_actors(event)
        
        risk_context = {
            "actor_trust": actor.get("trust_score", 50),
            "event_type": event.get("type", "unknown")
        }
        
        prediction = self.predict_risk(risk_context)
        
        decision = {
            "timestamp": datetime.now().isoformat(),
            "event_id": event.get("id", "unknown"),
            "actor_id": actor.get("id", "unknown"),
            "actor_trust": actor.get("trust_score", 50),
            "risk_score": prediction["risk_score"],
            "risk_level": prediction["risk_level"],
            "action": None,
            "reasoning": []
        }
        
        if prediction["risk_score"] > 80:
            decision["action"] = "block"
            decision["reasoning"].append("Critical risk level")
        elif prediction["risk_score"] > 60:
            decision["action"] = "alert"
            decision["reasoning"].append("High risk - alert admin")
        elif prediction["risk_score"] > 40:
            decision["action"] = "log"
            decision["reasoning"].append("Medium risk - log for monitoring")
        else:
            decision["action"] = "allow"
            decision["reasoning"].append("Low risk - allow normally")
        
        if actor["trust_score"] < 30:
            decision["action"] = "block" if decision["action"] != "block" else "block"
            decision["reasoning"].append("Low trust actor")
        
        if actor["permission"] == "admin" and prediction["risk_score"] < 50:
            decision["action"] = "allow"
            decision["reasoning"].append("Trusted admin override")
        
        return decision
    
    def update_world_model(self, event: Dict[str, Any]) -> Dict[str, Any]:
        system_snapshot = self.scan_system_state()
        
        actor_analysis = self.analyze_actors(event)
        
        prediction = self.predict_risk({
            "actor_trust": actor_analysis.get("trust_score", 50),
            "event_type": event.get("type", "unknown")
        })
        
        return {
            "timestamp": datetime.now().isoformat(),
            "event_id": event.get("id", "unknown"),
            "system_state": system_snapshot,
            "actor": actor_analysis,
            "prediction": prediction,
            "status": "updated"
        }
    
    def get_current_state(self) -> Dict[str, Any]:
        with open(self.system_state_file, 'r') as f:
            system_data = json.load(f)
        
        with open(self.actors_file, 'r') as f:
            actors_data = json.load(f)
        
        with open(self.predictions_file, 'r') as f:
            predictions_data = json.load(f)
        
        latest_snapshot = system_data["snapshots"][-1] if system_data["snapshots"] else None
        latest_prediction = predictions_data["predictions"][-1] if predictions_data["predictions"] else None
        
        return {
            "system_state": latest_snapshot,
            "total_actors": len(actors_data["actors"]),
            "latest_prediction": latest_prediction,
            "world_health": latest_snapshot["health_score"] if latest_snapshot else 0
        }
    
    def get_actor_stats(self) -> Dict[str, Any]:
        with open(self.actors_file, 'r') as f:
            data = json.load(f)
        
        actors = data["actors"]
        
        return {
            "total_actors": len(actors),
            "trusted_actors": len([a for a in actors.values() if a.get("trust_score", 0) >= 70]),
            "suspicious_actors": len([a for a in actors.values() if a.get("trust_score", 0) < 40]),
            "admin_actors": len([a for a in actors.values() if a.get("permission") == "admin"]),
            "top_actors": sorted(
                actors.values(),
                key=lambda x: x.get("interaction_count", 0),
                reverse=True
            )[:10]
        }
