import os
import json
from typing import Dict, Any, List, Optional
from datetime import datetime
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

class BehaviorAdapter:
    def __init__(self):
        api_key = os.getenv('OPENAI_API_KEY')
        if not api_key:
            raise ValueError("OPENAI_API_KEY not found")
        
        self.client = OpenAI(api_key=api_key)
        self.model = os.getenv('OPENAI_MODEL', 'gpt-4o-mini')
        
        self.social_dir = 'social'
        os.makedirs(self.social_dir, exist_ok=True)
    
    def _get_personality_traits(self) -> Dict[str, Any]:
        traits_file = 'personality/core_traits.json'
        
        if not os.path.exists(traits_file):
            return {
                "curiosity": 85,
                "caution": 70,
                "humor": 90,
                "skepticism": 95,
                "business_mindset": 88,
                "hacker_instinct": 92
            }
        
        with open(traits_file, 'r') as f:
            return json.load(f)
    
    def _get_emotional_state(self) -> Dict[str, Any]:
        emotions_file = 'emotions/state.json'
        
        if not os.path.exists(emotions_file):
            return {
                "stress_level": 30,
                "confidence": 80,
                "alertness": 75
            }
        
        with open(emotions_file, 'r') as f:
            return json.load(f)
    
    def adapt_behavior(self, input_context: Dict[str, Any]) -> Dict[str, Any]:
        traits = self._get_personality_traits()
        emotions = self._get_emotional_state()
        
        behavior = {
            "timestamp": datetime.now().isoformat(),
            "tone": "neutral",
            "style": "casual",
            "humor_level": 0,
            "skepticism_level": 0,
            "professionalism": 50,
            "intensity": 50
        }
        
        humor = traits.get('humor', 50)
        skepticism = traits.get('skepticism', 50)
        business = traits.get('business_mindset', 50)
        hacker = traits.get('hacker_instinct', 50)
        
        stress = emotions.get('stress_level', 30)
        confidence = emotions.get('confidence', 80)
        alertness = emotions.get('alertness', 75)
        
        threat_score = input_context.get('threat_score', 0)
        sentiment = input_context.get('sentiment', 'neutral')
        platform = input_context.get('platform', 'unknown')
        
        if threat_score > 70:
            behavior['tone'] = 'defensive'
            behavior['skepticism_level'] = 100
            behavior['humor_level'] = 0
            behavior['professionalism'] = 30
        elif threat_score > 40:
            behavior['tone'] = 'cautious'
            behavior['skepticism_level'] = 80
            behavior['humor_level'] = 20
        else:
            if humor > 80:
                behavior['humor_level'] = 70
                behavior['style'] = 'witty'
            
            if skepticism > 90:
                behavior['skepticism_level'] = 60
                behavior['tone'] = 'questioning'
            
            if business > 85:
                behavior['professionalism'] = 70
                behavior['style'] = 'professional_casual'
        
        if stress > 70:
            behavior['intensity'] = 30
            behavior['tone'] = 'brief'
        elif confidence > 80:
            behavior['intensity'] = 70
            behavior['tone'] = 'confident'
        
        if platform in ['facebook', 'tiktok']:
            behavior['humor_level'] = min(100, behavior['humor_level'] + 20)
            behavior['style'] = 'gen_z'
        elif platform == 'gmail':
            behavior['professionalism'] = min(100, behavior['professionalism'] + 30)
            behavior['humor_level'] = max(0, behavior['humor_level'] - 20)
        
        return behavior
    
    def generate_response(self, input_message: str, context: Dict[str, Any]) -> str:
        behavior = self.adapt_behavior(context)
        traits = self._get_personality_traits()
        
        personality_desc = f"""Bạn là CipherH, một AI agent với tính cách:
- Skepticism: {traits.get('skepticism', 95)}/100 (hoài nghi cao, luôn đặt câu hỏi)
- Humor: {traits.get('humor', 90)}/100 (châm biếm, witty, Gen Z)
- Hacker instinct: {traits.get('hacker_instinct', 92)}/100 (tư duy unconventional)
- Business mindset: {traits.get('business_mindset', 88)}/100 (focus ROI, practical)

Behavior hiện tại:
- Tone: {behavior['tone']}
- Style: {behavior['style']}
- Humor level: {behavior['humor_level']}/100
- Skepticism level: {behavior['skepticism_level']}/100
- Professionalism: {behavior['professionalism']}/100

Trả lời ngắn gọn, sắc sảo, tiếng Việt."""
        
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": personality_desc},
                    {"role": "user", "content": input_message}
                ],
                temperature=0.8,
                max_tokens=200
            )
            
            content = response.choices[0].message.content
            return content.strip() if content else "..."
        
        except Exception as e:
            return f"Lỗi: {str(e)}"
    
    def detect_intent(self, message: str) -> Dict[str, Any]:
        intents = {
            "question": ["?", "sao", "tại sao", "làm sao", "how", "why", "what"],
            "request": ["giúp", "làm", "tạo", "build", "help", "create", "make"],
            "greeting": ["hi", "hello", "chào", "hey"],
            "complaint": ["lỗi", "bug", "sai", "không hoạt động", "error", "fail"],
            "spam": ["khuyến mãi", "giảm giá", "mua ngay", "promotion", "sale"]
        }
        
        message_lower = message.lower()
        
        detected = []
        for intent, keywords in intents.items():
            for keyword in keywords:
                if keyword in message_lower:
                    detected.append(intent)
                    break
        
        return {
            "intents": detected if detected else ["unknown"],
            "primary_intent": detected[0] if detected else "unknown"
        }
    
    def analyze_sentiment(self, message: str) -> str:
        positive_words = ["tốt", "hay", "good", "great", "excellent", "cảm ơn", "thanks"]
        negative_words = ["tệ", "bad", "terrible", "lỗi", "sai", "error", "fail"]
        
        message_lower = message.lower()
        
        positive_count = sum(1 for word in positive_words if word in message_lower)
        negative_count = sum(1 for word in negative_words if word in message_lower)
        
        if positive_count > negative_count:
            return "positive"
        elif negative_count > positive_count:
            return "negative"
        else:
            return "neutral"
    
    def calculate_threat_score(self, message: str, context: Dict[str, Any]) -> int:
        threat_keywords = [
            "hack", "attack", "phishing", "scam", "lừa đảo",
            "password", "mật khẩu", "credit card", "bank account"
        ]
        
        message_lower = message.lower()
        
        threat_score = 0
        
        for keyword in threat_keywords:
            if keyword in message_lower:
                threat_score += 30
        
        if len(message) > 500:
            threat_score += 10
        
        if message.count('http') > 2:
            threat_score += 20
        
        return min(100, threat_score)
