import os
import json
from typing import Dict, Any, List, Optional
from datetime import datetime

class InteractionLogger:
    def __init__(self):
        self.social_dir = 'social'
        self.log_file = os.path.join(self.social_dir, 'interaction_logs.json')
        self.pattern_file = os.path.join(self.social_dir, 'interaction_patterns.json')
        
        os.makedirs(self.social_dir, exist_ok=True)
        
        self._init_files()
    
    def _init_files(self):
        if not os.path.exists(self.log_file):
            with open(self.log_file, 'w') as f:
                json.dump({
                    "interactions": [],
                    "total_interactions": 0
                }, f, indent=2)
        
        if not os.path.exists(self.pattern_file):
            with open(self.pattern_file, 'w') as f:
                json.dump({
                    "patterns": [],
                    "success_rate": {},
                    "platform_stats": {}
                }, f, indent=2)
    
    def log_interaction(self, event: Dict[str, Any]) -> Dict[str, Any]:
        with open(self.log_file, 'r') as f:
            log_data = json.load(f)
        
        interaction = {
            "id": f"int_{log_data['total_interactions'] + 1}",
            "timestamp": datetime.now().isoformat(),
            "platform": event.get('platform', 'unknown'),
            "input": event.get('input', ''),
            "output": event.get('output', ''),
            "behavior": event.get('behavior', {}),
            "intent": event.get('intent', 'unknown'),
            "sentiment": event.get('sentiment', 'neutral'),
            "threat_score": event.get('threat_score', 0),
            "success": event.get('success', True)
        }
        
        log_data['interactions'].append(interaction)
        log_data['total_interactions'] += 1
        
        if len(log_data['interactions']) > 1000:
            log_data['interactions'] = log_data['interactions'][-1000:]
        
        with open(self.log_file, 'w') as f:
            json.dump(log_data, f, indent=2)
        
        self._store_to_memory(interaction)
        
        return interaction
    
    def _store_to_memory(self, interaction: Dict[str, Any]):
        memory_file = 'memory/stm.json'
        
        if not os.path.exists(memory_file):
            return
        
        try:
            with open(memory_file, 'r') as f:
                stm = json.load(f)
            
            memory_entry = {
                "timestamp": interaction['timestamp'],
                "type": "social_interaction",
                "platform": interaction['platform'],
                "content": f"Input: {interaction['input'][:100]}... Output: {interaction['output'][:100]}...",
                "importance": 60 if interaction['success'] else 40
            }
            
            stm['memories'].append(memory_entry)
            
            if len(stm['memories']) > 100:
                stm['memories'] = stm['memories'][-100:]
            
            with open(memory_file, 'w') as f:
                json.dump(stm, f, indent=2)
        
        except Exception:
            pass
    
    def learn_interaction_pattern(self) -> Dict[str, Any]:
        with open(self.log_file, 'r') as f:
            log_data = json.load(f)
        
        interactions = log_data.get('interactions', [])
        
        if len(interactions) < 5:
            return {
                "status": "insufficient_data",
                "patterns": []
            }
        
        patterns = {
            "platform_performance": {},
            "intent_success_rate": {},
            "threat_handling": {},
            "common_topics": []
        }
        
        platform_stats = {}
        for interaction in interactions:
            platform = interaction.get('platform', 'unknown')
            if platform not in platform_stats:
                platform_stats[platform] = {
                    "total": 0,
                    "successful": 0
                }
            
            platform_stats[platform]['total'] += 1
            if interaction.get('success', False):
                platform_stats[platform]['successful'] += 1
        
        for platform, stats in platform_stats.items():
            success_rate = (stats['successful'] / stats['total'] * 100) if stats['total'] > 0 else 0
            patterns['platform_performance'][platform] = {
                "total_interactions": stats['total'],
                "success_rate": round(success_rate, 2)
            }
        
        intent_stats = {}
        for interaction in interactions:
            intent = interaction.get('intent', 'unknown')
            if intent not in intent_stats:
                intent_stats[intent] = {
                    "total": 0,
                    "successful": 0
                }
            
            intent_stats[intent]['total'] += 1
            if interaction.get('success', False):
                intent_stats[intent]['successful'] += 1
        
        for intent, stats in intent_stats.items():
            success_rate = (stats['successful'] / stats['total'] * 100) if stats['total'] > 0 else 0
            patterns['intent_success_rate'][intent] = round(success_rate, 2)
        
        high_threat = [i for i in interactions if i.get('threat_score', 0) > 50]
        patterns['threat_handling'] = {
            "total_threats": len(high_threat),
            "handled_successfully": sum(1 for i in high_threat if i.get('success', False))
        }
        
        with open(self.pattern_file, 'r') as f:
            pattern_data = json.load(f)
        
        pattern_data['patterns'].append({
            "timestamp": datetime.now().isoformat(),
            "analysis": patterns
        })
        
        if len(pattern_data['patterns']) > 50:
            pattern_data['patterns'] = pattern_data['patterns'][-50:]
        
        pattern_data['success_rate'] = patterns['intent_success_rate']
        pattern_data['platform_stats'] = patterns['platform_performance']
        
        with open(self.pattern_file, 'w') as f:
            json.dump(pattern_data, f, indent=2)
        
        return patterns
    
    def get_interaction_stats(self) -> Dict[str, Any]:
        with open(self.log_file, 'r') as f:
            log_data = json.load(f)
        
        interactions = log_data.get('interactions', [])
        
        successful = sum(1 for i in interactions if i.get('success', False))
        total = len(interactions)
        
        return {
            "total_interactions": total,
            "successful_interactions": successful,
            "success_rate": (successful / total * 100) if total > 0 else 0,
            "platforms": list(set(i.get('platform', 'unknown') for i in interactions))
        }
