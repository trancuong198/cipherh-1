import os
import json
from typing import Dict, Any, List, Optional
from datetime import datetime

class ReflectionEvaluator:
    def __init__(self):
        self.metacog2_dir = 'metacognition2'
        self.evaluation_file = os.path.join(self.metacog2_dir, 'evaluations.json')
        
        os.makedirs(self.metacog2_dir, exist_ok=True)
        
        self._init_evaluations()
    
    def _init_evaluations(self):
        if not os.path.exists(self.evaluation_file):
            with open(self.evaluation_file, 'w') as f:
                json.dump({
                    "evaluations": [],
                    "total_evaluations": 0
                }, f, indent=2)
    
    def evaluate_performance(self, module_name: str) -> Dict[str, Any]:
        evaluation = {
            "id": f"eval_{self._get_next_id()}",
            "timestamp": datetime.now().isoformat(),
            "module": module_name,
            "logic_analysis": {},
            "efficiency_analysis": {},
            "emotional_bias": {},
            "overall_score": 0,
            "issues_found": [],
            "recommendations": []
        }
        
        evaluation['logic_analysis'] = self._analyze_logic(module_name)
        evaluation['efficiency_analysis'] = self._analyze_efficiency(module_name)
        evaluation['emotional_bias'] = self._analyze_emotional_bias(module_name)
        
        scores = [
            evaluation['logic_analysis'].get('score', 75),
            evaluation['efficiency_analysis'].get('score', 75),
            100 - evaluation['emotional_bias'].get('bias_level', 25)
        ]
        evaluation['overall_score'] = sum(scores) / len(scores)
        
        if evaluation['logic_analysis'].get('flaws'):
            evaluation['issues_found'].extend(evaluation['logic_analysis']['flaws'])
        
        if evaluation['efficiency_analysis'].get('bottlenecks'):
            evaluation['issues_found'].extend(evaluation['efficiency_analysis']['bottlenecks'])
        
        if evaluation['emotional_bias'].get('bias_level', 0) > 30:
            evaluation['issues_found'].append("high_emotional_bias")
        
        evaluation['recommendations'] = self._generate_recommendations(evaluation)
        
        with open(self.evaluation_file, 'r') as f:
            eval_data = json.load(f)
        
        eval_data['evaluations'].append(evaluation)
        eval_data['total_evaluations'] += 1
        
        if len(eval_data['evaluations']) > 100:
            eval_data['evaluations'] = eval_data['evaluations'][-100:]
        
        with open(self.evaluation_file, 'w') as f:
            json.dump(eval_data, f, indent=2)
        
        return evaluation
    
    def _analyze_logic(self, module: str) -> Dict[str, Any]:
        score = 80
        flaws = []
        
        if module in ['memory_engine', 'ltm_map']:
            if not os.path.exists(f'{module.replace("_", "/")}.json'):
                flaws.append("data_persistence_issue")
                score -= 15
        
        if module == 'task_chain':
            flaws.append("potential_race_condition")
            score -= 10
        
        return {
            "score": score,
            "flaws": flaws,
            "consistency": "high" if score > 80 else "medium"
        }
    
    def _analyze_efficiency(self, module: str) -> Dict[str, Any]:
        score = 75
        bottlenecks = []
        
        if module in ['evolution', 'metacognition']:
            bottlenecks.append("heavy_computation")
            score -= 10
        
        if module == 'social':
            bottlenecks.append("external_api_latency")
            score -= 5
        
        return {
            "score": score,
            "bottlenecks": bottlenecks,
            "optimization_potential": 100 - score
        }
    
    def _analyze_emotional_bias(self, module: str) -> Dict[str, Any]:
        emotions_file = 'emotions/state.json'
        
        if not os.path.exists(emotions_file):
            return {
                "bias_level": 0,
                "bias_type": "none"
            }
        
        try:
            with open(emotions_file, 'r') as f:
                emotions = json.load(f)
            
            stress = emotions.get('stress_level', 0)
            confidence = emotions.get('confidence', 80)
            
            bias_level = 0
            bias_type = "none"
            
            if stress > 70:
                bias_level = 40
                bias_type = "stress_induced"
            elif confidence < 40:
                bias_level = 30
                bias_type = "low_confidence"
            
            return {
                "bias_level": bias_level,
                "bias_type": bias_type,
                "stress_level": stress,
                "confidence_level": confidence
            }
        
        except Exception:
            return {
                "bias_level": 0,
                "bias_type": "none"
            }
    
    def _generate_recommendations(self, evaluation: Dict[str, Any]) -> List[str]:
        recommendations = []
        
        if evaluation['overall_score'] < 70:
            recommendations.append("comprehensive_refactor_needed")
        
        if evaluation['logic_analysis'].get('flaws'):
            recommendations.append("fix_logic_flaws")
        
        if evaluation['efficiency_analysis'].get('bottlenecks'):
            recommendations.append("optimize_performance")
        
        if evaluation['emotional_bias'].get('bias_level', 0) > 30:
            recommendations.append("regulate_emotional_state")
        
        return recommendations
    
    def _get_next_id(self) -> int:
        with open(self.evaluation_file, 'r') as f:
            eval_data = json.load(f)
        return eval_data['total_evaluations'] + 1
    
    def get_evaluations(self) -> List[Dict[str, Any]]:
        with open(self.evaluation_file, 'r') as f:
            eval_data = json.load(f)
        return eval_data.get('evaluations', [])[-20:]
