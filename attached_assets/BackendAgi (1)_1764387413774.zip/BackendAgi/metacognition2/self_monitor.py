import os
import json
from typing import Dict, Any, List, Optional
from datetime import datetime

class SelfMonitor:
    def __init__(self):
        self.metacog2_dir = 'metacognition2'
        self.metrics_file = os.path.join(self.metacog2_dir, 'realtime_metrics.json')
        
        os.makedirs(self.metacog2_dir, exist_ok=True)
        
        self._init_metrics()
    
    def _init_metrics(self):
        if not os.path.exists(self.metrics_file):
            with open(self.metrics_file, 'w') as f:
                json.dump({
                    "current_metrics": {
                        "task_success_rate": 75,
                        "logic_consistency": 80,
                        "emotional_stability": 70,
                        "security_alertness": 85,
                        "social_interaction_quality": 78
                    },
                    "module_metrics": {},
                    "history": [],
                    "last_update": None
                }, f, indent=2)
    
    def monitor_all_modules(self) -> Dict[str, Any]:
        modules = [
            'memory_engine',
            'emotional_model',
            'task_chain',
            'personality_core',
            'world_model',
            'defense_firewall',
            'metacognition',
            'ltm_map',
            'evolution',
            'social',
            'security'
        ]
        
        monitoring_report = {
            "timestamp": datetime.now().isoformat(),
            "modules_monitored": len(modules),
            "module_status": {},
            "overall_health": 0
        }
        
        total_health = 0
        
        for module in modules:
            status = self._check_module_health(module)
            monitoring_report['module_status'][module] = status
            total_health += status['health_score']
        
        monitoring_report['overall_health'] = total_health / len(modules)
        
        with open(self.metrics_file, 'r') as f:
            metrics_data = json.load(f)
        
        metrics_data['module_metrics'] = monitoring_report['module_status']
        metrics_data['last_update'] = datetime.now().isoformat()
        
        metrics_data['history'].append({
            "timestamp": datetime.now().isoformat(),
            "overall_health": monitoring_report['overall_health']
        })
        
        if len(metrics_data['history']) > 100:
            metrics_data['history'] = metrics_data['history'][-100:]
        
        with open(self.metrics_file, 'w') as f:
            json.dump(metrics_data, f, indent=2)
        
        return monitoring_report
    
    def _check_module_health(self, module: str) -> Dict[str, Any]:
        health_score = 75
        issues = []
        
        if module == 'memory_engine':
            if self._check_file_exists('memory/stm.json'):
                health_score = 85
            else:
                issues.append("stm_file_missing")
                health_score = 60
        
        elif module == 'emotional_model':
            if self._check_file_exists('emotions/state.json'):
                health_score = 80
            else:
                issues.append("emotion_state_missing")
                health_score = 65
        
        elif module == 'security':
            if self._check_file_exists('security/hacker_insights.json'):
                health_score = 90
            else:
                issues.append("security_insights_missing")
                health_score = 70
        
        elif module == 'social':
            if self._check_file_exists('social/interaction_logs.json'):
                health_score = 82
            else:
                issues.append("interaction_logs_missing")
                health_score = 68
        
        return {
            "health_score": health_score,
            "status": "healthy" if health_score > 70 else "degraded",
            "issues": issues
        }
    
    def _check_file_exists(self, filepath: str) -> bool:
        return os.path.exists(filepath)
    
    def get_current_metrics(self) -> Dict[str, Any]:
        with open(self.metrics_file, 'r') as f:
            metrics_data = json.load(f)
        
        return metrics_data['current_metrics']
    
    def update_metric(self, metric_name: str, value: float) -> Dict[str, Any]:
        with open(self.metrics_file, 'r') as f:
            metrics_data = json.load(f)
        
        metrics_data['current_metrics'][metric_name] = value
        metrics_data['last_update'] = datetime.now().isoformat()
        
        with open(self.metrics_file, 'w') as f:
            json.dump(metrics_data, f, indent=2)
        
        return metrics_data['current_metrics']
