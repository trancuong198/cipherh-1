const loggerService = require('../services/loggerService');

async function generateStrategy(logAnalysis) {
  loggerService.info('=== STEP: Generating Strategy ===');
  
  const { patterns = [], insights = '', anomalyScore = 0 } = logAnalysis;
  
  let strategySummary = '';
  let suggestedActions = [];
  
  if (anomalyScore > 0.5) {
    strategySummary = 'Hệ thống có dấu hiệu bất thường. Tập trung ổn định.';
    suggestedActions = [
      'Phân tích lỗi chi tiết',
      'Giảm tải hệ thống',
      'Tăng cường monitoring'
    ];
  } else if (anomalyScore > 0.3) {
    strategySummary = 'Hệ thống ổn định nhưng cần theo dõi.';
    suggestedActions = [
      'Tiếp tục monitoring',
      'Review logs định kỳ',
      'Chuẩn bị kế hoạch phòng ngừa'
    ];
  } else {
    strategySummary = 'Hệ thống hoạt động tốt. Duy trì và mở rộng.';
    suggestedActions = [
      'Tối ưu hiệu suất',
      'Thêm tính năng mới',
      'Cải thiện độ tin cậy'
    ];
  }
  
  const strategy = {
    strategySummary,
    suggestedActions,
    timestamp: new Date().toISOString(),
    anomalyScore
  };
  
  loggerService.info('Strategy generated', { strategy });
  
  return strategy;
}

module.exports = { generateStrategy };
