const loggerService = require('../services/loggerService');

function detectAnomalies(logs) {
  loggerService.info('=== Detecting Anomalies ===', { logCount: logs.length });
  
  const anomalies = [];
  let anomalyScore = 0;
  
  const errorLogs = logs.filter(log => 
    log.content && log.content.toLowerCase().includes('error')
  );
  
  if (errorLogs.length > 5) {
    anomalies.push({
      type: 'high_error_rate',
      severity: 'high',
      description: `Detected ${errorLogs.length} error logs`,
      timestamp: new Date().toISOString()
    });
    anomalyScore += 0.3;
  }
  
  const warningLogs = logs.filter(log =>
    log.content && log.content.toLowerCase().includes('warning')
  );
  
  if (warningLogs.length > 10) {
    anomalies.push({
      type: 'high_warning_rate',
      severity: 'medium',
      description: `Detected ${warningLogs.length} warning logs`,
      timestamp: new Date().toISOString()
    });
    anomalyScore += 0.15;
  }
  
  const repeatedPatterns = findRepeatedPatterns(logs);
  if (repeatedPatterns.length > 0) {
    anomalies.push({
      type: 'repeated_patterns',
      severity: 'medium',
      description: `Found ${repeatedPatterns.length} repeated patterns`,
      patterns: repeatedPatterns,
      timestamp: new Date().toISOString()
    });
    anomalyScore += 0.2;
  }
  
  const result = {
    anomalies,
    anomalyScore: Math.min(1.0, anomalyScore),
    summary: `Detected ${anomalies.length} anomalies with score ${anomalyScore.toFixed(2)}`,
    timestamp: new Date().toISOString()
  };
  
  loggerService.info('Anomaly detection complete', { result });
  
  return result;
}

function findRepeatedPatterns(logs) {
  const patterns = new Map();
  
  logs.forEach(log => {
    if (!log.content) return;
    
    const words = log.content.split(' ').slice(0, 5).join(' ');
    const count = patterns.get(words) || 0;
    patterns.set(words, count + 1);
  });
  
  const repeated = [];
  patterns.forEach((count, pattern) => {
    if (count > 2) {
      repeated.push({ pattern, count });
    }
  });
  
  return repeated;
}

module.exports = {
  detectAnomalies
};
