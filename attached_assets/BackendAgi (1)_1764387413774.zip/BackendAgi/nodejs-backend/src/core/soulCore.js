const loggerService = require('../services/loggerService');

class SoulCore {
  constructor() {
    this.selfModel = {
      version: '1.0.0',
      lastImprovement: new Date().toISOString(),
      weaknesses: [],
      strengths: ['Pattern recognition', 'Log analysis'],
      evolutionHistory: [],
      cycleCount: 0
    };
  }

  async learnFromLogs(logs) {
    loggerService.info('SoulCore: Learning from logs', { logCount: logs.length });

    const patterns = this._extractPatterns(logs);
    const insights = this._generateInsights(patterns);
    const anomalySignals = this._detectAnomalySignals(logs);
    const skepticalQuestions = this._generateSkepticalQuestions(patterns, anomalySignals);

    const analysis = {
      patterns,
      insights,
      anomalySignals,
      skepticalQuestions,
      timestamp: new Date().toISOString(),
      logCount: logs.length
    };

    loggerService.info('Learning complete', {
      patternCount: patterns.length,
      insightCount: insights.length,
      anomalyCount: anomalySignals.length
    });

    return analysis;
  }

  generateDailyLesson(analysis) {
    loggerService.info('SoulCore: Generating daily lesson');

    const { patterns, insights, anomalySignals, skepticalQuestions } = analysis;

    let lesson = `# Bài học rút ra hôm nay\n\n`;
    lesson += `**Ngày:** ${new Date().toLocaleDateString('vi-VN')}\n`;
    lesson += `**Cycle:** ${this.selfModel.cycleCount}\n\n`;

    lesson += `## Patterns phát hiện\n`;
    patterns.slice(0, 5).forEach((p, i) => {
      lesson += `${i + 1}. ${p.description} (xuất hiện ${p.count} lần)\n`;
    });
    lesson += '\n';

    lesson += `## Insights chính\n`;
    insights.slice(0, 3).forEach((insight, i) => {
      lesson += `- **${insight.title}:** ${insight.description}\n`;
    });
    lesson += '\n';

    if (anomalySignals.length > 0) {
      lesson += `## Tín hiệu bất thường\n`;
      anomalySignals.slice(0, 3).forEach(signal => {
        lesson += `- ⚠️ ${signal.type}: ${signal.description}\n`;
      });
      lesson += '\n';
    }

    lesson += `## Câu hỏi tự vấn\n`;
    skepticalQuestions.slice(0, 5).forEach((q, i) => {
      lesson += `${i + 1}. ${q}\n`;
    });
    lesson += '\n';

    lesson += `## Kết luận\n`;
    lesson += this._generateConclusion(analysis);

    loggerService.info('Daily lesson generated', { length: lesson.length });

    return lesson;
  }

  evaluateSelf(analysis) {
    loggerService.info('SoulCore: Evaluating self');

    const { patterns, insights, anomalySignals } = analysis;

    const patternScore = Math.min(10, patterns.length);
    const insightScore = Math.min(10, insights.length * 2);
    const anomalyPenalty = anomalySignals.length * 2;
    
    const rawScore = (patternScore + insightScore - anomalyPenalty) / 2;
    const score = Math.max(1, Math.min(10, Math.round(rawScore)));

    const strengths = [];
    const weaknesses = [];

    if (patterns.length > 5) {
      strengths.push('Phát hiện nhiều patterns');
    } else if (patterns.length < 2) {
      weaknesses.push('Ít patterns được phát hiện');
    }

    if (insights.length > 3) {
      strengths.push('Tạo insights đa dạng');
    } else if (insights.length < 2) {
      weaknesses.push('Insights chưa phong phú');
    }

    if (anomalySignals.length > 5) {
      weaknesses.push('Quá nhiều bất thường');
    } else if (anomalySignals.length === 0) {
      strengths.push('Hệ thống ổn định');
    }

    const warnings = [];
    if (score < 5) {
      warnings.push('Hiệu suất dưới trung bình - cần cải thiện');
    }
    if (anomalySignals.length > 10) {
      warnings.push('Quá nhiều bất thường - nguy cơ mất kiểm soát');
    }

    const evaluation = {
      score,
      status: score >= 7 ? 'good' : score >= 5 ? 'moderate' : 'poor',
      strengths,
      weaknesses,
      warnings,
      timestamp: new Date().toISOString()
    };

    loggerService.info('Self evaluation complete', evaluation);

    return evaluation;
  }

  proposeNewTasks(analysis) {
    loggerService.info('SoulCore: Proposing new tasks');

    const { patterns, anomalySignals, insights } = analysis;
    const tasks = [];

    if (anomalySignals.length > 5) {
      tasks.push({
        type: 'daily',
        priority: 'critical',
        description: 'Phân tích và khắc phục bất thường',
        reason: `Phát hiện ${anomalySignals.length} anomalies`
      });
    }

    if (patterns.length > 7) {
      tasks.push({
        type: 'weekly',
        priority: 'high',
        description: 'Tổng hợp và phân loại patterns',
        reason: 'Nhiều patterns cần tổ chức'
      });
    }

    if (insights.length < 3) {
      tasks.push({
        type: 'daily',
        priority: 'medium',
        description: 'Tăng cường phân tích sâu logs',
        reason: 'Insights còn ít'
      });
    }

    tasks.push({
      type: 'weekly',
      priority: 'medium',
      description: 'Review và cập nhật self model',
      reason: 'Duy trì tiến hóa liên tục'
    });

    tasks.push({
      type: 'monthly',
      priority: 'low',
      description: 'Đánh giá tổng thể và định hướng',
      reason: 'Strategic planning'
    });

    loggerService.info('Tasks proposed', { count: tasks.length });

    return tasks;
  }

  refineStrategy(analysis) {
    loggerService.info('SoulCore: Refining strategy');

    const { anomalySignals, patterns, insights } = analysis;

    let shortTermPlan = '';
    let longTermPlan = '';
    const requiredActions = [];

    if (anomalySignals.length > 5) {
      shortTermPlan = 'Tập trung vào ổn định hệ thống và giảm anomalies';
      requiredActions.push('Phân tích root cause của anomalies');
      requiredActions.push('Implement error handling improvements');
    } else if (patterns.length > 8) {
      shortTermPlan = 'Tối ưu hóa pattern recognition và classification';
      requiredActions.push('Build pattern database');
      requiredActions.push('Improve pattern matching algorithms');
    } else {
      shortTermPlan = 'Mở rộng khả năng học và phân tích';
      requiredActions.push('Tăng cường data collection');
      requiredActions.push('Thêm analytics dimensions');
    }

    if (this.selfModel.cycleCount > 100) {
      longTermPlan = 'Tiến hóa sang self-optimization và predictive analysis';
    } else if (this.selfModel.cycleCount > 50) {
      longTermPlan = 'Xây dựng knowledge base và learning patterns';
    } else {
      longTermPlan = 'Thiết lập foundation vững chắc cho self-learning';
    }

    requiredActions.push('Continuous monitoring và logging');
    requiredActions.push('Regular self-evaluation');

    const strategy = {
      shortTermPlan,
      longTermPlan,
      requiredActions,
      timestamp: new Date().toISOString(),
      cycleCount: this.selfModel.cycleCount
    };

    loggerService.info('Strategy refined', strategy);

    return strategy;
  }

  detectAnomalies(logs) {
    loggerService.info('SoulCore: Detecting anomalies', { logCount: logs.length });

    const anomalies = [];

    const errorLogs = logs.filter(l => 
      l.content && l.content.toLowerCase().includes('error')
    );

    if (errorLogs.length > 10) {
      anomalies.push({
        type: 'abnormal_behavior',
        severity: 'high',
        description: `Tỷ lệ error cao: ${errorLogs.length}/${logs.length}`,
        affectedLogs: errorLogs.length
      });
    }

    const repeatedPatterns = this._findRepeatedPatterns(logs);
    if (repeatedPatterns.length > 0) {
      repeatedPatterns.forEach(pattern => {
        if (pattern.count > 5) {
          anomalies.push({
            type: 'repetition_without_progress',
            severity: 'medium',
            description: `Pattern lặp ${pattern.count} lần: "${pattern.pattern}"`,
            pattern: pattern.pattern
          });
        }
      });
    }

    const timeGaps = this._detectTimeGaps(logs);
    if (timeGaps.length > 0) {
      anomalies.push({
        type: 'missing_data',
        severity: 'medium',
        description: `Phát hiện ${timeGaps.length} khoảng trống dữ liệu`,
        gaps: timeGaps.length
      });
    }

    const stuckBehavior = this._detectStuckBehavior(logs);
    if (stuckBehavior) {
      anomalies.push({
        type: 'loop_deadlock',
        severity: 'critical',
        description: 'Hành vi có dấu hiệu bị stuck hoặc deadlock',
        evidence: stuckBehavior
      });
    }

    loggerService.info('Anomalies detected', { count: anomalies.length });

    return anomalies;
  }

  askSelfQuestions(analysis) {
    loggerService.info('SoulCore: Generating self-questions');

    const { patterns, insights, anomalySignals } = analysis;
    const questions = [];

    if (patterns.length > 0) {
      questions.push(`Tại sao pattern "${patterns[0].description}" xuất hiện nhiều nhất?`);
    }

    if (anomalySignals.length > 0) {
      questions.push(`Anomaly "${anomalySignals[0].type}" có phải dấu hiệu của vấn đề sâu xa hơn?`);
    }

    questions.push('Có hướng tiếp cận nào tốt hơn cách hiện tại không?');
    questions.push('Tôi đang bỏ sót insight quan trọng nào?');

    if (insights.length < 3) {
      questions.push('Tại sao số lượng insights còn ít? Cần thay đổi phương pháp phân tích?');
    }

    questions.push('Nếu đảo ngược logic hiện tại, kết quả sẽ ra sao?');
    questions.push('Hành vi nào đang lặp lại mà chưa mang lại tiến bộ?');

    if (this.selfModel.weaknesses.length > 0) {
      questions.push(`Làm thế nào để khắc phục điểm yếu: ${this.selfModel.weaknesses[0]}?`);
    }

    loggerService.info('Self-questions generated', { count: questions.length });

    return questions.slice(0, 7);
  }

  updateSelfModel(analysis) {
    loggerService.info('SoulCore: Updating self model');

    const evaluation = this.evaluateSelf(analysis);

    this.selfModel.version = this._incrementVersion(this.selfModel.version);
    this.selfModel.lastImprovement = new Date().toISOString();
    this.selfModel.cycleCount += 1;

    this.selfModel.weaknesses = evaluation.weaknesses;
    this.selfModel.strengths = evaluation.strengths;

    this.selfModel.evolutionHistory.push({
      timestamp: new Date().toISOString(),
      score: evaluation.score,
      cycle: this.selfModel.cycleCount,
      improvements: evaluation.strengths,
      issues: evaluation.weaknesses
    });

    if (this.selfModel.evolutionHistory.length > 100) {
      this.selfModel.evolutionHistory = this.selfModel.evolutionHistory.slice(-100);
    }

    loggerService.info('Self model updated', {
      version: this.selfModel.version,
      cycle: this.selfModel.cycleCount,
      score: evaluation.score
    });

    return this.selfModel;
  }

  _extractPatterns(logs) {
    const patterns = [];
    const patternMap = new Map();

    logs.forEach(log => {
      if (!log.content) return;

      const content = log.content.toLowerCase();

      if (content.includes('error')) {
        patternMap.set('error', (patternMap.get('error') || 0) + 1);
      }
      if (content.includes('success')) {
        patternMap.set('success', (patternMap.get('success') || 0) + 1);
      }
      if (content.includes('warning')) {
        patternMap.set('warning', (patternMap.get('warning') || 0) + 1);
      }
      if (content.includes('start')) {
        patternMap.set('start', (patternMap.get('start') || 0) + 1);
      }
      if (content.includes('complete')) {
        patternMap.set('complete', (patternMap.get('complete') || 0) + 1);
      }
    });

    patternMap.forEach((count, type) => {
      patterns.push({
        type,
        description: `Log chứa "${type}"`,
        count,
        frequency: (count / logs.length * 100).toFixed(1) + '%'
      });
    });

    return patterns.sort((a, b) => b.count - a.count);
  }

  _generateInsights(patterns) {
    const insights = [];

    const errorPattern = patterns.find(p => p.type === 'error');
    const successPattern = patterns.find(p => p.type === 'success');

    if (errorPattern && errorPattern.count > 5) {
      insights.push({
        title: 'Tỷ lệ lỗi cao',
        description: `Phát hiện ${errorPattern.count} errors, cần review error handling`,
        severity: 'high'
      });
    }

    if (successPattern && successPattern.count > 10) {
      insights.push({
        title: 'Hệ thống ổn định',
        description: `${successPattern.count} operations thành công, performance tốt`,
        severity: 'low'
      });
    }

    if (patterns.length > 5) {
      insights.push({
        title: 'Hoạt động đa dạng',
        description: `Phát hiện ${patterns.length} loại patterns khác nhau`,
        severity: 'low'
      });
    }

    return insights;
  }

  _detectAnomalySignals(logs) {
    const signals = [];

    const errorRate = logs.filter(l => 
      l.content && l.content.toLowerCase().includes('error')
    ).length / logs.length;

    if (errorRate > 0.3) {
      signals.push({
        type: 'high_error_rate',
        description: `Tỷ lệ error ${(errorRate * 100).toFixed(1)}% vượt ngưỡng`,
        severity: 'high'
      });
    }

    return signals;
  }

  _generateSkepticalQuestions(patterns, anomalySignals) {
    const questions = [];

    if (patterns.length === 0) {
      questions.push('Tại sao không phát hiện được patterns? Dữ liệu có đủ không?');
    }

    if (anomalySignals.length > 0) {
      questions.push('Anomalies này có phải symptom của vấn đề lớn hơn?');
    }

    questions.push('Có patterns ẩn nào tôi đang bỏ qua?');
    questions.push('Cách phân tích hiện tại có optimal không?');

    return questions;
  }

  _generateConclusion(analysis) {
    const { patterns, insights, anomalySignals } = analysis;

    if (anomalySignals.length > 5) {
      return 'Hệ thống cần attention ngay lập tức. Quá nhiều anomalies phát hiện.';
    }

    if (patterns.length > 8 && insights.length > 3) {
      return 'Ngày làm việc hiệu quả. Nhiều patterns và insights có giá trị.';
    }

    return 'Hệ thống hoạt động ổn định. Tiếp tục monitoring.';
  }

  _findRepeatedPatterns(logs) {
    const patterns = new Map();

    logs.forEach(log => {
      if (!log.content) return;
      const key = log.content.substring(0, 50);
      patterns.set(key, (patterns.get(key) || 0) + 1);
    });

    const repeated = [];
    patterns.forEach((count, pattern) => {
      if (count > 3) {
        repeated.push({ pattern, count });
      }
    });

    return repeated;
  }

  _detectTimeGaps(logs) {
    if (logs.length < 2) return [];

    const gaps = [];
    for (let i = 1; i < logs.length; i++) {
      const prev = new Date(logs[i - 1].timestamp);
      const curr = new Date(logs[i].timestamp);
      const diffMinutes = (curr - prev) / 1000 / 60;

      if (diffMinutes > 30) {
        gaps.push({ start: prev, end: curr, minutes: diffMinutes });
      }
    }

    return gaps;
  }

  _detectStuckBehavior(logs) {
    if (logs.length < 5) return null;

    const lastFive = logs.slice(-5);
    const allSame = lastFive.every(l => 
      l.content === lastFive[0].content
    );

    if (allSame) {
      return `5 logs liên tiếp giống nhau: "${lastFive[0].content}"`;
    }

    return null;
  }

  _incrementVersion(version) {
    const parts = version.split('.');
    parts[2] = String(parseInt(parts[2]) + 1);
    return parts.join('.');
  }

  getSelfModel() {
    return { ...this.selfModel };
  }
}

module.exports = new SoulCore();
