const loggerService = require('../services/loggerService');

const tasks = new Map();
let taskIdCounter = 1;

function addTask(task) {
  const taskId = `task_${taskIdCounter++}`;
  
  const newTask = {
    id: taskId,
    description: task.description,
    priority: task.priority || 'medium',
    schedule: task.schedule || 'weekly',
    status: 'pending',
    createdAt: new Date().toISOString(),
    completedAt: null
  };
  
  tasks.set(taskId, newTask);
  
  loggerService.info('Task added', { task: newTask });
  
  return newTask;
}

function getTasks(filter = {}) {
  let allTasks = Array.from(tasks.values());
  
  if (filter.status) {
    allTasks = allTasks.filter(t => t.status === filter.status);
  }
  
  if (filter.priority) {
    allTasks = allTasks.filter(t => t.priority === filter.priority);
  }
  
  loggerService.info('Retrieved tasks', { count: allTasks.length, filter });
  
  return allTasks;
}

function completeTask(taskId) {
  const task = tasks.get(taskId);
  
  if (!task) {
    loggerService.warn('Task not found', { taskId });
    return null;
  }
  
  task.status = 'completed';
  task.completedAt = new Date().toISOString();
  
  tasks.set(taskId, task);
  
  loggerService.info('Task completed', { task });
  
  return task;
}

function autoGenerateTasks(strategy) {
  loggerService.info('=== Auto-generating tasks from strategy ===');
  
  const generatedTasks = [];
  
  if (strategy.suggestedActions && strategy.suggestedActions.length > 0) {
    strategy.suggestedActions.forEach((action, index) => {
      const task = addTask({
        description: action,
        priority: index === 0 ? 'high' : 'medium',
        schedule: 'weekly'
      });
      generatedTasks.push(task);
    });
  }
  
  loggerService.info('Auto-generated tasks', { count: generatedTasks.length });
  
  return generatedTasks;
}

module.exports = {
  addTask,
  getTasks,
  completeTask,
  autoGenerateTasks
};
