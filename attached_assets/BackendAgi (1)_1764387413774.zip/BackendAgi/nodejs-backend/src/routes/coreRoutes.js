const express = require('express');
const router = express.Router();
const coreController = require('../controllers/coreController');

router.get('/run-loop', coreController.runInnerLoopController);

router.get('/strategy', coreController.getStrategy);

router.get('/tasks', coreController.getTasks);

router.get('/anomalies', coreController.getAnomalies);

router.get('/status', coreController.getStatus);

module.exports = router;
