# CipherH Soul Loop - Quick Start

## 🚀 Start Server

```bash
cd nodejs-backend

# Install dependencies (if needed)
npm install

# Configure environment
cp .env.example .env
# Edit .env với API keys

# Start server
npm start
```

## 🔧 Configuration

Edit `.env`:
```bash
PORT=3000
NOTION_KEY=secret_xxxxx              # Optional (placeholder mode if missing)
NOTION_DATABASE_ID=xxxxx             # Optional (placeholder mode if missing)
OPENAI_KEY=sk-xxxxx                  # Optional (placeholder mode if missing)

HEARTBEAT_CRON=*/10 * * * *          # Every 10 minutes
LOG_LEVEL=info
```

## 📡 Endpoints

```bash
# Health check
curl http://localhost:3000/health

# Get status
curl http://localhost:3000/core/status

# Run inner loop manually
curl http://localhost:3000/core/run-loop

# Get strategy
curl http://localhost:3000/core/strategy

# Get tasks
curl http://localhost:3000/core/tasks

# Get anomalies
curl http://localhost:3000/core/anomalies
```

## 🔄 How It Works

1. **Server starts** on port 3000
2. **Initial cycle** runs immediately
3. **Cron scheduler** runs inner loop every 10 minutes (configurable)
4. **Each cycle**:
   - Fetches logs from Notion
   - Analyzes with OpenAI
   - Detects anomalies
   - Generates strategy
   - Creates tasks
   - Updates state
   - Writes back to Notion

## 📊 Monitoring

**Logs**: `logs/app.log`

**Console output**:
```
2025-11-16 16:10:00 [INFO] Server running on port 3000
2025-11-16 16:10:00 [INFO] Scheduling inner loop with cron: */10 * * * *
2025-11-16 16:10:00 [INFO] Running initial inner loop cycle...
2025-11-16 16:10:01 [INFO] Initial cycle 1 completed
```

## 🛡️ Security

- ✅ API keys loaded from environment variables
- ✅ Placeholder mode if credentials missing
- ✅ No hardcoded secrets
- ✅ Graceful degradation
- ✅ Error handling on all endpoints

## ⚙️ Cron Schedule Examples

```bash
*/5 * * * *    # Every 5 minutes
*/10 * * * *   # Every 10 minutes (default)
*/30 * * * *   # Every 30 minutes
0 * * * *      # Every hour
0 0 * * *      # Daily at midnight
```

## 🔮 Production Deployment

```bash
# Using PM2
pm2 start src/server.js --name cipherh-soul

# Using Docker
docker build -t cipherh-soul .
docker run -d -p 3000:3000 --env-file .env cipherh-soul

# Using systemd
[Service]
ExecStart=/usr/bin/node /path/to/nodejs-backend/src/server.js
WorkingDirectory=/path/to/nodejs-backend
Environment="NODE_ENV=production"
```
