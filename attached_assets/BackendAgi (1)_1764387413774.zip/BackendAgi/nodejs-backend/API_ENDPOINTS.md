# CipherH Soul Loop - API Endpoints

Base URL: `http://localhost:3000/api/core`

---

## 📡 Endpoints

### 1. GET `/core/run-loop`
**Chức năng**: Chạy vòng lặp Inner Loop ngay lập tức

**Input**: None

**Output**:
```json
{
  "success": true,
  "timestamp": "2025-11-16T16:10:00.000Z",
  "cycle": 3,
  "stats": {
    "anomalyScore": 0,
    "confidence": 85,
    "doubts": 0,
    "tasksGenerated": 3
  }
}
```

**Placeholder**: Notion logs, OpenAI analysis

**Curl**:
```bash
curl http://localhost:3000/api/core/run-loop
```

---

### 2. GET `/core/strategy`
**Chức năng**: Lấy chiến lược hiện tại được sinh bởi strategy module

**Input**: None

**Output**:
```json
{
  "success": true,
  "timestamp": "2025-11-16T16:10:00.000Z",
  "strategy": {
    "strategySummary": "Hệ thống hoạt động tốt. Duy trì và mở rộng.",
    "suggestedActions": [
      "Tối ưu hiệu suất",
      "Thêm tính năng mới",
      "Cải thiện độ tin cậy"
    ],
    "timestamp": "2025-11-16T16:10:00.000Z",
    "anomalyScore": 0
  }
}
```

**Placeholder**: Fetches logs from Notion, generates strategy from analysis

**Curl**:
```bash
curl http://localhost:3000/api/core/strategy
```

---

### 3. GET `/core/tasks`
**Chức năng**: Lấy danh sách nhiệm vụ từ taskManager

**Input** (Query Parameters):
- `status` (optional): `pending` | `completed`
- `priority` (optional): `critical` | `high` | `medium` | `low`

**Output**:
```json
{
  "success": true,
  "timestamp": "2025-11-16T16:10:00.000Z",
  "count": 3,
  "tasks": [
    {
      "id": "task_1",
      "description": "Tối ưu hiệu suất",
      "priority": "high",
      "schedule": "weekly",
      "status": "pending",
      "createdAt": "2025-11-16T16:05:00.000Z",
      "completedAt": null
    }
  ]
}
```

**Placeholder**: Tasks auto-generated from strategy

**Curl**:
```bash
# All tasks
curl http://localhost:3000/api/core/tasks

# Filter by status
curl http://localhost:3000/api/core/tasks?status=pending

# Filter by priority
curl http://localhost:3000/api/core/tasks?priority=high
```

---

### 4. GET `/core/anomalies`
**Chức năng**: Lấy danh sách bất thường từ anomalyDetector

**Input**: None

**Output**:
```json
{
  "success": true,
  "timestamp": "2025-11-16T16:10:00.000Z",
  "anomalyScore": 0.3,
  "anomalies": [
    {
      "type": "high_error_rate",
      "severity": "high",
      "description": "Detected 8 error logs",
      "timestamp": "2025-11-16T16:10:00.000Z"
    }
  ],
  "summary": "Detected 1 anomalies with score 0.30"
}
```

**Placeholder**: Fetches logs from Notion, runs heuristic detection

**Curl**:
```bash
curl http://localhost:3000/api/core/anomalies
```

---

### 5. GET `/core/status`
**Chức năng**: Lấy trạng thái hiện tại của Inner Loop

**Input**: None

**Output**:
```json
{
  "success": true,
  "timestamp": "2025-11-16T16:10:00.000Z",
  "state": {
    "lastRun": "2025-11-16T16:05:00.000Z",
    "cycles": 3,
    "confidence": 85,
    "doubts": 0,
    "goals": []
  }
}
```

**Placeholder**: State managed in memory

**Curl**:
```bash
curl http://localhost:3000/api/core/status
```

---

## 🔄 Workflow

```
GET /run-loop
    ↓
Executes 10-step Inner Loop
    ↓ (creates)
Strategy, Tasks, Anomalies, State Updates
    ↓ (accessible via)
GET /strategy, /tasks, /anomalies, /status
```

---

## 🛡️ Error Handling

Tất cả endpoints trả về error format:
```json
{
  "success": false,
  "timestamp": "2025-11-16T16:10:00.000Z",
  "error": "Error message here"
}
```

HTTP Status Codes:
- `200` - Success
- `500` - Internal Server Error

---

## 📊 Logger

Tất cả requests được log:
```
info: Strategy requested via API
info: Strategy retrieved {"strategy":{"strategySummary":"..."}}
```

---

## 🔮 Placeholders

**Hiện tại chưa kết nối thật:**
- ❌ Notion API (fetchRecentLogs returns mock data)
- ❌ OpenAI API (analyzeLog returns mock analysis)

**Để enable:**
1. Add API keys vào `.env`
2. Uncomment real API calls trong services
3. Test với small operations first
