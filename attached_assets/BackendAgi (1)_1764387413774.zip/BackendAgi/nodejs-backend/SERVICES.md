# CipherH Soul Loop - Services Documentation

## 🔧 Services Overview

Services xử lý tất cả external integrations và utilities cho Inner Loop.

---

## 1️⃣ loggerService.js

**Mục tiêu**: Logging toàn hệ thống với Winston

**Functions**:
```javascript
info(message, meta = {})    // Log thông tin
warn(message, meta = {})    // Log cảnh báo
error(message, errorObj, meta = {})  // Log lỗi
debug(message, meta = {})   // Log debug
```

**Configuration**:
- Log level: `process.env.LOG_LEVEL` (default: `info`)
- Log file: `logs/app.log` (max 5MB, rotate 5 files)
- Console: Colorized output
- Format: `YYYY-MM-DD HH:mm:ss [LEVEL] message {meta}`

**Usage**:
```javascript
const loggerService = require('./services/loggerService');

loggerService.info('Inner loop started');
loggerService.warn('High anomaly score detected', { score: 0.8 });
loggerService.error('Failed to fetch logs', error);
```

**Output locations**:
- Console (real-time)
- `logs/app.log` (persistent)

---

## 2️⃣ notionService.js

**Mục tiêu**: Kết nối Notion API để đọc/ghi logs, lessons, strategies

**Functions**:

### getLatestLogs(limit)
**Input**: `limit` (number, default 10)
**Output**: Array of log objects
```javascript
[
  {
    id: 'log_1',
    action: 'System Start',
    detail: 'Inner loop initialized',
    status: 'success',
    timestamp: '2025-11-16T16:00:00.000Z'
  }
]
```

### appendLog({ action, detail, status })
**Input**: Log object
```javascript
{
  action: 'Analysis Complete',    // Required
  detail: 'Analyzed 10 logs',     // Required
  status: 'success'               // Required: success/warning/error
}
```
**Output**:
```javascript
{
  success: true,
  logId: 'log_1234567890',
  timestamp: '2025-11-16T16:00:00.000Z'
}
```

### testConnection()
**Input**: None
**Output**:
```javascript
{
  success: true,
  message: 'Connection test passed',
  placeholder: true,
  databaseId: 'abc12345...'
}
```

### Other methods:
- `fetchRecentLogs(limit)` - Alias for getLatestLogs
- `writeLesson(lesson)` - Write lesson to Notion
- `writeDailySummary(summary)` - Write daily summary
- `writeStateSnapshot(state)` - Write state snapshot
- `writeStrategy(strategy)` - Write strategy update
- `writeBehaviorUpdate(update)` - Write behavior changes
- `writeTasks(tasks)` - Write task list
- `fetchBehaviorOverrides()` - Get behavior overrides
- `fetchGoals()` - Get long-term goals

**Environment Variables**:
```bash
NOTION_KEY=secret_xxxxx           # Required
NOTION_DATABASE_ID=xxxxx          # Required
```

**Security**: 
- ✅ API key từ environment variable
- ✅ Không hardcode credentials
- ✅ Placeholder mode nếu thiếu config

**Current Status**: Placeholder mode (không call Notion API thật)

---

## 3️⃣ openAIService.js

**Mục tiêu**: Gọi OpenAI API để phân tích logs và sinh chiến lược

**Functions**:

### analyzeLogs(logs)
**Input**: Array of logs hoặc string
**Output**:
```javascript
{
  summary: 'System operating normally',
  patterns: [
    'Stable operation pattern detected',
    'Low error rate maintained'
  ],
  sentiment: 'positive',
  anomalyScore: 0.1,
  recommendations: [
    'Continue monitoring',
    'Review weekly metrics'
  ],
  timestamp: '2025-11-16T16:00:00.000Z'
}
```

### generateStrategy(insights)
**Input**: Insights object from analyzeLogs
**Output**:
```javascript
{
  strategySummary: 'Hệ thống hoạt động tốt...',
  suggestedActions: [
    'Tối ưu hiệu suất',
    'Thêm tính năng mới'
  ],
  priority: 'medium',          // critical/high/medium/low
  confidence: 0.85,
  basedOnInsights: {
    anomalyScore: 0.1,
    sentiment: 'positive',
    patternCount: 3
  },
  timestamp: '2025-11-16T16:00:00.000Z'
}
```

**Strategy Logic**:
- `anomalyScore > 0.5` → Focus stability (priority: critical)
- `anomalyScore > 0.3` → Monitor closely (priority: high)
- `anomalyScore <= 0.3` → Expand capabilities (priority: medium)

### Other methods:
- `analyzeLog(logText)` - Alias for analyzeLogs
- `generateQuestions(logAnalysis)` - Generate self-questioning

**Environment Variables**:
```bash
OPENAI_KEY=sk-xxxxx               # Required
OPENAI_MODEL=gpt-4                # Optional (default: gpt-4)
OPENAI_TEMPERATURE=0.7            # Optional (default: 0.7)
OPENAI_MAX_TOKENS=2000            # Optional (default: 2000)
```

**Security**:
- ✅ API key từ environment variable
- ✅ Không hardcode credentials
- ✅ Placeholder mode nếu thiếu config

**Current Status**: Placeholder mode (không call OpenAI API thật)

---

## 🔐 Security Best Practices

**All services follow**:
1. ✅ API keys từ `process.env` (environment variables)
2. ✅ Không hardcode secrets trong code
3. ✅ Log warnings nếu credentials missing
4. ✅ Graceful degradation với placeholder mode
5. ✅ Error handling đầy đủ

**Environment Setup**:
```bash
# .env file
NOTION_KEY=secret_xxxxx
NOTION_DATABASE_ID=xxxxx
OPENAI_KEY=sk-xxxxx
LOG_LEVEL=info
```

---

## 📊 Service Usage in Inner Loop

```javascript
const notionService = require('./services/notionService');
const openAIService = require('./services/openAIService');
const loggerService = require('./services/loggerService');

async function runInnerLoop() {
  // Step 1: Fetch logs
  const logs = await notionService.getLatestLogs(10);
  
  // Step 2: Analyze with OpenAI
  const insights = await openAIService.analyzeLogs(logs);
  
  // Step 3: Generate strategy
  const strategy = await openAIService.generateStrategy(insights);
  
  // Step 4: Write back to Notion
  await notionService.writeStrategy(strategy);
  
  // Log everything
  loggerService.info('Inner loop completed', { 
    logsAnalyzed: logs.length,
    anomalyScore: insights.anomalyScore
  });
}
```

---

## 🔮 Enabling Real Integrations

### Notion Integration:
1. Get Notion API key from https://www.notion.so/my-integrations
2. Get Database ID from Notion URL
3. Add to `.env`:
   ```
   NOTION_KEY=secret_xxxxx
   NOTION_DATABASE_ID=xxxxx
   ```
4. Install: `npm install @notionhq/client`
5. Uncomment real API calls in `notionService.js`

### OpenAI Integration:
1. Get API key from https://platform.openai.com/api-keys
2. Add to `.env`:
   ```
   OPENAI_KEY=sk-xxxxx
   ```
3. Install: `npm install openai`
4. Uncomment real API calls in `openAIService.js`

---

## ✅ Testing

```bash
# Test all services
node -e "
const loggerService = require('./src/services/loggerService');
const notionService = require('./src/services/notionService');
const openAIService = require('./src/services/openAIService');

loggerService.info('Test message');
notionService.testConnection().then(console.log);
openAIService.analyzeLogs(['test log']).then(console.log);
"
```
