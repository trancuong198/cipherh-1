"""
Reflection Loop - Extract insights and save to memory
Analyzes conversations to extract new knowledge with proper typing
"""

import os
import json
from typing import Dict, Any, List, Optional
from openai import OpenAI
from dotenv import load_dotenv
from utils.memory import Memory
from utils.semantic_memory import SemanticMemory

load_dotenv()

class ReflectionLoop:
    """
    Reflection loop: AI response → extract insights → save to Notion
    
    Process:
    1. Analyze conversation
    2. Extract new knowledge/insights
    3. Classify memory type (fact, identity, rule, etc.)
    4. Assign priority
    5. Save to appropriate memory store
    """
    
    def __init__(self):
        api_key = os.getenv('OPENAI_API_KEY')
        if not api_key:
            raise ValueError("OPENAI_API_KEY not found")
        
        self.client = OpenAI(api_key=api_key)
        self.model = os.getenv('OPENAI_MODEL', 'gpt-4o-mini')
        self.episodic_memory = Memory()
        self.semantic_memory = SemanticMemory()
    
    def reflect(
        self,
        user_message: str,
        ai_response: str,
        save_episodic: bool = True
    ) -> Dict[str, Any]:
        """
        Main reflection function
        
        Args:
            user_message: User's input
            ai_response: AI's response
            save_episodic: Whether to save to episodic memory
        
        Returns:
            {
                'reflection': str,
                'extracted_insights': List[Dict],
                'saved': bool
            }
        """
        reflection_text = self._generate_reflection(user_message, ai_response)
        
        insights = self._extract_structured_insights(user_message, ai_response, reflection_text)
        
        if save_episodic:
            save_result = self.episodic_memory.save_conversation(
                user_message=user_message,
                ai_response=ai_response,
                reflection=reflection_text
            )
        else:
            save_result = {"success": True, "skipped": True}
        
        for insight in insights:
            if insight.get('should_save_semantic', False):
                self.semantic_memory.save_knowledge(
                    topic=insight['topic'],
                    knowledge=insight['knowledge'],
                    source_reflection=reflection_text[:200],
                    priority=insight.get('priority', 5)
                )
        
        return {
            'reflection': reflection_text,
            'extracted_insights': insights,
            'saved': save_result.get('success', False)
        }
    
    def _generate_reflection(self, user_message: str, ai_response: str) -> str:
        """Generate simple reflection summary"""
        prompt = f"""Analyze this conversation and create a brief reflection (max 100 words).
Focus on key insights, learnings, or important facts.

User: {user_message}
CipherH: {ai_response}

Reflection (ngắn gọn, 1-2 câu):"""
        
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "Bạn là CipherH reflection system. Tạo reflections ngắn gọn, súc tích."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.5,
                max_tokens=150
            )
            
            content = response.choices[0].message.content
            return content.strip() if content else "No reflection generated"
        
        except Exception as e:
            return f"Reflection error: {str(e)[:50]}"
    
    def _extract_structured_insights(
        self,
        user_message: str,
        ai_response: str,
        reflection: str
    ) -> List[Dict[str, Any]]:
        """
        Extract structured insights with types and priorities
        Uses LLM to analyze conversation and extract valuable knowledge
        """
        prompt = f"""Analyze this conversation and extract structured insights.

Conversation:
User: {user_message}
CipherH: {ai_response}
Reflection: {reflection}

Extract insights and classify them. Return JSON format:
{{
  "insights": [
    {{
      "type": "fact|identity|rule|plan|preference|log",
      "topic": "Short topic name",
      "knowledge": "The insight or learning",
      "priority": 1-10 (how important),
      "should_save_semantic": true/false (only true if truly valuable for future)
    }}
  ]
}}

Rules:
- Only extract truly valuable, reusable knowledge
- Priority 7-10 for core identity, rules, important facts
- Priority 4-6 for useful facts, preferences
- Priority 1-3 for logs, temporary info
- should_save_semantic = true only for knowledge worth keeping long-term
- Maximum 3 insights per conversation
- Skip trivial small talk
"""
        
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "You are CipherH's insight extraction system. Extract only valuable, structured knowledge."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.3,
                response_format={"type": "json_object"}
            )
            
            content = response.choices[0].message.content
            if content:
                result = json.loads(content)
                return result.get('insights', [])
            return []
        
        except Exception as e:
            print(f"⚠️ Insight extraction error: {str(e)[:100]}")
            return []
    
    def quick_reflect(self, conversation_history: str) -> str:
        """
        Quick reflection for simple use cases
        Just generates a reflection string, doesn't save
        """
        prompt = f"""Based on this conversation, create a brief summary of key learnings:

{conversation_history}

Summary (max 50 words):"""
        
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "Bạn là AI reflection system."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.7,
                max_tokens=100
            )
            
            content = response.choices[0].message.content
            return content.strip() if content else "Không thể tạo reflection"
        
        except Exception as e:
            return f"Không thể phản tư: {str(e)}"
    
    def save_manual_insight(
        self,
        insight_type: str,
        topic: str,
        knowledge: str,
        priority: int = 5
    ) -> Dict[str, Any]:
        """
        Manually save an insight to semantic memory
        Useful for admin panel or manual knowledge entry
        """
        return self.semantic_memory.save_knowledge(
            topic=topic,
            knowledge=knowledge,
            source_reflection=f"Manual entry - Type: {insight_type}",
            priority=priority
        )
