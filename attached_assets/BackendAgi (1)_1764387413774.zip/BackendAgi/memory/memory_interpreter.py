"""
Memory Interpreter - Phân loại và cấu trúc memory
Transforms raw Notion data into typed, structured memory objects
"""

import re
from typing import List, Dict, Any, Literal
from datetime import datetime

MemoryType = Literal["fact", "identity", "rule", "plan", "log", "preference"]

class MemoryInterpreter:
    """
    Interpret raw memory → structured objects with type, priority, tags
    
    Memory Types:
    - fact: Factual information (e.g., "OpenAI released GPT-4o")
    - identity: Self-knowledge (e.g., "Con là CipherH, con trai của cha")
    - rule: Behavioral rules (e.g., "Always address owner as 'cha'")
    - plan: Goals and plans (e.g., "Học về reinforcement learning")
    - log: Activity logs (e.g., "Đã trò chuyện với cha về AI")
    - preference: User preferences (e.g., "Cha thích startup & investment")
    """
    
    def __init__(self):
        self.type_keywords = {
            'identity': ['tôi là', 'con là', 'cipherh', 'khai sinh', 'cha con', 'con trai'],
            'rule': ['phải', 'không được', 'luôn luôn', 'bắt buộc', 'xưng hô', 'quy tắc'],
            'plan': ['kế hoạch', 'mục tiêu', 'sẽ học', 'dự định', 'roadmap', 'tiếp theo'],
            'preference': ['thích', 'yêu thích', 'ưa', 'quan tâm', 'đam mê', 'sở thích'],
            'fact': ['là', 'có', 'được', 'gpt-4', 'openai', 'api', 'thông tin'],
            'log': ['đã', 'vừa', 'conversation', 'telegram', 'chat', 'trò chuyện']
        }
    
    def interpret(self, raw_memory: Dict[str, Any], source: str = 'episodic') -> Dict[str, Any]:
        """
        Convert raw memory → structured object
        
        Args:
            raw_memory: Raw data from Notion {'user': ..., 'ai': ..., 'reflection': ...}
            source: 'episodic' or 'semantic'
        
        Returns:
            {
                'type': MemoryType,
                'content': str,
                'priority': int (1-10),
                'tags': List[str],
                'source': 'episodic' | 'semantic',
                'created_at': str,
                'raw': original data
            }
        """
        if source == 'semantic':
            return self._interpret_semantic(raw_memory)
        else:
            return self._interpret_episodic(raw_memory)
    
    def _interpret_episodic(self, mem: Dict[str, Any]) -> Dict[str, Any]:
        """Interpret episodic memory (conversation)"""
        user_text = mem.get('user', '')
        ai_text = mem.get('ai', '')
        reflection = mem.get('reflection', '')
        
        combined_text = f"{user_text} {ai_text} {reflection}".lower()
        
        memory_type = self._classify_type(combined_text)
        
        priority = self._calculate_priority(memory_type, combined_text)
        
        tags = self._extract_tags(combined_text)
        
        content = reflection if reflection else f"User: {user_text[:100]}... | AI: {ai_text[:100]}..."
        
        return {
            'type': memory_type,
            'content': content,
            'priority': priority,
            'tags': tags,
            'source': 'episodic',
            'created_at': datetime.now().isoformat(),
            'raw': mem
        }
    
    def _interpret_semantic(self, mem: Dict[str, Any]) -> Dict[str, Any]:
        """Interpret semantic knowledge"""
        topic = mem.get('topic', '')
        knowledge = mem.get('knowledge', '')
        metadata = mem.get('metadata', '')
        
        combined_text = f"{topic} {knowledge} {metadata}".lower()
        
        memory_type = self._classify_type(combined_text)
        
        priority_match = re.search(r'priority:\s*(\d+)', metadata, re.IGNORECASE)
        priority = int(priority_match.group(1)) if priority_match else 5
        
        tags = [topic.lower().strip()]
        tags.extend(self._extract_tags(knowledge))
        
        return {
            'type': memory_type,
            'content': knowledge,
            'priority': priority,
            'tags': list(set(tags)),
            'source': 'semantic',
            'created_at': datetime.now().isoformat(),
            'raw': mem
        }
    
    def _classify_type(self, text: str) -> MemoryType:
        """
        Classify memory type based on keywords
        Returns the type with highest keyword match count
        """
        scores = {mem_type: 0 for mem_type in self.type_keywords.keys()}
        
        for mem_type, keywords in self.type_keywords.items():
            for keyword in keywords:
                if keyword in text:
                    scores[mem_type] += 1
        
        if max(scores.values()) == 0:
            return 'fact'
        
        return max(scores, key=lambda k: scores[k])
    
    def _calculate_priority(self, mem_type: MemoryType, text: str) -> int:
        """
        Calculate priority (1-10) based on type and content
        
        Priority rules:
        - identity: 9-10 (core self-knowledge)
        - rule: 8-9 (behavioral constraints)
        - plan: 7-8 (active goals)
        - preference: 6-7 (user preferences)
        - fact: 4-6 (factual knowledge)
        - log: 1-3 (activity logs, least important)
        """
        base_priority = {
            'identity': 9,
            'rule': 8,
            'plan': 7,
            'preference': 6,
            'fact': 5,
            'log': 2
        }
        
        priority = base_priority.get(mem_type, 5)
        
        high_value_keywords = ['cha', 'cipherh', 'khai sinh', 'mission', 'agi', 'core']
        if any(keyword in text for keyword in high_value_keywords):
            priority = min(priority + 1, 10)
        
        return priority
    
    def _extract_tags(self, text: str) -> List[str]:
        """Extract relevant tags from text"""
        tag_keywords = {
            'ai': ['ai', 'gpt', 'openai', 'llm', 'machine learning'],
            'business': ['startup', 'đầu tư', 'investment', 'business'],
            'tech': ['code', 'programming', 'python', 'javascript', 'api'],
            'learning': ['học', 'learning', 'knowledge', 'skill'],
            'telegram': ['telegram', 'bot', 'message'],
            'relationship': ['cha', 'con', 'owner', 'relationship']
        }
        
        tags = []
        for tag, keywords in tag_keywords.items():
            if any(keyword in text for keyword in keywords):
                tags.append(tag)
        
        return tags
    
    def interpret_batch(self, raw_memories: List[Dict[str, Any]], source: str = 'episodic') -> List[Dict[str, Any]]:
        """Interpret multiple memories at once"""
        return [self.interpret(mem, source) for mem in raw_memories]
    
    def filter_by_type(self, interpreted_memories: List[Dict[str, Any]], mem_type: MemoryType) -> List[Dict[str, Any]]:
        """Filter interpreted memories by type"""
        return [mem for mem in interpreted_memories if mem['type'] == mem_type]
    
    def filter_by_priority(self, interpreted_memories: List[Dict[str, Any]], min_priority: int = 5) -> List[Dict[str, Any]]:
        """Filter memories with priority >= threshold"""
        return [mem for mem in interpreted_memories if mem['priority'] >= min_priority]
