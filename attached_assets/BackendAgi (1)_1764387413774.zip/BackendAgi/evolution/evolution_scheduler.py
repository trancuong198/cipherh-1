import os
import json
from typing import Dict, Any, List, Optional
from datetime import datetime
from evolution.refactor_engine import RefactorEngine

class EvolutionScheduler:
    def __init__(self):
        self.refactor_engine = RefactorEngine()
        
        self.evolution_dir = 'evolution'
        self.schedule_file = os.path.join(self.evolution_dir, 'evolution_schedule.json')
        
        os.makedirs(self.evolution_dir, exist_ok=True)
        
        self._init_schedule()
    
    def _init_schedule(self):
        if not os.path.exists(self.schedule_file):
            with open(self.schedule_file, 'w') as f:
                json.dump({
                    "scheduled_evolutions": [],
                    "completed_evolutions": [],
                    "next_cycle": None
                }, f, indent=2)
    
    def schedule_evolution_cycle(self) -> Dict[str, Any]:
        modules = [
            'memory_engine',
            'emotional_model',
            'task_chain',
            'personality_core',
            'world_model',
            'defense_firewall',
            'metacognition',
            'ltm_map'
        ]
        
        evolution_plan = {
            "timestamp": datetime.now().isoformat(),
            "modules_to_evolve": [],
            "priority_order": []
        }
        
        module_priorities = []
        
        for module in modules:
            analysis = self.refactor_engine.analyze_performance(module)
            refactor_plan = self.refactor_engine.propose_refactor(module)
            
            score = analysis['metrics'].get('overall_score', 75)
            priority = refactor_plan.get('priority', 'low')
            
            priority_score = 0
            if priority == 'critical':
                priority_score = 100
            elif priority == 'high':
                priority_score = 75
            elif priority == 'medium':
                priority_score = 50
            else:
                priority_score = 25
            
            priority_score -= score
            
            module_priorities.append({
                "module": module,
                "priority_score": priority_score,
                "current_score": score,
                "refactor_plan": refactor_plan
            })
        
        module_priorities.sort(key=lambda x: x['priority_score'], reverse=True)
        
        emotional_state = self._get_emotional_state()
        stress = emotional_state.get('stress_level', 0)
        
        max_modules = 3
        if stress > 70:
            max_modules = 1
        elif stress > 50:
            max_modules = 2
        
        for i, module_info in enumerate(module_priorities[:max_modules]):
            evolution_plan['modules_to_evolve'].append({
                "module": module_info['module'],
                "priority": i + 1,
                "refactor_plan": module_info['refactor_plan']
            })
            evolution_plan['priority_order'].append(module_info['module'])
        
        with open(self.schedule_file, 'r') as f:
            schedule_data = json.load(f)
        
        schedule_data['scheduled_evolutions'].append(evolution_plan)
        schedule_data['next_cycle'] = datetime.now().isoformat()
        
        with open(self.schedule_file, 'w') as f:
            json.dump(schedule_data, f, indent=2)
        
        return evolution_plan
    
    def _get_emotional_state(self) -> Dict[str, Any]:
        emotions_file = 'emotions/state.json'
        
        if not os.path.exists(emotions_file):
            return {}
        
        with open(emotions_file, 'r') as f:
            return json.load(f)
    
    def execute_evolution_cycle(self) -> Dict[str, Any]:
        evolution_plan = self.schedule_evolution_cycle()
        
        results = {
            "timestamp": datetime.now().isoformat(),
            "modules_evolved": [],
            "total_improvements": 0,
            "failed_evolutions": []
        }
        
        for module_info in evolution_plan['modules_to_evolve']:
            module = module_info['module']
            refactor_plan = module_info['refactor_plan']
            
            try:
                refactor_result = self.refactor_engine.apply_refactor(module, refactor_plan)
                
                if refactor_result.get('status') == 'success':
                    results['modules_evolved'].append({
                        "module": module,
                        "refactor_id": refactor_result['refactor_id'],
                        "improvements": refactor_result['improvements']
                    })
                    
                    for imp in refactor_result.get('improvements', []):
                        results['total_improvements'] += imp.get('improvement', 0)
                
                else:
                    results['failed_evolutions'].append(module)
            
            except Exception as e:
                results['failed_evolutions'].append({
                    "module": module,
                    "error": str(e)
                })
        
        with open(self.schedule_file, 'r') as f:
            schedule_data = json.load(f)
        
        schedule_data['completed_evolutions'].append(results)
        
        if len(schedule_data['completed_evolutions']) > 50:
            schedule_data['completed_evolutions'] = schedule_data['completed_evolutions'][-50:]
        
        with open(self.schedule_file, 'w') as f:
            json.dump(schedule_data, f, indent=2)
        
        return results
    
    def get_evolution_stats(self) -> Dict[str, Any]:
        with open(self.schedule_file, 'r') as f:
            schedule_data = json.load(f)
        
        completed = schedule_data.get('completed_evolutions', [])
        
        total_modules_evolved = 0
        total_improvements = 0
        
        for evolution in completed:
            total_modules_evolved += len(evolution.get('modules_evolved', []))
            total_improvements += evolution.get('total_improvements', 0)
        
        return {
            "total_evolution_cycles": len(completed),
            "total_modules_evolved": total_modules_evolved,
            "total_improvements": total_improvements,
            "average_improvement_per_cycle": total_improvements / len(completed) if completed else 0
        }
