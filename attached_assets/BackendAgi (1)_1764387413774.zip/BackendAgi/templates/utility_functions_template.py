"""
Utility Functions Template - Học từ CipherH AI gốc
Style: Type hints, docstrings, error handling, pure functions
"""

from typing import Dict, Any, List, Optional, Callable
import re
import json
from datetime import datetime
import hashlib

def validate_email(email: str) -> bool:
    """
    Validate email format
    
    Args:
        email: Email string to validate
    
    Returns:
        True if valid email format
    
    Examples:
        >>> validate_email("user@example.com")
        True
        >>> validate_email("invalid-email")
        False
    """
    if not email or not isinstance(email, str):
        return False
    
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return bool(re.match(pattern, email))

def sanitize_string(text: str, max_length: Optional[int] = None) -> str:
    """
    Sanitize user input string
    
    Args:
        text: Input text
        max_length: Maximum allowed length (optional)
    
    Returns:
        Sanitized string
    
    Raises:
        ValueError: If text exceeds max_length
    """
    if not isinstance(text, str):
        raise ValueError("text must be string")
    
    sanitized = text.strip()
    
    sanitized = re.sub(r'[<>]', '', sanitized)
    
    if max_length and len(sanitized) > max_length:
        raise ValueError(f"text exceeds max_length of {max_length}")
    
    return sanitized

def parse_json_safe(json_string: str, default: Any = None) -> Any:
    """
    Safely parse JSON string
    
    Args:
        json_string: JSON string to parse
        default: Default value if parsing fails
    
    Returns:
        Parsed object or default value
    """
    try:
        if not json_string or not isinstance(json_string, str):
            return default
        
        return json.loads(json_string)
    
    except json.JSONDecodeError:
        return default
    
    except Exception:
        return default

def generate_id(prefix: str = "", length: int = 16) -> str:
    """
    Generate unique ID
    
    Args:
        prefix: Optional prefix for ID
        length: Length of random part
    
    Returns:
        Unique ID string
    """
    import uuid
    
    random_part = uuid.uuid4().hex[:length]
    
    if prefix:
        return f"{prefix}_{random_part}"
    
    return random_part

def hash_string(text: str, algorithm: str = 'sha256') -> str:
    """
    Hash string using specified algorithm
    
    Args:
        text: String to hash
        algorithm: Hash algorithm (sha256, md5, sha512)
    
    Returns:
        Hex digest of hash
    
    Raises:
        ValueError: If algorithm not supported
    """
    if algorithm not in ['sha256', 'md5', 'sha512']:
        raise ValueError(f"Unsupported algorithm: {algorithm}")
    
    if algorithm == 'sha256':
        return hashlib.sha256(text.encode()).hexdigest()
    elif algorithm == 'md5':
        return hashlib.md5(text.encode()).hexdigest()
    else:
        return hashlib.sha512(text.encode()).hexdigest()

def truncate_text(text: str, max_length: int, suffix: str = "...") -> str:
    """
    Truncate text to max length
    
    Args:
        text: Text to truncate
        max_length: Maximum length
        suffix: Suffix to add if truncated
    
    Returns:
        Truncated text
    """
    if not text or len(text) <= max_length:
        return text
    
    return text[:max_length - len(suffix)] + suffix

def merge_dicts(*dicts: Dict[str, Any]) -> Dict[str, Any]:
    """
    Merge multiple dictionaries
    Later dicts override earlier ones
    
    Args:
        *dicts: Variable number of dicts to merge
    
    Returns:
        Merged dictionary
    """
    result = {}
    
    for d in dicts:
        if isinstance(d, dict):
            result.update(d)
    
    return result

def filter_dict(data: Dict[str, Any], allowed_keys: List[str]) -> Dict[str, Any]:
    """
    Filter dictionary to only allowed keys
    
    Args:
        data: Input dictionary
        allowed_keys: List of allowed keys
    
    Returns:
        Filtered dictionary
    """
    return {k: v for k, v in data.items() if k in allowed_keys}

def retry_on_failure(
    func: Callable,
    max_attempts: int = 3,
    delay: float = 1.0
) -> Any:
    """
    Retry function on failure
    
    Args:
        func: Function to retry
        max_attempts: Maximum retry attempts
        delay: Delay between retries (seconds)
    
    Returns:
        Function result
    
    Raises:
        Exception: If all attempts fail
    """
    import time
    
    last_exception: Optional[Exception] = None
    
    for attempt in range(max_attempts):
        try:
            return func()
        
        except Exception as e:
            last_exception = e
            
            if attempt < max_attempts - 1:
                time.sleep(delay)
            
            continue
    
    if last_exception:
        raise last_exception
    
    raise Exception("All attempts failed")

def format_timestamp(timestamp: Optional[str] = None, format_str: str = "%Y-%m-%d %H:%M:%S") -> str:
    """
    Format timestamp to readable string
    
    Args:
        timestamp: ISO timestamp (default: now)
        format_str: Output format
    
    Returns:
        Formatted timestamp string
    """
    if timestamp:
        dt = datetime.fromisoformat(timestamp)
    else:
        dt = datetime.now()
    
    return dt.strftime(format_str)
