"""
Database Model Template - Học từ CipherH AI gốc
Style: Class-based model, validation methods, to_dict conversion
"""

from typing import Dict, Any, Optional, List
from datetime import datetime
import json

class BaseModel:
    """
    Base model với common methods
    Các model khác inherit từ đây
    """
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert model to dictionary"""
        raise NotImplementedError("Subclass must implement to_dict()")
    
    def validate(self) -> bool:
        """Validate model data"""
        raise NotImplementedError("Subclass must implement validate()")
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]):
        """Create model instance from dictionary"""
        raise NotImplementedError("Subclass must implement from_dict()")

class UserModel(BaseModel):
    """
    User model example
    
    Attributes:
        id: Unique identifier
        name: User name
        email: User email
        created_at: Timestamp
        metadata: Additional data
    """
    
    def __init__(
        self,
        id: Optional[str] = None,
        name: str = "",
        email: str = "",
        created_at: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None
    ):
        self.id = id
        self.name = name
        self.email = email
        self.created_at = created_at or datetime.now().isoformat()
        self.metadata = metadata or {}
    
    def validate(self) -> bool:
        """
        Validate user data
        
        Returns:
            True if valid
        
        Raises:
            ValueError: If validation fails
        """
        if not self.name or len(self.name.strip()) == 0:
            raise ValueError("name is required")
        
        if not self.email or '@' not in self.email:
            raise ValueError("valid email is required")
        
        if not isinstance(self.metadata, dict):
            raise ValueError("metadata must be dict")
        
        return True
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization"""
        return {
            "id": self.id,
            "name": self.name,
            "email": self.email,
            "created_at": self.created_at,
            "metadata": self.metadata
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'UserModel':
        """
        Create UserModel from dictionary
        
        Args:
            data: Dict containing user data
        
        Returns:
            UserModel instance
        """
        return cls(
            id=data.get('id'),
            name=data.get('name', ''),
            email=data.get('email', ''),
            created_at=data.get('created_at'),
            metadata=data.get('metadata', {})
        )
    
    def update(self, **kwargs) -> None:
        """
        Update model attributes
        
        Args:
            **kwargs: Attributes to update
        """
        for key, value in kwargs.items():
            if hasattr(self, key):
                setattr(self, key, value)
    
    def __repr__(self) -> str:
        return f"UserModel(id={self.id}, name={self.name}, email={self.email})"

class ConversationModel(BaseModel):
    """
    Conversation model example
    Lưu trữ cuộc hội thoại
    """
    
    def __init__(
        self,
        id: Optional[str] = None,
        user_message: str = "",
        ai_response: str = "",
        timestamp: Optional[str] = None,
        tags: Optional[List[str]] = None
    ):
        self.id = id
        self.user_message = user_message
        self.ai_response = ai_response
        self.timestamp = timestamp or datetime.now().isoformat()
        self.tags = tags or []
    
    def validate(self) -> bool:
        if not self.user_message:
            raise ValueError("user_message is required")
        
        if not self.ai_response:
            raise ValueError("ai_response is required")
        
        if not isinstance(self.tags, list):
            raise ValueError("tags must be list")
        
        return True
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "user_message": self.user_message,
            "ai_response": self.ai_response,
            "timestamp": self.timestamp,
            "tags": self.tags
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ConversationModel':
        return cls(
            id=data.get('id'),
            user_message=data.get('user_message', ''),
            ai_response=data.get('ai_response', ''),
            timestamp=data.get('timestamp'),
            tags=data.get('tags', [])
        )
    
    def add_tag(self, tag: str) -> None:
        """Add tag to conversation"""
        if tag not in self.tags:
            self.tags.append(tag)
    
    def remove_tag(self, tag: str) -> None:
        """Remove tag from conversation"""
        if tag in self.tags:
            self.tags.remove(tag)
