import os
import ast
import json
from typing import Dict, Any, List, Optional
from datetime import datetime

class AdaptiveLogic:
    def __init__(self):
        self.brain_dir = 'cipherh_brain'
        self.self_map_file = os.path.join(self.brain_dir, 'self_map.json')
        
        if not os.path.exists(self.self_map_file):
            self.build_self_map()
    
    def build_self_map(self) -> Dict[str, Any]:
        self_map = {
            "timestamp": datetime.now().isoformat(),
            "project_root": os.getcwd(),
            "files": [],
            "dependencies": [],
            "core_modules": [],
            "utility_modules": [],
            "api_routes": [],
            "performance": {},
            "warnings": []
        }
        
        for root, dirs, files in os.walk('.'):
            if any(skip in root for skip in ['node_modules', '.git', '__pycache__', 'venv', 'backups']):
                continue
            
            for file in files:
                filepath = os.path.join(root, file)
                
                if file.endswith('.py'):
                    file_info = self._analyze_python_file(filepath)
                    self_map["files"].append(file_info)
                    
                    if 'routes/' in filepath:
                        self_map["api_routes"].append(filepath)
                    elif 'utils/' in filepath:
                        self_map["utility_modules"].append(filepath)
                    elif any(core in filepath for core in ['brain', 'memory', 'pipeline']):
                        self_map["core_modules"].append(filepath)
                
                elif file == 'requirements.txt':
                    with open(filepath, 'r') as f:
                        self_map["dependencies"] = [line.strip() for line in f if line.strip()]
        
        self_map["warnings"] = self._detect_issues(self_map)
        
        with open(self.self_map_file, 'w') as f:
            json.dump(self_map, f, indent=2)
        
        return self_map
    
    def _analyze_python_file(self, filepath: str) -> Dict[str, Any]:
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                code = f.read()
            
            tree = ast.parse(code)
            
            info = {
                "path": filepath,
                "lines": len(code.split('\n')),
                "functions": [],
                "classes": [],
                "imports": [],
                "complexity": 0
            }
            
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef):
                    info["functions"].append(node.name)
                    info["complexity"] += len(node.body)
                
                elif isinstance(node, ast.ClassDef):
                    info["classes"].append(node.name)
                
                elif isinstance(node, ast.Import):
                    for alias in node.names:
                        info["imports"].append(alias.name)
                
                elif isinstance(node, ast.ImportFrom):
                    if node.module:
                        info["imports"].append(node.module)
            
            return info
        
        except Exception as e:
            return {
                "path": filepath,
                "error": str(e)
            }
    
    def _detect_issues(self, self_map: Dict[str, Any]) -> List[str]:
        warnings = []
        
        for file_info in self_map.get("files", []):
            if file_info.get("lines", 0) > 500:
                warnings.append(f"File too large: {file_info['path']} ({file_info['lines']} lines)")
            
            if file_info.get("complexity", 0) > 100:
                warnings.append(f"High complexity: {file_info['path']} (complexity: {file_info['complexity']})")
        
        return warnings
    
    def optimize_structure(self) -> Dict[str, Any]:
        self_map = self.get_self_map()
        
        optimizations = []
        
        for file_info in self_map.get("files", []):
            if file_info.get("lines", 0) > 500:
                optimizations.append({
                    "action": "split_file",
                    "target": file_info["path"],
                    "reason": "File too large"
                })
            
            if file_info.get("complexity", 0) > 100:
                optimizations.append({
                    "action": "refactor_complexity",
                    "target": file_info["path"],
                    "reason": "High complexity"
                })
        
        return {
            "timestamp": datetime.now().isoformat(),
            "optimizations_suggested": len(optimizations),
            "optimizations": optimizations
        }
    
    def refactor_functions(self, filepath: str) -> Dict[str, Any]:
        if not os.path.exists(filepath):
            return {"error": "File not found"}
        
        with open(filepath, 'r', encoding='utf-8') as f:
            code = f.read()
        
        try:
            tree = ast.parse(code)
            
            long_functions = []
            
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef):
                    if len(node.body) > 30:
                        long_functions.append({
                            "name": node.name,
                            "line": node.lineno,
                            "length": len(node.body),
                            "suggestion": "Split into smaller functions"
                        })
            
            return {
                "file": filepath,
                "long_functions": long_functions,
                "suggestions": len(long_functions)
            }
        
        except Exception as e:
            return {"error": str(e)}
    
    def improve_performance(self, filepath: str) -> Dict[str, Any]:
        if not os.path.exists(filepath):
            return {"error": "File not found"}
        
        with open(filepath, 'r', encoding='utf-8') as f:
            code = f.read()
        
        improvements = []
        
        if 'for ' in code and 'in range(' in code:
            improvements.append({
                "type": "loop_optimization",
                "suggestion": "Consider list comprehension or numpy for large ranges"
            })
        
        if code.count('for ') > 3:
            improvements.append({
                "type": "nested_loops",
                "suggestion": "Check for nested loops, consider optimization"
            })
        
        if '.append(' in code and 'for ' in code:
            improvements.append({
                "type": "list_building",
                "suggestion": "Consider using list comprehension instead of append in loop"
            })
        
        return {
            "file": filepath,
            "improvements": improvements,
            "count": len(improvements)
        }
    
    def reduce_complexity(self, filepath: str) -> Dict[str, Any]:
        if not os.path.exists(filepath):
            return {"error": "File not found"}
        
        with open(filepath, 'r', encoding='utf-8') as f:
            code = f.read()
        
        try:
            tree = ast.parse(code)
            
            complexity_issues = []
            
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef):
                    branches = 0
                    for child in ast.walk(node):
                        if isinstance(child, (ast.If, ast.For, ast.While, ast.Try)):
                            branches += 1
                    
                    if branches > 5:
                        complexity_issues.append({
                            "function": node.name,
                            "line": node.lineno,
                            "branches": branches,
                            "suggestion": "Reduce branching, extract logic"
                        })
            
            return {
                "file": filepath,
                "complexity_issues": complexity_issues,
                "count": len(complexity_issues)
            }
        
        except Exception as e:
            return {"error": str(e)}
    
    def auto_split_or_merge_files(self) -> Dict[str, Any]:
        self_map = self.get_self_map()
        
        actions = []
        
        for file_info in self_map.get("files", []):
            lines = file_info.get("lines", 0)
            
            if lines > 600:
                actions.append({
                    "action": "split",
                    "file": file_info["path"],
                    "reason": f"Too large ({lines} lines)"
                })
            
            elif lines < 50 and len(file_info.get("functions", [])) < 3:
                actions.append({
                    "action": "consider_merge",
                    "file": file_info["path"],
                    "reason": f"Very small ({lines} lines), could merge with related module"
                })
        
        return {
            "timestamp": datetime.now().isoformat(),
            "actions_suggested": len(actions),
            "actions": actions
        }
    
    def get_self_map(self) -> Dict[str, Any]:
        if not os.path.exists(self.self_map_file):
            return self.build_self_map()
        
        with open(self.self_map_file, 'r') as f:
            return json.load(f)
    
    def refresh_self_map(self) -> Dict[str, Any]:
        return self.build_self_map()
