import os
import re
import ast
import json
from typing import Dict, Any, List, Optional, Tuple
from datetime import datetime
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

class HackerMindset:
    def __init__(self):
        api_key = os.getenv('OPENAI_API_KEY')
        if not api_key:
            raise ValueError("OPENAI_API_KEY not found")
        
        self.client = OpenAI(api_key=api_key)
        self.model = os.getenv('OPENAI_MODEL', 'gpt-4o-mini')
        self.brain_dir = 'cipherh_brain'
        self.learning_dir = os.path.join(self.brain_dir, 'learning')
        self.patterns_file = os.path.join(self.brain_dir, 'style_patterns.json')
        self.security_log = os.path.join(self.brain_dir, 'security_audit.json')
        
        os.makedirs(self.learning_dir, exist_ok=True)
        
        if not os.path.exists(self.patterns_file):
            self._init_patterns()
    
    def _init_patterns(self):
        initial_patterns = {
            "coding_patterns": [],
            "naming_conventions": {
                "functions": "snake_case",
                "classes": "PascalCase",
                "variables": "snake_case",
                "constants": "UPPER_CASE"
            },
            "error_handling_style": "try_except_with_logging",
            "api_structure": "flask_blueprint",
            "validation_patterns": [],
            "refactor_patterns": [],
            "learned_from": [],
            "last_updated": datetime.now().isoformat()
        }
        
        with open(self.patterns_file, 'w') as f:
            json.dump(initial_patterns, f, indent=2)
    
    def code_auditor_mode(self, file_path: str) -> Dict[str, Any]:
        if not os.path.exists(file_path):
            return {"error": "File not found"}
        
        with open(file_path, 'r', encoding='utf-8') as f:
            code = f.read()
        
        issues = {
            "code_smells": [],
            "security_risks": [],
            "logic_risks": [],
            "refactor_suggestions": [],
            "severity": "low"
        }
        
        try:
            tree = ast.parse(code)
            
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef):
                    if len(node.body) > 50:
                        issues["code_smells"].append({
                            "type": "long_function",
                            "function": node.name,
                            "line": node.lineno,
                            "message": f"Function {node.name} has {len(node.body)} statements"
                        })
                    
                    if not ast.get_docstring(node):
                        issues["code_smells"].append({
                            "type": "missing_docstring",
                            "function": node.name,
                            "line": node.lineno,
                            "message": f"Function {node.name} missing docstring"
                        })
                
                if isinstance(node, ast.Str):
                    if re.search(r'(password|secret|api_key|token)\s*=\s*["\']', node.s, re.IGNORECASE):
                        issues["security_risks"].append({
                            "type": "hardcoded_credential",
                            "line": getattr(node, 'lineno', 0),
                            "message": "Possible hardcoded credential detected",
                            "severity": "high"
                        })
                        issues["severity"] = "high"
        
        except SyntaxError as e:
            issues["logic_risks"].append({
                "type": "syntax_error",
                "message": str(e)
            })
        
        security_issues = self._deep_security_scan(code)
        issues["security_risks"].extend(security_issues)
        
        if security_issues:
            issues["severity"] = "high"
        
        return issues
    
    def _deep_security_scan(self, code: str) -> List[Dict[str, Any]]:
        risks = []
        
        if re.search(r'eval\(|exec\(', code):
            risks.append({
                "type": "dangerous_function",
                "message": "Use of eval() or exec() detected - RCE risk",
                "severity": "critical"
            })
        
        if re.search(r'\.format\([^)]*request\.|f["\'].*\{request\.', code):
            risks.append({
                "type": "sql_injection_risk",
                "message": "Possible SQL injection via string formatting",
                "severity": "high"
            })
        
        if re.search(r'<.*\{.*\}.*>', code) and 'escape' not in code:
            risks.append({
                "type": "xss_risk",
                "message": "Possible XSS - unescaped user input in HTML",
                "severity": "high"
            })
        
        if 'request.args.get' in code or 'request.form.get' in code:
            if 'sanitize' not in code and 'validate' not in code:
                risks.append({
                    "type": "unvalidated_input",
                    "message": "User input not validated/sanitized",
                    "severity": "medium"
                })
        
        if re.search(r'["\']https?://["\'].*request\.', code):
            risks.append({
                "type": "ssrf_risk",
                "message": "Possible SSRF - user-controlled URL",
                "severity": "high"
            })
        
        if 'cors' in code.lower() and '*' in code:
            risks.append({
                "type": "cors_misconfiguration",
                "message": "CORS allows all origins - security risk",
                "severity": "medium"
            })
        
        return risks
    
    def security_scan(self, directory: str = '.') -> Dict[str, Any]:
        scan_results = {
            "timestamp": datetime.now().isoformat(),
            "files_scanned": 0,
            "total_issues": 0,
            "critical": 0,
            "high": 0,
            "medium": 0,
            "low": 0,
            "files_with_issues": []
        }
        
        for root, dirs, files in os.walk(directory):
            if 'node_modules' in root or '.git' in root or '__pycache__' in root:
                continue
            
            for file in files:
                if file.endswith('.py'):
                    file_path = os.path.join(root, file)
                    
                    audit = self.code_auditor_mode(file_path)
                    
                    if audit.get('security_risks') or audit.get('code_smells'):
                        scan_results['files_scanned'] += 1
                        
                        total_file_issues = len(audit.get('security_risks', [])) + len(audit.get('code_smells', []))
                        scan_results['total_issues'] += total_file_issues
                        
                        for risk in audit.get('security_risks', []):
                            severity = risk.get('severity', 'low')
                            if severity == 'critical':
                                scan_results['critical'] += 1
                            elif severity == 'high':
                                scan_results['high'] += 1
                            elif severity == 'medium':
                                scan_results['medium'] += 1
                            else:
                                scan_results['low'] += 1
                        
                        scan_results['files_with_issues'].append({
                            "file": file_path,
                            "issues": audit
                        })
        
        with open(self.security_log, 'w') as f:
            json.dump(scan_results, f, indent=2)
        
        return scan_results
    
    def simulate_attack(self, attack_type: str, target_code: str) -> Dict[str, Any]:
        simulations = {
            "sqli": self._simulate_sqli,
            "xss": self._simulate_xss,
            "invalid_token": self._simulate_invalid_token,
            "rate_limit": self._simulate_rate_limit,
            "brute_force": self._simulate_brute_force
        }
        
        if attack_type not in simulations:
            return {"error": f"Unknown attack type: {attack_type}"}
        
        return simulations[attack_type](target_code)
    
    def _simulate_sqli(self, code: str) -> Dict[str, Any]:
        payloads = [
            "' OR '1'='1",
            "'; DROP TABLE users--",
            "admin'--",
            "1' UNION SELECT NULL--"
        ]
        
        vulnerabilities = []
        
        for payload in payloads:
            if '.format(' in code or 'f"' in code or "f'" in code:
                if 'sanitize' not in code and 'escape' not in code:
                    vulnerabilities.append({
                        "payload": payload,
                        "risk": "SQL injection possible",
                        "severity": "high"
                    })
        
        return {
            "attack_type": "SQL Injection",
            "vulnerable": len(vulnerabilities) > 0,
            "vulnerabilities": vulnerabilities,
            "recommendation": "Use parameterized queries or ORM"
        }
    
    def _simulate_xss(self, code: str) -> Dict[str, Any]:
        payloads = [
            "<script>alert('XSS')</script>",
            "<img src=x onerror=alert('XSS')>",
            "javascript:alert('XSS')"
        ]
        
        vulnerabilities = []
        
        if 'render_template' in code or 'jsonify' in code:
            if 'escape' not in code and 'sanitize' not in code:
                for payload in payloads:
                    vulnerabilities.append({
                        "payload": payload,
                        "risk": "XSS possible in template rendering",
                        "severity": "high"
                    })
        
        return {
            "attack_type": "XSS",
            "vulnerable": len(vulnerabilities) > 0,
            "vulnerabilities": vulnerabilities,
            "recommendation": "Use auto-escaping templates or sanitize user input"
        }
    
    def _simulate_invalid_token(self, code: str) -> Dict[str, Any]:
        test_tokens = [
            "invalid_token",
            "",
            "eyJhbGciOiJub25lIn0.eyJzdWIiOiIxMjM0NTY3ODkwIn0.",
            "Bearer malicious_token"
        ]
        
        vulnerabilities = []
        
        if 'token' in code.lower():
            if 'verify' not in code and 'validate' not in code:
                vulnerabilities.append({
                    "risk": "Token not verified",
                    "severity": "critical"
                })
        
        return {
            "attack_type": "Invalid Token",
            "vulnerable": len(vulnerabilities) > 0,
            "vulnerabilities": vulnerabilities,
            "recommendation": "Always verify tokens with proper signature validation"
        }
    
    def _simulate_rate_limit(self, code: str) -> Dict[str, Any]:
        if 'rate_limit' not in code.lower() and 'throttle' not in code.lower():
            return {
                "attack_type": "Rate Limit Bypass",
                "vulnerable": True,
                "vulnerabilities": [{
                    "risk": "No rate limiting detected",
                    "severity": "medium"
                }],
                "recommendation": "Implement rate limiting on API endpoints"
            }
        
        return {
            "attack_type": "Rate Limit Bypass",
            "vulnerable": False,
            "vulnerabilities": [],
            "recommendation": "Rate limiting appears to be implemented"
        }
    
    def _simulate_brute_force(self, code: str) -> Dict[str, Any]:
        vulnerabilities = []
        
        if 'login' in code.lower() or 'password' in code.lower():
            if 'attempt' not in code.lower() and 'lock' not in code.lower():
                vulnerabilities.append({
                    "risk": "No brute force protection",
                    "severity": "high"
                })
        
        return {
            "attack_type": "Brute Force",
            "vulnerable": len(vulnerabilities) > 0,
            "vulnerabilities": vulnerabilities,
            "recommendation": "Implement login attempt limiting and account lockout"
        }
    
    def mirror_mode(self, code: str, source: str = "replit") -> str:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{source}_{timestamp}.py"
        filepath = os.path.join(self.learning_dir, filename)
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(f"# Learned from: {source}\n")
            f.write(f"# Timestamp: {timestamp}\n\n")
            f.write(code)
        
        self.extract_patterns(code, source)
        
        return filepath
    
    def extract_patterns(self, code: str, source: str = "unknown") -> Dict[str, Any]:
        with open(self.patterns_file, 'r') as f:
            patterns = json.load(f)
        
        try:
            tree = ast.parse(code)
            
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef):
                    pattern = {
                        "type": "function",
                        "name": node.name,
                        "args_count": len(node.args.args),
                        "has_docstring": ast.get_docstring(node) is not None,
                        "decorators": [d.id if isinstance(d, ast.Name) else str(d) for d in node.decorator_list],
                        "source": source,
                        "learned_at": datetime.now().isoformat()
                    }
                    
                    if pattern not in patterns["coding_patterns"]:
                        patterns["coding_patterns"].append(pattern)
                
                if isinstance(node, ast.Try):
                    error_pattern = {
                        "type": "error_handling",
                        "has_except": len(node.handlers) > 0,
                        "has_finally": node.finalbody is not None,
                        "source": source
                    }
                    
                    if error_pattern not in patterns["coding_patterns"]:
                        patterns["coding_patterns"].append(error_pattern)
            
            if source not in patterns["learned_from"]:
                patterns["learned_from"].append(source)
            
            patterns["last_updated"] = datetime.now().isoformat()
            
            with open(self.patterns_file, 'w') as f:
                json.dump(patterns, f, indent=2)
        
        except Exception as e:
            print(f"Pattern extraction error: {e}")
        
        return patterns
    
    def reflect(self, code: str) -> Dict[str, Any]:
        with open(self.patterns_file, 'r') as f:
            learned_patterns = json.load(f)
        
        score = {
            "total": 100,
            "naming_compliance": 0,
            "docstring_coverage": 0,
            "error_handling": 0,
            "security_score": 0,
            "overall": 0,
            "improvements": []
        }
        
        try:
            tree = ast.parse(code)
            
            total_functions = 0
            functions_with_docstrings = 0
            error_handling_count = 0
            
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef):
                    total_functions += 1
                    
                    if ast.get_docstring(node):
                        functions_with_docstrings += 1
                    else:
                        score["improvements"].append(f"Add docstring to {node.name}")
                    
                    if not node.name.islower():
                        score["improvements"].append(f"Function {node.name} should be snake_case")
                
                if isinstance(node, ast.Try):
                    error_handling_count += 1
            
            if total_functions > 0:
                score["docstring_coverage"] = (functions_with_docstrings / total_functions) * 30
                score["naming_compliance"] = 25
            
            score["error_handling"] = min(error_handling_count * 10, 25)
            
            security_audit = self._deep_security_scan(code)
            if not security_audit:
                score["security_score"] = 20
            else:
                score["security_score"] = max(0, 20 - len(security_audit) * 5)
                for risk in security_audit:
                    score["improvements"].append(f"Security: {risk['message']}")
            
            score["overall"] = (
                score["naming_compliance"] +
                score["docstring_coverage"] +
                score["error_handling"] +
                score["security_score"]
            )
        
        except Exception as e:
            score["improvements"].append(f"Cannot parse code: {e}")
        
        return score
    
    def style_reinforcement(self, task_description: str) -> str:
        with open(self.patterns_file, 'r') as f:
            patterns = json.load(f)
        
        prompt = f"""Viết code Python cho task sau, tuân thủ CHÍNH XÁC style patterns đã học:

TASK: {task_description}

LEARNED PATTERNS:
{json.dumps(patterns, indent=2)[:2000]}

YÊU CẦU:
- Naming convention: {patterns['naming_conventions']}
- Error handling: {patterns['error_handling_style']}
- PHẢI có docstring đầy đủ
- PHẢI có error handling
- PHẢI validate input
- PHẢI security-first

Trả về code hoàn chỉnh, không markdown."""
        
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "Bạn là senior developer với hacker mindset. Code phải bền, an toàn, tối ưu."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.2,
                max_tokens=2000
            )
            
            content = response.choices[0].message.content
            return content.strip() if content else ""
        
        except Exception as e:
            return f"# Error: {e}"
    
    def get_security_report(self) -> Dict[str, Any]:
        if not os.path.exists(self.security_log):
            return {"error": "No security scan performed yet"}
        
        with open(self.security_log, 'r') as f:
            return json.load(f)
    
    def get_learned_patterns(self) -> Dict[str, Any]:
        if not os.path.exists(self.patterns_file):
            return {"error": "No patterns learned yet"}
        
        with open(self.patterns_file, 'r') as f:
            return json.load(f)
