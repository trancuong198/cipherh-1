import os
import json
import time
import threading
import queue
from typing import Dict, Any, List, Optional, Callable
from datetime import datetime
from enum import Enum
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

class EventType(Enum):
    HTTP_REQUEST = "http_request"
    DATABASE_CHANGE = "database_change"
    API_CALLBACK = "api_callback"
    CODE_CHANGE = "code_change"
    SECURITY_ALERT = "security_alert"
    ERROR = "error"
    PERFORMANCE = "performance"

class EventPriority(Enum):
    CRITICAL = 1
    HIGH = 2
    MEDIUM = 3
    LOW = 4

class RealTimeBrain:
    def __init__(self):
        api_key = os.getenv('OPENAI_API_KEY')
        if not api_key:
            raise ValueError("OPENAI_API_KEY not found")
        
        self.client = OpenAI(api_key=api_key)
        self.model = os.getenv('OPENAI_MODEL', 'gpt-4o-mini')
        self.brain_dir = 'cipherh_brain'
        self.event_log = os.path.join(self.brain_dir, 'event_log.json')
        self.brain_state = os.path.join(self.brain_dir, 'brain_state.json')
        
        self.event_queue = queue.PriorityQueue()
        self.is_running = False
        self.processing_thread = None
        
        self.event_handlers: Dict[EventType, Callable] = {}
        self.action_count = 0
        self.last_action_time = time.time()
        
        if not os.path.exists(self.event_log):
            self._init_event_log()
        
        if not os.path.exists(self.brain_state):
            self._init_brain_state()
        
        self._register_default_handlers()
    
    def _init_event_log(self):
        log_data = {
            "initialized": datetime.now().isoformat(),
            "total_events": 0,
            "events": []
        }
        
        with open(self.event_log, 'w') as f:
            json.dump(log_data, f, indent=2)
    
    def _init_brain_state(self):
        state = {
            "status": "initialized",
            "uptime_start": datetime.now().isoformat(),
            "total_actions": 0,
            "successful_actions": 0,
            "failed_actions": 0,
            "learning_rate": 1.0,
            "adaptive_speed": "normal",
            "last_updated": datetime.now().isoformat()
        }
        
        with open(self.brain_state, 'w') as f:
            json.dump(state, f, indent=2)
    
    def _register_default_handlers(self):
        self.event_handlers[EventType.SECURITY_ALERT] = self._handle_security_alert
        self.event_handlers[EventType.ERROR] = self._handle_error
        self.event_handlers[EventType.CODE_CHANGE] = self._handle_code_change
        self.event_handlers[EventType.PERFORMANCE] = self._handle_performance
        self.event_handlers[EventType.HTTP_REQUEST] = self._handle_http_request
    
    def start(self):
        if self.is_running:
            return {"status": "already_running"}
        
        self.is_running = True
        self.processing_thread = threading.Thread(target=self._event_loop, daemon=True)
        self.processing_thread.start()
        
        self._update_brain_state({"status": "running"})
        
        return {
            "status": "started",
            "timestamp": datetime.now().isoformat()
        }
    
    def stop(self):
        if not self.is_running:
            return {"status": "not_running"}
        
        self.is_running = False
        if self.processing_thread:
            self.processing_thread.join(timeout=5)
        
        self._update_brain_state({"status": "stopped"})
        
        return {
            "status": "stopped",
            "timestamp": datetime.now().isoformat()
        }
    
    def push_event(self, event_type: EventType, data: Dict[str, Any], priority: EventPriority = EventPriority.MEDIUM):
        event = {
            "id": f"evt_{int(time.time() * 1000)}",
            "type": event_type.value,
            "data": data,
            "priority": priority.value,
            "timestamp": datetime.now().isoformat(),
            "processed": False
        }
        
        self.event_queue.put((priority.value, event))
        
        self._log_event(event)
        
        return event
    
    def _event_loop(self):
        while self.is_running:
            try:
                if not self.event_queue.empty():
                    priority, event = self.event_queue.get(timeout=1)
                    
                    self._process_event(event)
                    
                    event["processed"] = True
                    self.event_queue.task_done()
                else:
                    time.sleep(0.1)
            
            except queue.Empty:
                continue
            except Exception as e:
                print(f"Event loop error: {e}")
    
    def _process_event(self, event: Dict[str, Any]):
        event_type_str = event.get('type')
        
        try:
            event_type = EventType(event_type_str)
        except ValueError:
            event_type = None
        
        if event_type and event_type in self.event_handlers:
            handler = self.event_handlers[event_type]
            
            try:
                action = handler(event)
                
                if action:
                    self._execute_action(action, event)
            
            except Exception as e:
                print(f"Handler error for {event_type}: {e}")
        
        self._real_time_learning(event)
    
    def _execute_action(self, action: Dict[str, Any], event: Dict[str, Any]):
        action_type = action.get('type')
        
        result = {
            "action_id": f"act_{int(time.time() * 1000)}",
            "action_type": action_type,
            "event_id": event.get('id'),
            "timestamp": datetime.now().isoformat(),
            "success": False
        }
        
        try:
            if action_type == "mutation":
                result["result"] = self._execute_mutation(action)
                result["success"] = result["result"].get("success", False)
            
            elif action_type == "security_scan":
                result["result"] = self._execute_security_scan(action)
                result["success"] = True
            
            elif action_type == "debug":
                result["result"] = self._execute_debug(action)
                result["success"] = True
            
            elif action_type == "log":
                result["result"] = self._execute_log(action)
                result["success"] = True
            
            elif action_type == "notify":
                result["result"] = self._execute_notify(action)
                result["success"] = True
            
            self.action_count += 1
            self.last_action_time = time.time()
            
            self._update_brain_state({
                "total_actions": self.action_count,
                "successful_actions": self.action_count if result["success"] else 0
            })
            
            self._feedback_loop(result, event)
        
        except Exception as e:
            result["error"] = str(e)
            result["success"] = False
            
            self._update_brain_state({
                "failed_actions": self.action_count
            })
    
    def _execute_mutation(self, action: Dict[str, Any]) -> Dict[str, Any]:
        from cipherh_brain.evolution_kernel import EvolutionKernel
        
        kernel = EvolutionKernel()
        
        target_file = action.get('target_file')
        mutation_type = action.get('mutation_type', 'auto')
        
        if not target_file:
            return {"success": False, "error": "No target file"}
        
        mutation = kernel.generate_mutation(target_file, mutation_type)
        
        test_result = kernel.test_mutation(mutation)
        
        if test_result.get('passed'):
            apply_result = kernel.apply_mutation(mutation)
            return apply_result
        else:
            return {
                "success": False,
                "reason": "mutation_failed_test",
                "errors": test_result.get('errors')
            }
    
    def _execute_security_scan(self, action: Dict[str, Any]) -> Dict[str, Any]:
        from cipherh_brain.hacker import HackerMindset
        
        hacker = HackerMindset()
        
        directory = action.get('directory', '.')
        
        scan_result = hacker.security_scan(directory)
        
        return scan_result
    
    def _execute_debug(self, action: Dict[str, Any]) -> Dict[str, Any]:
        from cipherh_brain.hacker import HackerMindset
        
        hacker = HackerMindset()
        
        file_path = action.get('file_path')
        
        if not file_path:
            return {"error": "No file path"}
        
        audit = hacker.code_auditor_mode(file_path)
        
        return audit
    
    def _execute_log(self, action: Dict[str, Any]) -> Dict[str, Any]:
        message = action.get('message', '')
        severity = action.get('severity', 'info')
        
        log_entry = {
            "timestamp": datetime.now().isoformat(),
            "severity": severity,
            "message": message
        }
        
        return log_entry
    
    def _execute_notify(self, action: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "notified": True,
            "message": action.get('message')
        }
    
    def _handle_security_alert(self, event: Dict[str, Any]) -> Dict[str, Any]:
        data = event.get('data', {})
        
        return {
            "type": "security_scan",
            "directory": data.get('directory', '.'),
            "priority": "critical"
        }
    
    def _handle_error(self, event: Dict[str, Any]) -> Dict[str, Any]:
        data = event.get('data', {})
        
        file_path = data.get('file_path')
        
        if file_path and os.path.exists(file_path):
            return {
                "type": "mutation",
                "target_file": file_path,
                "mutation_type": "auto"
            }
        
        return {
            "type": "log",
            "message": f"Error event: {data.get('error')}",
            "severity": "error"
        }
    
    def _handle_code_change(self, event: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        data = event.get('data', {})
        
        file_path = data.get('file_path')
        
        if file_path and os.path.exists(file_path):
            return {
                "type": "debug",
                "file_path": file_path
            }
        
        return None
    
    def _handle_performance(self, event: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        data = event.get('data', {})
        
        file_path = data.get('file_path')
        
        if file_path and os.path.exists(file_path):
            return {
                "type": "mutation",
                "target_file": file_path,
                "mutation_type": "optimize"
            }
        
        return None
    
    def _handle_http_request(self, event: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        data = event.get('data', {})
        
        if data.get('status_code', 200) >= 500:
            return {
                "type": "log",
                "message": f"Server error: {data.get('path')}",
                "severity": "error"
            }
        
        return None
    
    def _real_time_learning(self, event: Dict[str, Any]):
        from cipherh_brain.hacker import HackerMindset
        
        event_type = event.get('type')
        data = event.get('data', {})
        
        if event_type == EventType.CODE_CHANGE.value:
            code = data.get('code')
            
            if code:
                hacker = HackerMindset()
                hacker.extract_patterns(code, source="realtime_event")
        
        self._update_brain_state({
            "last_learning_event": datetime.now().isoformat(),
            "learning_rate": self._calculate_learning_rate()
        })
    
    def _calculate_learning_rate(self) -> float:
        time_since_last = time.time() - self.last_action_time
        
        if time_since_last < 60:
            return 1.5
        elif time_since_last < 300:
            return 1.0
        else:
            return 0.5
    
    def _feedback_loop(self, result: Dict[str, Any], event: Dict[str, Any]):
        if result.get('success'):
            adaptive_speed = "fast"
        else:
            adaptive_speed = "slow"
        
        self._update_brain_state({
            "adaptive_speed": adaptive_speed,
            "last_feedback": datetime.now().isoformat()
        })
        
        if not result.get('success') and result.get('action_type') == 'mutation':
            from cipherh_brain.evolution_kernel import EvolutionKernel
            
            kernel = EvolutionKernel()
            
            target_file = event.get('data', {}).get('file_path')
            
            if target_file:
                kernel.rollback(target_file)
    
    def _log_event(self, event: Dict[str, Any]):
        try:
            with open(self.event_log, 'r') as f:
                log_data = json.load(f)
            
            log_data["total_events"] += 1
            log_data["events"].append(event)
            
            if len(log_data["events"]) > 1000:
                log_data["events"] = log_data["events"][-1000:]
            
            with open(self.event_log, 'w') as f:
                json.dump(log_data, f, indent=2)
        
        except Exception as e:
            print(f"Event logging error: {e}")
    
    def _update_brain_state(self, updates: Dict[str, Any]):
        try:
            with open(self.brain_state, 'r') as f:
                state = json.load(f)
            
            state.update(updates)
            state["last_updated"] = datetime.now().isoformat()
            
            with open(self.brain_state, 'w') as f:
                json.dump(state, f, indent=2)
        
        except Exception as e:
            print(f"State update error: {e}")
    
    def get_brain_state(self) -> Dict[str, Any]:
        try:
            with open(self.brain_state, 'r') as f:
                return json.load(f)
        except:
            return {"error": "Cannot read brain state"}
    
    def get_event_log(self, limit: int = 100) -> Dict[str, Any]:
        try:
            with open(self.event_log, 'r') as f:
                log_data = json.load(f)
            
            return {
                "total_events": log_data.get("total_events", 0),
                "events": log_data.get("events", [])[-limit:]
            }
        except:
            return {"error": "Cannot read event log"}
    
    def get_queue_status(self) -> Dict[str, Any]:
        return {
            "queue_size": self.event_queue.qsize(),
            "is_running": self.is_running,
            "action_count": self.action_count,
            "last_action_time": datetime.fromtimestamp(self.last_action_time).isoformat()
        }
    
    def register_handler(self, event_type: EventType, handler: Callable):
        self.event_handlers[event_type] = handler
        return {"registered": event_type.value}
