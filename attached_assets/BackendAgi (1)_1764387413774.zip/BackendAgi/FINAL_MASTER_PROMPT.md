# 🚀 FINAL MASTER PROMPT - CIPHERH BACKEND COMPLETE

**Copy-paste this ENTIRE prompt into Replit to generate the complete CipherH backend in one go!**

---

## 🎯 MISSION

Generate toàn bộ backend CipherH - Autonomous Vietnamese AI Agent với:
- ✅ Inner Loop (14 steps) - Lõi Linh Hồn tự học, tự hoài nghi, tự cải thiện
- ✅ SoulCore (8 methods) - Pure JavaScript brain
- ✅ REST API (6 endpoints) - Full control interface
- ✅ Cron scheduler (24/7) - Autonomous operation
- ✅ Notion integration - Long-term memory
- ✅ OpenAI integration - Deep analysis
- ✅ CI/CD ready - GitHub → Render auto-deploy
- ✅ Visual blueprints - Architecture diagrams
- ✅ Budget compliant - Under $25/month

**Total: 2,050+ lines of production-ready code**

---

## 📦 PROJECT STRUCTURE

```
nodejs-backend/
├── src/
│   ├── core/
│   │   ├── innerLoop.js       (521 lines - 14 steps)
│   │   ├── soulCore.js        (450 lines - 8 methods)
│   │   ├── strategy.js        (~50 lines)
│   │   ├── policy.js          (~20 lines)
│   │   ├── taskManager.js     (~60 lines)
│   │   └── anomalyDetector.js (~40 lines)
│   ├── services/
│   │   ├── loggerService.js   (~30 lines - Winston)
│   │   ├── notionService.js   (~90 lines - Notion API)
│   │   └── openAIService.js   (~40 lines - OpenAI API)
│   ├── controllers/
│   │   └── coreController.js  (~60 lines)
│   ├── routes/
│   │   └── coreRoutes.js      (~15 lines)
│   ├── app.js                 (~40 lines - Express)
│   └── server.js              (~35 lines - Cron + startup)
├── logs/                      (Auto-created)
├── .env.example
├── .gitignore
├── package.json
└── README.md
```

---

## 1️⃣ CORE MODULES - INNER LOOP (521 LINES)

### src/core/innerLoop.js

**Requirements:**
- Import: notionService, openAIService, loggerService, SoulCore, strategy, taskManager, anomalyDetector, policy
- Export: runInnerLoop(), getState()
- State: lastRun, cycles, confidence (30-100), doubts (0-100), goals, lastLesson, modulePerformance, discrepancies

**Implementation:**

```javascript
const loggerService = require('../services/loggerService');
const notionService = require('../services/notionService');
const openAIService = require('../services/openAIService');
const SoulCore = require('./soulCore');
const { detectAnomalies } = require('./anomalyDetector');
const { generateStrategy } = require('./strategy');
const { evaluatePolicy } = require('./policy');
const { autoGenerateTasks } = require('./taskManager');

let cycleCount = 0;
let state = {
  lastRun: null,
  cycles: 0,
  confidence: 80,
  doubts: 0,
  goals: [],
  lastLesson: null,
  lastEvaluationScore: null,
  lastConfidence: null,
  modulePerformance: {
    strategy: { successRate: 100, errors: 0 },
    taskManager: { successRate: 100, errors: 0 },
    anomalyDetector: { successRate: 100, errors: 0 }
  },
  discrepancies: []
};

async function runInnerLoop() {
  cycleCount++;
  
  loggerService.info('============================================================');
  loggerService.info(`SOUL LOOP CYCLE ${cycleCount} - START`);
  loggerService.info('============================================================');
  
  try {
    // Step 1: Đọc logs từ Notion (10 items)
    loggerService.info('Step 1: Đọc log mới nhất từ Notion (10 items)');
    const logs = await notionService.fetchRecentLogs(10);
    loggerService.info(`Retrieved ${logs.length} logs from Notion`);
    
    // Step 2: Phân tích hành vi với SoulCore
    loggerService.info('Step 2: Phân tích hành vi gần nhất với SoulCore');
    const soulAnalysis = await SoulCore.learnFromLogs(logs);
    loggerService.info('SoulCore learning complete', {
      patterns: soulAnalysis.patterns.length,
      insights: soulAnalysis.insights.length,
      questions: soulAnalysis.skepticalQuestions.length
    });
    
    // Step 3: Phát hiện bất thường (dual system)
    loggerService.info('Step 3: Phát hiện bất thường');
    const systemAnomalies = detectAnomalies(logs);
    const soulAnomalies = SoulCore.detectAnomalies(logs);
    loggerService.info('Anomalies detected', {
      system: systemAnomalies.anomalies.length,
      soul: soulAnomalies.length
    });
    
    const fullAnalysis = {
      ...soulAnalysis,
      systemAnomalies: systemAnomalies.anomalies,
      soulAnomalies: soulAnomalies,
      anomalyScore: systemAnomalies.anomalyScore
    };
    
    // Step 4: Rút quy luật và bài học
    loggerService.info('Step 4: Rút quy luật và bài học');
    const dailyLesson = SoulCore.generateDailyLesson(soulAnalysis);
    loggerService.info('Daily lesson generated', { length: dailyLesson.length });
    
    // Step 5: Viết bài học vào Notion
    loggerService.info('Step 5: Viết bài học vào Notion');
    await notionService.writeLesson(dailyLesson);
    loggerService.info('Lesson written to Notion');
    
    // Step 6: Tự đánh giá (1-10 score)
    loggerService.info('Step 6: Tự đánh giá (tốt/xấu)');
    const selfEvaluation = SoulCore.evaluateSelf(soulAnalysis);
    loggerService.info('Self evaluation complete', {
      score: selfEvaluation.score,
      status: selfEvaluation.status,
      warnings: selfEvaluation.warnings.length
    });
    
    // Step 7: So sánh với mục tiêu dài hạn
    loggerService.info('Step 7: So sánh với mục tiêu dài hạn');
    const goals = await notionService.fetchGoals();
    const goalAlignment = compareWithGoals(goals, fullAnalysis, selfEvaluation);
    loggerService.info('Goal alignment evaluated', {
      alignmentScore: goalAlignment.alignmentScore,
      gaps: goalAlignment.gaps.length
    });
    
    // Step 8: Tạo chiến lược (dual: soul + system) with error handling
    loggerService.info('Step 8: Tạo chiến lược');
    let soulStrategy, systemStrategy, combinedStrategy;
    try {
      soulStrategy = SoulCore.refineStrategy(soulAnalysis);
      systemStrategy = await generateStrategy(fullAnalysis);
      combinedStrategy = {
        ...soulStrategy,
        systemSummary: systemStrategy.strategySummary,
        systemActions: systemStrategy.suggestedActions,
        timestamp: new Date().toISOString()
      };
      state.modulePerformance.strategy.successRate = Math.min(100, state.modulePerformance.strategy.successRate + 1);
      loggerService.info('Strategy generated', {
        shortTerm: soulStrategy.shortTermPlan,
        actions: soulStrategy.requiredActions.length
      });
    } catch (error) {
      state.modulePerformance.strategy.errors++;
      state.modulePerformance.strategy.successRate = Math.max(0, state.modulePerformance.strategy.successRate - 5);
      loggerService.error('Strategy generation failed', error);
      combinedStrategy = {
        shortTermPlan: 'Duy trì hoạt động hiện tại',
        longTermPlan: 'Chờ phân tích thêm',
        requiredActions: [],
        systemSummary: 'Lỗi khi tạo chiến lược',
        systemActions: [],
        timestamp: new Date().toISOString()
      };
    }
    
    // Step 9: Tự tạo nhiệm vụ tuần/tháng with error handling
    loggerService.info('Step 9: Tự tạo nhiệm vụ tuần/tháng');
    let soulTasks, systemTasks, allTasks;
    try {
      soulTasks = SoulCore.proposeNewTasks(soulAnalysis);
      systemTasks = autoGenerateTasks(systemStrategy || combinedStrategy);
      allTasks = [...soulTasks.map(t => ({
        description: t.description,
        priority: t.priority,
        schedule: t.type
      })), ...systemTasks];
      state.modulePerformance.taskManager.successRate = Math.min(100, state.modulePerformance.taskManager.successRate + 1);
      loggerService.info('Tasks generated', {
        soulTasks: soulTasks.length,
        systemTasks: systemTasks.length,
        total: allTasks.length
      });
      await notionService.writeTasks(soulTasks);
    } catch (error) {
      state.modulePerformance.taskManager.errors++;
      state.modulePerformance.taskManager.successRate = Math.max(0, state.modulePerformance.taskManager.successRate - 5);
      loggerService.error('Task generation failed', error);
      soulTasks = [];
      allTasks = [];
    }
    
    // Step 10: Tự hoài nghi - phát hiện discrepancies
    loggerService.info('Step 10: Tự hoài nghi và phát hiện discrepancies');
    const discrepancies = await detectDiscrepancies(
      fullAnalysis, 
      combinedStrategy, 
      goalAlignment, 
      selfEvaluation,
      allTasks
    );
    loggerService.info('Discrepancies detected', {
      count: discrepancies.length,
      critical: discrepancies.filter(d => d.severity === 'critical').length
    });
    
    // Step 11: Đánh giá hiệu quả modules
    loggerService.info('Step 11: Đánh giá hiệu quả modules');
    const moduleReport = generateModuleReport();
    loggerService.info('Module performance', moduleReport);
    
    // Step 12: Tự củng cố và cải thiện
    loggerService.info('Step 12: Tự củng cố và cải thiện');
    const improvementTasks = await selfReinforce(discrepancies, moduleReport);
    loggerService.info('Improvement tasks', { count: improvementTasks.length });
    
    // Step 13: So sánh với bài học vòng trước
    loggerService.info('Step 13: So sánh với bài học vòng trước');
    const progressComparison = compareProgress(dailyLesson, state.lastLesson, selfEvaluation);
    loggerService.info('Progress comparison', progressComparison);
    
    // Step 14: Cập nhật trạng thái backend
    loggerService.info('Step 14: Cập nhật trạng thái backend');
    const updatedModel = SoulCore.updateSelfModel(soulAnalysis);
    updateState(fullAnalysis, combinedStrategy, selfEvaluation, discrepancies, progressComparison);
    loggerService.info('State updated', {
      confidence: state.confidence,
      doubts: state.doubts,
      soulVersion: updatedModel.version,
      soulCycle: updatedModel.cycleCount,
      discrepancies: state.discrepancies.length
    });
    
    // Write all to Notion
    await notionService.writeStrategy(combinedStrategy);
    await notionService.writeBehaviorUpdate({
      confidence: state.confidence,
      doubts: state.doubts,
      score: selfEvaluation.score,
      soulVersion: updatedModel.version,
      discrepancies: discrepancies.length,
      modulePerformance: moduleReport,
      timestamp: new Date().toISOString()
    });
    
    if (discrepancies.length > 0) {
      await notionService.writeDiscrepancies(discrepancies);
    }
    
    if (improvementTasks.length > 0) {
      await notionService.writeTasks(improvementTasks);
    }
    
    state.lastLesson = dailyLesson;
    
    // Self-questioning
    const selfQuestions = SoulCore.askSelfQuestions(soulAnalysis);
    loggerService.info('Self-questioning', {
      questions: selfQuestions.slice(0, 3)
    });
    
    loggerService.info('============================================================');
    loggerService.info(`SOUL LOOP CYCLE ${cycleCount} - COMPLETED SUCCESSFULLY`);
    loggerService.info('============================================================');
    
    return {
      success: true,
      cycle: cycleCount,
      soulCycle: updatedModel.cycleCount,
      stats: {
        anomalyScore: fullAnalysis.anomalyScore,
        confidence: state.confidence,
        doubts: state.doubts,
        score: selfEvaluation.score,
        tasksGenerated: allTasks.length,
        soulVersion: updatedModel.version,
        discrepancies: discrepancies.length,
        modulePerformance: moduleReport,
        improvementTasks: improvementTasks.length,
        progress: progressComparison.trend
      }
    };
    
  } catch (error) {
    loggerService.error('Inner loop failed', error);
    return {
      success: false,
      cycle: cycleCount,
      error: error.message
    };
  }
}

// Helper: Compare with goals
function compareWithGoals(goals, analysis, evaluation) {
  let alignmentScore = 50;
  
  if (evaluation.score >= 7) alignmentScore = 85;
  else if (evaluation.score >= 5) alignmentScore = 65;
  
  if (analysis.anomalyScore > 0.5) alignmentScore -= 20;
  
  const gaps = [];
  if (evaluation.score < 7) gaps.push('Cần cải thiện hiệu suất tổng thể');
  if (analysis.anomalyScore > 0.3) gaps.push('Giảm tỷ lệ bất thường');
  if (evaluation.weaknesses.length > 0) gaps.push(`Khắc phục điểm yếu: ${evaluation.weaknesses.join(', ')}`);
  
  const recommendations = [];
  if (alignmentScore >= 80) {
    recommendations.push('Duy trì chiến lược hiện tại');
    recommendations.push('Mở rộng capabilities');
  } else if (alignmentScore >= 60) {
    recommendations.push('Tối ưu hóa performance');
    recommendations.push('Theo dõi chặt chẽ');
  } else {
    recommendations.push('Cần điều chỉnh chiến lược ngay');
    recommendations.push('Focus vào ổn định hệ thống');
  }
  
  return { goals, alignmentScore, gaps, recommendations };
}

// Helper: Detect discrepancies
async function detectDiscrepancies(analysis, strategy, goalAlignment, evaluation, tasks) {
  const discrepancies = [];
  
  if (goalAlignment.alignmentScore < 60) {
    discrepancies.push({
      type: 'goal_misalignment',
      severity: 'high',
      description: `Goal alignment chỉ ${goalAlignment.alignmentScore}%, thấp hơn target 60%`,
      suggestedFix: 'Review và điều chỉnh chiến lược để align với goals'
    });
  }
  
  if (evaluation.score < 5 && analysis.anomalyScore > 0.3) {
    discrepancies.push({
      type: 'performance_anomaly',
      severity: 'critical',
      description: 'Score thấp kết hợp với anomaly score cao',
      suggestedFix: 'Kiểm tra logs chi tiết, xác định root cause'
    });
  }
  
  if (tasks.length === 0) {
    discrepancies.push({
      type: 'no_tasks_generated',
      severity: 'medium',
      description: 'Không có tasks nào được tạo ra',
      suggestedFix: 'Review task generation logic trong taskManager'
    });
  }
  
  if (state.modulePerformance.strategy.successRate < 80) {
    discrepancies.push({
      type: 'strategy_module_degraded',
      severity: 'high',
      description: `Strategy module success rate: ${state.modulePerformance.strategy.successRate}%`,
      suggestedFix: 'Debug strategy.js, kiểm tra input data quality'
    });
  }
  
  if (state.doubts > 70) {
    discrepancies.push({
      type: 'high_doubt_level',
      severity: 'medium',
      description: `Doubt level cao: ${state.doubts}/100`,
      suggestedFix: 'Tăng cường confidence qua successful operations'
    });
  }
  
  return discrepancies;
}

// Helper: Generate module report
function generateModuleReport() {
  const { strategy, taskManager, anomalyDetector } = state.modulePerformance;
  
  return {
    strategy: {
      successRate: `${strategy.successRate.toFixed(1)}%`,
      errors: strategy.errors,
      status: strategy.successRate >= 90 ? 'healthy' : strategy.successRate >= 70 ? 'warning' : 'critical'
    },
    taskManager: {
      successRate: `${taskManager.successRate.toFixed(1)}%`,
      errors: taskManager.errors,
      status: taskManager.successRate >= 90 ? 'healthy' : taskManager.successRate >= 70 ? 'warning' : 'critical'
    },
    anomalyDetector: {
      successRate: `${anomalyDetector.successRate.toFixed(1)}%`,
      errors: anomalyDetector.errors,
      status: anomalyDetector.successRate >= 90 ? 'healthy' : anomalyDetector.successRate >= 70 ? 'warning' : 'critical'
    }
  };
}

// Helper: Self-reinforce
async function selfReinforce(discrepancies, moduleReport) {
  const improvementTasks = [];
  
  const criticalDiscrepancies = discrepancies.filter(d => d.severity === 'critical');
  const highDiscrepancies = discrepancies.filter(d => d.severity === 'high');
  
  if (criticalDiscrepancies.length > 0) {
    improvementTasks.push({
      type: 'daily',
      priority: 'critical',
      description: `FIX CRITICAL: ${criticalDiscrepancies[0].description}`,
      reason: criticalDiscrepancies[0].suggestedFix,
      module: criticalDiscrepancies[0].type
    });
  }
  
  if (highDiscrepancies.length > 0) {
    improvementTasks.push({
      type: 'weekly',
      priority: 'high',
      description: `Cải thiện: ${highDiscrepancies[0].description}`,
      reason: highDiscrepancies[0].suggestedFix,
      module: highDiscrepancies[0].type
    });
  }
  
  Object.keys(moduleReport).forEach(moduleName => {
    const module = moduleReport[moduleName];
    if (module.status === 'critical') {
      improvementTasks.push({
        type: 'daily',
        priority: 'critical',
        description: `DEBUG module ${moduleName}`,
        reason: `Success rate: ${module.successRate}, Errors: ${module.errors}`,
        module: moduleName
      });
    } else if (module.status === 'warning') {
      improvementTasks.push({
        type: 'weekly',
        priority: 'medium',
        description: `Optimize module ${moduleName}`,
        reason: `Success rate đang giảm: ${module.successRate}`,
        module: moduleName
      });
    }
  });
  
  if (discrepancies.length > 5) {
    improvementTasks.push({
      type: 'weekly',
      priority: 'high',
      description: 'Tổng review toàn bộ Inner Loop',
      reason: `Quá nhiều discrepancies: ${discrepancies.length}`,
      module: 'innerLoop'
    });
  }
  
  return improvementTasks;
}

// Helper: Compare progress
function compareProgress(currentLesson, previousLesson, currentEvaluation) {
  if (!previousLesson) {
    return {
      trend: 'first_cycle',
      improvement: 0,
      message: 'Vòng đầu tiên - chưa có dữ liệu so sánh'
    };
  }
  
  const scoreDiff = currentEvaluation.score - (state.lastEvaluationScore || 5);
  const confidenceDiff = state.confidence - (state.lastConfidence || 80);
  
  let trend = 'stable';
  if (scoreDiff > 2 && confidenceDiff > 5) {
    trend = 'improving';
  } else if (scoreDiff < -2 || confidenceDiff < -10) {
    trend = 'degrading';
  }
  
  const improvement = ((scoreDiff + (confidenceDiff / 10)) / 2).toFixed(1);
  
  let message = '';
  if (trend === 'improving') {
    message = `Tiến bộ rõ rệt: Score +${scoreDiff}, Confidence +${confidenceDiff}`;
  } else if (trend === 'degrading') {
    message = `Suy giảm: Score ${scoreDiff}, Confidence ${confidenceDiff}`;
  } else {
    message = 'Hoạt động ổn định, không có thay đổi lớn';
  }
  
  state.lastEvaluationScore = currentEvaluation.score;
  state.lastConfidence = state.confidence;
  
  return {
    trend,
    improvement: parseFloat(improvement),
    message,
    currentScore: currentEvaluation.score,
    scoreDiff,
    confidenceDiff
  };
}

// Helper: Update state
function updateState(analysis, strategy, evaluation, discrepancies, progressComparison) {
  state.lastRun = new Date().toISOString();
  state.cycles = cycleCount;
  
  if (evaluation.score < 5) {
    state.confidence = Math.max(30, state.confidence - 15);
    state.doubts = Math.min(100, state.doubts + 20);
  } else if (evaluation.score >= 7) {
    state.confidence = Math.min(100, state.confidence + 10);
    state.doubts = Math.max(0, state.doubts - 10);
  }
  
  if (analysis.anomalyScore > 0.5) {
    state.confidence = Math.max(30, state.confidence - 10);
    state.doubts = Math.min(100, state.doubts + 15);
  } else if (analysis.anomalyScore < 0.2) {
    state.confidence = Math.min(100, state.confidence + 5);
    state.doubts = Math.max(0, state.doubts - 5);
  }
  
  if (discrepancies.length > 5) {
    state.doubts = Math.min(100, state.doubts + 10);
  }
  
  if (progressComparison.trend === 'improving') {
    state.confidence = Math.min(100, state.confidence + 5);
    state.doubts = Math.max(0, state.doubts - 5);
  } else if (progressComparison.trend === 'degrading') {
    state.doubts = Math.min(100, state.doubts + 10);
  }
  
  state.discrepancies = discrepancies.slice(-20);
  
  loggerService.info('State internal update', { 
    confidence: state.confidence,
    doubts: state.doubts,
    discrepanciesCount: state.discrepancies.length,
    trend: progressComparison.trend
  });
}

// Get state
function getState() {
  const soulModel = SoulCore.getSelfModel();
  
  return {
    ...state,
    soul: {
      version: soulModel.version,
      cycleCount: soulModel.cycleCount,
      strengths: soulModel.strengths,
      weaknesses: soulModel.weaknesses
    }
  };
}

module.exports = {
  runInnerLoop,
  getState
};
```

**Copy the complete soulCore.js, strategy.js, policy.js, taskManager.js, anomalyDetector.js, all services, controllers, routes, app.js, and server.js from MASTER_PROMPT.md**

---

## 📋 COMPLETE FILE LIST TO GENERATE

### Essential Files (15 total):

1. **src/core/innerLoop.js** - 521 lines (code above)
2. **src/core/soulCore.js** - 450 lines (8 methods pure JS)
3. **src/core/strategy.js** - 50 lines
4. **src/core/policy.js** - 20 lines
5. **src/core/taskManager.js** - 60 lines
6. **src/core/anomalyDetector.js** - 40 lines
7. **src/services/loggerService.js** - 30 lines (Winston)
8. **src/services/notionService.js** - 90 lines (Notion integration)
9. **src/services/openAIService.js** - 40 lines (OpenAI integration)
10. **src/controllers/coreController.js** - 60 lines
11. **src/routes/coreRoutes.js** - 15 lines
12. **src/app.js** - 40 lines
13. **src/server.js** - 35 lines
14. **package.json** - Dependencies
15. **.env.example** - Environment template

Plus: .gitignore, README.md

---

## ✅ SUCCESS CRITERIA

**When complete, you should have:**

1. ✅ All 15+ files created
2. ✅ `npm install` works
3. ✅ `npm start` runs on port 3000
4. ✅ Cycle 1 executes on startup
5. ✅ Cron scheduled for */10 min
6. ✅ All 6 endpoints respond:
   - GET /health
   - GET /core/status
   - GET /core/run-loop
   - GET /core/strategy
   - GET /core/tasks
   - GET /core/anomalies
7. ✅ Logs flow to console + file
8. ✅ State updates correctly
9. ✅ No errors
10. ✅ Ready to deploy

---

## 🎨 VISUAL BLUEPRINT

```
┌────────────────────────────────────────────────────────────┐
│              CIPHERH ARCHITECTURE                           │
│                                                              │
│  External:  Notion ←→ OpenAI                                │
│                ↓         ↓                                   │
│  Services:  notionService + openAIService + loggerService   │
│                ↓                                             │
│  Core:      Inner Loop (14 steps)                           │
│             ├─ SoulCore (8 methods)                         │
│             ├─ Strategy                                      │
│             ├─ TaskManager                                   │
│             ├─ AnomalyDetector                               │
│             └─ Policy                                        │
│                ↓                                             │
│  API:       coreController → coreRoutes                     │
│                ↓                                             │
│  App:       Express (app.js)                                │
│                ↓                                             │
│  Server:    Cron + Startup (server.js)                      │
│                ↓                                             │
│  Output:    REST API on port 3000                           │
│             Cron runs every 10 min                           │
│             24/7 autonomous operation                        │
└────────────────────────────────────────────────────────────┘
```

---

## 🚀 QUICK START AFTER GENERATION

```bash
cd nodejs-backend
npm install
cp .env.example .env
npm start

# Test
curl http://localhost:3000/health
curl http://localhost:3000/core/status

# Deploy
git init
git remote add origin https://github.com/YOUR_USERNAME/cipherh-backend.git
git add .
git commit -m "Initial: CipherH Soul Loop Backend"
git push -u origin main

# Render: Connect repo, deploy, add env vars
# Done - backend runs 24/7!
```

---

## 💰 BUDGET

- Render Starter: $7/month
- OpenAI API: ~$10/month
- **Total: ~$17/month ✅**

---

**COPY THIS ENTIRE PROMPT → PASTE INTO REPLIT → GET COMPLETE BACKEND! 🚀✨**

**For complete implementation details of all files, refer to MASTER_PROMPT.md (1,057 lines) which contains the full code for every single file.**
