import os
import sys
import time
import logging
from datetime import datetime
from dotenv import load_dotenv

from core.soul_loop import SoulLoop

# Load environment variables
load_dotenv()

def setup_logger():
    """Setup logging để ghi ra console và logs/system.log"""
    log_dir = "logs"
    os.makedirs(log_dir, exist_ok=True)
    
    log_file = os.path.join(log_dir, "system.log")
    
    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_file),
            logging.StreamHandler(sys.stdout)
        ]
    )
    
    logger = logging.getLogger(__name__)
    logger.info("Logger initialized")
    
    return logger

def main():
    logger = setup_logger()
    logger.info("=" * 50)
    logger.info("Soul Loop Backend Starting...")
    logger.info("Running 24/7 mode")
    logger.info("=" * 50)
    
    soul = SoulLoop(sleep_minutes=1)
    
    while True:
        try:
            result = soul.run()
            
            if result["success"]:
                logger.info(f"✓ Cycle {result['cycle']} completed")
            else:
                logger.error(f"✗ Cycle {result['cycle']} failed: {result.get('error')}")
        
        except Exception as e:
            logger.critical(f"CRITICAL ERROR: {str(e)}")
            logger.exception("Full traceback:")
        
        finally:
            logger.info("Sleeping 60 seconds before next cycle...")
            time.sleep(60)

if __name__ == "__main__":
    main()
