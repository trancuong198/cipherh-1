import os
import json
from typing import Dict, Any, List, Optional
from datetime import datetime
from collections import defaultdict

class PatternAnalyzer:
    def __init__(self):
        self.ltm_dir = 'ltm'
        self.patterns_file = os.path.join(self.ltm_dir, 'patterns.json')
        
        os.makedirs(self.ltm_dir, exist_ok=True)
        
        self._init_patterns()
    
    def _init_patterns(self):
        if not os.path.exists(self.patterns_file):
            with open(self.patterns_file, 'w') as f:
                json.dump({
                    "patterns": [],
                    "total_analyses": 0
                }, f, indent=2)
    
    def analyze_patterns(self) -> Dict[str, Any]:
        memories = self._get_memories()
        
        analysis = {
            "id": f"analysis_{self._get_next_id()}",
            "timestamp": datetime.now().isoformat(),
            "trends": [],
            "recurring_errors": [],
            "opportunities": [],
            "total_analyzed": len(memories)
        }
        
        analysis['trends'] = self._find_trends(memories)
        analysis['recurring_errors'] = self._find_recurring_errors(memories)
        analysis['opportunities'] = self._find_opportunities(memories)
        
        with open(self.patterns_file, 'r') as f:
            patterns_data = json.load(f)
        
        patterns_data['patterns'].append(analysis)
        patterns_data['total_analyses'] += 1
        
        if len(patterns_data['patterns']) > 100:
            patterns_data['patterns'] = patterns_data['patterns'][-100:]
        
        with open(self.patterns_file, 'w') as f:
            json.dump(patterns_data, f, indent=2)
        
        return analysis
    
    def _find_trends(self, memories: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        trends = []
        
        module_success = defaultdict(int)
        module_total = defaultdict(int)
        
        for memory in memories[-100:]:
            module = memory['module_origin']
            outcome = memory['outcome']
            
            module_total[module] += 1
            if outcome == 'success':
                module_success[module] += 1
        
        for module, total in module_total.items():
            success_rate = (module_success[module] / total * 100) if total > 0 else 0
            
            if success_rate > 85:
                trends.append({
                    "type": "high_performance",
                    "module": module,
                    "success_rate": round(success_rate, 2),
                    "confidence": 90
                })
            elif success_rate < 60:
                trends.append({
                    "type": "low_performance",
                    "module": module,
                    "success_rate": round(success_rate, 2),
                    "confidence": 85
                })
        
        pattern_counts = defaultdict(int)
        for memory in memories[-50:]:
            pattern_counts[memory['pattern_tag']] += 1
        
        for pattern, count in pattern_counts.items():
            if count > 10:
                trends.append({
                    "type": "frequent_pattern",
                    "pattern": pattern,
                    "occurrences": count,
                    "confidence": 80
                })
        
        return trends
    
    def _find_recurring_errors(self, memories: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        errors = []
        
        error_patterns = defaultdict(list)
        
        for memory in memories[-100:]:
            if memory['outcome'] in ['failed', 'error', 'critical']:
                pattern = memory['pattern_tag']
                error_patterns[pattern].append(memory)
        
        for pattern, error_list in error_patterns.items():
            if len(error_list) >= 3:
                errors.append({
                    "pattern": pattern,
                    "occurrences": len(error_list),
                    "severity": "high" if len(error_list) > 5 else "medium",
                    "recommendation": "investigate_and_fix"
                })
        
        return errors
    
    def _find_opportunities(self, memories: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        opportunities = []
        
        module_performance = defaultdict(lambda: {"success": 0, "total": 0})
        
        for memory in memories[-100:]:
            module = memory['module_origin']
            outcome = memory['outcome']
            
            module_performance[module]['total'] += 1
            if outcome == 'success':
                module_performance[module]['success'] += 1
        
        for module, perf in module_performance.items():
            success_rate = (perf['success'] / perf['total'] * 100) if perf['total'] > 0 else 0
            
            if 70 <= success_rate < 85:
                opportunities.append({
                    "type": "improvement_potential",
                    "module": module,
                    "current_performance": round(success_rate, 2),
                    "potential_gain": "15-20%",
                    "action": "optimize_module"
                })
        
        social_memories = [m for m in memories if 'social' in m['module_origin']]
        if len(social_memories) > 20:
            opportunities.append({
                "type": "social_engagement",
                "insight": "high_social_activity",
                "action": "enhance_personality_response"
            })
        
        security_memories = [m for m in memories if 'security' in m['module_origin'] or 'threat' in m['pattern_tag']]
        if len(security_memories) > 10:
            opportunities.append({
                "type": "security_awareness",
                "insight": "frequent_security_events",
                "action": "strengthen_defense"
            })
        
        return opportunities
    
    def _get_memories(self) -> List[Dict[str, Any]]:
        storage_file = 'ltm/memories.json'
        
        if not os.path.exists(storage_file):
            return []
        
        try:
            with open(storage_file, 'r') as f:
                storage = json.load(f)
            return storage.get('memories', [])
        except Exception:
            return []
    
    def _get_next_id(self) -> int:
        with open(self.patterns_file, 'r') as f:
            patterns_data = json.load(f)
        return patterns_data['total_analyses'] + 1
    
    def get_patterns(self) -> List[Dict[str, Any]]:
        with open(self.patterns_file, 'r') as f:
            patterns_data = json.load(f)
        return patterns_data.get('patterns', [])[-20:]
