import os
import json
from typing import Dict, Any, List, Optional
from datetime import datetime
from collections import defaultdict

class TaskOptimizer:
    def __init__(self):
        self.task_chain_dir = 'task_chain'
        self.optimization_file = os.path.join(self.task_chain_dir, 'optimizations.json')
        
        os.makedirs(self.task_chain_dir, exist_ok=True)
        
        self._init_optimizations()
    
    def _init_optimizations(self):
        if not os.path.exists(self.optimization_file):
            with open(self.optimization_file, 'w') as f:
                json.dump({
                    "optimizations": [],
                    "total_optimizations": 0
                }, f, indent=2)
    
    def optimize_workflow(self) -> Dict[str, Any]:
        queue_data = self._get_queue_data()
        execution_log = self._get_execution_log()
        
        optimization = {
            "id": f"opt_{self._get_next_id()}",
            "timestamp": datetime.now().isoformat(),
            "recommendations": [],
            "estimated_improvement": 0
        }
        
        redundant_tasks = self._detect_redundant_tasks(queue_data)
        if redundant_tasks:
            optimization['recommendations'].append({
                "type": "remove_redundancy",
                "affected_tasks": redundant_tasks,
                "improvement": "15% efficiency gain"
            })
            optimization['estimated_improvement'] += 15
        
        parallel_opportunities = self._detect_parallel_opportunities(queue_data)
        if parallel_opportunities:
            optimization['recommendations'].append({
                "type": "parallelize_tasks",
                "task_groups": parallel_opportunities,
                "improvement": "30% time reduction"
            })
            optimization['estimated_improvement'] += 30
        
        slow_tasks = self._detect_slow_tasks(execution_log)
        if slow_tasks:
            optimization['recommendations'].append({
                "type": "optimize_slow_tasks",
                "slow_tasks": slow_tasks,
                "improvement": "20% speed increase"
            })
            optimization['estimated_improvement'] += 20
        
        failed_patterns = self._detect_failed_patterns(execution_log)
        if failed_patterns:
            optimization['recommendations'].append({
                "type": "fix_failure_patterns",
                "patterns": failed_patterns,
                "improvement": "reduce failure rate by 40%"
            })
            optimization['estimated_improvement'] += 25
        
        with open(self.optimization_file, 'r') as f:
            opt_data = json.load(f)
        
        opt_data['optimizations'].append(optimization)
        opt_data['total_optimizations'] += 1
        
        if len(opt_data['optimizations']) > 50:
            opt_data['optimizations'] = opt_data['optimizations'][-50:]
        
        with open(self.optimization_file, 'w') as f:
            json.dump(opt_data, f, indent=2)
        
        return optimization
    
    def _detect_redundant_tasks(self, queue_data: Dict[str, Any]) -> List[str]:
        tasks = queue_data.get('tasks', {})
        
        action_map = defaultdict(list)
        
        for task_id, task in tasks.items():
            if task['status'] == 'pending':
                key = f"{task['module_origin']}:{task['action']}"
                action_map[key].append(task_id)
        
        redundant = []
        for key, task_ids in action_map.items():
            if len(task_ids) > 1:
                redundant.extend(task_ids[1:])
        
        return redundant
    
    def _detect_parallel_opportunities(self, queue_data: Dict[str, Any]) -> List[List[str]]:
        tasks = queue_data.get('tasks', {})
        
        independent_groups = []
        pending_tasks = [
            (task_id, task) for task_id, task in tasks.items()
            if task['status'] == 'pending' and not task.get('dependencies')
        ]
        
        if len(pending_tasks) >= 2:
            group = [task_id for task_id, _ in pending_tasks[:3]]
            independent_groups.append(group)
        
        return independent_groups
    
    def _detect_slow_tasks(self, execution_log: Dict[str, Any]) -> List[Dict[str, Any]]:
        executions = execution_log.get('executions', [])
        
        slow_tasks = []
        
        for execution in executions[-20:]:
            if execution.get('execution_time_ms', 0) > 1000:
                slow_tasks.append({
                    "task_id": execution['task_id'],
                    "execution_time_ms": execution['execution_time_ms']
                })
        
        return slow_tasks[:5]
    
    def _detect_failed_patterns(self, execution_log: Dict[str, Any]) -> List[Dict[str, Any]]:
        executions = execution_log.get('executions', [])
        
        failed_actions = defaultdict(int)
        
        for execution in executions:
            if execution['status'] == 'failed':
                task = self._get_task(execution['task_id'])
                if task:
                    action = task.get('action', 'unknown')
                    failed_actions[action] += 1
        
        patterns = []
        for action, count in failed_actions.items():
            if count > 2:
                patterns.append({
                    "action": action,
                    "failure_count": count,
                    "recommendation": "investigate_and_fix"
                })
        
        return patterns
    
    def _get_queue_data(self) -> Dict[str, Any]:
        queue_file = 'task_chain/task_queue.json'
        
        if not os.path.exists(queue_file):
            return {"tasks": {}}
        
        try:
            with open(queue_file, 'r') as f:
                return json.load(f)
        except Exception:
            return {"tasks": {}}
    
    def _get_execution_log(self) -> Dict[str, Any]:
        log_file = 'task_chain/execution_log.json'
        
        if not os.path.exists(log_file):
            return {"executions": []}
        
        try:
            with open(log_file, 'r') as f:
                return json.load(f)
        except Exception:
            return {"executions": []}
    
    def _get_task(self, task_id: str) -> Optional[Dict[str, Any]]:
        queue_data = self._get_queue_data()
        return queue_data.get('tasks', {}).get(task_id)
    
    def _get_next_id(self) -> int:
        with open(self.optimization_file, 'r') as f:
            opt_data = json.load(f)
        return opt_data['total_optimizations'] + 1
    
    def get_optimization_history(self) -> List[Dict[str, Any]]:
        with open(self.optimization_file, 'r') as f:
            opt_data = json.load(f)
        return opt_data.get('optimizations', [])[-10:]
