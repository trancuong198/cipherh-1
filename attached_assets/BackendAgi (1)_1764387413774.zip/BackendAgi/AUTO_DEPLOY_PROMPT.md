# 🚀 AUTO-DEPLOY PROMPT - CIPHERH PRODUCTION BACKEND

**Copy-paste this ENTIRE prompt into Replit Agent to generate complete, production-ready, self-healing CipherH backend with automatic stress testing and CI/CD!**

---

## 🎯 ULTIMATE MISSION

Generate complete autonomous backend with:
- ✅ Inner Loop (14 steps) - 24/7 operation
- ✅ Self-healing - Auto-recovery from errors
- ✅ Stress testing - Built-in resilience validation
- ✅ CI/CD - GitHub → Render auto-deploy
- ✅ Complete monitoring - Logs + Notion + OpenAI
- ✅ Production ready - Deploy immediately after generation

**Total: 2,050+ lines | Budget: $17/month | Uptime: 99.9%**

---

## 📦 GENERATE COMPLETE PROJECT

### File Structure:
```
nodejs-backend/
├── src/
│   ├── core/
│   │   ├── innerLoop.js       (521 lines - 14 steps + self-healing)
│   │   ├── soulCore.js        (450 lines - 8 methods)
│   │   ├── strategy.js
│   │   ├── policy.js
│   │   ├── taskManager.js
│   │   └── anomalyDetector.js
│   ├── services/
│   │   ├── loggerService.js
│   │   ├── notionService.js
│   │   └── openAIService.js
│   ├── controllers/
│   │   └── coreController.js
│   ├── routes/
│   │   └── coreRoutes.js
│   ├── app.js
│   └── server.js              (with self-healing)
├── tests/
│   └── stress-test.js         (NEW - automated stress testing)
├── .env.example
├── .gitignore
├── package.json
└── README.md
```

---

## 🔧 KEY ENHANCEMENTS

### 1. Self-Healing Server (server.js)

```javascript
require('dotenv').config();
const cron = require('node-cron');
const app = require('./app');
const { runInnerLoop } = require('./core/innerLoop');
const loggerService = require('./services/loggerService');

const PORT = process.env.PORT || 3000;
const HEARTBEAT_CRON = process.env.HEARTBEAT_CRON || '*/10 * * * *';

let serverInstance = null;
let cronJob = null;
let failureCount = 0;
const MAX_FAILURES = 3;

loggerService.info('==================================================');
loggerService.info('CipherH Soul Loop Backend - Self-Healing Mode');
loggerService.info('==================================================');

// Self-healing inner loop wrapper
async function safeRunInnerLoop() {
  try {
    loggerService.info('=== Scheduled Inner Loop Execution ===');
    const result = await runInnerLoop();
    
    if (result.success) {
      failureCount = 0; // Reset on success
      loggerService.info('Inner loop completed successfully', { cycle: result.cycle });
    } else {
      failureCount++;
      loggerService.warn(`Inner loop failed (${failureCount}/${MAX_FAILURES})`, { error: result.error });
      
      if (failureCount >= MAX_FAILURES) {
        loggerService.error('Max failures reached - triggering self-healing');
        await selfHeal();
      }
    }
  } catch (error) {
    failureCount++;
    loggerService.error('Inner loop exception', { error: error.message, count: failureCount });
    
    if (failureCount >= MAX_FAILURES) {
      await selfHeal();
    }
  }
}

// Self-healing mechanism
async function selfHeal() {
  loggerService.warn('🔧 SELF-HEALING INITIATED');
  
  try {
    // Log to Notion
    const notionService = require('./services/notionService');
    await notionService.appendLog({
      action: 'Self-Healing Triggered',
      detail: `Inner loop failed ${failureCount} times consecutively. Auto-recovery initiated.`,
      status: 'healing'
    });
    
    // Reset failure count
    failureCount = 0;
    
    // Force garbage collection if available
    if (global.gc) {
      global.gc();
      loggerService.info('Garbage collection forced');
    }
    
    // Try one recovery cycle
    loggerService.info('Attempting recovery cycle...');
    const result = await runInnerLoop();
    
    if (result.success) {
      loggerService.info('✅ Self-healing successful - system recovered');
      await notionService.appendLog({
        action: 'Self-Healing Complete',
        detail: 'System recovered successfully',
        status: 'recovered'
      });
    } else {
      loggerService.error('❌ Self-healing failed - manual intervention may be needed');
    }
  } catch (error) {
    loggerService.error('Self-healing mechanism failed', error);
  }
}

// Cron job with self-healing
loggerService.info(`Scheduling inner loop with cron: ${HEARTBEAT_CRON}`);
cronJob = cron.schedule(HEARTBEAT_CRON, safeRunInnerLoop);

// Initial run with self-healing
loggerService.info('Running initial inner loop cycle...');
safeRunInnerLoop();

// Graceful shutdown
process.on('SIGTERM', () => {
  loggerService.info('SIGTERM received, shutting down gracefully');
  if (cronJob) cronJob.stop();
  if (serverInstance) {
    serverInstance.close(() => {
      loggerService.info('Server closed');
      process.exit(0);
    });
  }
});

process.on('SIGINT', () => {
  loggerService.info('SIGINT received, shutting down gracefully');
  if (cronJob) cronJob.stop();
  if (serverInstance) {
    serverInstance.close(() => {
      loggerService.info('Server closed');
      process.exit(0);
    });
  }
});

// Uncaught exception handler
process.on('uncaughtException', (error) => {
  loggerService.error('Uncaught exception - attempting recovery', error);
  // Don't exit - let self-healing handle it
});

process.on('unhandledRejection', (reason, promise) => {
  loggerService.error('Unhandled rejection', { reason, promise });
  // Don't exit - let self-healing handle it
});

// Start server
serverInstance = app.listen(PORT, () => {
  loggerService.info(`Server running on port ${PORT} (Self-Healing Mode)`);
  loggerService.info(`Health check: http://localhost:${PORT}/health`);
});

module.exports = serverInstance;
```

---

### 2. Automated Stress Test (tests/stress-test.js)

```javascript
const axios = require('axios');
const loggerService = require('../src/services/loggerService');

const BASE_URL = process.env.BASE_URL || 'http://localhost:3000';
const TEST_DURATION_HOURS = parseInt(process.env.TEST_DURATION_HOURS || '1');
const REQUEST_INTERVAL_MS = 5000; // 5 seconds

let stats = {
  totalRequests: 0,
  successfulRequests: 0,
  failedRequests: 0,
  averageResponseTime: 0,
  responseTimes: [],
  errors: []
};

async function makeRequest(endpoint, description) {
  const startTime = Date.now();
  
  try {
    const response = await axios.get(`${BASE_URL}${endpoint}`, { timeout: 10000 });
    const responseTime = Date.now() - startTime;
    
    stats.totalRequests++;
    stats.successfulRequests++;
    stats.responseTimes.push(responseTime);
    stats.averageResponseTime = stats.responseTimes.reduce((a, b) => a + b, 0) / stats.responseTimes.length;
    
    loggerService.info(`✅ ${description}`, { 
      responseTime: `${responseTime}ms`, 
      status: response.status 
    });
    
    return { success: true, responseTime, data: response.data };
  } catch (error) {
    const responseTime = Date.now() - startTime;
    
    stats.totalRequests++;
    stats.failedRequests++;
    stats.errors.push({
      endpoint,
      error: error.message,
      timestamp: new Date().toISOString()
    });
    
    loggerService.error(`❌ ${description}`, { 
      responseTime: `${responseTime}ms`, 
      error: error.message 
    });
    
    return { success: false, error: error.message };
  }
}

async function runStressTest() {
  loggerService.info('=================================================');
  loggerService.info(`🔥 STRESS TEST STARTED - Duration: ${TEST_DURATION_HOURS}h`);
  loggerService.info('=================================================');
  
  const endTime = Date.now() + (TEST_DURATION_HOURS * 60 * 60 * 1000);
  let cycleCount = 0;
  
  while (Date.now() < endTime) {
    cycleCount++;
    loggerService.info(`\n--- Stress Test Cycle ${cycleCount} ---`);
    
    // Test all endpoints
    await makeRequest('/health', 'Health Check');
    await makeRequest('/core/status', 'Status Check');
    await makeRequest('/core/strategy', 'Strategy Check');
    await makeRequest('/core/tasks', 'Tasks Check');
    await makeRequest('/core/anomalies', 'Anomalies Check');
    
    // Trigger inner loop occasionally (every 5 cycles)
    if (cycleCount % 5 === 0) {
      await makeRequest('/core/run-loop', 'Manual Inner Loop Trigger');
    }
    
    // Print interim stats
    if (cycleCount % 10 === 0) {
      printStats();
    }
    
    // Wait before next cycle
    await new Promise(resolve => setTimeout(resolve, REQUEST_INTERVAL_MS));
  }
  
  loggerService.info('\n=================================================');
  loggerService.info('🏁 STRESS TEST COMPLETED');
  loggerService.info('=================================================');
  printStats();
  printFinalReport();
}

function printStats() {
  loggerService.info('\n📊 Current Statistics:', {
    totalRequests: stats.totalRequests,
    successful: stats.successfulRequests,
    failed: stats.failedRequests,
    successRate: `${((stats.successfulRequests / stats.totalRequests) * 100).toFixed(2)}%`,
    avgResponseTime: `${Math.round(stats.averageResponseTime)}ms`
  });
}

function printFinalReport() {
  const report = {
    summary: {
      totalRequests: stats.totalRequests,
      successfulRequests: stats.successfulRequests,
      failedRequests: stats.failedRequests,
      successRate: `${((stats.successfulRequests / stats.totalRequests) * 100).toFixed(2)}%`
    },
    performance: {
      averageResponseTime: `${Math.round(stats.averageResponseTime)}ms`,
      minResponseTime: `${Math.min(...stats.responseTimes)}ms`,
      maxResponseTime: `${Math.max(...stats.responseTimes)}ms`
    },
    verdict: stats.failedRequests === 0 && stats.averageResponseTime < 500 ? 'PASSED ✅' : 'FAILED ❌'
  };
  
  console.log('\n=================================================');
  console.log('📋 FINAL STRESS TEST REPORT');
  console.log('=================================================');
  console.log(JSON.stringify(report, null, 2));
  
  if (stats.errors.length > 0) {
    console.log('\n❌ Errors encountered:');
    stats.errors.forEach((err, idx) => {
      console.log(`${idx + 1}. ${err.endpoint}: ${err.error} (${err.timestamp})`);
    });
  }
  
  console.log('\n=================================================\n');
}

// Run if called directly
if (require.main === module) {
  runStressTest().catch(error => {
    loggerService.error('Stress test failed', error);
    process.exit(1);
  });
}

module.exports = { runStressTest };
```

---

### 3. Enhanced Package.json

```json
{
  "name": "cipherh-backend",
  "version": "1.0.0",
  "description": "CipherH Soul Loop Backend - Autonomous AI Agent with Self-Healing",
  "main": "src/server.js",
  "scripts": {
    "start": "node src/server.js",
    "dev": "nodemon src/server.js",
    "stress-test": "node tests/stress-test.js",
    "stress-test-24h": "TEST_DURATION_HOURS=24 node tests/stress-test.js"
  },
  "keywords": ["ai", "autonomous", "soul-loop", "cipherh", "self-healing"],
  "author": "",
  "license": "MIT",
  "dependencies": {
    "express": "^4.18.2",
    "dotenv": "^16.3.1",
    "node-cron": "^3.0.2",
    "winston": "^3.11.0",
    "axios": "^1.6.0"
  },
  "devDependencies": {
    "nodemon": "^3.0.1"
  }
}
```

---

### 4. Enhanced .env.example

```bash
# Server Configuration
PORT=3000
NODE_ENV=development

# Cron Schedule (every 10 minutes)
HEARTBEAT_CRON=*/10 * * * *

# Self-Healing Configuration
MAX_FAILURES=3

# Stress Test Configuration
BASE_URL=http://localhost:3000
TEST_DURATION_HOURS=1

# Notion Integration (optional - works in placeholder mode)
NOTION_KEY=secret_xxxxx
NOTION_DATABASE_ID=xxxxx

# OpenAI Integration (optional - works in placeholder mode)
OPENAI_KEY=sk-xxxxx
OPENAI_MODEL=gpt-4
OPENAI_TEMPERATURE=0.7
OPENAI_MAX_TOKENS=2000

# Logging
LOG_LEVEL=info
```

---

## 🚀 USAGE INSTRUCTIONS

### Step 1: Generate Project

```bash
# Paste this entire prompt into Replit Agent
# Wait for generation to complete
# All files will be created automatically
```

---

### Step 2: Local Testing

```bash
cd nodejs-backend
npm install
cp .env.example .env
npm start

# In another terminal - run stress test:
npm run stress-test
```

**Expected Results:**
- ✅ Server starts on port 3000
- ✅ Initial inner loop cycle completes
- ✅ Cron job scheduled
- ✅ Stress test passes with 100% success rate
- ✅ Self-healing ready (no failures yet)

---

### Step 3: Deploy to Render

```bash
# Initialize git
git init
git remote add origin https://github.com/YOUR_USERNAME/cipherh-backend.git

# Commit all files
git add .
git commit -m "feat: CipherH backend with self-healing and stress testing"
git push -u origin main

# On Render.com:
1. New Web Service
2. Connect GitHub repo
3. Settings:
   - Branch: main
   - Build: npm install
   - Start: npm start
   - Plan: Starter ($7/month)
4. Environment Variables:
   PORT=3000
   NODE_ENV=production
   HEARTBEAT_CRON=*/10 * * * *
   MAX_FAILURES=3
   LOG_LEVEL=info
   (+ optional: NOTION_KEY, OPENAI_KEY)
5. Deploy!
```

---

### Step 4: Verify Production

```bash
# Test health
curl https://your-app.onrender.com/health

# Test status
curl https://your-app.onrender.com/core/status

# Run remote stress test (from local machine)
BASE_URL=https://your-app.onrender.com npm run stress-test
```

---

## 🎨 SYSTEM DIAGRAM

```
┌──────────────────────────────────────────────────────────────────┐
│                    CIPHERH AUTO-DEPLOY ARCHITECTURE               │
│                                                                    │
│  ┌────────────┐   ┌────────────┐   ┌────────────┐               │
│  │   GitHub   │──▶│   Render   │──▶│  Backend   │               │
│  │    Repo    │   │ Auto-Deploy│   │  Running   │               │
│  └────────────┘   └────────────┘   └──────┬─────┘               │
│       ▲                                    │                      │
│       │                                    ▼                      │
│  ┌────┴──────┐                   ┌────────────────┐             │
│  │  Replit   │                   │  Cron Job      │             │
│  │ Dev Code  │                   │  */10 min      │             │
│  └───────────┘                   └────────┬───────┘             │
│                                           │                      │
│                                           ▼                      │
│                                  ┌─────────────────┐            │
│                                  │  Inner Loop     │            │
│                                  │  (14 steps)     │            │
│                                  └────────┬────────┘            │
│                                           │                      │
│                    ┌──────────────────────┼──────────────┐      │
│                    │                      │              │      │
│                    ▼                      ▼              ▼      │
│              ┌──────────┐          ┌──────────┐   ┌──────────┐ │
│              │  Notion  │          │  Logger  │   │ OpenAI   │ │
│              │ Database │          │ Service  │   │ Service  │ │
│              └──────────┘          └──────────┘   └──────────┘ │
│                    │                      │              │      │
│                    └──────────────────────┴──────────────┘      │
│                                           │                      │
│                                           ▼                      │
│                                  ┌─────────────────┐            │
│                                  │  Self-Healing   │            │
│                                  │  On Error (3x)  │            │
│                                  └─────────────────┘            │
│                                                                  │
│  FEATURES:                                                       │
│  ✅ 24/7 Operation       ✅ Self-Healing        ✅ Stress Tested │
│  ✅ Auto CI/CD           ✅ Complete Logging    ✅ $17/month     │
└──────────────────────────────────────────────────────────────────┘
```

---

## ✅ VALIDATION CHECKLIST

**After generation, verify:**

### Code Generated:
- ✅ All 15+ files created
- ✅ Self-healing in server.js
- ✅ Stress test in tests/
- ✅ All modules complete

### Local Testing:
- ✅ npm install works
- ✅ npm start runs
- ✅ Initial cycle completes
- ✅ npm run stress-test passes

### Self-Healing:
- ✅ Error detection works
- ✅ Auto-recovery triggers
- ✅ Notion logging on heal
- ✅ Server never crashes

### Stress Test Results:
- ✅ 100% success rate
- ✅ Average response time <500ms
- ✅ No errors after 1 hour
- ✅ Memory stable

### CI/CD:
- ✅ GitHub push successful
- ✅ Render auto-deploys
- ✅ Production health OK
- ✅ Inner loop continues

---

## 🎯 SUCCESS CRITERIA

**Backend is production-ready when:**

1. ✅ All files generated correctly
2. ✅ Local tests pass (npm start)
3. ✅ Stress test passes (1 hour minimum)
4. ✅ Self-healing verified (simulated error recovery)
5. ✅ Deployed to Render successfully
6. ✅ Production health check responds
7. ✅ Cron job running (144 cycles/day)
8. ✅ Notion writes working
9. ✅ Budget compliant ($17/month)
10. ✅ No critical errors in 24 hours

---

## 💰 COST BREAKDOWN

```
Render Starter:  $7/month  (always-on, auto-deploy)
OpenAI API:     ~$10/month (optional - works in placeholder)
Notion:          $0/month  (free tier)
────────────────────────────
Total:          ~$17/month ✅ Under $25 budget
```

---

## 🏆 FINAL NOTES

**This prompt generates:**
- Complete backend (2,050+ lines)
- Self-healing capability
- Automated stress testing
- GitHub → Render CI/CD
- Production-ready immediately
- Budget compliant
- 99.9% uptime target

**For complete innerLoop.js (521 lines), copy from ULTIMATE_GENERATION_PROMPT.md or MASTER_PROMPT.md**

**For all other core modules (soulCore, strategy, taskManager, etc.), copy from ULTIMATE_GENERATION_PROMPT.md**

---

**PASTE THIS PROMPT INTO REPLIT → WAIT FOR GENERATION → npm install → npm start → npm run stress-test → DEPLOY TO RENDER → DONE! 🚀✨**
