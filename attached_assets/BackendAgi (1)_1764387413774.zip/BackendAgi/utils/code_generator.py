import os
import json
from typing import Dict, Any, List, Optional
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

class CodeGenerator:
    def __init__(self):
        api_key = os.getenv('OPENAI_API_KEY')
        if not api_key:
            raise ValueError("OPENAI_API_KEY not found")
        
        self.client = OpenAI(api_key=api_key)
        self.model = os.getenv('OPENAI_MODEL', 'gpt-4o-mini')
    
    def analyze_codebase_style(self, file_paths: List[str]) -> Dict[str, Any]:
        codebase_context = ""
        
        for file_path in file_paths:
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                    codebase_context += f"\n\n=== {file_path} ===\n{content}"
            except Exception as e:
                print(f"⚠️ Không đọc được {file_path}: {e}")
        
        prompt = f"""Phân tích codebase này và trích xuất style patterns:

{codebase_context[:8000]}

Trả về JSON:
{{
  "naming_conventions": {{"functions": "", "classes": "", "variables": ""}},
  "code_structure": {{"modular": true, "separation": ""}},
  "comment_style": "",
  "error_handling": "",
  "common_patterns": []
}}"""
        
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "Bạn là code analyzer chuyên nghiệp."},
                    {"role": "user", "content": prompt}
                ],
                response_format={"type": "json_object"},
                temperature=0.3
            )
            
            content = response.choices[0].message.content
            if content:
                return json.loads(content)
            return {}
        
        except Exception as e:
            print(f"❌ Lỗi phân tích: {e}")
            return {}
    
    def generate_module(
        self,
        module_type: str,
        requirements: str,
        style_guide: Optional[Dict[str, Any]] = None
    ) -> str:
        style_context = ""
        if style_guide:
            style_context = f"\n\nStyle guide:\n{json.dumps(style_guide, indent=2)}"
        
        prompt = f"""Generate Python module: {module_type}

Requirements:
{requirements}
{style_context}

Viết code hoàn chỉnh, professional, có docstring và error handling.
Trả về code thuần, không markdown."""
        
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "Bạn là senior Python developer. Viết code production-ready."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.2,
                max_tokens=2000
            )
            
            content = response.choices[0].message.content
            return content.strip() if content else ""
        
        except Exception as e:
            return f"# Error generating module: {e}"
    
    def fix_code(self, code: str, error_message: str, style_guide: Optional[Dict[str, Any]] = None) -> str:
        style_context = ""
        if style_guide:
            style_context = f"\n\nStyle guide:\n{json.dumps(style_guide, indent=2)}"
        
        prompt = f"""Code hiện tại:
```python
{code}
```

Error:
{error_message}
{style_context}

Fix code, giữ nguyên style. Trả về code đã fix, không markdown."""
        
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "Bạn là debugger chuyên nghiệp."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.2
            )
            
            content = response.choices[0].message.content
            return content.strip() if content else code
        
        except Exception as e:
            return code
    
    def generate_api_endpoint(
        self,
        endpoint_name: str,
        method: str,
        description: str,
        framework: str = "flask"
    ) -> str:
        requirements = f"""
Endpoint: {endpoint_name}
Method: {method}
Description: {description}
Framework: {framework}

Tạo Flask route hoàn chỉnh với:
- Error handling
- Input validation
- Docstring
- Response formatting
"""
        
        return self.generate_module("API Endpoint", requirements)
    
    def generate_database_model(
        self,
        model_name: str,
        fields: Dict[str, str],
        description: str
    ) -> str:
        fields_str = "\n".join([f"- {name}: {type_}" for name, type_ in fields.items()])
        
        requirements = f"""
Model: {model_name}
Description: {description}

Fields:
{fields_str}

Tạo class model với:
- All fields defined
- Validation methods
- to_dict() method
- Docstring
"""
        
        return self.generate_module("Database Model", requirements)
    
    def generate_utility_function(
        self,
        function_name: str,
        purpose: str,
        inputs: str,
        outputs: str
    ) -> str:
        requirements = f"""
Function: {function_name}
Purpose: {purpose}
Inputs: {inputs}
Outputs: {outputs}

Tạo utility function với:
- Type hints
- Docstring
- Error handling
- Unit testable
"""
        
        return self.generate_module("Utility Function", requirements)
