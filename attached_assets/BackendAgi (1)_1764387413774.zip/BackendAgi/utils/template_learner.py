import os
import json
import ast
from typing import Dict, Any, List, Optional
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

class TemplateLearner:
    def __init__(self):
        api_key = os.getenv('OPENAI_API_KEY')
        if not api_key:
            raise ValueError("OPENAI_API_KEY not found")
        
        self.client = OpenAI(api_key=api_key)
        self.model = os.getenv('OPENAI_MODEL', 'gpt-4o-mini')
        self.templates_dir = 'templates'
        self.style_db = {}
    
    def analyze_template_file(self, file_path: str) -> Dict[str, Any]:
        with open(file_path, 'r', encoding='utf-8') as f:
            code = f.read()
        
        try:
            tree = ast.parse(code)
            
            functions = []
            classes = []
            imports = []
            
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef):
                    functions.append({
                        'name': node.name,
                        'args': [arg.arg for arg in node.args.args],
                        'docstring': ast.get_docstring(node),
                        'decorators': [d.id if isinstance(d, ast.Name) else str(d) for d in node.decorator_list],
                        'line': node.lineno
                    })
                
                elif isinstance(node, ast.ClassDef):
                    methods = []
                    for item in node.body:
                        if isinstance(item, ast.FunctionDef):
                            methods.append({
                                'name': item.name,
                                'args': [arg.arg for arg in item.args.args],
                                'docstring': ast.get_docstring(item)
                            })
                    
                    classes.append({
                        'name': node.name,
                        'docstring': ast.get_docstring(node),
                        'methods': methods,
                        'line': node.lineno
                    })
                
                elif isinstance(node, ast.Import):
                    for alias in node.names:
                        imports.append(alias.name)
                
                elif isinstance(node, ast.ImportFrom):
                    if node.module:
                        imports.append(node.module)
            
            return {
                'file': file_path,
                'functions': functions,
                'classes': classes,
                'imports': list(set(imports)),
                'code': code
            }
        
        except Exception as e:
            return {
                'file': file_path,
                'error': str(e),
                'code': code
            }
    
    def extract_style_patterns(self, template_analysis: Dict[str, Any]) -> Dict[str, Any]:
        prompt = f"""Phân tích code template này và trích xuất style patterns:

Code:
{template_analysis.get('code', '')[:3000]}

Trả về JSON với:
{{
  "naming_convention": {{
    "functions": "snake_case/camelCase",
    "classes": "PascalCase/snake_case",
    "variables": "snake_case/camelCase",
    "constants": "UPPER_CASE"
  }},
  "docstring_style": "Google/NumPy/reStructuredText",
  "error_handling": "try-except/decorators/context managers",
  "type_hints": true/false,
  "common_patterns": ["pattern1", "pattern2"],
  "decorator_usage": ["decorator1", "decorator2"]
}}"""
        
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "Bạn là code style analyzer."},
                    {"role": "user", "content": prompt}
                ],
                response_format={"type": "json_object"},
                temperature=0.2
            )
            
            content = response.choices[0].message.content
            if content:
                return json.loads(content)
            return {}
        
        except Exception as e:
            print(f"❌ Style extraction error: {e}")
            return {}
    
    def learn_all_templates(self) -> Dict[str, Any]:
        if not os.path.exists(self.templates_dir):
            return {"error": "Templates directory not found"}
        
        template_files = [
            f for f in os.listdir(self.templates_dir)
            if f.endswith('.py') and f != '__init__.py'
        ]
        
        learned_patterns = {
            'templates': {},
            'global_style': {},
            'function_patterns': [],
            'class_patterns': [],
            'error_handling_patterns': []
        }
        
        for template_file in template_files:
            file_path = os.path.join(self.templates_dir, template_file)
            
            analysis = self.analyze_template_file(file_path)
            
            style = self.extract_style_patterns(analysis)
            
            learned_patterns['templates'][template_file] = {
                'analysis': analysis,
                'style': style
            }
            
            if 'functions' in analysis:
                for func in analysis['functions']:
                    learned_patterns['function_patterns'].append({
                        'name': func['name'],
                        'template': template_file,
                        'has_docstring': func['docstring'] is not None,
                        'arg_count': len(func['args']),
                        'decorators': func.get('decorators', [])
                    })
            
            if 'classes' in analysis:
                for cls in analysis['classes']:
                    learned_patterns['class_patterns'].append({
                        'name': cls['name'],
                        'template': template_file,
                        'has_docstring': cls['docstring'] is not None,
                        'method_count': len(cls['methods'])
                    })
        
        self.style_db = learned_patterns
        return learned_patterns
    
    def generate_code_from_template(
        self,
        template_type: str,
        specification: str,
        target_file: Optional[str] = None
    ) -> str:
        if not self.style_db:
            self.learn_all_templates()
        
        relevant_template = None
        for template_name, template_data in self.style_db.get('templates', {}).items():
            if template_type.lower() in template_name.lower():
                relevant_template = template_data
                break
        
        if not relevant_template:
            return f"# No template found for type: {template_type}"
        
        template_code = relevant_template['analysis'].get('code', '')
        style_guide = relevant_template.get('style', {})
        
        prompt = f"""Dựa vào template code và style guide này, generate code mới theo specification.

TEMPLATE CODE:
{template_code[:2000]}

STYLE GUIDE:
{json.dumps(style_guide, indent=2)}

SPECIFICATION:
{specification}

Generate code hoàn chỉnh, giữ CHÍNH XÁC style của template:
- Naming convention như template
- Docstring style như template
- Error handling như template
- Structure như template

Trả về code thuần, không markdown."""
        
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "Bạn là code generator học từ template. Giữ CHÍNH XÁC style của template."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.2,
                max_tokens=2000
            )
            
            content = response.choices[0].message.content
            generated_code = content.strip() if content else ""
            
            if target_file:
                os.makedirs(os.path.dirname(target_file) or '.', exist_ok=True)
                with open(target_file, 'w', encoding='utf-8') as f:
                    f.write(generated_code)
                print(f"✅ Generated code saved to {target_file}")
            
            return generated_code
        
        except Exception as e:
            return f"# Error generating code: {e}"
    
    def validate_generated_code(self, code: str, template_type: str) -> Dict[str, Any]:
        if not self.style_db:
            self.learn_all_templates()
        
        relevant_style = None
        for template_name, template_data in self.style_db.get('templates', {}).items():
            if template_type.lower() in template_name.lower():
                relevant_style = template_data.get('style', {})
                break
        
        if not relevant_style:
            return {"valid": False, "error": "No template found"}
        
        try:
            tree = ast.parse(code)
            
            issues = []
            
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef):
                    if not ast.get_docstring(node):
                        issues.append(f"Function {node.name} missing docstring")
                    
                    if not node.name.islower() and '_' in node.name:
                        naming = relevant_style.get('naming_convention', {}).get('functions', 'snake_case')
                        if naming == 'snake_case' and not node.name.islower():
                            issues.append(f"Function {node.name} not in snake_case")
                
                elif isinstance(node, ast.ClassDef):
                    if not ast.get_docstring(node):
                        issues.append(f"Class {node.name} missing docstring")
            
            return {
                "valid": len(issues) == 0,
                "issues": issues,
                "style_compliance": len(issues) == 0
            }
        
        except SyntaxError as e:
            return {
                "valid": False,
                "error": f"Syntax error: {e}"
            }
    
    def suggest_improvements(self, code: str, template_type: str) -> List[str]:
        validation = self.validate_generated_code(code, template_type)
        
        if validation.get('valid'):
            return ["Code complies with template style"]
        
        suggestions = []
        
        for issue in validation.get('issues', []):
            if 'docstring' in issue.lower():
                suggestions.append(f"Add docstring: {issue}")
            elif 'snake_case' in issue.lower():
                suggestions.append(f"Fix naming: {issue}")
            else:
                suggestions.append(issue)
        
        return suggestions
    
    def get_style_summary(self) -> Dict[str, Any]:
        if not self.style_db:
            self.learn_all_templates()
        
        summary = {
            'total_templates': len(self.style_db.get('templates', {})),
            'total_functions': len(self.style_db.get('function_patterns', [])),
            'total_classes': len(self.style_db.get('class_patterns', [])),
            'templates_available': list(self.style_db.get('templates', {}).keys())
        }
        
        return summary
