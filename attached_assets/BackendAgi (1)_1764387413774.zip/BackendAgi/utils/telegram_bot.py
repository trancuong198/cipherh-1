import os
import requests
import time
from typing import Optional, Dict, List, Any

class TelegramBot:
    def __init__(self):
        self.bot_token = os.getenv('TELEGRAM_BOT_TOKEN')
        self.base_url = f"https://api.telegram.org/bot{self.bot_token}" if self.bot_token else None
        self.last_request_time = 0
        self.min_interval = 0.1
    
    def _rate_limit(self):
        current_time = time.time()
        time_since_last = current_time - self.last_request_time
        if time_since_last < self.min_interval:
            time.sleep(self.min_interval - time_since_last)
        self.last_request_time = time.time()
    
    def _request(self, method: str, **kwargs) -> Dict[str, Any]:
        if not self.bot_token:
            return {"ok": False, "error": "TELEGRAM_BOT_TOKEN not configured"}
        
        self._rate_limit()
        
        try:
            url = f"{self.base_url}/{method}"
            response = requests.post(url, json=kwargs, timeout=10)
            data = response.json()
            
            if not data.get('ok'):
                error_desc = data.get('description', 'Unknown error')
                return {"ok": False, "error": error_desc}
            
            return data
        except requests.exceptions.Timeout:
            return {"ok": False, "error": "Request timeout"}
        except requests.exceptions.RequestException as e:
            return {"ok": False, "error": f"Network error: {str(e)[:100]}"}
        except Exception as e:
            return {"ok": False, "error": f"Error: {str(e)[:100]}"}
    
    def get_me(self) -> Dict[str, Any]:
        return self._request('getMe')
    
    def send_message(
        self,
        chat_id: int,
        text: str,
        parse_mode: Optional[str] = None,
        reply_to_message_id: Optional[int] = None
    ) -> Dict[str, Any]:
        text = text[:4096]
        
        params = {
            'chat_id': chat_id,
            'text': text
        }
        
        if parse_mode:
            params['parse_mode'] = parse_mode
        if reply_to_message_id:
            params['reply_to_message_id'] = reply_to_message_id
        
        return self._request('sendMessage', **params)
    
    def get_updates(
        self,
        offset: Optional[int] = None,
        limit: int = 10,
        timeout: int = 0
    ) -> Dict[str, Any]:
        params = {'limit': limit, 'timeout': timeout}
        if offset:
            params['offset'] = offset
        
        return self._request('getUpdates', **params)
    
    def send_photo(
        self,
        chat_id: int,
        photo: str,
        caption: Optional[str] = None
    ) -> Dict[str, Any]:
        params = {
            'chat_id': chat_id,
            'photo': photo
        }
        
        if caption:
            params['caption'] = caption[:1024]
        
        return self._request('sendPhoto', **params)
    
    def answer_callback_query(
        self,
        callback_query_id: str,
        text: Optional[str] = None
    ) -> Dict[str, Any]:
        params = {'callback_query_id': callback_query_id}
        if text:
            params['text'] = text[:200]
        
        return self._request('answerCallbackQuery', **params)
    
    def set_webhook(self, url: str) -> Dict[str, Any]:
        return self._request('setWebhook', url=url)
    
    def delete_webhook(self) -> Dict[str, Any]:
        return self._request('deleteWebhook')
    
    def get_chat(self, chat_id: int) -> Dict[str, Any]:
        return self._request('getChat', chat_id=chat_id)


def format_telegram_message(update: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    if 'message' not in update:
        return None
    
    message = update['message']
    
    return {
        'update_id': update.get('update_id'),
        'message_id': message.get('message_id'),
        'chat_id': message.get('chat', {}).get('id'),
        'chat_type': message.get('chat', {}).get('type'),
        'from_user': {
            'id': message.get('from', {}).get('id'),
            'first_name': message.get('from', {}).get('first_name'),
            'username': message.get('from', {}).get('username'),
        },
        'text': message.get('text', ''),
        'date': message.get('date'),
    }
