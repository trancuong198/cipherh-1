from flask import Blueprint, request, jsonify, session
from utils.code_generator import CodeGenerator
import os

code_gen_bp = Blueprint('code_gen', __name__)
code_generator = CodeGenerator()

@code_gen_bp.route('/api/code/analyze', methods=['POST'])
def analyze_codebase():
    try:
        data = request.json
        if not data or 'file_paths' not in data:
            return jsonify({"error": "file_paths required"}), 400
        
        file_paths = data['file_paths']
        
        style_analysis = code_generator.analyze_codebase_style(file_paths)
        
        return jsonify({
            "success": True,
            "style_analysis": style_analysis
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@code_gen_bp.route('/api/code/generate', methods=['POST'])
def generate_code():
    try:
        data = request.json
        if not data or 'module_type' not in data or 'requirements' not in data:
            return jsonify({"error": "module_type and requirements required"}), 400
        
        module_type = data['module_type']
        requirements = data['requirements']
        style_guide = data.get('style_guide')
        
        generated_code = code_generator.generate_module(
            module_type=module_type,
            requirements=requirements,
            style_guide=style_guide
        )
        
        return jsonify({
            "success": True,
            "code": generated_code
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@code_gen_bp.route('/api/code/fix', methods=['POST'])
def fix_code():
    try:
        data = request.json
        if not data or 'code' not in data or 'error_message' not in data:
            return jsonify({"error": "code and error_message required"}), 400
        
        code = data['code']
        error_message = data['error_message']
        style_guide = data.get('style_guide')
        
        fixed_code = code_generator.fix_code(
            code=code,
            error_message=error_message,
            style_guide=style_guide
        )
        
        return jsonify({
            "success": True,
            "fixed_code": fixed_code
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@code_gen_bp.route('/api/code/endpoint', methods=['POST'])
def generate_endpoint():
    try:
        data = request.json
        if not data or 'endpoint_name' not in data or 'method' not in data or 'description' not in data:
            return jsonify({"error": "endpoint_name, method, and description required"}), 400
        
        endpoint_name = data['endpoint_name']
        method = data['method']
        description = data['description']
        framework = data.get('framework', 'flask')
        
        code = code_generator.generate_api_endpoint(
            endpoint_name=endpoint_name,
            method=method,
            description=description,
            framework=framework
        )
        
        return jsonify({
            "success": True,
            "code": code
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@code_gen_bp.route('/api/code/model', methods=['POST'])
def generate_model():
    try:
        data = request.json
        if not data or 'model_name' not in data or 'fields' not in data or 'description' not in data:
            return jsonify({"error": "model_name, fields, and description required"}), 400
        
        model_name = data['model_name']
        fields = data['fields']
        description = data['description']
        
        code = code_generator.generate_database_model(
            model_name=model_name,
            fields=fields,
            description=description
        )
        
        return jsonify({
            "success": True,
            "code": code
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@code_gen_bp.route('/api/code/utility', methods=['POST'])
def generate_utility():
    try:
        data = request.json
        if not data or 'function_name' not in data or 'purpose' not in data:
            return jsonify({"error": "function_name and purpose required"}), 400
        
        function_name = data['function_name']
        purpose = data['purpose']
        inputs = data.get('inputs', '')
        outputs = data.get('outputs', '')
        
        code = code_generator.generate_utility_function(
            function_name=function_name,
            purpose=purpose,
            inputs=inputs,
            outputs=outputs
        )
        
        return jsonify({
            "success": True,
            "code": code
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500
