from flask import Blueprint, render_template, request, jsonify, session
from utils.brain import Brain
from memory import MemoryPipeline, ReflectionLoop
import json
from datetime import datetime

main_bp = Blueprint('main', __name__)

brain = None
pipeline = None
reflection_loop = None

def init_routes(app):
    global brain, pipeline, reflection_loop
    try:
        brain = Brain()
        print("✓ Bộ não CipherH đã được khởi tạo")
    except Exception as e:
        print(f"✗ Lỗi khi khởi tạo bộ não: {str(e)}")
    
    try:
        pipeline = MemoryPipeline()
        print("✓ Memory Pipeline v2.0 đã được kết nối (Fetch→Interpret→Route→Inject)")
    except Exception as e:
        print(f"✗ Lỗi khi khởi tạo pipeline: {str(e)}")
    
    try:
        reflection_loop = ReflectionLoop()
        print("✓ Reflection Loop đã được khởi động")
    except Exception as e:
        print(f"✗ Lỗi khi khởi tạo reflection loop: {str(e)}")

@main_bp.route('/')
def index():
    return render_template('chat.html')

@main_bp.route('/dashboard')
def dashboard():
    return render_template('dashboard.html')

@main_bp.route('/admin')
def admin():
    return render_template('admin.html')

@main_bp.route('/api/chat', methods=['POST'])
def chat():
    if not brain:
        return jsonify({"error": "Bộ não CipherH chưa được khởi tạo. Vui lòng kiểm tra OPENAI_API_KEY."}), 500
    
    data = request.json
    if not data:
        return jsonify({"error": "No data provided"}), 400
    
    user_message = data.get('message', '').strip()
    
    if not user_message:
        return jsonify({"error": "Tin nhắn không được để trống"}), 400
    
    print(f"\n🧠 NEW PIPELINE: Processing '{user_message[:50]}...'")
    
    context_data = ""
    if pipeline:
        try:
            context_data = pipeline.get_context_for_query(
                user_query=user_message,
                episodic_limit=30,
                semantic_limit=50,
                context_limit=10
            )
            print(f"✅ Pipeline context built: {len(context_data)} chars")
        except Exception as e:
            print(f"⚠️ Pipeline error: {str(e)}")
            context_data = ""
    
    ai_response = brain.chat(user_message, context_data)
    
    if reflection_loop and data.get('save_to_memory', True):
        try:
            reflection_result = reflection_loop.reflect(
                user_message=user_message,
                ai_response=ai_response,
                save_episodic=True
            )
            insights_count = len(reflection_result.get('extracted_insights', []))
            print(f"💡 Reflection saved: {insights_count} insights extracted")
        except Exception as e:
            print(f"⚠️ Reflection error: {str(e)}")
    
    return jsonify({
        "response": ai_response,
        "timestamp": datetime.now().isoformat(),
        "pipeline_version": "v2.0"
    })

@main_bp.route('/api/memories', methods=['GET'])
def get_memories():
    if not pipeline:
        return jsonify({"error": "Memory pipeline chưa được kết nối"}), 500
    
    try:
        stats = pipeline.get_stats()
        return jsonify({
            "stats": stats,
            "pipeline_version": "v2.0"
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@main_bp.route('/api/stats', methods=['GET'])
def get_stats():
    stats = {
        "brain_status": "active" if brain else "inactive",
        "pipeline_status": "active" if pipeline else "inactive",
        "reflection_status": "active" if reflection_loop else "inactive",
        "pipeline_version": "v2.0 (Fetch→Interpret→Route→Inject→Reflect)"
    }
    
    if pipeline:
        try:
            stats["memory_stats"] = pipeline.get_stats()
        except Exception as e:
            stats["memory_stats_error"] = str(e)
    
    try:
        with open('cipherh_manifest.json', 'r', encoding='utf-8') as f:
            manifest = json.load(f)
            stats["manifest"] = manifest
    except Exception as e:
        stats["manifest_error"] = str(e)
    
    return jsonify(stats)

@main_bp.route('/api/reflect', methods=['POST'])
def reflect_endpoint():
    if not reflection_loop:
        return jsonify({"error": "Reflection loop chưa sẵn sàng"}), 500
    
    data = request.json
    if not data:
        return jsonify({"error": "No data provided"}), 400
    
    user_message = data.get('user_message', '')
    ai_response = data.get('ai_response', '')
    
    if not user_message or not ai_response:
        return jsonify({"error": "user_message và ai_response đều bắt buộc"}), 400
    
    try:
        result = reflection_loop.reflect(user_message, ai_response, save_episodic=True)
        
        return jsonify({
            "reflection": result.get('reflection', ''),
            "insights": result.get('extracted_insights', []),
            "saved": result.get('saved', False),
            "timestamp": datetime.now().isoformat()
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@main_bp.route('/api/health', methods=['GET'])
def health():
    return jsonify({
        "status": "healthy",
        "pipeline_version": "v2.0",
        "components": {
            "brain": "ok" if brain else "not_initialized",
            "memory_pipeline": "ok" if pipeline else "not_initialized",
            "reflection_loop": "ok" if reflection_loop else "not_initialized"
        }
    })
