from flask import Blueprint, request, jsonify
from emotions.emotional_model import EmotionalModel

emotion_bp = Blueprint('emotion', __name__)
emotion_model = EmotionalModel()

@emotion_bp.route('/api/emotion/update', methods=['POST'])
def update_emotion():
    try:
        data = request.json
        if not data:
            return jsonify({"error": "event data required"}), 400
        
        result = emotion_model.update_emotion(data)
        
        return jsonify({
            "success": True,
            "result": result
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@emotion_bp.route('/api/emotion/evaluate', methods=['GET'])
def evaluate_state():
    try:
        evaluation = emotion_model.evaluate_emotional_state()
        
        return jsonify({
            "success": True,
            "evaluation": evaluation
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@emotion_bp.route('/api/emotion/influence', methods=['POST'])
def influence_action():
    try:
        data = request.json
        if not data:
            return jsonify({"error": "action data required"}), 400
        
        result = emotion_model.influence_action(data)
        
        return jsonify({
            "success": True,
            "result": result
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@emotion_bp.route('/api/emotion/reflect', methods=['POST'])
def reflect_on_memory():
    try:
        memory_data = emotion_model.reflect_emotion_on_memory()
        
        return jsonify({
            "success": True,
            "memory_data": memory_data
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@emotion_bp.route('/api/emotion/learn', methods=['POST'])
def adaptive_learning():
    try:
        learning = emotion_model.adaptive_emotion_learning()
        
        return jsonify({
            "success": True,
            "learning": learning
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@emotion_bp.route('/api/emotion/state', methods=['GET'])
def get_state():
    try:
        state = emotion_model.get_current_state()
        
        return jsonify({
            "success": True,
            "state": state
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@emotion_bp.route('/api/emotion/reset', methods=['POST'])
def reset_emotions():
    try:
        result = emotion_model.reset_emotions()
        
        return jsonify({
            "success": True,
            "result": result
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500
