from flask import Blueprint, request, jsonify
from personality.personality_core import PersonalityCore

personality_bp = Blueprint('personality', __name__)
personality = PersonalityCore()

@personality_bp.route('/api/personality/update-traits', methods=['POST'])
def update_traits():
    try:
        data = request.json
        if not data or 'event' not in data or 'outcome' not in data or 'emotion' not in data:
            return jsonify({"error": "event, outcome, and emotion required"}), 400
        
        result = personality.update_traits(
            data['event'],
            data['outcome'],
            data['emotion']
        )
        
        return jsonify({
            "success": True,
            "result": result
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@personality_bp.route('/api/personality/reflect', methods=['POST'])
def reflect_on_action():
    try:
        data = request.json
        if not data or 'task_id' not in data or 'result' not in data:
            return jsonify({"error": "task_id and result required"}), 400
        
        reflection = personality.reflect_on_action(
            data['task_id'],
            data['result']
        )
        
        return jsonify({
            "success": True,
            "reflection": reflection
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@personality_bp.route('/api/personality/influence-decision', methods=['POST'])
def influence_decision():
    try:
        data = request.json
        if not data or 'action' not in data:
            return jsonify({"error": "action required"}), 400
        
        result = personality.influence_decision(data['action'])
        
        return jsonify({
            "success": True,
            "result": result
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@personality_bp.route('/api/personality/express', methods=['POST'])
def express_behavior():
    try:
        data = request.json
        if not data or 'content' not in data:
            return jsonify({"error": "content required"}), 400
        
        result = personality.express_behavior(data)
        
        return jsonify({
            "success": True,
            "result": result
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@personality_bp.route('/api/personality/learn-pattern', methods=['GET'])
def learn_pattern():
    try:
        patterns = personality.learn_personality_pattern()
        
        return jsonify({
            "success": True,
            "patterns": patterns
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@personality_bp.route('/api/personality/traits', methods=['GET'])
def get_traits():
    try:
        traits = personality.get_current_traits()
        
        return jsonify({
            "success": True,
            "traits": traits
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@personality_bp.route('/api/personality/soul-scars', methods=['GET'])
def get_soul_scars():
    try:
        scars = personality.get_soul_scars()
        
        return jsonify({
            "success": True,
            "soul_scars": scars,
            "count": len(scars)
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@personality_bp.route('/api/personality/stats', methods=['GET'])
def get_stats():
    try:
        stats = personality.get_reflective_stats()
        
        return jsonify({
            "success": True,
            "stats": stats
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500
