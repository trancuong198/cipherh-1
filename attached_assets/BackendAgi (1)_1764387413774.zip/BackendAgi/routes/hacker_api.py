from flask import Blueprint, request, jsonify
from cipherh_brain.hacker import HackerMindset
import os

hacker_bp = Blueprint('hacker', __name__)
hacker = HackerMindset()

@hacker_bp.route('/api/hacker/audit', methods=['POST'])
def audit_file():
    try:
        data = request.json
        if not data or 'file_path' not in data:
            return jsonify({"error": "file_path required"}), 400
        
        file_path = data['file_path']
        
        if not os.path.exists(file_path):
            return jsonify({"error": "File not found"}), 404
        
        audit = hacker.code_auditor_mode(file_path)
        
        return jsonify({
            "success": True,
            "audit": audit
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@hacker_bp.route('/api/hacker/security-scan', methods=['POST'])
def security_scan():
    try:
        data = request.json or {}
        directory = data.get('directory', '.')
        
        scan_results = hacker.security_scan(directory)
        
        return jsonify({
            "success": True,
            "scan_results": scan_results
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@hacker_bp.route('/api/hacker/simulate-attack', methods=['POST'])
def simulate_attack():
    try:
        data = request.json
        if not data or 'attack_type' not in data or 'target_code' not in data:
            return jsonify({"error": "attack_type and target_code required"}), 400
        
        attack_type = data['attack_type']
        target_code = data['target_code']
        
        simulation = hacker.simulate_attack(attack_type, target_code)
        
        return jsonify({
            "success": True,
            "simulation": simulation
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@hacker_bp.route('/api/hacker/mirror', methods=['POST'])
def mirror_code():
    try:
        data = request.json
        if not data or 'code' not in data:
            return jsonify({"error": "code required"}), 400
        
        code = data['code']
        source = data.get('source', 'replit')
        
        filepath = hacker.mirror_mode(code, source)
        
        return jsonify({
            "success": True,
            "filepath": filepath,
            "message": "Code mirrored and patterns extracted"
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@hacker_bp.route('/api/hacker/extract-patterns', methods=['POST'])
def extract_patterns():
    try:
        data = request.json
        if not data or 'code' not in data:
            return jsonify({"error": "code required"}), 400
        
        code = data['code']
        source = data.get('source', 'unknown')
        
        patterns = hacker.extract_patterns(code, source)
        
        return jsonify({
            "success": True,
            "patterns": patterns
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@hacker_bp.route('/api/hacker/reflect', methods=['POST'])
def reflect_code():
    try:
        data = request.json
        if not data or 'code' not in data:
            return jsonify({"error": "code required"}), 400
        
        code = data['code']
        
        score = hacker.reflect(code)
        
        return jsonify({
            "success": True,
            "score": score
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@hacker_bp.route('/api/hacker/generate', methods=['POST'])
def generate_with_style():
    try:
        data = request.json
        if not data or 'task' not in data:
            return jsonify({"error": "task description required"}), 400
        
        task = data['task']
        
        code = hacker.style_reinforcement(task)
        
        return jsonify({
            "success": True,
            "code": code
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@hacker_bp.route('/api/hacker/security-report', methods=['GET'])
def get_security_report():
    try:
        report = hacker.get_security_report()
        
        return jsonify({
            "success": True,
            "report": report
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@hacker_bp.route('/api/hacker/patterns', methods=['GET'])
def get_patterns():
    try:
        patterns = hacker.get_learned_patterns()
        
        return jsonify({
            "success": True,
            "patterns": patterns
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500
