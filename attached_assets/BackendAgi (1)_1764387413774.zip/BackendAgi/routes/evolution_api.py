from flask import Blueprint, request, jsonify
from cipherh_brain.evolution_kernel import EvolutionKernel
from cipherh_brain.adaptive_logic import AdaptiveLogic

evolution_bp = Blueprint('evolution', __name__)
kernel = EvolutionKernel()
adaptive = AdaptiveLogic()

@evolution_bp.route('/api/evolution/evaluate', methods=['POST'])
def evaluate():
    try:
        data = request.json or {}
        file_path = data.get('file_path')
        
        result = kernel.evaluate_self(file_path)
        
        return jsonify({
            "success": True,
            "evaluation": result
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@evolution_bp.route('/api/evolution/mutate', methods=['POST'])
def mutate():
    try:
        data = request.json
        if not data or 'target_file' not in data:
            return jsonify({"error": "target_file required"}), 400
        
        target_file = data['target_file']
        mutation_type = data.get('mutation_type', 'auto')
        
        mutation = kernel.generate_mutation(target_file, mutation_type)
        
        return jsonify({
            "success": True,
            "mutation": mutation
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@evolution_bp.route('/api/evolution/test-mutation', methods=['POST'])
def test_mutation():
    try:
        data = request.json
        if not data or 'mutation' not in data:
            return jsonify({"error": "mutation data required"}), 400
        
        mutation_data = data['mutation']
        
        test_result = kernel.test_mutation(mutation_data)
        
        return jsonify({
            "success": True,
            "test_result": test_result
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@evolution_bp.route('/api/evolution/apply-mutation', methods=['POST'])
def apply_mutation():
    try:
        data = request.json
        if not data or 'mutation' not in data:
            return jsonify({"error": "mutation data required"}), 400
        
        mutation_data = data['mutation']
        
        result = kernel.apply_mutation(mutation_data)
        
        return jsonify(result)
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@evolution_bp.route('/api/evolution/rollback', methods=['POST'])
def rollback():
    try:
        data = request.json
        if not data or 'target_file' not in data:
            return jsonify({"error": "target_file required"}), 400
        
        target_file = data['target_file']
        
        result = kernel.rollback(target_file)
        
        return jsonify(result)
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@evolution_bp.route('/api/evolution/cycle', methods=['POST'])
def evolution_cycle():
    try:
        data = request.json or {}
        target_files = data.get('target_files')
        
        result = kernel.evolution_cycle(target_files)
        
        return jsonify({
            "success": True,
            "cycle_result": result
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@evolution_bp.route('/api/evolution/history', methods=['GET'])
def get_history():
    try:
        history = kernel.get_evolution_history()
        
        return jsonify({
            "success": True,
            "history": history
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@evolution_bp.route('/api/adaptive/self-map', methods=['GET'])
def get_self_map():
    try:
        self_map = adaptive.get_self_map()
        
        return jsonify({
            "success": True,
            "self_map": self_map
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@evolution_bp.route('/api/adaptive/refresh-map', methods=['POST'])
def refresh_map():
    try:
        self_map = adaptive.refresh_self_map()
        
        return jsonify({
            "success": True,
            "self_map": self_map,
            "message": "Self map refreshed"
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@evolution_bp.route('/api/adaptive/optimize', methods=['POST'])
def optimize_structure():
    try:
        result = adaptive.optimize_structure()
        
        return jsonify({
            "success": True,
            "optimization": result
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@evolution_bp.route('/api/adaptive/refactor-functions', methods=['POST'])
def refactor_functions():
    try:
        data = request.json
        if not data or 'filepath' not in data:
            return jsonify({"error": "filepath required"}), 400
        
        filepath = data['filepath']
        
        result = adaptive.refactor_functions(filepath)
        
        return jsonify({
            "success": True,
            "refactoring": result
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@evolution_bp.route('/api/adaptive/improve-performance', methods=['POST'])
def improve_performance():
    try:
        data = request.json
        if not data or 'filepath' not in data:
            return jsonify({"error": "filepath required"}), 400
        
        filepath = data['filepath']
        
        result = adaptive.improve_performance(filepath)
        
        return jsonify({
            "success": True,
            "improvements": result
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@evolution_bp.route('/api/adaptive/reduce-complexity', methods=['POST'])
def reduce_complexity():
    try:
        data = request.json
        if not data or 'filepath' not in data:
            return jsonify({"error": "filepath required"}), 400
        
        filepath = data['filepath']
        
        result = adaptive.reduce_complexity(filepath)
        
        return jsonify({
            "success": True,
            "complexity_analysis": result
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@evolution_bp.route('/api/adaptive/auto-split-merge', methods=['POST'])
def auto_split_merge():
    try:
        result = adaptive.auto_split_or_merge_files()
        
        return jsonify({
            "success": True,
            "analysis": result
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500
