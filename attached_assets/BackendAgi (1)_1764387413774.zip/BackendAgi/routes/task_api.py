from flask import Blueprint, request, jsonify
from task.executor import TaskExecutor

task_bp = Blueprint('task', __name__)
executor = TaskExecutor()

@task_bp.route('/api/task/create', methods=['POST'])
def create_task():
    try:
        data = request.json
        if not data or 'description' not in data:
            return jsonify({"error": "description required"}), 400
        
        description = data['description']
        priority = data.get('priority', 50)
        dependencies = data.get('dependencies', [])
        
        task = executor.create_task(description, priority, dependencies)
        
        return jsonify({
            "success": True,
            "task": task
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@task_bp.route('/api/task/update-status', methods=['POST'])
def update_status():
    try:
        data = request.json
        if not data or 'task_id' not in data or 'status' not in data:
            return jsonify({"error": "task_id and status required"}), 400
        
        task_id = data['task_id']
        status = data['status']
        result = data.get('result')
        error = data.get('error')
        
        task = executor.update_task_status(task_id, status, result, error)
        
        return jsonify({
            "success": True,
            "task": task
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@task_bp.route('/api/task/schedule', methods=['GET'])
def schedule_tasks():
    try:
        scheduled = executor.schedule_tasks()
        
        return jsonify({
            "success": True,
            "scheduled_tasks": scheduled,
            "count": len(scheduled)
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@task_bp.route('/api/task/execute', methods=['POST'])
def execute_task():
    try:
        data = request.json
        if not data or 'task_id' not in data:
            return jsonify({"error": "task_id required"}), 400
        
        task_id = data['task_id']
        
        result = executor.execute_task(task_id)
        
        return jsonify({
            "success": True,
            "execution": result
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@task_bp.route('/api/task/reflect', methods=['POST'])
def reflect_outcome():
    try:
        data = request.json
        if not data or 'task_id' not in data:
            return jsonify({"error": "task_id required"}), 400
        
        task_id = data['task_id']
        success = data.get('success', True)
        error = data.get('error')
        
        reflection = executor.reflect_task_outcome(task_id, success, error)
        
        return jsonify({
            "success": True,
            "reflection": reflection
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@task_bp.route('/api/task/learn-patterns', methods=['GET'])
def learn_patterns():
    try:
        patterns = executor.learn_task_patterns()
        
        return jsonify({
            "success": True,
            "patterns": patterns
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@task_bp.route('/api/task/get', methods=['GET'])
def get_task():
    try:
        task_id = request.args.get('task_id')
        if not task_id:
            return jsonify({"error": "task_id required"}), 400
        
        task = executor.get_task(task_id)
        
        if not task:
            return jsonify({"error": "Task not found"}), 404
        
        return jsonify({
            "success": True,
            "task": task
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@task_bp.route('/api/task/list', methods=['GET'])
def list_tasks():
    try:
        status = request.args.get('status')
        
        tasks = executor.get_all_tasks(status)
        
        return jsonify({
            "success": True,
            "tasks": tasks,
            "count": len(tasks)
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@task_bp.route('/api/task/scheduler-status', methods=['GET'])
def get_scheduler_status():
    try:
        status = executor.get_scheduler_status()
        
        return jsonify({
            "success": True,
            "scheduler": status
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500
