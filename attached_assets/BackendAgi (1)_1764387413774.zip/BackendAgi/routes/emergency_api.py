from flask import Blueprint, request, jsonify
from security.emergency_detector import EmergencyDetector
from security.self_protection import SelfProtection
from security.safe_mode import SafeMode
from security.recovery_engine import RecoveryEngine
from security.threat_patterns import ThreatPatterns

emergency_bp = Blueprint('emergency', __name__)
detector = EmergencyDetector()
protection = SelfProtection()
safe_mode = SafeMode()
recovery = RecoveryEngine()
patterns = ThreatPatterns()

@emergency_bp.route('/api/emergency/detect/ddos', methods=['POST'])
def detect_ddos():
    try:
        data = request.json
        if not data or 'ip' not in data or 'request_count' not in data:
            return jsonify({"error": "ip and request_count required"}), 400
        
        result = detector.detect_ddos(data['ip'], data['request_count'], data.get('time_window', 60))
        
        return jsonify({
            "success": True,
            "result": result
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@emergency_bp.route('/api/emergency/detect/bruteforce', methods=['POST'])
def detect_bruteforce():
    try:
        data = request.json
        if not data or 'ip' not in data or 'failed_login_count' not in data:
            return jsonify({"error": "ip and failed_login_count required"}), 400
        
        result = detector.detect_bruteforce(data['ip'], data['failed_login_count'])
        
        return jsonify({
            "success": True,
            "result": result
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@emergency_bp.route('/api/emergency/detect/memory-spike', methods=['POST'])
def detect_memory_spike():
    try:
        data = request.json
        if not data or 'memory_usage' not in data:
            return jsonify({"error": "memory_usage required"}), 400
        
        result = detector.detect_memory_spike(data['memory_usage'])
        
        return jsonify({
            "success": True,
            "result": result
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@emergency_bp.route('/api/emergency/active', methods=['GET'])
def get_active_emergencies():
    try:
        emergencies = detector.get_active_emergencies()
        
        return jsonify({
            "success": True,
            "emergencies": emergencies,
            "count": len(emergencies)
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@emergency_bp.route('/api/emergency/resolve/<emergency_id>', methods=['POST'])
def resolve_emergency(emergency_id):
    try:
        result = detector.resolve_emergency(emergency_id)
        
        return jsonify({
            "success": True,
            "result": result
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@emergency_bp.route('/api/protection/block-ip', methods=['POST'])
def block_ip():
    try:
        data = request.json
        if not data or 'ip' not in data:
            return jsonify({"error": "ip required"}), 400
        
        result = protection.block_ip(data['ip'], data.get('reason', 'security_threat'))
        
        return jsonify(result)
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@emergency_bp.route('/api/protection/disable-route', methods=['POST'])
def disable_route():
    try:
        data = request.json
        if not data or 'route' not in data:
            return jsonify({"error": "route required"}), 400
        
        result = protection.disable_route(data['route'], data.get('reason', 'security_threat'))
        
        return jsonify(result)
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@emergency_bp.route('/api/protection/defense-level', methods=['POST'])
def set_defense_level():
    try:
        data = request.json
        if not data or 'level' not in data:
            return jsonify({"error": "level required"}), 400
        
        result = protection.enable_defense_layer(data['level'])
        
        return jsonify(result)
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@emergency_bp.route('/api/protection/status', methods=['GET'])
def get_protection_status():
    try:
        status = protection.get_protection_status()
        
        return jsonify({
            "success": True,
            "status": status
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@emergency_bp.route('/api/safe-mode/enter', methods=['POST'])
def enter_safe_mode():
    try:
        data = request.json
        reason = data.get('reason', 'emergency_threat') if data else 'emergency_threat'
        
        result = safe_mode.enter_safe_mode(reason)
        
        return jsonify(result)
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@emergency_bp.route('/api/safe-mode/exit', methods=['POST'])
def exit_safe_mode():
    try:
        result = safe_mode.exit_safe_mode()
        
        return jsonify(result)
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@emergency_bp.route('/api/safe-mode/status', methods=['GET'])
def get_safe_mode_status():
    try:
        status = safe_mode.safe_mode_status()
        
        return jsonify({
            "success": True,
            "status": status
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@emergency_bp.route('/api/recovery/restart-module', methods=['POST'])
def restart_module():
    try:
        data = request.json
        if not data or 'module' not in data:
            return jsonify({"error": "module required"}), 400
        
        result = recovery.restart_module(data['module'])
        
        return jsonify(result)
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@emergency_bp.route('/api/recovery/diagnose', methods=['POST'])
def diagnose_error():
    try:
        data = request.json
        if not data:
            return jsonify({"error": "error_data required"}), 400
        
        diagnosis = recovery.diagnose_error(data)
        
        return jsonify({
            "success": True,
            "diagnosis": diagnosis
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@emergency_bp.route('/api/recovery/auto-fix', methods=['POST'])
def auto_fix():
    try:
        data = request.json
        if not data or 'issue_type' not in data:
            return jsonify({"error": "issue_type required"}), 400
        
        result = recovery.auto_fix_common_issues(data['issue_type'])
        
        return jsonify(result)
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@emergency_bp.route('/api/recovery/history', methods=['GET'])
def get_recovery_history():
    try:
        history = recovery.get_recovery_history()
        
        return jsonify({
            "success": True,
            "history": history,
            "count": len(history)
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@emergency_bp.route('/api/threats/signatures', methods=['GET'])
def get_threat_signatures():
    try:
        signatures = patterns.load_threat_signatures()
        
        return jsonify({
            "success": True,
            "signatures": signatures
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@emergency_bp.route('/api/threats/match', methods=['POST'])
def match_pattern():
    try:
        data = request.json
        if not data:
            return jsonify({"error": "request_data required"}), 400
        
        result = patterns.match_pattern(data)
        
        return jsonify({
            "success": True,
            "result": result
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@emergency_bp.route('/api/threats/update', methods=['POST'])
def update_threat_database():
    try:
        data = request.json
        if not data:
            return jsonify({"error": "pattern_data required"}), 400
        
        result = patterns.update_threat_database(data)
        
        return jsonify(result)
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@emergency_bp.route('/api/threats/incidents', methods=['GET'])
def get_incidents():
    try:
        incidents = patterns.get_incident_history()
        
        return jsonify({
            "success": True,
            "incidents": incidents,
            "count": len(incidents)
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500
