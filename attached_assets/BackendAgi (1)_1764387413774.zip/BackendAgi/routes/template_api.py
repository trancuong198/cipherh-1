from flask import Blueprint, request, jsonify
from utils.template_learner import TemplateLearner
import os

template_api_bp = Blueprint('template_api', __name__)
learner = TemplateLearner()

@template_api_bp.route('/api/template/learn', methods=['POST'])
def learn_templates():
    try:
        patterns = learner.learn_all_templates()
        
        return jsonify({
            "success": True,
            "patterns": patterns,
            "summary": learner.get_style_summary()
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@template_api_bp.route('/api/template/generate', methods=['POST'])
def generate_from_template():
    try:
        data = request.json
        if not data or 'template_type' not in data or 'specification' not in data:
            return jsonify({"error": "template_type and specification required"}), 400
        
        template_type = data['template_type']
        specification = data['specification']
        target_file = data.get('target_file')
        
        code = learner.generate_code_from_template(
            template_type=template_type,
            specification=specification,
            target_file=target_file
        )
        
        return jsonify({
            "success": True,
            "code": code,
            "file": target_file
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@template_api_bp.route('/api/template/validate', methods=['POST'])
def validate_code():
    try:
        data = request.json
        if not data or 'code' not in data or 'template_type' not in data:
            return jsonify({"error": "code and template_type required"}), 400
        
        code = data['code']
        template_type = data['template_type']
        
        validation = learner.validate_generated_code(code, template_type)
        suggestions = learner.suggest_improvements(code, template_type)
        
        return jsonify({
            "success": True,
            "validation": validation,
            "suggestions": suggestions
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@template_api_bp.route('/api/template/analyze', methods=['POST'])
def analyze_template():
    try:
        data = request.json
        if not data or 'file_path' not in data:
            return jsonify({"error": "file_path required"}), 400
        
        file_path = data['file_path']
        
        if not os.path.exists(file_path):
            return jsonify({"error": "File not found"}), 404
        
        analysis = learner.analyze_template_file(file_path)
        style = learner.extract_style_patterns(analysis)
        
        return jsonify({
            "success": True,
            "analysis": analysis,
            "style": style
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@template_api_bp.route('/api/template/summary', methods=['GET'])
def get_summary():
    try:
        summary = learner.get_style_summary()
        
        return jsonify({
            "success": True,
            "summary": summary
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500
