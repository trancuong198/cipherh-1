from flask import Blueprint, request, jsonify
from task_chain.scheduler import TaskScheduler
from task_chain.executor import TaskExecutor
from task_chain.feedback_logger import FeedbackLogger
from task_chain.optimizer import TaskOptimizer

task_chain_bp = Blueprint('task_chain', __name__)
scheduler = TaskScheduler()
executor = TaskExecutor()
feedback_logger = FeedbackLogger()
optimizer = TaskOptimizer()

@task_chain_bp.route('/api/task-chain/create', methods=['POST'])
def create_task():
    try:
        data = request.json
        if not data or 'module' not in data or 'action' not in data:
            return jsonify({"error": "module and action required"}), 400
        
        task = scheduler.create_task(
            module_name=data['module'],
            action=data['action'],
            priority=data.get('priority', 50),
            dependencies=data.get('dependencies', [])
        )
        
        return jsonify({
            "success": True,
            "task": task
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@task_chain_bp.route('/api/task-chain/execute', methods=['POST'])
def execute_task():
    try:
        data = request.json
        if not data or 'task_id' not in data:
            return jsonify({"error": "task_id required"}), 400
        
        result = executor.execute_task(data['task_id'])
        
        if result.get('success'):
            feedback_logger.feedback_to_memory(
                data['task_id'],
                result.get('result', {}).get('action', 'completed')
            )
        
        return jsonify(result)
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@task_chain_bp.route('/api/task-chain/prioritize', methods=['GET'])
def prioritize_tasks():
    try:
        prioritized = scheduler.prioritize_tasks()
        
        return jsonify({
            "success": True,
            "prioritized_tasks": prioritized,
            "count": len(prioritized)
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@task_chain_bp.route('/api/task-chain/optimize', methods=['POST'])
def optimize_workflow():
    try:
        optimization = optimizer.optimize_workflow()
        
        return jsonify({
            "success": True,
            "optimization": optimization
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@task_chain_bp.route('/api/task-chain/update-status', methods=['POST'])
def update_status():
    try:
        data = request.json
        if not data or 'task_id' not in data or 'status' not in data:
            return jsonify({"error": "task_id and status required"}), 400
        
        task = scheduler.update_task_status(
            data['task_id'],
            data['status'],
            data.get('outcome')
        )
        
        return jsonify({
            "success": True,
            "task": task
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@task_chain_bp.route('/api/task-chain/stats', methods=['GET'])
def get_stats():
    try:
        queue_stats = scheduler.get_queue_stats()
        exec_stats = executor.get_execution_stats()
        feedback_stats = feedback_logger.get_feedback_stats()
        
        return jsonify({
            "success": True,
            "stats": {
                "queue": queue_stats,
                "execution": exec_stats,
                "feedback": feedback_stats
            }
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@task_chain_bp.route('/api/task-chain/task/<task_id>', methods=['GET'])
def get_task(task_id):
    try:
        task = scheduler.get_task(task_id)
        
        if not task:
            return jsonify({"error": "Task not found"}), 404
        
        return jsonify({
            "success": True,
            "task": task
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@task_chain_bp.route('/api/task-chain/optimizations', methods=['GET'])
def get_optimizations():
    try:
        optimizations = optimizer.get_optimization_history()
        
        return jsonify({
            "success": True,
            "optimizations": optimizations,
            "count": len(optimizations)
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500
