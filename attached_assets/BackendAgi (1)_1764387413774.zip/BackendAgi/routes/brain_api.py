from flask import Blueprint, request, jsonify
from cipherh_brain.real_time_brain import RealTimeBrain, EventType, EventPriority

brain_bp = Blueprint('brain', __name__)
brain = RealTimeBrain()

@brain_bp.route('/api/brain/start', methods=['POST'])
def start_brain():
    try:
        result = brain.start()
        
        return jsonify({
            "success": True,
            "result": result
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@brain_bp.route('/api/brain/stop', methods=['POST'])
def stop_brain():
    try:
        result = brain.stop()
        
        return jsonify({
            "success": True,
            "result": result
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@brain_bp.route('/api/brain/push-event', methods=['POST'])
def push_event():
    try:
        data = request.json
        if not data or 'event_type' not in data:
            return jsonify({"error": "event_type required"}), 400
        
        event_type_str = data['event_type']
        event_data = data.get('data', {})
        priority_str = data.get('priority', 'MEDIUM')
        
        try:
            event_type = EventType[event_type_str.upper()]
        except KeyError:
            return jsonify({"error": f"Invalid event_type: {event_type_str}"}), 400
        
        try:
            priority = EventPriority[priority_str.upper()]
        except KeyError:
            priority = EventPriority.MEDIUM
        
        event = brain.push_event(event_type, event_data, priority)
        
        return jsonify({
            "success": True,
            "event": event
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@brain_bp.route('/api/brain/state', methods=['GET'])
def get_state():
    try:
        state = brain.get_brain_state()
        
        return jsonify({
            "success": True,
            "state": state
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@brain_bp.route('/api/brain/event-log', methods=['GET'])
def get_event_log():
    try:
        limit = request.args.get('limit', 100, type=int)
        
        log = brain.get_event_log(limit)
        
        return jsonify({
            "success": True,
            "log": log
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@brain_bp.route('/api/brain/queue-status', methods=['GET'])
def get_queue_status():
    try:
        status = brain.get_queue_status()
        
        return jsonify({
            "success": True,
            "queue_status": status
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@brain_bp.route('/api/brain/simulate-event', methods=['POST'])
def simulate_event():
    try:
        data = request.json or {}
        
        event_type = EventType.HTTP_REQUEST
        event_data = {
            "path": "/test",
            "method": "GET",
            "status_code": data.get('status_code', 200)
        }
        priority = EventPriority.LOW
        
        event = brain.push_event(event_type, event_data, priority)
        
        return jsonify({
            "success": True,
            "event": event,
            "message": "Event simulated"
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500
