from flask import Blueprint, request, jsonify
from security.red_team import RedTeam
from security.blue_team import BlueTeam
from security.hacker_mindset import HackerMindset
from defense.threat_scanner import ThreatScanner

hacker_security_bp = Blueprint('hacker_security', __name__)
red_team = RedTeam()
blue_team = BlueTeam()
hacker_mindset = HackerMindset()
threat_scanner = ThreatScanner()

@hacker_security_bp.route('/api/security/scan', methods=['POST'])
def scan_request():
    try:
        data = request.json
        if not data:
            return jsonify({"error": "request data required"}), 400
        
        scan_result = threat_scanner.scan_request(data)
        
        if scan_result.get('threat_score', 0) > 50:
            pattern = hacker_mindset.calculate_threat_pattern({
                "attack_type": scan_result.get('threat_type', 'unknown'),
                "threat_score": scan_result['threat_score'],
                "target": data.get('endpoint', 'unknown')
            })
        
        return jsonify({
            "success": True,
            "scan_result": scan_result
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@hacker_security_bp.route('/api/security/red-team/simulate', methods=['POST'])
def simulate_attack():
    try:
        data = request.json
        if not data or 'target_module' not in data:
            return jsonify({"error": "target_module required"}), 400
        
        simulation = red_team.simulate_attack(data['target_module'])
        
        for vuln in simulation.get('vulnerabilities', []):
            patch = blue_team.apply_patch({
                "type": vuln['type'],
                "module": data['target_module'],
                "severity": vuln['severity']
            })
        
        return jsonify({
            "success": True,
            "simulation": simulation
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@hacker_security_bp.route('/api/security/blue-team/apply-patch', methods=['POST'])
def apply_patch():
    try:
        data = request.json
        if not data or 'vulnerability' not in data:
            return jsonify({"error": "vulnerability data required"}), 400
        
        patch = blue_team.apply_patch(data['vulnerability'])
        
        return jsonify({
            "success": True,
            "patch": patch
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@hacker_security_bp.route('/api/security/firewall/update-rules', methods=['POST'])
def update_firewall():
    try:
        data = request.json
        if not data or 'threat_score' not in data:
            return jsonify({"error": "threat_score required"}), 400
        
        result = blue_team.update_firewall_rules(data['threat_score'])
        
        return jsonify({
            "success": True,
            "result": result
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@hacker_security_bp.route('/api/security/firewall/block-pattern', methods=['POST'])
def block_pattern():
    try:
        data = request.json
        if not data or 'pattern' not in data:
            return jsonify({"error": "pattern required"}), 400
        
        result = blue_team.block_pattern(
            data['pattern'],
            data.get('reason', 'malicious_activity')
        )
        
        return jsonify({
            "success": True,
            "result": result
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@hacker_security_bp.route('/api/security/mindset/calculate-pattern', methods=['POST'])
def calculate_pattern():
    try:
        data = request.json
        if not data:
            return jsonify({"error": "threat data required"}), 400
        
        pattern = hacker_mindset.calculate_threat_pattern(data)
        
        return jsonify({
            "success": True,
            "pattern": pattern
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@hacker_security_bp.route('/api/security/mindset/predict-attack', methods=['GET'])
def predict_attack():
    try:
        prediction = hacker_mindset.predict_next_attack()
        
        return jsonify({
            "success": True,
            "prediction": prediction
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@hacker_security_bp.route('/api/security/mindset/analyze-behavior', methods=['POST'])
def analyze_behavior():
    try:
        data = request.json
        if not data or 'attack_data' not in data:
            return jsonify({"error": "attack_data required"}), 400
        
        analysis = hacker_mindset.analyze_attacker_behavior(data['attack_data'])
        
        return jsonify({
            "success": True,
            "analysis": analysis
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@hacker_security_bp.route('/api/security/red-team/history', methods=['GET'])
def red_team_history():
    try:
        history = red_team.get_attack_history()
        
        return jsonify({
            "success": True,
            "history": history
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@hacker_security_bp.route('/api/security/blue-team/patches', methods=['GET'])
def blue_team_patches():
    try:
        patches = blue_team.get_patch_history()
        
        return jsonify({
            "success": True,
            "patches": patches
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@hacker_security_bp.route('/api/security/blue-team/firewall-status', methods=['GET'])
def firewall_status():
    try:
        status = blue_team.get_firewall_status()
        
        return jsonify({
            "success": True,
            "status": status
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@hacker_security_bp.route('/api/security/mindset/insights', methods=['GET'])
def mindset_insights():
    try:
        insights = hacker_mindset.get_insights()
        
        return jsonify({
            "success": True,
            "insights": insights
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500
