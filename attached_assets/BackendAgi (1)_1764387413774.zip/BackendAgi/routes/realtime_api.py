from flask import Blueprint, request, jsonify
from realtime.event_listener import EventListener
from realtime.event_dispatcher import EventDispatcher
from realtime.reaction_processor import ReactionProcessor
from realtime.feedback_integrator import FeedbackIntegrator

realtime_bp = Blueprint('realtime', __name__)
listener = EventListener()
dispatcher = EventDispatcher()
processor = ReactionProcessor()
integrator = FeedbackIntegrator()

@realtime_bp.route('/api/realtime/event', methods=['POST'])
def create_event():
    try:
        data = request.json
        if not data or 'source' not in data or 'data' not in data:
            return jsonify({"error": "source and data required"}), 400
        
        event = listener.listen_event(data['source'], data['data'])
        
        dispatch = dispatcher.dispatch_event(event['id'], event['priority'])
        
        reaction = processor.process_reaction(event['id'])
        
        integration = integrator.log_feedback(event['id'], 'success')
        
        listener.mark_processed(event['id'])
        
        return jsonify({
            "success": True,
            "event": event,
            "dispatch": dispatch,
            "reaction": reaction,
            "integration": integration
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@realtime_bp.route('/api/realtime/events', methods=['GET'])
def get_events():
    try:
        events = listener.get_active_events()
        
        return jsonify({
            "success": True,
            "events": events,
            "count": len(events)
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@realtime_bp.route('/api/realtime/event/<event_id>', methods=['GET'])
def get_event(event_id):
    try:
        event = listener.get_event(event_id)
        
        if not event:
            return jsonify({"error": "Event not found"}), 404
        
        return jsonify({
            "success": True,
            "event": event
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@realtime_bp.route('/api/realtime/dispatch/<event_id>', methods=['POST'])
def dispatch_event(event_id):
    try:
        data = request.json
        priority = data.get('priority', 50) if data else 50
        
        dispatch = dispatcher.dispatch_event(event_id, priority)
        
        return jsonify({
            "success": True,
            "dispatch": dispatch
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@realtime_bp.route('/api/realtime/reaction/<event_id>', methods=['POST'])
def process_reaction(event_id):
    try:
        reaction = processor.process_reaction(event_id)
        
        return jsonify({
            "success": True,
            "reaction": reaction
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@realtime_bp.route('/api/realtime/adapt', methods=['POST'])
def adapt_response():
    try:
        adaptation = processor.adapt_realtime_response()
        
        return jsonify({
            "success": True,
            "adaptation": adaptation
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@realtime_bp.route('/api/realtime/stats', methods=['GET'])
def get_stats():
    try:
        dispatch_stats = dispatcher.get_dispatch_stats()
        integration_stats = integrator.get_integration_stats()
        
        return jsonify({
            "success": True,
            "stats": {
                "dispatch": dispatch_stats,
                "integration": integration_stats
            }
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500
