import os
import json
from typing import Dict, Any, Optional
from datetime import datetime, timedelta

class DefenseEngine:
    def __init__(self):
        self.defense_dir = 'defense'
        self.blocklist_file = os.path.join(self.defense_dir, 'blocklist.json')
        self.security_mode_file = os.path.join(self.defense_dir, 'security_mode.json')
        
        os.makedirs(self.defense_dir, exist_ok=True)
        
        self._init_security_mode()
    
    def _init_security_mode(self):
        if not os.path.exists(self.security_mode_file):
            with open(self.security_mode_file, 'w') as f:
                json.dump({
                    "current_mode": "normal",
                    "modes_history": [],
                    "timestamp": datetime.now().isoformat()
                }, f, indent=2)
    
    def block_source(self, source: str, reason: str, duration: Optional[int] = None) -> Dict[str, Any]:
        with open(self.blocklist_file, 'r') as f:
            blocklist = json.load(f)
        
        block_data = {
            "reason": reason,
            "blocked_at": datetime.now().isoformat(),
            "permanent": duration is None
        }
        
        if duration:
            block_data["expires_at"] = (datetime.now() + timedelta(seconds=duration)).isoformat()
            blocklist["temporary_blocks"][source] = block_data
        else:
            blocklist["blocked_ips"][source] = reason
        
        with open(self.blocklist_file, 'w') as f:
            json.dump(blocklist, f, indent=2)
        
        try:
            from emotions.emotional_model import EmotionalModel
            emotion = EmotionalModel()
            emotion.update_emotion({"type": "security_alert"})
        except:
            pass
        
        return {
            "source": source,
            "status": "blocked",
            "duration": "permanent" if duration is None else f"{duration}s",
            "reason": reason
        }
    
    def unblock_source(self, source: str) -> Dict[str, Any]:
        with open(self.blocklist_file, 'r') as f:
            blocklist = json.load(f)
        
        removed = False
        
        if source in blocklist.get('blocked_ips', {}):
            del blocklist['blocked_ips'][source]
            removed = True
        
        if source in blocklist.get('temporary_blocks', {}):
            del blocklist['temporary_blocks'][source]
            removed = True
        
        with open(self.blocklist_file, 'w') as f:
            json.dump(blocklist, f, indent=2)
        
        return {
            "source": source,
            "status": "unblocked" if removed else "not_found"
        }
    
    def check_expired_blocks(self) -> Dict[str, Any]:
        with open(self.blocklist_file, 'r') as f:
            blocklist = json.load(f)
        
        expired = []
        temp_blocks = blocklist.get('temporary_blocks', {}).copy()
        
        for source, data in temp_blocks.items():
            if 'expires_at' in data:
                expires = datetime.fromisoformat(data['expires_at'])
                if datetime.now() >= expires:
                    expired.append(source)
        
        for source in expired:
            del blocklist['temporary_blocks'][source]
        
        if expired:
            with open(self.blocklist_file, 'w') as f:
                json.dump(blocklist, f, indent=2)
        
        return {
            "expired_blocks": expired,
            "count": len(expired)
        }
    
    def escalate_defense_mode(self, level: str) -> Dict[str, Any]:
        valid_levels = ["normal", "surveillance", "strict", "sandbox", "lockdown"]
        
        if level not in valid_levels:
            return {"error": f"Invalid level. Must be one of: {valid_levels}"}
        
        with open(self.security_mode_file, 'r') as f:
            mode_data = json.load(f)
        
        old_mode = mode_data.get("current_mode", "normal")
        mode_data["current_mode"] = level
        mode_data["timestamp"] = datetime.now().isoformat()
        
        mode_data["modes_history"].append({
            "from": old_mode,
            "to": level,
            "timestamp": datetime.now().isoformat()
        })
        
        if len(mode_data["modes_history"]) > 100:
            mode_data["modes_history"] = mode_data["modes_history"][-100:]
        
        with open(self.security_mode_file, 'w') as f:
            json.dump(mode_data, f, indent=2)
        
        try:
            from emotions.emotional_model import EmotionalModel
            emotion = EmotionalModel()
            
            if level in ["strict", "sandbox", "lockdown"]:
                emotion.update_emotion({"type": "security_alert"})
            elif level == "normal":
                emotion.update_emotion({"type": "success"})
        except:
            pass
        
        return {
            "old_mode": old_mode,
            "new_mode": level,
            "timestamp": datetime.now().isoformat()
        }
    
    def get_defense_mode(self) -> Dict[str, Any]:
        with open(self.security_mode_file, 'r') as f:
            mode_data = json.load(f)
        
        return {
            "current_mode": mode_data.get("current_mode", "normal"),
            "timestamp": mode_data.get("timestamp")
        }
    
    def defense_memory_log(self, event: Dict[str, Any]) -> Dict[str, Any]:
        memory_dir = 'memory'
        security_history_file = os.path.join(memory_dir, 'security_history.json')
        
        os.makedirs(memory_dir, exist_ok=True)
        
        if not os.path.exists(security_history_file):
            with open(security_history_file, 'w') as f:
                json.dump({"events": []}, f, indent=2)
        
        with open(security_history_file, 'r') as f:
            history = json.load(f)
        
        event['logged_at'] = datetime.now().isoformat()
        history['events'].append(event)
        
        if len(history['events']) > 1000:
            history['events'] = history['events'][-1000:]
        
        with open(security_history_file, 'w') as f:
            json.dump(history, f, indent=2)
        
        try:
            from memory.memory_manager import MemoryManager
            memory = MemoryManager()
            
            importance = 60
            if event.get('severity') == 'critical':
                importance = 90
            elif event.get('severity') == 'high':
                importance = 75
            
            memory.save_memory({
                "type": "security_event",
                "event": event
            }, importance_score=importance)
        except:
            pass
        
        return {
            "status": "logged",
            "event_id": len(history['events']) - 1
        }
    
    def get_security_stats(self) -> Dict[str, Any]:
        memory_dir = 'memory'
        security_history_file = os.path.join(memory_dir, 'security_history.json')
        
        if not os.path.exists(security_history_file):
            return {
                "total_events": 0,
                "critical": 0,
                "high": 0,
                "medium": 0,
                "low": 0
            }
        
        with open(security_history_file, 'r') as f:
            history = json.load(f)
        
        events = history.get('events', [])
        
        stats = {
            "total_events": len(events),
            "critical": len([e for e in events if e.get('severity') == 'critical']),
            "high": len([e for e in events if e.get('severity') == 'high']),
            "medium": len([e for e in events if e.get('severity') == 'medium']),
            "low": len([e for e in events if e.get('severity') == 'low'])
        }
        
        with open(self.blocklist_file, 'r') as f:
            blocklist = json.load(f)
        
        stats["blocked_ips"] = len(blocklist.get('blocked_ips', {}))
        stats["temporary_blocks"] = len(blocklist.get('temporary_blocks', {}))
        
        return stats
