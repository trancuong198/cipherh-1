import os
import json
import shutil
from typing import Dict, Any, List, Optional
from datetime import datetime
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

class SelfHeal:
    def __init__(self):
        api_key = os.getenv('OPENAI_API_KEY')
        if not api_key:
            raise ValueError("OPENAI_API_KEY not found")
        
        self.client = OpenAI(api_key=api_key)
        self.model = os.getenv('OPENAI_MODEL', 'gpt-4o-mini')
        
        self.defense_dir = 'defense'
        self.patches_file = os.path.join(self.defense_dir, 'patches_history.json')
        self.backups_dir = os.path.join(self.defense_dir, 'backups')
        
        os.makedirs(self.defense_dir, exist_ok=True)
        os.makedirs(self.backups_dir, exist_ok=True)
        
        self._init_patches_history()
    
    def _init_patches_history(self):
        if not os.path.exists(self.patches_file):
            with open(self.patches_file, 'w') as f:
                json.dump({
                    "patches": [],
                    "total_patches": 0
                }, f, indent=2)
    
    def auto_patch(self, issue: Dict[str, Any]) -> Dict[str, Any]:
        issue_type = issue.get('type', 'unknown')
        file_path = issue.get('file_path')
        error_msg = issue.get('error', '')
        severity = issue.get('severity', 'medium')
        
        patch_result = {
            "issue_type": issue_type,
            "timestamp": datetime.now().isoformat(),
            "severity": severity,
            "success": False
        }
        
        if file_path and os.path.exists(file_path):
            backup_path = self._backup_file(file_path)
            patch_result["backup_path"] = backup_path
            
            try:
                with open(file_path, 'r') as f:
                    code = f.read()
                
                patched_code = self._generate_patch(code, error_msg, issue_type)
                
                if patched_code and patched_code != code:
                    with open(file_path, 'w') as f:
                        f.write(patched_code)
                    
                    patch_result["success"] = True
                    patch_result["action"] = "patched"
                else:
                    patch_result["action"] = "no_patch_needed"
            
            except Exception as e:
                patch_result["error"] = str(e)
                patch_result["action"] = "patch_failed"
        
        else:
            patch_result["action"] = "disable_feature"
            patch_result["success"] = True
        
        self._log_patch(patch_result)
        
        try:
            from emotions.emotional_model import EmotionalModel
            emotion = EmotionalModel()
            
            if patch_result["success"]:
                emotion.update_emotion({"type": "success"})
            else:
                emotion.update_emotion({"type": "error"})
        except:
            pass
        
        return patch_result
    
    def _backup_file(self, file_path: str) -> str:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = os.path.basename(file_path)
        backup_path = os.path.join(self.backups_dir, f"{filename}.{timestamp}.bak")
        
        shutil.copy2(file_path, backup_path)
        
        return backup_path
    
    def _generate_patch(self, code: str, error: str, issue_type: str) -> Optional[str]:
        prompt = f"""Phân tích lỗi và sửa code sau:

Loại lỗi: {issue_type}
Error: {error}

Code hiện tại:
```
{code[:2000]}
```

Yêu cầu:
1. Sửa lỗi chính xác
2. Giữ nguyên logic
3. Không thêm comment
4. Trả về TOÀN BỘ code đã sửa

Chỉ trả về code, không giải thích."""

        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "Bạn là self-healing system, sửa lỗi code tự động."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.2,
                max_tokens=2000
            )
            
            content = response.choices[0].message.content
            if content:
                content = content.replace('```python', '').replace('```', '').strip()
                return content
        
        except Exception as e:
            return None
        
        return None
    
    def rollback_patch(self, backup_path: str, target_path: str) -> Dict[str, Any]:
        if not os.path.exists(backup_path):
            return {
                "success": False,
                "error": "Backup file not found"
            }
        
        try:
            shutil.copy2(backup_path, target_path)
            
            return {
                "success": True,
                "action": "rolled_back",
                "timestamp": datetime.now().isoformat()
            }
        
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    def disable_dangerous_feature(self, feature_name: str) -> Dict[str, Any]:
        disabled_features_file = os.path.join(self.defense_dir, 'disabled_features.json')
        
        if not os.path.exists(disabled_features_file):
            with open(disabled_features_file, 'w') as f:
                json.dump({"disabled": []}, f, indent=2)
        
        with open(disabled_features_file, 'r') as f:
            data = json.load(f)
        
        if feature_name not in data['disabled']:
            data['disabled'].append({
                "feature": feature_name,
                "disabled_at": datetime.now().isoformat(),
                "reason": "security_risk"
            })
        
        with open(disabled_features_file, 'w') as f:
            json.dump(data, f, indent=2)
        
        return {
            "feature": feature_name,
            "status": "disabled",
            "timestamp": datetime.now().isoformat()
        }
    
    def _log_patch(self, patch_result: Dict[str, Any]):
        with open(self.patches_file, 'r') as f:
            history = json.load(f)
        
        history['patches'].append(patch_result)
        history['total_patches'] += 1
        
        if len(history['patches']) > 100:
            history['patches'] = history['patches'][-100:]
        
        with open(self.patches_file, 'w') as f:
            json.dump(history, f, indent=2)
    
    def learn_threat_patterns(self) -> Dict[str, Any]:
        memory_dir = 'memory'
        security_history_file = os.path.join(memory_dir, 'security_history.json')
        
        if not os.path.exists(security_history_file):
            return {
                "status": "no_data",
                "patterns": []
            }
        
        with open(security_history_file, 'r') as f:
            history = json.load(f)
        
        events = history.get('events', [])
        
        if len(events) < 10:
            return {
                "status": "insufficient_data",
                "patterns": []
            }
        
        threat_counts = {}
        for event in events:
            threats = event.get('threats', [])
            for threat in threats:
                if threat in threat_counts:
                    threat_counts[threat] += 1
                else:
                    threat_counts[threat] = 1
        
        patterns = sorted(
            [{"threat": k, "count": v, "percentage": (v / len(events)) * 100}
             for k, v in threat_counts.items()],
            key=lambda x: x['count'],
            reverse=True
        )
        
        with open(self.patches_file, 'r') as f:
            patch_history = json.load(f)
        
        successful_patches = len([p for p in patch_history['patches'] if p.get('success')])
        total_patches = patch_history.get('total_patches', 0)
        
        return {
            "status": "analyzed",
            "total_events": len(events),
            "common_threats": patterns[:10],
            "patches_applied": total_patches,
            "successful_patches": successful_patches,
            "success_rate": (successful_patches / total_patches * 100) if total_patches > 0 else 0
        }
    
    def get_patch_history(self) -> Dict[str, Any]:
        with open(self.patches_file, 'r') as f:
            history = json.load(f)
        
        return {
            "total_patches": history.get('total_patches', 0),
            "recent_patches": history.get('patches', [])[-10:]
        }
