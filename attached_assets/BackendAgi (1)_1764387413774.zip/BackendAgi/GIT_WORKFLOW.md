# Git Workflow - CipherH Backend

## 🌳 Branch Strategy

```
main (production)
  ↓
  Render auto-deploys
  ↓
  Always stable, tested code

dev (development)
  ↓
  Testing new features
  ↓
  Merge to main when ready
```

---

## 🚀 Quick Commands

### Initial Setup
```bash
cd nodejs-backend

# Initialize git
git init

# Add remote
git remote add origin https://github.com/YOUR_USERNAME/cipherh-backend.git

# First commit
git add .
git commit -m "Initial commit: CipherH Soul Loop Backend"
git push -u origin main

# Create dev branch
git checkout -b dev
git push -u origin dev
```

---

## 💻 Development Workflow

### Adding New Feature

```bash
# 1. Switch to dev branch
git checkout dev

# 2. Create feature branch (optional)
git checkout -b feature/soul-memory-expansion

# 3. Make changes
# Edit code...

# 4. Test locally
npm install
npm start
curl http://localhost:3000/health

# 5. Commit
git add .
git commit -m "feat: Add memory expansion to SoulCore

- Expand evolution history to 200 cycles
- Add memory compression algorithm
- Improve pattern recognition"

# 6. Push to dev
git push origin feature/soul-memory-expansion

# 7. Merge to dev
git checkout dev
git merge feature/soul-memory-expansion
git push origin dev

# 8. Test on dev environment
# Verify everything works

# 9. Merge to main (production)
git checkout main
git merge dev
git push origin main

# 10. Render auto-deploys
# Monitor deployment
```

---

## 🔥 Hotfix Workflow

### Critical Bug Fix

```bash
# 1. Switch to main
git checkout main

# 2. Create hotfix branch
git checkout -b hotfix/inner-loop-crash

# 3. Fix bug
# Edit code...

# 4. Test quickly
npm start
# Verify fix

# 5. Commit
git add .
git commit -m "fix: Prevent Inner Loop crash on empty logs

- Add null check in SoulCore.learnFromLogs()
- Handle edge case with 0 logs
- Add error logging"

# 6. Merge to main
git checkout main
git merge hotfix/inner-loop-crash
git push origin main

# 7. Merge back to dev
git checkout dev
git merge main
git push origin dev

# 8. Render auto-deploys hotfix
# Monitor logs
```

---

## 📝 Commit Message Convention

### Format
```
<type>: <subject>

<body>

<footer>
```

### Types
- `feat`: New feature
- `fix`: Bug fix
- `docs`: Documentation
- `style`: Code style (formatting)
- `refactor`: Code refactoring
- `perf`: Performance improvement
- `test`: Add/update tests
- `chore`: Maintenance

### Examples

**Good:**
```bash
git commit -m "feat: Add self-doubt mechanism to SoulCore

- Implement askSelfQuestions() method
- Generate 3-7 philosophical questions per cycle
- Integrate with Inner Loop step 8"

git commit -m "fix: Correct anomaly detection threshold

Previous threshold was too sensitive, causing false positives.
Adjusted from 0.3 to 0.5 based on production data."

git commit -m "docs: Update API endpoint documentation

- Add examples for all endpoints
- Document query parameters
- Add error response formats"
```

**Bad:**
```bash
git commit -m "update"
git commit -m "fix stuff"
git commit -m "changes"
```

---

## 🔍 Useful Commands

### Check Status
```bash
git status
git log --oneline -10
git branch -a
```

### View Changes
```bash
git diff
git diff --cached
git show
```

### Undo Changes
```bash
# Unstage files
git reset HEAD file.js

# Discard local changes
git checkout -- file.js

# Undo last commit (keep changes)
git reset --soft HEAD~1

# Undo last commit (discard changes)
git reset --hard HEAD~1
```

### Sync with Remote
```bash
# Pull latest
git pull origin main

# Force push (use carefully!)
git push -f origin main
```

---

## 🛡️ Best Practices

### Before Committing
- ✅ Test locally
- ✅ Check `npm start` works
- ✅ Review changes with `git diff`
- ✅ Write clear commit message

### Before Pushing to Main
- ✅ All tests passing
- ✅ No console errors
- ✅ API endpoints working
- ✅ Ready for production

### After Pushing
- ✅ Monitor Render deployment
- ✅ Check logs for errors
- ✅ Verify health endpoint
- ✅ Test API endpoints

---

## 🔄 Merge Conflicts

### Resolving Conflicts
```bash
# When merge has conflicts
git merge dev

# Fix conflicts in files
# Look for <<<<<<< markers

# After fixing
git add .
git commit -m "Merge dev into main"
git push origin main
```

---

## 📊 Release Process

### Creating a Release

```bash
# 1. Ensure main is stable
git checkout main
git pull origin main

# 2. Tag version
git tag -a v1.0.0 -m "Release v1.0.0

Features:
- SoulCore with 8 methods
- Inner Loop 10 steps
- REST API 6 endpoints
- Cron scheduler
- Full documentation"

# 3. Push tag
git push origin v1.0.0

# 4. Create release notes on GitHub
```

---

## 🎯 Quick Reference

```bash
# Start new feature
git checkout dev
git checkout -b feature/name
# ... code ...
git add .
git commit -m "feat: description"
git push origin feature/name

# Deploy to production
git checkout main
git merge dev
git push origin main
# → Render auto-deploys

# Hotfix
git checkout main
git checkout -b hotfix/name
# ... fix ...
git add .
git commit -m "fix: description"
git checkout main
git merge hotfix/name
git push origin main
# → Render auto-deploys
```

---

**Clean commits = Clean deployments! 🚀**
