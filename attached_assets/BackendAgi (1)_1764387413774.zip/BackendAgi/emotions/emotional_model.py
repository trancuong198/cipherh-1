import os
import json
from typing import Dict, Any, List, Optional
from datetime import datetime
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

class EmotionalModel:
    def __init__(self):
        api_key = os.getenv('OPENAI_API_KEY')
        if not api_key:
            raise ValueError("OPENAI_API_KEY not found")
        
        self.client = OpenAI(api_key=api_key)
        self.model = os.getenv('OPENAI_MODEL', 'gpt-4o-mini')
        
        self.emotions_dir = 'emotions'
        self.state_file = os.path.join(self.emotions_dir, 'state.json')
        self.triggers_file = os.path.join(self.emotions_dir, 'triggers.json')
        self.action_influence_file = os.path.join(self.emotions_dir, 'action_influence.json')
        
        os.makedirs(self.emotions_dir, exist_ok=True)
        
        self._init_emotional_files()
    
    def _init_emotional_files(self):
        if not os.path.exists(self.state_file):
            initial_state = {
                "timestamp": datetime.now().isoformat(),
                "focus_level": 70,
                "stress_level": 30,
                "alertness": 60,
                "confidence": 65,
                "curiosity": 75,
                "overall_mood": "balanced",
                "history": []
            }
            with open(self.state_file, 'w') as f:
                json.dump(initial_state, f, indent=2)
        
        if not os.path.exists(self.triggers_file):
            triggers = {
                "error": {
                    "stress_level": +15,
                    "confidence": -10,
                    "focus_level": +5
                },
                "success": {
                    "confidence": +10,
                    "stress_level": -5,
                    "curiosity": +3
                },
                "security_alert": {
                    "alertness": +20,
                    "stress_level": +10,
                    "focus_level": +15
                },
                "user_feedback_positive": {
                    "confidence": +15,
                    "curiosity": +5,
                    "stress_level": -10
                },
                "user_feedback_negative": {
                    "confidence": -15,
                    "curiosity": +10,
                    "stress_level": +5
                },
                "overload": {
                    "stress_level": +25,
                    "focus_level": -20,
                    "alertness": +10
                },
                "idle": {
                    "stress_level": -10,
                    "focus_level": -5,
                    "curiosity": +5
                },
                "learning": {
                    "curiosity": +10,
                    "focus_level": +10,
                    "confidence": +5
                }
            }
            with open(self.triggers_file, 'w') as f:
                json.dump(triggers, f, indent=2)
        
        if not os.path.exists(self.action_influence_file):
            influence = {
                "high_stress": {
                    "priority_boost": 20,
                    "mutation_intensity": "aggressive",
                    "log_verbosity": "high",
                    "alert_threshold": "low"
                },
                "high_confidence": {
                    "priority_boost": -5,
                    "mutation_intensity": "moderate",
                    "log_verbosity": "normal",
                    "alert_threshold": "normal"
                },
                "high_alertness": {
                    "priority_boost": 15,
                    "mutation_intensity": "conservative",
                    "log_verbosity": "high",
                    "alert_threshold": "low"
                },
                "low_focus": {
                    "priority_boost": 0,
                    "mutation_intensity": "minimal",
                    "log_verbosity": "low",
                    "alert_threshold": "high"
                },
                "high_curiosity": {
                    "priority_boost": 5,
                    "mutation_intensity": "experimental",
                    "log_verbosity": "normal",
                    "alert_threshold": "normal"
                }
            }
            with open(self.action_influence_file, 'w') as f:
                json.dump(influence, f, indent=2)
    
    def update_emotion(self, event: Dict[str, Any]) -> Dict[str, Any]:
        event_type = event.get('type', 'unknown')
        
        with open(self.triggers_file, 'r') as f:
            triggers = json.load(f)
        
        with open(self.state_file, 'r') as f:
            state = json.load(f)
        
        if event_type in triggers:
            trigger = triggers[event_type]
            
            for emotion, change in trigger.items():
                if emotion in state:
                    state[emotion] = max(0, min(100, state[emotion] + change))
        
        state["timestamp"] = datetime.now().isoformat()
        
        overall_mood = self._calculate_overall_mood(state)
        state["overall_mood"] = overall_mood
        
        state["history"].append({
            "timestamp": datetime.now().isoformat(),
            "event_type": event_type,
            "focus_level": state["focus_level"],
            "stress_level": state["stress_level"],
            "alertness": state["alertness"],
            "confidence": state["confidence"],
            "curiosity": state["curiosity"],
            "overall_mood": overall_mood
        })
        
        if len(state["history"]) > 100:
            state["history"] = state["history"][-100:]
        
        with open(self.state_file, 'w') as f:
            json.dump(state, f, indent=2)
        
        return {
            "event_type": event_type,
            "new_state": {
                "focus_level": state["focus_level"],
                "stress_level": state["stress_level"],
                "alertness": state["alertness"],
                "confidence": state["confidence"],
                "curiosity": state["curiosity"],
                "overall_mood": overall_mood
            }
        }
    
    def _calculate_overall_mood(self, state: Dict[str, Any]) -> str:
        focus = state.get("focus_level", 50)
        stress = state.get("stress_level", 50)
        alertness = state.get("alertness", 50)
        confidence = state.get("confidence", 50)
        curiosity = state.get("curiosity", 50)
        
        if stress > 80:
            return "overwhelmed"
        elif stress > 60 and alertness > 70:
            return "vigilant"
        elif confidence > 75 and focus > 70:
            return "confident"
        elif curiosity > 75 and focus > 60:
            return "curious"
        elif stress < 30 and confidence > 60:
            return "calm"
        elif focus < 40 and stress < 40:
            return "relaxed"
        else:
            return "balanced"
    
    def evaluate_emotional_state(self) -> Dict[str, Any]:
        with open(self.state_file, 'r') as f:
            state = json.load(f)
        
        evaluation = {
            "timestamp": datetime.now().isoformat(),
            "current_state": {
                "focus_level": state["focus_level"],
                "stress_level": state["stress_level"],
                "alertness": state["alertness"],
                "confidence": state["confidence"],
                "curiosity": state["curiosity"],
                "overall_mood": state["overall_mood"]
            },
            "analysis": {
                "needs_attention": [],
                "strengths": [],
                "recommendations": []
            }
        }
        
        if state["stress_level"] > 70:
            evaluation["analysis"]["needs_attention"].append("High stress - consider relaxation cycle")
            evaluation["analysis"]["recommendations"].append("Trigger memory decay or cleanup")
        
        if state["focus_level"] < 40:
            evaluation["analysis"]["needs_attention"].append("Low focus - may affect performance")
            evaluation["analysis"]["recommendations"].append("Reduce task load")
        
        if state["confidence"] < 40:
            evaluation["analysis"]["needs_attention"].append("Low confidence - review recent actions")
            evaluation["analysis"]["recommendations"].append("Run reflection cycle")
        
        if state["confidence"] > 75:
            evaluation["analysis"]["strengths"].append("High confidence - good performance")
        
        if state["curiosity"] > 75:
            evaluation["analysis"]["strengths"].append("High curiosity - active learning mode")
        
        if state["alertness"] > 75:
            evaluation["analysis"]["strengths"].append("High alertness - security-aware")
        
        return evaluation
    
    def influence_action(self, action: Dict[str, Any]) -> Dict[str, Any]:
        with open(self.state_file, 'r') as f:
            state = json.load(f)
        
        with open(self.action_influence_file, 'r') as f:
            influences = json.load(f)
        
        modified_action = action.copy()
        applied_influences = []
        
        if state["stress_level"] > 70:
            influence = influences["high_stress"]
            applied_influences.append("high_stress")
            modified_action["priority"] = modified_action.get("priority", 50) + influence["priority_boost"]
            modified_action["mutation_intensity"] = influence["mutation_intensity"]
            modified_action["log_verbosity"] = influence["log_verbosity"]
        
        if state["confidence"] > 75:
            influence = influences["high_confidence"]
            applied_influences.append("high_confidence")
            modified_action["priority"] = modified_action.get("priority", 50) + influence["priority_boost"]
        
        if state["alertness"] > 75:
            influence = influences["high_alertness"]
            applied_influences.append("high_alertness")
            modified_action["priority"] = modified_action.get("priority", 50) + influence["priority_boost"]
            modified_action["alert_threshold"] = influence["alert_threshold"]
        
        if state["focus_level"] < 40:
            influence = influences["low_focus"]
            applied_influences.append("low_focus")
            modified_action["mutation_intensity"] = influence["mutation_intensity"]
        
        if state["curiosity"] > 75:
            influence = influences["high_curiosity"]
            applied_influences.append("high_curiosity")
            modified_action["mutation_intensity"] = influence["mutation_intensity"]
        
        return {
            "original_action": action,
            "modified_action": modified_action,
            "applied_influences": applied_influences,
            "emotional_state": state["overall_mood"]
        }
    
    def reflect_emotion_on_memory(self) -> Dict[str, Any]:
        with open(self.state_file, 'r') as f:
            state = json.load(f)
        
        memory_data = {
            "timestamp": datetime.now().isoformat(),
            "emotional_snapshot": {
                "focus_level": state["focus_level"],
                "stress_level": state["stress_level"],
                "alertness": state["alertness"],
                "confidence": state["confidence"],
                "curiosity": state["curiosity"],
                "overall_mood": state["overall_mood"]
            },
            "importance_score": self._calculate_memory_importance(state),
            "data": {
                "type": "emotional_state",
                "mood": state["overall_mood"],
                "needs_attention": state["stress_level"] > 70 or state["focus_level"] < 40
            }
        }
        
        return memory_data
    
    def _calculate_memory_importance(self, state: Dict[str, Any]) -> int:
        score = 50
        
        if state["stress_level"] > 70:
            score += 20
        
        if state["confidence"] < 40:
            score += 15
        
        if state["alertness"] > 75:
            score += 10
        
        if state["curiosity"] > 75:
            score += 5
        
        return min(100, score)
    
    def adaptive_emotion_learning(self) -> Dict[str, Any]:
        with open(self.state_file, 'r') as f:
            state = json.load(f)
        
        history = state.get("history", [])
        
        if len(history) < 10:
            return {
                "status": "insufficient_data",
                "message": "Need more emotional history for learning"
            }
        
        recent_history = history[-20:]
        
        patterns = {
            "stress_peaks": 0,
            "confidence_drops": 0,
            "high_alertness_periods": 0,
            "balanced_periods": 0
        }
        
        for i, entry in enumerate(recent_history):
            if entry.get("stress_level", 0) > 70:
                patterns["stress_peaks"] += 1
            
            if entry.get("confidence", 0) < 40:
                patterns["confidence_drops"] += 1
            
            if entry.get("alertness", 0) > 75:
                patterns["high_alertness_periods"] += 1
            
            if entry.get("overall_mood") == "balanced":
                patterns["balanced_periods"] += 1
        
        learning = {
            "timestamp": datetime.now().isoformat(),
            "patterns_detected": patterns,
            "recommendations": []
        }
        
        if patterns["stress_peaks"] > 5:
            learning["recommendations"].append("Frequent stress peaks detected - adjust trigger sensitivity")
        
        if patterns["confidence_drops"] > 3:
            learning["recommendations"].append("Multiple confidence drops - review success criteria")
        
        if patterns["balanced_periods"] > 10:
            learning["recommendations"].append("System maintaining balance well")
        
        return learning
    
    def get_current_state(self) -> Dict[str, Any]:
        with open(self.state_file, 'r') as f:
            state = json.load(f)
        
        return {
            "focus_level": state["focus_level"],
            "stress_level": state["stress_level"],
            "alertness": state["alertness"],
            "confidence": state["confidence"],
            "curiosity": state["curiosity"],
            "overall_mood": state["overall_mood"],
            "timestamp": state["timestamp"]
        }
    
    def reset_emotions(self) -> Dict[str, Any]:
        with open(self.state_file, 'r') as f:
            state = json.load(f)
        
        state["focus_level"] = 70
        state["stress_level"] = 30
        state["alertness"] = 60
        state["confidence"] = 65
        state["curiosity"] = 75
        state["overall_mood"] = "balanced"
        state["timestamp"] = datetime.now().isoformat()
        
        with open(self.state_file, 'w') as f:
            json.dump(state, f, indent=2)
        
        return {
            "status": "reset",
            "new_state": self.get_current_state()
        }
