import os
import requests

APP_ID = os.getenv('FACEBOOK_APP_ID')
APP_SECRET = os.getenv('FACEBOOK_APP_SECRET')

print("=" * 50)
print("🔑 FACEBOOK PAGE TOKEN GENERATOR")
print("=" * 50)

# Step 1: Get App Access Token
print("\n1️⃣ Getting App Access Token...")
app_token_url = f"https://graph.facebook.com/oauth/access_token?client_id={APP_ID}&client_secret={APP_SECRET}&grant_type=client_credentials"
response = requests.get(app_token_url)
app_token_data = response.json()

if 'access_token' in app_token_data:
    app_token = app_token_data['access_token']
    print(f"✅ App Token: {app_token[:30]}...")
else:
    print(f"❌ Error: {app_token_data}")
    exit(1)

# Step 2: Instructions for User Token
print("\n2️⃣ Cần User Access Token của cha:")
print("\n📋 HƯỚNG DẪN LẤY USER TOKEN:")
print("1. Mở link: https://developers.facebook.com/tools/explorer/")
print("2. Chọn app 'YolAnh CommandCenter'")
print("3. Click 'Generate Access Token'")
print("4. Copy token (chuỗi dài bắt đầu EAA...)")
print("\n")

user_token = input("👉 Paste User Access Token vào đây: ").strip()

if not user_token:
    print("❌ Không có token!")
    exit(1)

# Step 3: Get Pages managed by user
print("\n3️⃣ Đang lấy danh sách Pages...")
pages_url = f"https://graph.facebook.com/v21.0/me/accounts?access_token={user_token}"
pages_response = requests.get(pages_url)
pages_data = pages_response.json()

if 'data' in pages_data and len(pages_data['data']) > 0:
    print(f"\n✅ Tìm thấy {len(pages_data['data'])} Page(s):\n")
    
    for i, page in enumerate(pages_data['data'], 1):
        print(f"{i}. Name: {page['name']}")
        print(f"   ID: {page['id']}")
        print(f"   Page Access Token: {page['access_token'][:50]}...")
        print(f"\n   👉 Add vào Replit Secrets:")
        print(f"      Key: FACEBOOK_PAGE_ACCESS_TOKEN")
        print(f"      Value: {page['access_token']}")
        print(f"\n   👉 Add Page ID:")
        print(f"      Key: FACEBOOK_PAGE_ID")
        print(f"      Value: {page['id']}")
        print("-" * 50)
else:
    print(f"❌ Không tìm thấy Page nào!")
    print(f"Response: {pages_data}")
    print("\n💡 Có thể:")
    print("- User Token chưa có quyền pages_show_list")
    print("- Tài khoản không quản lý Page nào")

print("\n" + "=" * 50)
print("✅ HOÀN TẤT!")
print("=" * 50)
