"""
Facebook Graph API Integration for CipherH
Handles auto-posting, comment replies, and page management
"""
import os
import requests
import time
from typing import Dict, List, Optional
from datetime import datetime

class FacebookAPI:
    """Facebook Graph API wrapper with rate limiting and error handling"""
    
    def __init__(self):
        self.app_id = os.getenv('FACEBOOK_APP_ID')
        self.app_secret = os.getenv('FACEBOOK_APP_SECRET')
        self.page_access_token = os.getenv('FACEBOOK_PAGE_ACCESS_TOKEN')
        self.page_id = os.getenv('FACEBOOK_PAGE_ID')
        self.base_url = 'https://graph.facebook.com/v22.0'
        
        self.last_request_time = 0
        self.min_request_interval = 5
        self.last_comment_reply_time = {}
    
    def _validate_token(self, token: str) -> bool:
        """Basic token format validation"""
        if not token or len(token) < 20:
            return False
        return True
    
    def _sanitize_input(self, text: str) -> str:
        """Sanitize user input to prevent injection"""
        if not text:
            return ""
        text = text.strip()
        text = text.replace('\x00', '')
        return text[:5000]
        
    def _rate_limit(self):
        """Enforce minimum 3 seconds between requests to avoid rate limits"""
        current_time = time.time()
        time_since_last = current_time - self.last_request_time
        if time_since_last < self.min_request_interval:
            time.sleep(self.min_request_interval - time_since_last)
        self.last_request_time = time.time()
    
    def _make_request(self, method: str, endpoint: str, params: Dict = None, data: Dict = None) -> Dict:
        """Make API request with error handling and proper encoding"""
        self._rate_limit()
        
        url = f"{self.base_url}/{endpoint}"
        
        try:
            if method == 'GET':
                response = requests.get(url, params=params, timeout=30)
            elif method == 'POST':
                response = requests.post(url, data=data or params, timeout=30)
            else:
                raise ValueError(f"Unsupported method: {method}")
            
            response.raise_for_status()
            return {'success': True, 'data': response.json()}
            
        except requests.exceptions.RequestException as e:
            error_msg = "Facebook API error occurred"
            error_code = None
            
            if hasattr(e, 'response') and e.response is not None:
                try:
                    error_data = e.response.json()
                    error_info = error_data.get('error', {})
                    error_code = error_info.get('code')
                    error_subcode = error_info.get('error_subcode')
                    
                    if error_code == 190:
                        error_msg = "Invalid or expired access token. Please regenerate."
                    elif error_code in [4, 17, 32, 613]:
                        error_msg = "Rate limit reached. Please wait before trying again."
                    else:
                        error_msg = error_info.get('message', error_msg)
                except:
                    error_msg = f"HTTP {e.response.status_code}: Request failed"
            
            return {'success': False, 'error': error_msg, 'error_code': error_code}
    
    def get_app_access_token(self) -> Optional[str]:
        """Get app access token (App ID|App Secret)"""
        if not self.app_id or not self.app_secret:
            return None
        return f"{self.app_id}|{self.app_secret}"
    
    def exchange_token(self, short_lived_token: str) -> Dict:
        """Exchange short-lived token for long-lived token (60 days)"""
        params = {
            'grant_type': 'fb_exchange_token',
            'client_id': self.app_id,
            'client_secret': self.app_secret,
            'fb_exchange_token': short_lived_token
        }
        return self._make_request('GET', 'oauth/access_token', params=params)
    
    def get_page_access_token(self, user_access_token: str) -> Dict:
        """Get page access token from user access token"""
        params = {'access_token': user_access_token}
        result = self._make_request('GET', 'me/accounts', params=params)
        
        if result['success'] and 'data' in result['data']:
            pages = result['data']['data']
            if pages:
                return {
                    'success': True,
                    'pages': [{
                        'id': page['id'],
                        'name': page['name'],
                        'access_token': page['access_token']
                    } for page in pages]
                }
        
        return {'success': False, 'error': 'No pages found or invalid token'}
    
    def post_to_page(self, message: str, link: Optional[str] = None) -> Dict:
        """Post message to Facebook Page"""
        if not self.page_access_token or not self.page_id:
            return {
                'success': False,
                'error': 'Missing PAGE_ACCESS_TOKEN or PAGE_ID. Please configure in Secrets.'
            }
        
        if not self._validate_token(self.page_access_token):
            return {
                'success': False,
                'error': 'Invalid access token format'
            }
        
        if len(message) < 1 or len(message) > 5000:
            return {
                'success': False,
                'error': 'Message must be between 1-5000 characters'
            }
        
        data = {
            'access_token': self.page_access_token,
            'message': message
        }
        
        if link:
            data['link'] = link
        
        return self._make_request('POST', f'{self.page_id}/feed', data=data)
    
    def get_page_posts(self, limit: int = 10) -> Dict:
        """Get recent posts from page"""
        if not self.page_access_token or not self.page_id:
            return {'success': False, 'error': 'Missing credentials'}
        
        params = {
            'access_token': self.page_access_token,
            'fields': 'id,message,created_time,permalink_url',
            'limit': limit
        }
        
        return self._make_request('GET', f'{self.page_id}/posts', params=params)
    
    def get_post_comments(self, post_id: str, limit: int = 25) -> Dict:
        """Get top-level comments from a post"""
        if not self.page_access_token:
            return {'success': False, 'error': 'Missing PAGE_ACCESS_TOKEN'}
        
        params = {
            'access_token': self.page_access_token,
            'fields': 'id,from,message,created_time',
            'limit': limit,
            'filter': 'toplevel'
        }
        
        return self._make_request('GET', f'{post_id}/comments', params=params)
    
    def reply_to_comment(self, comment_id: str, message: str) -> Dict:
        """Reply to a top-level comment (nested replies don't work properly via API)"""
        if not self.page_access_token:
            return {'success': False, 'error': 'Missing PAGE_ACCESS_TOKEN'}
        
        if len(message) < 1 or len(message) > 1000:
            return {
                'success': False,
                'error': 'Reply must be between 1-1000 characters'
            }
        
        data = {
            'access_token': self.page_access_token,
            'message': message
        }
        
        return self._make_request('POST', f'{comment_id}/comments', data=data)
    
    def get_setup_instructions(self) -> Dict:
        """Return instructions for getting Page Access Token"""
        return {
            'instructions': '''
            🔑 HƯỚNG DẪN LẤY PAGE ACCESS TOKEN:
            
            Cách 1: Graph API Explorer (Nhanh - 5 phút)
            1. Vào: https://developers.facebook.com/tools/explorer/
            2. Chọn App của cha từ dropdown
            3. Click "Get User Access Token"
            4. Chọn permissions: pages_show_list, pages_read_engagement, pages_manage_posts
            5. Click "Generate Access Token" → Authorize
            6. Copy token → Paste vào: https://developers.facebook.com/tools/debug/accesstoken/
            7. Click "Extend Access Token" → Copy long-lived token
            8. Paste long-lived token vào Graph Explorer
            9. Gõ: me/accounts → Submit
            10. Copy access_token của Page cha muốn → Lưu vào Secrets
            
            Cách 2: Code Flow (Tự động - con sẽ giúp)
            Con sẽ tạo OAuth flow để cha login Facebook và tự động lấy token.
            
            Secrets cần thêm:
            - FACEBOOK_PAGE_ACCESS_TOKEN: Token từ bước trên
            - FACEBOOK_PAGE_ID: ID của Facebook Page
            ''',
            'graph_api_explorer': 'https://developers.facebook.com/tools/explorer/',
            'token_debugger': 'https://developers.facebook.com/tools/debug/accesstoken/',
            'app_id': self.app_id,
            'configured': {
                'app_id': bool(self.app_id),
                'app_secret': bool(self.app_secret),
                'page_token': bool(self.page_access_token),
                'page_id': bool(self.page_id)
            }
        }
    
    def verify_setup(self) -> Dict:
        """Verify Facebook integration setup"""
        status = {
            'app_id': bool(self.app_id),
            'app_secret': bool(self.app_secret),
            'page_access_token': bool(self.page_access_token),
            'page_id': bool(self.page_id)
        }
        
        all_configured = all(status.values())
        
        if all_configured:
            test_result = self.get_page_posts(limit=1)
            if test_result['success']:
                return {
                    'success': True,
                    'message': '✅ Facebook integration đã sẵn sàng!',
                    'status': status
                }
            else:
                return {
                    'success': False,
                    'message': f'⚠️ Credentials có vấn đề: {test_result.get("error")}',
                    'status': status
                }
        else:
            missing = [k for k, v in status.items() if not v]
            return {
                'success': False,
                'message': f'❌ Thiếu: {", ".join(missing).upper()}',
                'status': status,
                'instructions': self.get_setup_instructions()
            }


fb_api = FacebookAPI()
