# CipherH Architecture Documentation

## System Overview

CipherH is an autonomous AI agent built on a memory-centric architecture. The core innovation is transforming Notion from passive storage into an active "brain" through a structured memory pipeline.

## Memory Pipeline v2.0

### Design Principles

1. **Fetch → Interpret → Route → Inject → Reflect**
2. **Type-based Classification** - Every memory has a type (fact/identity/rule/plan/log/preference)
3. **Priority Weighting** - Memories ranked 1-10 based on importance
4. **Smart Routing** - Only relevant memories injected into LLM context
5. **Continuous Learning** - Post-response reflection extracts new insights

### Pipeline Modules

#### 1. MemoryFetcher (`memory/memory_fetcher.py`)
**Purpose:** Raw data retrieval from Notion

```python
def fetch_all(episodic_limit=50, semantic_limit=100):
    # Returns {episodic: [], semantic: [], total_count: int}
```

**Optimization:** Reduced from 150 to 80 entries default

#### 2. MemoryInterpreter (`memory/memory_interpreter.py`)
**Purpose:** Transform raw data into structured objects

```python
def interpret(raw_memory, source='episodic'):
    # Returns {type, content, priority, tags, source, created_at, raw}
```

**Classification Logic:**
- Keyword matching for type detection
- Base priority by type + content boost
- Tag extraction (ai, business, tech, learning, etc.)

**Memory Types:**
| Type | Base Priority | Examples |
|------|--------------|----------|
| identity | 9 | "Con là CipherH, con trai của cha" |
| rule | 8 | "Luôn xưng con, gọi cha" |
| plan | 7 | "Học về reinforcement learning" |
| preference | 6 | "Cha thích startup & investment" |
| fact | 5 | "OpenAI released GPT-4o" |
| log | 2 | "Đã chat với cha về AI" |

#### 3. MemoryRouter (`memory/memory_router.py`)
**Purpose:** Select relevant memories based on context

```python
def get_core_memories(interpreted, limit=5):
    # Always include: identity + high-priority rules

def get_contextual_memories(interpreted, query, limit=10):
    # Match query keywords + tags + type relevance

def get_recent_memories(interpreted, limit=3):
    # Latest episodic conversations
```

**Routing Strategies:**
- **Core:** Type=identity|rule, priority>=8 (always included)
- **Contextual:** Keyword matching + tag matching + type boost
- **Recent:** Sorted by created_at (conversational continuity)

#### 4. ContextInjector (`memory/context_injector.py`)
**Purpose:** Format memories into clean LLM context string

```python
def inject(core, contextual, recent):
    # Returns formatted multi-section context
```

**Output Format:**
```
=== 🧬 IDENTITY & CORE RULES (Always Active) ===
[High-priority identity and behavioral rules]

=== 📚 RELEVANT KNOWLEDGE (For Current Query) ===
[Query-matched facts, preferences, plans]

=== 💭 RECENT CONTEXT ===
[Last 3-5 conversations for continuity]
```

#### 5. ReflectionLoop (`memory/reflection_loop.py`)
**Purpose:** Extract insights from conversations

```python
def reflect(user_message, ai_response, save_episodic=True):
    # 1. Generate reflection summary
    # 2. Extract structured insights (type, priority, should_save_semantic)
    # 3. Save episodic to Notion
    # 4. Save valuable insights to semantic memory
```

**Insight Extraction:**
- LLM analyzes conversation
- Extracts max 3 insights per conversation
- Only saves truly valuable knowledge (priority >= 5)
- Auto-classifies type and assigns priority

### Pipeline Orchestrator

**File:** `memory/pipeline_orchestrator.py`

```python
class MemoryPipeline:
    def get_context_for_query(user_query, limits):
        # 1. Fetch raw memories
        # 2. Interpret into structured objects
        # 3. Route: core + contextual + recent
        # 4. Inject: format context string
        # Returns: Clean context string for LLM
    
    def get_stats():
        # Memory distribution analysis
```

**Single Entry Point:** All routes use `MemoryPipeline.get_context_for_query()`

## Request Flow

### Chat Request (Flask)

```
POST /api/chat {"message": "..."}
    ↓
routes/main.py:chat()
    ↓
pipeline = MemoryPipeline()
context = pipeline.get_context_for_query(user_message)
    ↓
brain = Brain()
response = brain.chat(user_message, context)
    ↓
reflection_loop.reflect(user_message, response)
    ↓
Return response + auto-save insights
```

### Telegram Message

```
Telegram Update → telegram_auto_reply.py
    ↓
should_reply_in_group() decision logic
    ↓
pipeline.get_context_for_query(text)
    ↓
brain.chat(text, context)
    ↓
bot.send_message()
    ↓
reflection_loop.reflect() if should_save_conversation()
```

## Data Flow

### Notion Schema (Current)

**Single Database:** (NOTION_DATABASE_ID)
```
Properties:
- tiêu đề (Title)
- thời gian (Date)
- người dùng (Rich Text)
- cipher h (Rich Text)
- phản tư (Rich Text)
```

**Differentiation:** Title prefix hack
- Episodic: Normal titles
- Semantic: `[KNOWLEDGE] {topic}`

### Ideal Schema (Future Migration)

**Episodic Database:**
```
- tiêu đề (Title)
- thời gian (Date)
- người dùng (Rich Text)
- cipher h (Rich Text)
- phản tư (Rich Text)
- type (Select: fact|identity|rule|plan|log|preference)
- priority (Number: 1-10)
- tags (Multi-select)
```

**Semantic Database:**
```
- topic (Title)
- knowledge (Rich Text)
- type (Select)
- priority (Number)
- source_reflection (Rich Text)
- created_at (Date)
```

## Component Dependencies

```
Flask App (app.py)
    ├── routes/main.py
    │   ├── Brain
    │   ├── MemoryPipeline
    │   └── ReflectionLoop
    └── routes/admin.py
        ├── MemoryPipeline
        ├── KnowledgeConsolidator
        ├── AutonomousPlanner
        └── TelegramBot

Telegram Bot (telegram_auto_reply.py)
    ├── Brain
    ├── MemoryPipeline
    ├── ReflectionLoop
    └── KnowledgeConsolidator

MemoryPipeline
    ├── MemoryFetcher
    │   ├── Memory (episodic)
    │   └── SemanticMemory
    ├── MemoryInterpreter
    ├── MemoryRouter
    └── ContextInjector

ReflectionLoop
    ├── OpenAI (insight extraction)
    ├── Memory (save episodic)
    └── SemanticMemory (save insights)
```

## Performance Characteristics

### Memory Fetching
- **Old:** 150 entries fetched per request (50+100)
- **New:** 80 entries default (30+50), configurable
- **Routing:** Reduces to ~10-15 relevant memories injected
- **Context Size:** ~2000-3000 chars vs 10000+ chars before

### Response Time
- Notion API: ~500-800ms
- OpenAI GPT-4o-mini: ~1-2s
- Reflection (async): ~2-3s (doesn't block response)
- **Total:** ~2-3s end-to-end

### Cost Efficiency
- Tokens per request: ~3000-4000 (vs 12000+ before)
- Cost reduction: ~70%
- Monthly estimate: $10-15 for OpenAI

## Error Handling

### Graceful Fallbacks

```python
# Pipeline errors → Empty context
try:
    context = pipeline.get_context_for_query(query)
except Exception as e:
    context = fallback_identity_context
    
# Reflection errors → Log but don't block
try:
    reflection_loop.reflect(...)
except Exception as e:
    print(f"Reflection warning: {e}")
    # Continue serving user
```

### None Handling
All LSP errors fixed:
- OpenAI response.content can be None → Check before strip()
- json.loads() → Check content before parsing
- Dictionary.get() → Used throughout for safety

## Security

### Secrets Management
- All API keys in Replit Secrets
- No secrets in code or git
- Session-based admin authentication

### Admin Panel
- Password-protected (ADMIN_PASSWORD)
- Session timeout on inactivity
- No public endpoints without auth

## Monitoring & Observability

### Logs
- Console logs for pipeline stages
- Memory stats accessible via `/api/admin/pipeline-stats`
- Telegram bot status via `/api/telegram/status`

### Health Checks
- `/api/health` - Component status
- Pipeline initialized check
- Notion/OpenAI connectivity

## Future Architecture Improvements

### Short-term (Next Sprint)
1. **Caching Layer** - Redis/in-memory cache for hot memories
2. **Batch Processing** - Queue reflection jobs instead of blocking
3. **Notion Migration** - Add type/priority fields to schema

### Long-term
1. **Vector Database** - Semantic search with embeddings
2. **Multi-Agent System** - Specialized agents (planner, executor, critic)
3. **Reinforcement Learning** - Self-improvement loop based on feedback
4. **Distributed Memory** - Shard by time periods for scale

---
Document Version: 2.0  
Last Updated: 2025-11-16
