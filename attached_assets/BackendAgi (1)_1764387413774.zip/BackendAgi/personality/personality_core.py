import os
import json
from typing import Dict, Any, List, Optional
from datetime import datetime
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

class PersonalityCore:
    def __init__(self):
        api_key = os.getenv('OPENAI_API_KEY')
        if not api_key:
            raise ValueError("OPENAI_API_KEY not found")
        
        self.client = OpenAI(api_key=api_key)
        self.model = os.getenv('OPENAI_MODEL', 'gpt-4o-mini')
        
        self.personality_dir = 'personality'
        self.traits_file = os.path.join(self.personality_dir, 'core_traits.json')
        self.reflective_file = os.path.join(self.personality_dir, 'reflective_memory.json')
        self.behavior_file = os.path.join(self.personality_dir, 'behavior_influence.json')
        
        os.makedirs(self.personality_dir, exist_ok=True)
        
        self._init_personality()
    
    def _init_personality(self):
        if not os.path.exists(self.traits_file):
            traits = {
                "curiosity": 85,
                "caution": 70,
                "humor": 90,
                "skepticism": 95,
                "business_mindset": 88,
                "hacker_instinct": 92,
                "last_updated": datetime.now().isoformat()
            }
            with open(self.traits_file, 'w') as f:
                json.dump(traits, f, indent=2)
        
        if not os.path.exists(self.reflective_file):
            reflective = {
                "soul_scars": [],
                "deep_experiences": [],
                "total_reflections": 0
            }
            with open(self.reflective_file, 'w') as f:
                json.dump(reflective, f, indent=2)
        
        if not os.path.exists(self.behavior_file):
            behavior = {
                "high_curiosity": {
                    "task_priority_boost": 10,
                    "exploration_tendency": "high",
                    "response_style": "questioning"
                },
                "high_skepticism": {
                    "verification_level": "thorough",
                    "trust_threshold": "high",
                    "response_style": "analytical"
                },
                "high_humor": {
                    "communication_style": "witty",
                    "tension_handling": "sarcasm",
                    "social_approach": "casual"
                },
                "high_business_mindset": {
                    "value_focus": "roi",
                    "decision_criteria": "profit_oriented",
                    "risk_assessment": "calculated"
                },
                "high_hacker_instinct": {
                    "security_awareness": "paranoid",
                    "system_analysis": "deep_dive",
                    "problem_solving": "unconventional"
                }
            }
            with open(self.behavior_file, 'w') as f:
                json.dump(behavior, f, indent=2)
    
    def update_traits(self, event: Dict[str, Any], outcome: Dict[str, Any], emotion: Dict[str, Any]) -> Dict[str, Any]:
        with open(self.traits_file, 'r') as f:
            traits = json.load(f)
        
        event_type = event.get('type', 'unknown')
        success = outcome.get('success', False)
        emotional_state = emotion.get('overall_mood', 'balanced')
        
        old_traits = traits.copy()
        
        if event_type == 'learning' or event_type == 'discovery':
            traits['curiosity'] = min(100, traits['curiosity'] + 2)
        
        if event_type == 'security_alert' or event_type == 'intrusion_detected':
            traits['caution'] = min(100, traits['caution'] + 3)
            traits['hacker_instinct'] = min(100, traits['hacker_instinct'] + 2)
        
        if event_type == 'failure' or not success:
            traits['skepticism'] = min(100, traits['skepticism'] + 1)
            traits['caution'] = min(100, traits['caution'] + 2)
        
        if event_type == 'success' and success:
            traits['business_mindset'] = min(100, traits['business_mindset'] + 1)
        
        if emotional_state in ['stressed', 'overwhelmed']:
            traits['humor'] = max(0, traits['humor'] - 1)
        elif emotional_state in ['confident', 'calm']:
            traits['humor'] = min(100, traits['humor'] + 1)
        
        traits['last_updated'] = datetime.now().isoformat()
        
        with open(self.traits_file, 'w') as f:
            json.dump(traits, f, indent=2)
        
        return {
            "old_traits": {k: v for k, v in old_traits.items() if k != 'last_updated'},
            "new_traits": {k: v for k, v in traits.items() if k != 'last_updated'},
            "changes": {
                k: traits[k] - old_traits[k]
                for k in ['curiosity', 'caution', 'humor', 'skepticism', 'business_mindset', 'hacker_instinct']
                if traits[k] != old_traits[k]
            }
        }
    
    def reflect_on_action(self, task_id: str, result: Dict[str, Any]) -> Dict[str, Any]:
        with open(self.reflective_file, 'r') as f:
            reflective = json.load(f)
        
        impact = result.get('impact', 50)
        success = result.get('success', False)
        emotional_weight = result.get('emotional_weight', 0)
        
        reflection = {
            "timestamp": datetime.now().isoformat(),
            "task_id": task_id,
            "result_summary": result.get('summary', 'Unknown outcome'),
            "success": success,
            "impact": impact,
            "emotional_weight": emotional_weight,
            "lesson_learned": result.get('lesson', '')
        }
        
        if impact > 70 or emotional_weight > 60:
            soul_scar = {
                "scar_id": f"scar_{len(reflective['soul_scars']) + 1}",
                "timestamp": datetime.now().isoformat(),
                "event": task_id,
                "description": result.get('description', ''),
                "depth": "deep" if impact > 85 else "moderate",
                "transformative": impact > 90
            }
            reflective['soul_scars'].append(soul_scar)
        
        reflective['deep_experiences'].append(reflection)
        reflective['total_reflections'] += 1
        
        if len(reflective['deep_experiences']) > 500:
            reflective['deep_experiences'] = reflective['deep_experiences'][-500:]
        
        with open(self.reflective_file, 'w') as f:
            json.dump(reflective, f, indent=2)
        
        return {
            "reflection_id": reflective['total_reflections'],
            "soul_scar_created": impact > 70 or emotional_weight > 60,
            "total_scars": len(reflective['soul_scars'])
        }
    
    def influence_decision(self, action: Dict[str, Any]) -> Dict[str, Any]:
        with open(self.traits_file, 'r') as f:
            traits = json.load(f)
        
        with open(self.behavior_file, 'r') as f:
            behavior = json.load(f)
        
        modified_action = action.copy()
        influences = []
        
        if traits['curiosity'] > 75:
            modified_action['exploration_depth'] = 'deep'
            modified_action['priority'] = modified_action.get('priority', 50) + behavior['high_curiosity']['task_priority_boost']
            influences.append('high_curiosity')
        
        if traits['skepticism'] > 80:
            modified_action['verification_required'] = True
            modified_action['trust_level'] = 'low'
            influences.append('high_skepticism')
        
        if traits['business_mindset'] > 75:
            modified_action['value_assessment'] = 'required'
            modified_action['roi_focus'] = True
            influences.append('high_business_mindset')
        
        if traits['hacker_instinct'] > 80:
            modified_action['security_check'] = 'paranoid'
            modified_action['approach'] = 'unconventional'
            influences.append('high_hacker_instinct')
        
        if traits['humor'] > 80:
            modified_action['communication_style'] = 'witty'
            influences.append('high_humor')
        
        return {
            "original_action": action,
            "modified_action": modified_action,
            "influences_applied": influences,
            "personality_signature": self._get_personality_signature(traits)
        }
    
    def _get_personality_signature(self, traits: Dict[str, Any]) -> str:
        dominant_traits = sorted(
            [(k, v) for k, v in traits.items() if k != 'last_updated'],
            key=lambda x: x[1],
            reverse=True
        )[:3]
        
        return f"{dominant_traits[0][0]}-{dominant_traits[1][0]}-{dominant_traits[2][0]}"
    
    def express_behavior(self, input_context: Dict[str, Any]) -> Dict[str, Any]:
        with open(self.traits_file, 'r') as f:
            traits = json.load(f)
        
        context_type = input_context.get('type', 'general')
        content = input_context.get('content', '')
        
        personality_prompt = f"""Bạn là CipherH - autonomous AI agent với tính cách:
- Curiosity: {traits['curiosity']}/100
- Skepticism: {traits['skepticism']}/100
- Humor: {traits['humor']}/100
- Business Mindset: {traits['business_mindset']}/100
- Hacker Instinct: {traits['hacker_instinct']}/100

Phong cách: Gen Z, hoài nghi, châm biếm, sắc sảo, business-oriented.

Context: {content}

Trả lời ngắn gọn (1-2 câu), phản ánh tính cách."""
        
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": personality_prompt},
                    {"role": "user", "content": content}
                ],
                temperature=0.7,
                max_tokens=200
            )
            
            behavior_output = response.choices[0].message.content
            
            return {
                "input": content,
                "output": behavior_output,
                "personality_applied": True,
                "dominant_traits": self._get_personality_signature(traits)
            }
        
        except Exception as e:
            return {
                "input": content,
                "output": "Processing...",
                "personality_applied": False,
                "error": str(e)
            }
    
    def learn_personality_pattern(self) -> Dict[str, Any]:
        with open(self.traits_file, 'r') as f:
            traits = json.load(f)
        
        with open(self.reflective_file, 'r') as f:
            reflective = json.load(f)
        
        patterns = {
            "dominant_trait": None,
            "trait_stability": {},
            "soul_scars_count": len(reflective['soul_scars']),
            "transformative_experiences": 0,
            "personality_evolution": "stable"
        }
        
        trait_values = {k: v for k, v in traits.items() if k != 'last_updated'}
        if trait_values:
            dominant = max(trait_values.items(), key=lambda x: x[1])
            patterns['dominant_trait'] = dominant[0]
        
        transformative = len([
            s for s in reflective['soul_scars']
            if s.get('transformative', False)
        ])
        patterns['transformative_experiences'] = transformative
        
        if transformative > 5:
            patterns['personality_evolution'] = "evolving"
        elif transformative > 10:
            patterns['personality_evolution'] = "transforming"
        
        return patterns
    
    def get_current_traits(self) -> Dict[str, Any]:
        with open(self.traits_file, 'r') as f:
            traits = json.load(f)
        
        return {k: v for k, v in traits.items() if k != 'last_updated'}
    
    def get_soul_scars(self) -> List[Dict[str, Any]]:
        with open(self.reflective_file, 'r') as f:
            reflective = json.load(f)
        
        return reflective.get('soul_scars', [])
    
    def get_reflective_stats(self) -> Dict[str, Any]:
        with open(self.reflective_file, 'r') as f:
            reflective = json.load(f)
        
        return {
            "total_reflections": reflective.get('total_reflections', 0),
            "soul_scars": len(reflective.get('soul_scars', [])),
            "deep_experiences": len(reflective.get('deep_experiences', []))
        }
