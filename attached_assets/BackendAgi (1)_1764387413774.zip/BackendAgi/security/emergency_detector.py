import os
import json
from typing import Dict, Any, List, Optional
from datetime import datetime, timedelta
from collections import defaultdict

class EmergencyDetector:
    def __init__(self):
        self.security_dir = 'security'
        self.emergencies_file = os.path.join(self.security_dir, 'emergencies.json')
        self.traffic_log = defaultdict(list)
        self.failed_attempts = defaultdict(int)
        
        os.makedirs(self.security_dir, exist_ok=True)
        
        self._init_emergencies()
    
    def _init_emergencies(self):
        if not os.path.exists(self.emergencies_file):
            with open(self.emergencies_file, 'w') as f:
                json.dump({
                    "emergencies": [],
                    "total_emergencies": 0,
                    "active_threats": 0
                }, f, indent=2)
    
    def detect_ddos(self, ip: str, request_count: int, time_window: int = 60) -> Dict[str, Any]:
        threshold = 100
        
        if request_count > threshold:
            return self.trigger_emergency_event('ddos', {
                'ip': ip,
                'request_count': request_count,
                'time_window': time_window,
                'threshold': threshold
            }, severity='critical')
        
        return {"threat_detected": False}
    
    def detect_bruteforce(self, ip: str, failed_login_count: int) -> Dict[str, Any]:
        threshold = 5
        
        if failed_login_count >= threshold:
            return self.trigger_emergency_event('bruteforce', {
                'ip': ip,
                'failed_attempts': failed_login_count,
                'threshold': threshold
            }, severity='high')
        
        return {"threat_detected": False}
    
    def detect_token_leak(self, token: str, suspicious_usage: bool) -> Dict[str, Any]:
        if suspicious_usage:
            return self.trigger_emergency_event('token_leak', {
                'token': token[:10] + '...',
                'reason': 'suspicious_usage_pattern'
            }, severity='critical')
        
        return {"threat_detected": False}
    
    def detect_unusual_traffic(self, traffic_pattern: Dict[str, Any]) -> Dict[str, Any]:
        normal_rpm = traffic_pattern.get('normal_rpm', 50)
        current_rpm = traffic_pattern.get('current_rpm', 0)
        
        if current_rpm > normal_rpm * 3:
            return self.trigger_emergency_event('unusual_traffic', {
                'normal_rpm': normal_rpm,
                'current_rpm': current_rpm,
                'spike_ratio': current_rpm / normal_rpm
            }, severity='high')
        
        return {"threat_detected": False}
    
    def detect_faulty_module(self, module_name: str, error_rate: float) -> Dict[str, Any]:
        threshold = 0.3
        
        if error_rate > threshold:
            return self.trigger_emergency_event('faulty_module', {
                'module': module_name,
                'error_rate': error_rate,
                'threshold': threshold
            }, severity='high')
        
        return {"threat_detected": False}
    
    def detect_memory_spike(self, memory_usage: int) -> Dict[str, Any]:
        threshold = 85
        
        if memory_usage > threshold:
            return self.trigger_emergency_event('memory_spike', {
                'memory_usage_percent': memory_usage,
                'threshold': threshold
            }, severity='critical' if memory_usage > 95 else 'high')
        
        return {"threat_detected": False}
    
    def detect_invalid_api_requests(self, invalid_count: int, total_count: int) -> Dict[str, Any]:
        if total_count == 0:
            return {"threat_detected": False}
        
        invalid_ratio = invalid_count / total_count
        threshold = 0.5
        
        if invalid_ratio > threshold:
            return self.trigger_emergency_event('invalid_api_requests', {
                'invalid_count': invalid_count,
                'total_count': total_count,
                'invalid_ratio': invalid_ratio
            }, severity='medium')
        
        return {"threat_detected": False}
    
    def trigger_emergency_event(self, threat_type: str, data: Dict[str, Any], severity: str = 'medium') -> Dict[str, Any]:
        with open(self.emergencies_file, 'r') as f:
            emergencies_data = json.load(f)
        
        emergency = {
            "id": f"emergency_{emergencies_data['total_emergencies'] + 1}",
            "type": threat_type,
            "severity": severity,
            "data": data,
            "timestamp": datetime.now().isoformat(),
            "status": "active",
            "resolved": False
        }
        
        emergencies_data['emergencies'].append(emergency)
        emergencies_data['total_emergencies'] += 1
        emergencies_data['active_threats'] += 1
        
        if len(emergencies_data['emergencies']) > 500:
            emergencies_data['emergencies'] = emergencies_data['emergencies'][-500:]
        
        with open(self.emergencies_file, 'w') as f:
            json.dump(emergencies_data, f, indent=2)
        
        return {
            "threat_detected": True,
            "emergency": emergency
        }
    
    def resolve_emergency(self, emergency_id: str) -> Dict[str, Any]:
        with open(self.emergencies_file, 'r') as f:
            emergencies_data = json.load(f)
        
        for emergency in emergencies_data['emergencies']:
            if emergency['id'] == emergency_id and emergency['status'] == 'active':
                emergency['status'] = 'resolved'
                emergency['resolved'] = True
                emergency['resolved_at'] = datetime.now().isoformat()
                emergencies_data['active_threats'] -= 1
                break
        
        with open(self.emergencies_file, 'w') as f:
            json.dump(emergencies_data, f, indent=2)
        
        return {"success": True}
    
    def get_active_emergencies(self) -> List[Dict[str, Any]]:
        with open(self.emergencies_file, 'r') as f:
            emergencies_data = json.load(f)
        
        return [e for e in emergencies_data['emergencies'] if e['status'] == 'active']
