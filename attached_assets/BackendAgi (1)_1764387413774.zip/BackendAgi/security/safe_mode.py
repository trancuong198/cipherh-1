import os
import json
from typing import Dict, Any
from datetime import datetime

class SafeMode:
    def __init__(self):
        self.security_dir = 'security'
        self.safe_mode_file = os.path.join(self.security_dir, 'safe_mode.json')
        
        os.makedirs(self.security_dir, exist_ok=True)
        
        self._init_safe_mode()
    
    def _init_safe_mode(self):
        if not os.path.exists(self.safe_mode_file):
            with open(self.safe_mode_file, 'w') as f:
                json.dump({
                    "enabled": False,
                    "activated_at": None,
                    "reason": None,
                    "restrictions": {
                        "non_essential_routes_disabled": False,
                        "only_owner_access": False,
                        "all_external_requests_blocked": False,
                        "background_workers_stopped": False,
                        "firewall_maximum": False
                    },
                    "activation_history": []
                }, f, indent=2)
    
    def enter_safe_mode(self, reason: str = 'emergency_threat') -> Dict[str, Any]:
        with open(self.safe_mode_file, 'r') as f:
            safe_mode_data = json.load(f)
        
        if safe_mode_data['enabled']:
            return {
                "success": False,
                "message": "Safe mode already active"
            }
        
        safe_mode_data['enabled'] = True
        safe_mode_data['activated_at'] = datetime.now().isoformat()
        safe_mode_data['reason'] = reason
        
        safe_mode_data['restrictions'] = {
            "non_essential_routes_disabled": True,
            "only_owner_access": True,
            "all_external_requests_blocked": True,
            "background_workers_stopped": True,
            "firewall_maximum": True
        }
        
        safe_mode_data['activation_history'].append({
            'activated_at': datetime.now().isoformat(),
            'reason': reason
        })
        
        if len(safe_mode_data['activation_history']) > 50:
            safe_mode_data['activation_history'] = safe_mode_data['activation_history'][-50:]
        
        with open(self.safe_mode_file, 'w') as f:
            json.dump(safe_mode_data, f, indent=2)
        
        return {
            "success": True,
            "message": "Safe mode activated",
            "restrictions": safe_mode_data['restrictions']
        }
    
    def exit_safe_mode(self) -> Dict[str, Any]:
        with open(self.safe_mode_file, 'r') as f:
            safe_mode_data = json.load(f)
        
        if not safe_mode_data['enabled']:
            return {
                "success": False,
                "message": "Safe mode not active"
            }
        
        safe_mode_data['enabled'] = False
        safe_mode_data['deactivated_at'] = datetime.now().isoformat()
        
        safe_mode_data['restrictions'] = {
            "non_essential_routes_disabled": False,
            "only_owner_access": False,
            "all_external_requests_blocked": False,
            "background_workers_stopped": False,
            "firewall_maximum": False
        }
        
        with open(self.safe_mode_file, 'w') as f:
            json.dump(safe_mode_data, f, indent=2)
        
        return {
            "success": True,
            "message": "Safe mode deactivated",
            "restrictions": safe_mode_data['restrictions']
        }
    
    def safe_mode_status(self) -> Dict[str, Any]:
        with open(self.safe_mode_file, 'r') as f:
            safe_mode_data = json.load(f)
        
        return {
            "enabled": safe_mode_data['enabled'],
            "activated_at": safe_mode_data.get('activated_at'),
            "reason": safe_mode_data.get('reason'),
            "restrictions": safe_mode_data['restrictions'],
            "total_activations": len(safe_mode_data['activation_history'])
        }
