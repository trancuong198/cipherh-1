import os
import json
from typing import Dict, Any, List, Optional
from datetime import datetime

class SelfProtection:
    def __init__(self):
        self.security_dir = 'security'
        self.blocked_file = os.path.join(self.security_dir, 'blocked.json')
        
        os.makedirs(self.security_dir, exist_ok=True)
        
        self._init_blocked()
    
    def _init_blocked(self):
        if not os.path.exists(self.blocked_file):
            with open(self.blocked_file, 'w') as f:
                json.dump({
                    "blocked_ips": [],
                    "disabled_routes": [],
                    "invalidated_tokens": [],
                    "frozen_modules": [],
                    "locked_apis": [],
                    "defense_level": 0
                }, f, indent=2)
    
    def block_ip(self, ip: str, reason: str = 'security_threat') -> Dict[str, Any]:
        with open(self.blocked_file, 'r') as f:
            blocked_data = json.load(f)
        
        if ip not in blocked_data['blocked_ips']:
            blocked_data['blocked_ips'].append({
                'ip': ip,
                'reason': reason,
                'blocked_at': datetime.now().isoformat()
            })
        
        with open(self.blocked_file, 'w') as f:
            json.dump(blocked_data, f, indent=2)
        
        return {
            "success": True,
            "action": "ip_blocked",
            "ip": ip
        }
    
    def disable_route(self, route: str, reason: str = 'security_threat') -> Dict[str, Any]:
        with open(self.blocked_file, 'r') as f:
            blocked_data = json.load(f)
        
        if route not in [r['route'] for r in blocked_data['disabled_routes']]:
            blocked_data['disabled_routes'].append({
                'route': route,
                'reason': reason,
                'disabled_at': datetime.now().isoformat()
            })
        
        with open(self.blocked_file, 'w') as f:
            json.dump(blocked_data, f, indent=2)
        
        return {
            "success": True,
            "action": "route_disabled",
            "route": route
        }
    
    def invalidate_token(self, token: str, reason: str = 'security_threat') -> Dict[str, Any]:
        with open(self.blocked_file, 'r') as f:
            blocked_data = json.load(f)
        
        token_hash = token[:10] + '...'
        
        if token_hash not in [t['token'] for t in blocked_data['invalidated_tokens']]:
            blocked_data['invalidated_tokens'].append({
                'token': token_hash,
                'reason': reason,
                'invalidated_at': datetime.now().isoformat()
            })
        
        with open(self.blocked_file, 'w') as f:
            json.dump(blocked_data, f, indent=2)
        
        return {
            "success": True,
            "action": "token_invalidated",
            "token": token_hash
        }
    
    def freeze_module(self, module_name: str, reason: str = 'security_threat') -> Dict[str, Any]:
        with open(self.blocked_file, 'r') as f:
            blocked_data = json.load(f)
        
        if module_name not in [m['module'] for m in blocked_data['frozen_modules']]:
            blocked_data['frozen_modules'].append({
                'module': module_name,
                'reason': reason,
                'frozen_at': datetime.now().isoformat()
            })
        
        with open(self.blocked_file, 'w') as f:
            json.dump(blocked_data, f, indent=2)
        
        return {
            "success": True,
            "action": "module_frozen",
            "module": module_name
        }
    
    def lock_external_api(self, api_name: str, reason: str = 'security_threat') -> Dict[str, Any]:
        with open(self.blocked_file, 'r') as f:
            blocked_data = json.load(f)
        
        if api_name not in [a['api'] for a in blocked_data['locked_apis']]:
            blocked_data['locked_apis'].append({
                'api': api_name,
                'reason': reason,
                'locked_at': datetime.now().isoformat()
            })
        
        with open(self.blocked_file, 'w') as f:
            json.dump(blocked_data, f, indent=2)
        
        return {
            "success": True,
            "action": "api_locked",
            "api": api_name
        }
    
    def enable_defense_layer(self, level: int) -> Dict[str, Any]:
        with open(self.blocked_file, 'r') as f:
            blocked_data = json.load(f)
        
        old_level = blocked_data['defense_level']
        blocked_data['defense_level'] = min(10, max(0, level))
        
        with open(self.blocked_file, 'w') as f:
            json.dump(blocked_data, f, indent=2)
        
        return {
            "success": True,
            "action": "defense_level_changed",
            "old_level": old_level,
            "new_level": blocked_data['defense_level']
        }
    
    def unblock_ip(self, ip: str) -> Dict[str, Any]:
        with open(self.blocked_file, 'r') as f:
            blocked_data = json.load(f)
        
        blocked_data['blocked_ips'] = [b for b in blocked_data['blocked_ips'] if b['ip'] != ip]
        
        with open(self.blocked_file, 'w') as f:
            json.dump(blocked_data, f, indent=2)
        
        return {"success": True, "action": "ip_unblocked"}
    
    def enable_route(self, route: str) -> Dict[str, Any]:
        with open(self.blocked_file, 'r') as f:
            blocked_data = json.load(f)
        
        blocked_data['disabled_routes'] = [r for r in blocked_data['disabled_routes'] if r['route'] != route]
        
        with open(self.blocked_file, 'w') as f:
            json.dump(blocked_data, f, indent=2)
        
        return {"success": True, "action": "route_enabled"}
    
    def get_protection_status(self) -> Dict[str, Any]:
        with open(self.blocked_file, 'r') as f:
            blocked_data = json.load(f)
        
        return {
            "blocked_ips_count": len(blocked_data['blocked_ips']),
            "disabled_routes_count": len(blocked_data['disabled_routes']),
            "invalidated_tokens_count": len(blocked_data['invalidated_tokens']),
            "frozen_modules_count": len(blocked_data['frozen_modules']),
            "locked_apis_count": len(blocked_data['locked_apis']),
            "defense_level": blocked_data['defense_level']
        }
