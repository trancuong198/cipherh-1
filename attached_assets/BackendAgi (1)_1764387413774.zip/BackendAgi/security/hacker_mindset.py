import os
import json
from typing import Dict, Any, List, Optional
from datetime import datetime
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

class HackerMindset:
    def __init__(self):
        api_key = os.getenv('OPENAI_API_KEY')
        if not api_key:
            raise ValueError("OPENAI_API_KEY not found")
        
        self.client = OpenAI(api_key=api_key)
        self.model = os.getenv('OPENAI_MODEL', 'gpt-4o-mini')
        
        self.security_dir = 'security'
        self.mindset_file = os.path.join(self.security_dir, 'hacker_insights.json')
        
        os.makedirs(self.security_dir, exist_ok=True)
        
        self._init_mindset()
    
    def _init_mindset(self):
        if not os.path.exists(self.mindset_file):
            with open(self.mindset_file, 'w') as f:
                json.dump({
                    "insights": [],
                    "threat_patterns": [],
                    "predictions": [],
                    "total_analyses": 0
                }, f, indent=2)
    
    def calculate_threat_pattern(self, data: Dict[str, Any]) -> Dict[str, Any]:
        pattern = {
            "id": f"pattern_{self._get_next_id()}",
            "timestamp": datetime.now().isoformat(),
            "attack_signature": self._extract_signature(data),
            "frequency": 1,
            "severity": self._assess_severity(data),
            "attack_vector": data.get('attack_type', 'unknown'),
            "target_modules": data.get('targets', [])
        }
        
        with open(self.mindset_file, 'r') as f:
            mindset_data = json.load(f)
        
        existing = None
        for p in mindset_data['threat_patterns']:
            if p['attack_signature'] == pattern['attack_signature']:
                existing = p
                break
        
        if existing:
            existing['frequency'] += 1
            existing['last_seen'] = datetime.now().isoformat()
        else:
            mindset_data['threat_patterns'].append(pattern)
        
        if len(mindset_data['threat_patterns']) > 100:
            mindset_data['threat_patterns'] = sorted(
                mindset_data['threat_patterns'], 
                key=lambda x: x.get('frequency', 0), 
                reverse=True
            )[:100]
        
        with open(self.mindset_file, 'w') as f:
            json.dump(mindset_data, f, indent=2)
        
        return pattern
    
    def predict_next_attack(self) -> Dict[str, Any]:
        with open(self.mindset_file, 'r') as f:
            mindset_data = json.load(f)
        
        patterns = mindset_data.get('threat_patterns', [])
        
        if len(patterns) == 0:
            return {
                "prediction": "no_data",
                "confidence": 0,
                "next_likely_attack": "unknown"
            }
        
        patterns_sorted = sorted(patterns, key=lambda x: x.get('frequency', 0), reverse=True)
        
        top_pattern = patterns_sorted[0]
        
        prediction = {
            "id": f"pred_{len(mindset_data['predictions']) + 1}",
            "timestamp": datetime.now().isoformat(),
            "next_likely_attack": top_pattern['attack_vector'],
            "confidence": min(95, top_pattern['frequency'] * 10),
            "reasoning": f"Pattern detected {top_pattern['frequency']} times",
            "target_modules": top_pattern.get('target_modules', []),
            "recommended_actions": self._generate_recommendations(top_pattern)
        }
        
        mindset_data['predictions'].append(prediction)
        
        if len(mindset_data['predictions']) > 50:
            mindset_data['predictions'] = mindset_data['predictions'][-50:]
        
        with open(self.mindset_file, 'w') as f:
            json.dump(mindset_data, f, indent=2)
        
        return prediction
    
    def analyze_attacker_behavior(self, attack_data: List[Dict[str, Any]]) -> Dict[str, Any]:
        if not attack_data:
            return {"status": "no_data"}
        
        analysis = {
            "timestamp": datetime.now().isoformat(),
            "total_attacks": len(attack_data),
            "attack_types": {},
            "time_patterns": [],
            "sophistication_level": "low",
            "attacker_profile": "opportunistic"
        }
        
        for attack in attack_data:
            attack_type = attack.get('attack_type', 'unknown')
            if attack_type in analysis['attack_types']:
                analysis['attack_types'][attack_type] += 1
            else:
                analysis['attack_types'][attack_type] = 1
        
        unique_types = len(analysis['attack_types'])
        
        if unique_types > 5:
            analysis['sophistication_level'] = "high"
            analysis['attacker_profile'] = "advanced_persistent_threat"
        elif unique_types > 2:
            analysis['sophistication_level'] = "medium"
            analysis['attacker_profile'] = "skilled_attacker"
        
        with open(self.mindset_file, 'r') as f:
            mindset_data = json.load(f)
        
        mindset_data['insights'].append(analysis)
        mindset_data['total_analyses'] += 1
        
        if len(mindset_data['insights']) > 50:
            mindset_data['insights'] = mindset_data['insights'][-50:]
        
        with open(self.mindset_file, 'w') as f:
            json.dump(mindset_data, f, indent=2)
        
        return analysis
    
    def _extract_signature(self, data: Dict[str, Any]) -> str:
        attack_type = data.get('attack_type', 'unknown')
        target = data.get('target', 'unknown')
        return f"{attack_type}:{target}"
    
    def _assess_severity(self, data: Dict[str, Any]) -> str:
        threat_score = data.get('threat_score', 0)
        
        if threat_score > 80:
            return "critical"
        elif threat_score > 60:
            return "high"
        elif threat_score > 40:
            return "medium"
        else:
            return "low"
    
    def _generate_recommendations(self, pattern: Dict[str, Any]) -> List[str]:
        recommendations = []
        
        attack_vector = pattern.get('attack_vector', '')
        
        if 'injection' in attack_vector:
            recommendations.append("implement_input_sanitization")
            recommendations.append("use_parameterized_queries")
        
        if 'brute_force' in attack_vector:
            recommendations.append("add_rate_limiting")
            recommendations.append("implement_account_lockout")
        
        if 'token' in attack_vector or 'session' in attack_vector:
            recommendations.append("rotate_tokens_frequently")
            recommendations.append("add_token_expiry")
        
        if pattern.get('frequency', 0) > 5:
            recommendations.append("block_pattern_permanently")
        
        recommendations.append("increase_monitoring")
        
        return recommendations
    
    def _get_next_id(self) -> int:
        with open(self.mindset_file, 'r') as f:
            mindset_data = json.load(f)
        return len(mindset_data.get('threat_patterns', [])) + 1
    
    def get_insights(self) -> Dict[str, Any]:
        with open(self.mindset_file, 'r') as f:
            return json.load(f)
