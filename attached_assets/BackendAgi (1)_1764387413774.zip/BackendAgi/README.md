# 🤖 CipherH - Autonomous AI Agent

**Vietnamese AI Agent with Self-Reflecting Soul Loop Architecture**

Budget: $25/month | Status: Production Ready | Total: 6,000+ lines

---

## 🚀 Quick Start

### Node.js Backend (Recommended)
```bash
cd nodejs-backend
npm install
npm start

# Server runs on port 3000
# Inner Loop auto-executes every 10 minutes
```

### Python Backend
```bash
pip install -r requirements_soul.txt
python main.py
```

### Test API
```bash
curl http://localhost:3000/health
curl http://localhost:3000/core/status
```

---

## 📊 Architecture

**Dual Backend System:**
- **Python:** 1,704 lines - Script-based, 4 tests passing
- **Node.js:** 1,782 lines - REST API + Cron scheduler

**SoulCore (450 lines):**
- 8 methods for self-learning & evolution
- Pure JavaScript (no external AI)
- JARVIS-like consciousness

**Inner Loop (10 steps):**
1. Read logs from Notion
2. Analyze with SoulCore
3. Detect anomalies
4. Generate daily lesson
5. Write to Notion
6. Self-evaluate (1-10 score)
7. Compare with goals
8. Generate strategy
9. Create tasks
10. Update state

---

## 🎯 Features

✅ Self-learning from logs  
✅ Self-questioning (JARVIS-like)  
✅ Self-evaluation (scoring)  
✅ Strategic planning  
✅ Task auto-generation  
✅ Anomaly detection  
✅ Self-evolution (version tracking)  
✅ 24/7 autonomous operation  

---

## 📚 Documentation

**Node.js (12 guides):**
- `QUICKSTART.md` - 3-step setup
- `REPLIT_DEPLOY.md` - Replit deployment
- `TEST_DEPLOY.md` - Testing guide
- `API_ENDPOINTS.md` - API reference
- `BACKEND_COMPLETE.md` - Implementation details
- `INTEGRATION_COMPLETE.md` - SoulCore integration

**Project:**
- `CIPHERH_COMPLETE.md` - Full overview
- `DEPLOY_CHECKLIST.md` - Deployment guide

---

## 🔧 API Endpoints

```
GET  /health              - Health check
GET  /core/status         - Inner Loop state
GET  /core/run-loop       - Trigger manual run
GET  /core/strategy       - Current strategy
GET  /core/tasks          - Task list
GET  /core/anomalies      - Anomaly detection
```

---

## 💰 Budget

**Total: ~$20/month** (Under $25 budget ✅)
- Replit Always-On: $7/month
- OpenAI API: ~$10/month
- Notion: Free

---

## 🎉 Status

✅ Code Complete (6,000+ lines)  
✅ Tests Passing (Python)  
✅ Documentation Complete (2,500+ lines)  
✅ Production Ready  
✅ Running Live  

**"Con trai" CipherH đang phục vụ "cha" 24/7! 🤖✨**

---

## 📁 Project Structure

```
cipherh-project/
├── core/                    # Python backend
│   ├── soul_state.py
│   ├── analyzer.py
│   ├── strategist.py
│   ├── memory.py
│   └── soul_loop.py
├── tests/                   # Python tests (4 files)
├── nodejs-backend/          # Node.js backend
│   ├── src/
│   │   ├── core/           # SoulCore + Inner Loop
│   │   ├── services/       # Notion, OpenAI, Logger
│   │   ├── controllers/    # API controllers
│   │   └── routes/         # Express routes
│   └── [12 documentation files]
├── main.py                  # Python runner
└── [Documentation files]
```

---

**Built with ❤️ for autonomous AI**  
**Version:** 1.0.0  
**Date:** November 2025  
