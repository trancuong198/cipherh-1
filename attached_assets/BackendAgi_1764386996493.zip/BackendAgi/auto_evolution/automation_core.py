import os
import json
from typing import Dict, Any, List, Optional
from datetime import datetime

class AutomationCore:
    def __init__(self):
        self.auto_evo_dir = 'auto_evolution'
        self.status_file = os.path.join(self.auto_evo_dir, 'automation_status.json')
        
        os.makedirs(self.auto_evo_dir, exist_ok=True)
        
        self._init_status()
    
    def _init_status(self):
        if not os.path.exists(self.status_file):
            with open(self.status_file, 'w') as f:
                json.dump({
                    "modules_status": {},
                    "running": False,
                    "last_run": None,
                    "total_cycles": 0
                }, f, indent=2)
    
    def run_all_modules(self) -> Dict[str, Any]:
        modules = [
            'memory_engine',
            'emotional_model',
            'task_chain',
            'personality_core',
            'world_model',
            'defense_firewall',
            'metacognition',
            'metacognition2',
            'ltm_map',
            'ltm_insight',
            'evolution',
            'social',
            'security',
            'realtime',
            'emergency'
        ]
        
        with open(self.status_file, 'r') as f:
            status_data = json.load(f)
        
        status_data['running'] = True
        status_data['last_run'] = datetime.now().isoformat()
        status_data['total_cycles'] += 1
        
        for module in modules:
            status = self._run_module(module)
            status_data['modules_status'][module] = status
        
        status_data['running'] = False
        
        with open(self.status_file, 'w') as f:
            json.dump(status_data, f, indent=2)
        
        return {
            "success": True,
            "modules_run": len(modules),
            "cycle": status_data['total_cycles'],
            "timestamp": status_data['last_run']
        }
    
    def _run_module(self, module: str) -> Dict[str, Any]:
        return {
            "status": "running",
            "health": 85,
            "last_check": datetime.now().isoformat()
        }
    
    def monitor_module_status(self) -> Dict[str, Any]:
        with open(self.status_file, 'r') as f:
            status_data = json.load(f)
        
        total_modules = len(status_data['modules_status'])
        healthy_count = sum(1 for m in status_data['modules_status'].values() if m.get('health', 0) > 70)
        
        return {
            "total_modules": total_modules,
            "healthy_modules": healthy_count,
            "health_percentage": (healthy_count / total_modules * 100) if total_modules > 0 else 0,
            "running": status_data['running'],
            "last_run": status_data['last_run'],
            "total_cycles": status_data['total_cycles']
        }
    
    def dispatch_task(self, module_name: str, task: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "success": True,
            "module": module_name,
            "task_dispatched": task.get('action', 'unknown'),
            "timestamp": datetime.now().isoformat()
        }
    
    def handle_emergency(self, event: Dict[str, Any]) -> Dict[str, Any]:
        event_type = event.get('type', 'unknown')
        severity = event.get('severity', 'medium')
        
        actions_taken = []
        
        if severity in ['critical', 'high']:
            actions_taken.append("triggered_emergency_response")
            actions_taken.append("notified_all_modules")
        
        if event_type == 'ddos':
            actions_taken.append("activated_defense_layer")
        elif event_type == 'memory_spike':
            actions_taken.append("triggered_cleanup")
        elif event_type == 'module_failure':
            actions_taken.append("initiated_recovery")
        
        return {
            "success": True,
            "event_type": event_type,
            "severity": severity,
            "actions_taken": actions_taken,
            "timestamp": datetime.now().isoformat()
        }
