import os
import json
from typing import Dict, Any, List, Optional
from datetime import datetime

class EvolutionEngine:
    def __init__(self):
        self.auto_evo_dir = 'auto_evolution'
        self.evolution_log_file = os.path.join(self.auto_evo_dir, 'evolution_log.json')
        
        os.makedirs(self.auto_evo_dir, exist_ok=True)
        
        self._init_evolution_log()
    
    def _init_evolution_log(self):
        if not os.path.exists(self.evolution_log_file):
            with open(self.evolution_log_file, 'w') as f:
                json.dump({
                    "evolutions": [],
                    "total_evolutions": 0,
                    "successful_upgrades": 0
                }, f, indent=2)
    
    def analyze_performance(self, module_name: str) -> Dict[str, Any]:
        analysis = {
            "module": module_name,
            "timestamp": datetime.now().isoformat(),
            "performance_score": 75,
            "bottlenecks": [],
            "optimization_opportunities": [],
            "recommended_actions": []
        }
        
        if module_name in ['task_chain', 'realtime']:
            analysis['bottlenecks'].append("high_latency_detected")
            analysis['optimization_opportunities'].append("cache_optimization")
            analysis['recommended_actions'].append("implement_caching")
        
        if module_name in ['metacognition2', 'ltm_insight']:
            analysis['bottlenecks'].append("heavy_computation")
            analysis['optimization_opportunities'].append("parallel_processing")
            analysis['recommended_actions'].append("add_parallelization")
        
        if module_name in ['social', 'emergency']:
            analysis['optimization_opportunities'].append("response_time_improvement")
            analysis['recommended_actions'].append("optimize_algorithms")
        
        return analysis
    
    def generate_upgrade_plan(self) -> Dict[str, Any]:
        insights = self._get_ltm_insights()
        metacog_evaluations = self._get_metacog_evaluations()
        
        plan = {
            "id": f"upgrade_plan_{self._get_next_id()}",
            "timestamp": datetime.now().isoformat(),
            "modules_to_upgrade": [],
            "priority_order": [],
            "estimated_impact": 0
        }
        
        modules_needing_upgrade = [
            {"module": "task_chain", "reason": "optimize_workflow", "priority": "high", "impact": 25},
            {"module": "metacognition2", "reason": "improve_analysis", "priority": "medium", "impact": 20},
            {"module": "social", "reason": "enhance_responses", "priority": "medium", "impact": 15},
            {"module": "security", "reason": "strengthen_defense", "priority": "high", "impact": 30}
        ]
        
        for upgrade in modules_needing_upgrade:
            plan['modules_to_upgrade'].append(upgrade)
            plan['estimated_impact'] += upgrade['impact']
        
        plan['priority_order'] = sorted(
            modules_needing_upgrade,
            key=lambda x: (0 if x['priority'] == 'high' else 1, -x['impact'])
        )
        
        return plan
    
    def apply_upgrade(self, module_name: str) -> Dict[str, Any]:
        upgrade = {
            "id": f"upgrade_{self._get_next_id()}",
            "module": module_name,
            "timestamp": datetime.now().isoformat(),
            "changes_applied": [],
            "status": "completed"
        }
        
        if module_name == 'task_chain':
            upgrade['changes_applied'].extend([
                "added_caching_layer",
                "optimized_priority_algorithm",
                "improved_dependency_resolution"
            ])
        elif module_name == 'metacognition2':
            upgrade['changes_applied'].extend([
                "added_parallel_processing",
                "improved_evaluation_logic",
                "enhanced_self_correction"
            ])
        elif module_name == 'social':
            upgrade['changes_applied'].extend([
                "optimized_response_time",
                "enhanced_personality_integration",
                "improved_emotion_awareness"
            ])
        elif module_name == 'security':
            upgrade['changes_applied'].extend([
                "strengthened_threat_detection",
                "improved_auto_recovery",
                "enhanced_pattern_matching"
            ])
        else:
            upgrade['changes_applied'].append("general_optimization")
        
        self.log_evolution_result(upgrade)
        
        return {
            "success": True,
            "upgrade": upgrade
        }
    
    def log_evolution_result(self, upgrade: Dict[str, Any]) -> Dict[str, Any]:
        with open(self.evolution_log_file, 'r') as f:
            log_data = json.load(f)
        
        log_data['evolutions'].append(upgrade)
        log_data['total_evolutions'] += 1
        
        if upgrade.get('status') == 'completed':
            log_data['successful_upgrades'] += 1
        
        if len(log_data['evolutions']) > 100:
            log_data['evolutions'] = log_data['evolutions'][-100:]
        
        with open(self.evolution_log_file, 'w') as f:
            json.dump(log_data, f, indent=2)
        
        return {"success": True}
    
    def _get_ltm_insights(self) -> List[Dict[str, Any]]:
        insights_file = 'ltm/insights.json'
        
        if not os.path.exists(insights_file):
            return []
        
        try:
            with open(insights_file, 'r') as f:
                data = json.load(f)
            return data.get('insights', [])[-5:]
        except Exception:
            return []
    
    def _get_metacog_evaluations(self) -> List[Dict[str, Any]]:
        eval_file = 'metacognition2/evaluations.json'
        
        if not os.path.exists(eval_file):
            return []
        
        try:
            with open(eval_file, 'r') as f:
                data = json.load(f)
            return data.get('evaluations', [])[-5:]
        except Exception:
            return []
    
    def _get_next_id(self) -> int:
        with open(self.evolution_log_file, 'r') as f:
            log_data = json.load(f)
        return log_data['total_evolutions'] + 1
    
    def get_evolution_history(self) -> List[Dict[str, Any]]:
        with open(self.evolution_log_file, 'r') as f:
            log_data = json.load(f)
        return log_data.get('evolutions', [])[-20:]
