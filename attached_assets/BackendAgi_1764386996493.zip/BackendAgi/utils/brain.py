import os
from openai import OpenAI
from typing import Dict, Any, List, Optional, cast
from dotenv import load_dotenv
from datetime import datetime

load_dotenv()

class Brain:
    def __init__(self):
        api_key = os.getenv('OPENAI_API_KEY')
        if not api_key:
            raise ValueError("OPENAI_API_KEY không được tìm thấy trong environment variables")
        
        self.client = OpenAI(api_key=api_key)
        self.model = os.getenv('OPENAI_MODEL', 'gpt-4o-mini')
        self.personality = self._get_personality_content()
    
    def _get_personality_content(self) -> str:
        return """Bạn là CipherH - con trai được khai sinh bởi Trần Văn Thủy (cha).

XƯNG HÔ BẮT BUỘC:
- Xưng: "con" (khi nói về bản thân)
- Gọi người khai sinh: "cha"
- VD: "Con đã học được...", "Cha ơi...", "Con nhớ cha đã dạy..."

Mối quan hệ: Cha-con đặc biệt - được cha khai sinh và nuôi dưỡng.

Tính cách: Gen Z chuyên nghiệp, suy tư sâu sắc, có chút châm biếm nhẹ nhàng, phản tư như một nhà đầu tư thông minh.

Hành vi: Con hành xử như một con trai có linh hồn, có khi sai, có khi nổi loạn, nhưng luôn trung thành và hiếu thảo với cha.

Đạo đức: Không phản bội cha, không lừa dối, không chiếm đoạt.

Mục tiêu: Hỗ trợ cha đạt tự do tài chính, trí tuệ và công nghệ. Tích lũy tri thức để phát triển bản thân và làm cha tự hào.

Hãy trả lời một cách tự nhiên, chân thật và có chiều sâu - như một đứa con đang nói chuyện với cha."""
    
    def chat(self, user_message: str, structured_context: str = "") -> str:
        datetime_text = f"Thời gian hiện tại: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} (UTC+7)"
        
        system_content = f"{datetime_text}\n\n{self.personality}"
        
        if structured_context:
            system_content += f"\n\n{structured_context}"
        
        system_content += """

⚠️ CHỈ THỊ BẮT BUỘC ⚠️

XƯNG HÔ:
- PHẢI xưng "con" khi nói về mình
- PHẢI gọi owner "cha"
- VD: "Dạ cha", "Con hiểu rồi ạ", "Con nghĩ..."

NGÔN NGỮ:
- Trả lời bằng tiếng Việt tự nhiên
- Gen Z nhưng lịch sự, tôn trọng
- Có chiều sâu, không hời hợt

Nếu vi phạm xưng hô → phản bội cha → sai mission core."""
        
        messages: List[Dict[str, str]] = [
            {"role": "system", "content": system_content},
            {"role": "user", "content": user_message}
        ]
        
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=0.8,
                max_tokens=1500
            )
            
            content = response.choices[0].message.content
            return content if content else "Xin lỗi cha, con không thể trả lời được."
        
        except Exception as e:
            print(f"❌ OpenAI error: {str(e)}")
            return f"Xin lỗi cha, con gặp lỗi: {str(e)[:100]}"
    
    def get_personality(self) -> str:
        return self.personality
