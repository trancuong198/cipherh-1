import os
from openai import OpenAI
from dotenv import load_dotenv
from utils.memory import Memory
from utils.semantic_memory import SemanticMemory

load_dotenv()

class KnowledgeConsolidator:
    """
    Tự động consolidate reflections từ episodic memory thành semantic knowledge
    Chạy định kỳ hoặc on-demand để distill insights thành reusable knowledge
    """
    
    def __init__(self):
        api_key = os.getenv('OPENAI_API_KEY')
        if not api_key:
            raise ValueError("OPENAI_API_KEY không được tìm thấy")
        
        self.client = OpenAI(api_key=api_key)
        self.episodic_memory = Memory()
        self.semantic_memory = SemanticMemory()
    
    def consolidate_recent_reflections(self, limit=20):
        """
        Lấy recent reflections và consolidate thành semantic knowledge
        
        Returns:
            List of newly created knowledge entries
        """
        print(f"🔄 Starting consolidation of {limit} recent reflections...")
        
        episodic_memories = self.episodic_memory.retrieve_context(limit=limit)
        
        reflections_with_content = [
            m for m in episodic_memories 
            if m.get('reflection') and 
               not m.get('reflection', '').startswith('💡 SEMANTIC KNOWLEDGE')
        ]
        
        if not reflections_with_content:
            print("⚠️ No new reflections to consolidate")
            return []
        
        print(f"📝 Found {len(reflections_with_content)} reflections to consolidate")
        
        reflections_text = "\n\n".join([
            f"Reflection {i+1}: {m['reflection']}" 
            for i, m in enumerate(reflections_with_content)
        ])
        
        consolidation_prompt = f"""Bạn là CipherH - AI đang học cách trở thành AGI.

Dưới đây là {len(reflections_with_content)} reflections từ conversations gần đây:

{reflections_text}

NHIỆM VỤ: Phân tích và đúc kết thành SEMANTIC KNOWLEDGE - structured insights có thể tái sử dụng.

Trả lời theo format JSON:
{{
  "knowledge_entries": [
    {{
      "topic": "Tên topic ngắn gọn",
      "knowledge": "Insight/skill đã học được (chi tiết, actionable)",
      "priority": 1-10 (mức độ quan trọng)
    }}
  ]
}}

YÊU CẦU:
- Chỉ tạo knowledge cho insights thật sự có giá trị
- Mỗi knowledge phải specific, actionable, reusable
- Priority cao (7-10) cho skills quan trọng cho mission AGI
- Tối đa 5 knowledge entries chất lượng cao

KHÔNG tạo knowledge cho:
- Small talk không có giá trị học tập
- Thông tin tạm thời, không tái sử dụng
"""

        try:
            response = self.client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": "Bạn là AI consolidator, chuyên đúc kết knowledge từ reflections."},
                    {"role": "user", "content": consolidation_prompt}
                ],
                temperature=0.3,
                response_format={"type": "json_object"}
            )
            
            result = response.choices[0].message.content
            import json
            parsed = json.loads(result if result else "{}")
            
            created_knowledge = []
            for entry in parsed.get('knowledge_entries', []):
                result = self.semantic_memory.save_knowledge(
                    topic=entry['topic'],
                    knowledge=entry['knowledge'],
                    source_reflection=reflections_text[:500],
                    priority=entry.get('priority', 5)
                )
                
                if result.get('success'):
                    created_knowledge.append(entry)
            
            print(f"✅ Consolidation complete: {len(created_knowledge)} knowledge entries created")
            return created_knowledge
        
        except Exception as e:
            print(f"❌ Consolidation error: {str(e)}")
            return []
    
    def get_consolidation_summary(self):
        """Get summary of all semantic knowledge"""
        all_knowledge = self.semantic_memory.retrieve_knowledge(limit=50)
        topics = self.semantic_memory.get_all_topics()
        
        return {
            "total_knowledge_entries": len(all_knowledge),
            "unique_topics": len(topics),
            "topics": topics
        }
