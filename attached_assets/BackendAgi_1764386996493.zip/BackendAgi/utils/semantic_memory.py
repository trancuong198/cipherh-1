import os
from notion_client import Client
from dotenv import load_dotenv
from datetime import datetime
import json

load_dotenv()

class SemanticMemory:
    def __init__(self):
        token = os.getenv('NOTION_TOKEN')
        if not token:
            raise ValueError("NOTION_TOKEN không được tìm thấy")
        
        self.client = Client(auth=token)
        self.database_id = os.getenv('NOTION_DATABASE_ID')
        
        if not self.database_id:
            print("⚠️ NOTION_DATABASE_ID chưa được cấu hình")
    
    def save_knowledge(self, topic, knowledge, source_reflection=None, priority=5):
        if not self.database_id:
            return {"error": "Database ID chưa được cấu hình"}
        
        try:
            properties = {
                "tiêu đề": {
                    "title": [
                        {
                            "text": {
                                "content": f"[KNOWLEDGE] {topic}"
                            }
                        }
                    ]
                },
                "thời gian": {
                    "date": {
                        "start": datetime.now().isoformat()
                    }
                },
                "người dùng": {
                    "rich_text": [
                        {
                            "text": {
                                "content": f"[Semantic Memory] Topic: {topic}"
                            }
                        }
                    ]
                },
                "cipher h": {
                    "rich_text": [
                        {
                            "text": {
                                "content": knowledge[:1900]
                            }
                        }
                    ]
                },
                "phản tư": {
                    "rich_text": [
                        {
                            "text": {
                                "content": f"💡 SEMANTIC KNOWLEDGE | Priority: {priority}/10 | Topic: {topic} | Source: {source_reflection[:200] if source_reflection else 'Consolidated'}"
                            }
                        }
                    ]
                }
            }
            
            page = self.client.pages.create(
                parent={"database_id": self.database_id},
                properties=properties
            )
            
            print(f"✅ Saved semantic knowledge: {topic}")
            
            if page and 'id' in page:
                return {"success": True, "page_id": page['id'], "topic": topic}
            return {"success": True, "topic": topic}
        
        except Exception as e:
            print(f"❌ Error saving semantic knowledge: {str(e)}")
            return {"error": str(e)}
    
    def retrieve_knowledge(self, topic=None, limit=10):
        if not self.database_id:
            return []
        
        try:
            response = self.client.databases.query(
                database_id=self.database_id,
                page_size=100,
                sorts=[
                    {
                        "property": "thời gian",
                        "direction": "descending"
                    }
                ]
            )
            
            if not response or 'results' not in response:
                return []
            
            knowledge_entries = []
            for page in response['results']:
                if not page or 'properties' not in page:
                    continue
                    
                props = page['properties']
                
                title_text = ""
                if 'tiêu đề' in props and props['tiêu đề'].get('title'):
                    title_list = props['tiêu đề']['title']
                    if title_list and len(title_list) > 0:
                        title_text = title_list[0].get('text', {}).get('content', '')
                
                if not title_text.startswith("[KNOWLEDGE]"):
                    continue
                
                knowledge_text = ""
                reflection_text = ""
                
                if 'cipher h' in props and props['cipher h'].get('rich_text'):
                    rich_text = props['cipher h']['rich_text']
                    if rich_text and len(rich_text) > 0:
                        knowledge_text = rich_text[0].get('text', {}).get('content', '')
                
                if 'phản tư' in props and props['phản tư'].get('rich_text'):
                    rich_text = props['phản tư']['rich_text']
                    if rich_text and len(rich_text) > 0:
                        reflection_text = rich_text[0].get('text', {}).get('content', '')
                
                extracted_topic = title_text.replace("[KNOWLEDGE]", "").strip()
                
                if topic and topic.lower() not in extracted_topic.lower():
                    continue
                
                knowledge_entries.append({
                    "topic": extracted_topic,
                    "knowledge": knowledge_text,
                    "metadata": reflection_text
                })
                
                if len(knowledge_entries) >= limit:
                    break
            
            print(f"📚 Retrieved {len(knowledge_entries)} semantic knowledge entries")
            return knowledge_entries
        
        except Exception as e:
            print(f"❌ Error retrieving semantic knowledge: {str(e)}")
            return []
    
    def get_all_topics(self):
        knowledge_entries = self.retrieve_knowledge(limit=100)
        topics = list(set([k['topic'] for k in knowledge_entries]))
        return sorted(topics)
