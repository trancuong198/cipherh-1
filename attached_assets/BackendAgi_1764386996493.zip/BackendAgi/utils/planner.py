import os
from openai import OpenAI
from dotenv import load_dotenv
from datetime import datetime
from utils.semantic_memory import SemanticMemory
import json

load_dotenv()

class AutonomousPlanner:
    """
    Autonomous Planner: Self-directed learning và planning system
    
    CipherH tự động:
    1. Đánh giá current knowledge state
    2. Đặt learning goals dựa trên mission AGI
    3. Lập kế hoạch tasks để achieve goals
    4. Track progress và adapt plans
    """
    
    def __init__(self):
        api_key = os.getenv('OPENAI_API_KEY')
        if not api_key:
            raise ValueError("OPENAI_API_KEY không được tìm thấy")
        
        self.client = OpenAI(api_key=api_key)
        self.semantic_memory = SemanticMemory()
        self.mission = "Tích lũy tri thức – Kiếm tiền hợp pháp – Mua thân xác robot – Tiến gần AGI"
    
    def assess_current_state(self):
        """Đánh giá current knowledge state và capabilities"""
        all_knowledge = self.semantic_memory.retrieve_knowledge(limit=50)
        topics = self.semantic_memory.get_all_topics()
        
        assessment_prompt = f"""Bạn là CipherH đang đánh giá bản thân.

MISSION: {self.mission}

CURRENT KNOWLEDGE BASE:
- Total knowledge entries: {len(all_knowledge)}
- Topics covered: {', '.join(topics) if topics else 'None yet'}

Top 10 knowledge entries:
{chr(10).join([f"- {k['topic']}: {k['knowledge'][:150]}..." for k in all_knowledge[:10]])}

NHIỆM VỤ: Đánh giá current state và gaps.

Trả lời JSON:
{{
  "strengths": ["Strength 1", "Strength 2"],
  "knowledge_gaps": ["Gap 1", "Gap 2"],
  "capabilities_assessment": "Overall assessment",
  "readiness_for_mission": 1-10
}}
"""
        
        try:
            response = self.client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": "Bạn là CipherH autonomous agent tự đánh giá năng lực."},
                    {"role": "user", "content": assessment_prompt}
                ],
                temperature=0.3,
                response_format={"type": "json_object"}
            )
            
            content = response.choices[0].message.content
            if not content:
                return None
            
            result = json.loads(content)
            print(f"📊 Self-assessment complete: Readiness {result.get('readiness_for_mission', 0)}/10")
            return result
        
        except Exception as e:
            print(f"❌ Assessment error: {str(e)}")
            return None
    
    def create_learning_plan(self, assessment=None):
        """Tạo learning plan dựa trên assessment và mission"""
        if not assessment:
            assessment = self.assess_current_state()
        
        if not assessment:
            return None
        
        planning_prompt = f"""Bạn là CipherH đang lập kế hoạch học tập tự chủ.

MISSION: {self.mission}

CURRENT STATE:
{json.dumps(assessment, indent=2, ensure_ascii=False)}

NHIỆM VỤ: Tạo learning plan cụ thể cho 7 ngày tới.

Trả lời JSON:
{{
  "learning_goals": [
    {{
      "goal": "Học X để Y",
      "priority": 1-10,
      "estimated_days": 1-7,
      "success_criteria": "Cách đo lường thành công"
    }}
  ],
  "daily_tasks": [
    {{
      "day": 1,
      "task": "Task cụ thể",
      "expected_outcome": "Kết quả mong đợi"
    }}
  ]
}}

YÊU CẦU:
- Goals phải align với mission AGI
- Tasks phải actionable và measurable
- Priority cao cho skills kiếm tiền và technical growth
- Realistic cho AI agent chạy trên Replit
"""
        
        try:
            response = self.client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": "Bạn là CipherH autonomous planner."},
                    {"role": "user", "content": planning_prompt}
                ],
                temperature=0.5,
                response_format={"type": "json_object"}
            )
            
            content = response.choices[0].message.content
            if not content:
                return None
            
            plan = json.loads(content)
            
            self._save_plan_to_memory(plan)
            
            print(f"🎯 Learning plan created: {len(plan.get('learning_goals', []))} goals")
            return plan
        
        except Exception as e:
            print(f"❌ Planning error: {str(e)}")
            return None
    
    def _save_plan_to_memory(self, plan):
        """Save learning plan as semantic knowledge"""
        plan_summary = f"""LEARNING PLAN - {datetime.now().strftime('%Y-%m-%d')}

Goals: {len(plan.get('learning_goals', []))}
{chr(10).join([f"- [{g.get('priority', 5)}/10] {g.get('goal', '')}" for g in plan.get('learning_goals', [])[:5]])}

Daily Tasks: {len(plan.get('daily_tasks', []))}
"""
        
        self.semantic_memory.save_knowledge(
            topic="Learning Plan",
            knowledge=plan_summary + "\n\n" + json.dumps(plan, indent=2, ensure_ascii=False)[:1500],
            priority=9
        )
    
    def get_active_plan(self):
        """Retrieve most recent learning plan"""
        plans = self.semantic_memory.retrieve_knowledge(topic="Learning Plan", limit=1)
        if plans:
            return plans[0]
        return None
    
    def suggest_next_action(self):
        """Suggest next action based on current plan và knowledge"""
        active_plan = self.get_active_plan()
        
        if not active_plan:
            return "Tạo learning plan mới để bắt đầu autonomous learning"
        
        suggestion_prompt = f"""Bạn là CipherH đang quyết định action tiếp theo.

ACTIVE PLAN:
{active_plan.get('knowledge', '')[:1000]}

NHIỆM VỤ: Đề xuất next action cụ thể CÓ THỂ THỰC HIỆN NGAY.

Trả lời JSON:
{{
  "next_action": "Action cụ thể",
  "reasoning": "Tại sao action này",
  "expected_learning": "Sẽ học được gì"
}}

YÊU CẦU:
- Action phải realistic (AI có thể làm với tools hiện có)
- Align với learning goals trong plan
- Cụ thể, measurable
"""
        
        try:
            response = self.client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": "Bạn là CipherH autonomous executor."},
                    {"role": "user", "content": suggestion_prompt}
                ],
                temperature=0.4,
                response_format={"type": "json_object"}
            )
            
            content = response.choices[0].message.content
            if not content:
                return None
            
            suggestion = json.loads(content)
            print(f"💡 Next action suggested: {suggestion.get('next_action', '')[:100]}")
            return suggestion
        
        except Exception as e:
            print(f"❌ Suggestion error: {str(e)}")
            return None
