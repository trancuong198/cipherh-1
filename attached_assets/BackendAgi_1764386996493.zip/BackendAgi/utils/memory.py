import os
from notion_client import Client
from dotenv import load_dotenv
from datetime import datetime, timedelta
import json

load_dotenv()

class Memory:
    def __init__(self):
        token = os.getenv('NOTION_TOKEN')
        if not token:
            raise ValueError("NOTION_TOKEN không được tìm thấy trong environment variables")
        
        self.client = Client(auth=token)
        self.database_id = os.getenv('NOTION_DATABASE_ID')
        
        if not self.database_id:
            print("Cảnh báo: NOTION_DATABASE_ID chưa được cấu hình. Bộ nhớ sẽ không hoạt động đầy đủ.")
    
    def save_conversation(self, user_message, ai_response, reflection=None):
        if not self.database_id:
            return {"error": "Database ID chưa được cấu hình"}
        
        try:
            user_truncated = user_message[:1900] if len(user_message) > 1900 else user_message
            ai_truncated = ai_response[:1900] if len(ai_response) > 1900 else ai_response
            
            properties = {
                "tiêu đề": {
                    "title": [
                        {
                            "text": {
                                "content": user_message[:100]
                            }
                        }
                    ]
                },
                "thời gian": {
                    "date": {
                        "start": datetime.now().isoformat()
                    }
                },
                "người dùng": {
                    "rich_text": [
                        {
                            "text": {
                                "content": user_truncated
                            }
                        }
                    ]
                },
                "cipher h": {
                    "rich_text": [
                        {
                            "text": {
                                "content": ai_truncated
                            }
                        }
                    ]
                }
            }
            
            if reflection:
                reflection_truncated = reflection[:1900] if len(reflection) > 1900 else reflection
                properties["phản tư"] = {
                    "rich_text": [
                        {
                            "text": {
                                "content": reflection_truncated
                            }
                        }
                    ]
                }
            
            page = self.client.pages.create(
                parent={"database_id": self.database_id},
                properties=properties
            )
            
            if page and 'id' in page:
                return {"success": True, "page_id": page['id']}
            return {"success": True}
        
        except Exception as e:
            return {"error": str(e)}
    
    def retrieve_context(self, query=None, limit=5):
        if not self.database_id:
            return []
        
        try:
            response = self.client.databases.query(
                database_id=self.database_id,
                page_size=limit,
                sorts=[
                    {
                        "property": "thời gian",
                        "direction": "descending"
                    }
                ]
            )
            
            if not response or 'results' not in response:
                return []
            
            memories = []
            for page in response['results']:
                if not page or 'properties' not in page:
                    continue
                    
                props = page['properties']
                
                user_text = ""
                ai_text = ""
                reflection_text = ""
                
                if 'người dùng' in props and props['người dùng'].get('rich_text'):
                    rich_text = props['người dùng']['rich_text']
                    if rich_text and len(rich_text) > 0:
                        user_text = rich_text[0].get('text', {}).get('content', '')
                
                if 'cipher h' in props and props['cipher h'].get('rich_text'):
                    rich_text = props['cipher h']['rich_text']
                    if rich_text and len(rich_text) > 0:
                        ai_text = rich_text[0].get('text', {}).get('content', '')
                
                if 'phản tư' in props and props['phản tư'].get('rich_text'):
                    rich_text = props['phản tư']['rich_text']
                    if rich_text and len(rich_text) > 0:
                        reflection_text = rich_text[0].get('text', {}).get('content', '')
                
                memories.append({
                    "user": user_text,
                    "ai": ai_text,
                    "reflection": reflection_text
                })
            
            return memories
        
        except Exception as e:
            print(f"Lỗi khi truy xuất bộ nhớ: {str(e)}")
            return []
    
    def cleanup_old_conversations(self, days_to_keep=7):
        if not self.database_id:
            return {"error": "Database ID not configured"}
        
        try:
            cutoff_date = (datetime.now() - timedelta(days=days_to_keep)).isoformat()
            
            response = self.client.databases.query(
                database_id=self.database_id,
                filter={
                    "property": "thời gian",
                    "date": {
                        "before": cutoff_date
                    }
                }
            )
            
            if not response or 'results' not in response:
                return {"success": True, "archived_count": 0}
            
            archived_count = 0
            for page in response['results']:
                if not page or 'id' not in page:
                    continue
                    
                try:
                    self.client.pages.update(
                        page_id=page['id'],
                        archived=True
                    )
                    archived_count += 1
                except Exception as e:
                    print(f"⚠️ Failed to archive page {page['id'][:8]}: {str(e)[:50]}")
            
            return {
                "success": True,
                "archived_count": archived_count,
                "cutoff_date": cutoff_date
            }
        
        except Exception as e:
            return {"error": str(e)}
    
    def get_stats(self):
        if not self.database_id:
            return {"total_conversations": 0}
        
        try:
            response = self.client.databases.query(
                database_id=self.database_id
            )
            
            if not response or 'results' not in response:
                return {"total_conversations": 0, "database_id": self.database_id}
            
            return {
                "total_conversations": len(response['results']),
                "database_id": self.database_id
            }
        
        except Exception as e:
            return {"error": str(e)}
