# 🚀 ADVANCED CI/CD + AUTO DEPLOY + SELF-HEALING PROMPT

**Complete automation: From code push → Testing → Deployment → Self-healing → 24/7 operation**

---

## 🎯 MISSION

Create **fully automated production pipeline** for CipherH with:
- ✅ Advanced CI/CD with automated testing
- ✅ Auto-deploy to Render on push
- ✅ Test-driven deployment (fail = rollback)
- ✅ Enhanced self-healing with recovery strategies
- ✅ Continuous stress testing
- ✅ Zero-downtime deployments
- ✅ Complete automation (Replit only for new features)

**Push code → Tests run → Deploy → Self-heal → Operate forever! 🔄**

---

## 🔧 COMPLETE CI/CD PIPELINE

### **1. GitHub Workflow Configuration**

Create `.github/workflows/ci-cd.yml`:

```yaml
name: CipherH CI/CD Pipeline

on:
  push:
    branches: [ main ]
  pull_request:
    branches: [ main ]

env:
  NODE_VERSION: '20.x'

jobs:
  test:
    name: Run Tests
    runs-on: ubuntu-latest
    
    steps:
    - name: Checkout code
      uses: actions/checkout@v3
      
    - name: Setup Node.js
      uses: actions/setup-node@v3
      with:
        node-version: ${{ env.NODE_VERSION }}
        cache: 'npm'
        cache-dependency-path: nodejs-backend/package-lock.json
        
    - name: Install dependencies
      working-directory: ./nodejs-backend
      run: npm ci
      
    - name: Run Core Tests
      working-directory: ./nodejs-backend
      run: npm run test:core
      
    - name: Run Services Tests
      working-directory: ./nodejs-backend
      run: npm run test:services
      
    - name: Run Integration Tests
      working-directory: ./nodejs-backend
      run: npm run test:integration
      
    - name: Upload test results
      if: always()
      uses: actions/upload-artifact@v3
      with:
        name: test-results
        path: nodejs-backend/test-results/
        
  build:
    name: Build Application
    needs: test
    runs-on: ubuntu-latest
    
    steps:
    - name: Checkout code
      uses: actions/checkout@v3
      
    - name: Setup Node.js
      uses: actions/setup-node@v3
      with:
        node-version: ${{ env.NODE_VERSION }}
        
    - name: Install dependencies
      working-directory: ./nodejs-backend
      run: npm ci
      
    - name: Build application
      working-directory: ./nodejs-backend
      run: npm run build
      
  deploy:
    name: Deploy to Render
    needs: build
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main' && github.event_name == 'push'
    
    steps:
    - name: Trigger Render Deployment
      run: |
        curl -X POST ${{ secrets.RENDER_DEPLOY_HOOK }}
        
    - name: Wait for deployment
      run: sleep 60
      
    - name: Health check
      run: |
        response=$(curl -s -o /dev/null -w "%{http_code}" ${{ secrets.RENDER_URL }}/health)
        if [ $response -ne 200 ]; then
          echo "Health check failed with status $response"
          exit 1
        fi
        echo "Health check passed!"
        
    - name: Notify success
      if: success()
      run: |
        echo "Deployment successful to ${{ secrets.RENDER_URL }}"
```

---

### **2. Enhanced package.json Scripts**

```json
{
  "scripts": {
    "start": "node src/server.js",
    "dev": "nodemon src/server.js",
    "build": "echo 'Build successful'",
    
    "test": "npm run test:core && npm run test:services && npm run test:integration",
    "test:core": "node tests/core.test.js",
    "test:services": "node tests/services.test.js",
    "test:integration": "node tests/integration.test.js",
    
    "stress-test": "node tests/stress-test.js",
    "stress-test-24h": "TEST_DURATION_HOURS=24 node tests/stress-test.js",
    
    "health-check": "curl http://localhost:3000/health",
    "deploy": "git push origin main"
  }
}
```

---

### **3. Core Module Tests**

Create `tests/core.test.js`:

```javascript
/**
 * Core Module Tests
 * Tests: innerLoop, soulCore, strategy, policy, taskManager, anomalyDetector
 */

const { runInnerLoop, getState } = require('../src/core/innerLoop');
const SoulCore = require('../src/core/soulCore');
const { generateStrategy } = require('../src/core/strategy');
const { evaluatePolicy } = require('../src/core/policy');
const { autoGenerateTasks } = require('../src/core/taskManager');
const { detectAnomalies } = require('../src/core/anomalyDetector');

let testsPassed = 0;
let testsFailed = 0;

function assert(condition, message) {
  if (condition) {
    console.log(`✅ PASS: ${message}`);
    testsPassed++;
  } else {
    console.log(`❌ FAIL: ${message}`);
    testsFailed++;
  }
}

async function testSoulCore() {
  console.log('\n🧠 Testing SoulCore...');
  
  const mockLogs = [
    { id: 'log_1', action: 'Test', detail: 'Test detail', status: 'success' },
    { id: 'log_2', action: 'Test2', detail: 'Test detail 2', status: 'success' }
  ];
  
  // Test learnFromLogs
  const analysis = SoulCore.learnFromLogs(mockLogs);
  assert(analysis.patterns && Array.isArray(analysis.patterns), 'SoulCore.learnFromLogs returns patterns');
  assert(analysis.insights && Array.isArray(analysis.insights), 'SoulCore.learnFromLogs returns insights');
  assert(analysis.skepticalQuestions && Array.isArray(analysis.skepticalQuestions), 'SoulCore.learnFromLogs returns questions');
  
  // Test detectAnomalies
  const anomalies = SoulCore.detectAnomalies(mockLogs);
  assert(Array.isArray(anomalies), 'SoulCore.detectAnomalies returns array');
  
  // Test generateDailyLesson
  const lesson = SoulCore.generateDailyLesson(analysis);
  assert(typeof lesson === 'string', 'SoulCore.generateDailyLesson returns string');
  assert(lesson.includes('Bài học'), 'Lesson contains Vietnamese text');
  
  // Test evaluateSelf
  const evaluation = SoulCore.evaluateSelf(analysis);
  assert(evaluation.score >= 1 && evaluation.score <= 10, 'Evaluation score is 1-10');
  assert(evaluation.status, 'Evaluation has status');
  
  // Test getSelfModel
  const model = SoulCore.getSelfModel();
  assert(model.version, 'Self model has version');
  assert(typeof model.cycleCount === 'number', 'Self model has cycleCount');
}

async function testStrategy() {
  console.log('\n📊 Testing Strategy...');
  
  const mockAnalysis = { anomalyScore: 0.1 };
  const strategy = await generateStrategy(mockAnalysis);
  
  assert(strategy.strategySummary, 'Strategy has summary');
  assert(Array.isArray(strategy.suggestedActions), 'Strategy has actions array');
  assert(strategy.timestamp, 'Strategy has timestamp');
}

async function testTaskManager() {
  console.log('\n📋 Testing TaskManager...');
  
  const mockStrategy = {
    suggestedActions: ['Action 1', 'Action 2', 'Action 3']
  };
  
  const tasks = autoGenerateTasks(mockStrategy);
  assert(Array.isArray(tasks), 'Returns tasks array');
  assert(tasks.length === 3, 'Generates correct number of tasks');
  assert(tasks[0].id, 'Tasks have IDs');
  assert(tasks[0].description, 'Tasks have descriptions');
}

async function testAnomalyDetector() {
  console.log('\n🔍 Testing AnomalyDetector...');
  
  const mockLogs = [
    { id: 'log_1', status: 'success' },
    { id: 'log_2', status: 'failed' },
    { id: 'log_3', status: 'success' }
  ];
  
  const result = detectAnomalies(mockLogs);
  assert(result.anomalies, 'Returns anomalies array');
  assert(typeof result.anomalyScore === 'number', 'Has anomaly score');
  assert(result.anomalyScore >= 0 && result.anomalyScore <= 1, 'Score is 0-1');
}

async function testInnerLoop() {
  console.log('\n🔄 Testing InnerLoop...');
  
  try {
    const result = await runInnerLoop();
    assert(result.success !== undefined, 'Returns success status');
    assert(typeof result.cycle === 'number', 'Returns cycle number');
    
    const state = getState();
    assert(state.cycles >= 0, 'State has cycles');
    assert(state.confidence >= 30 && state.confidence <= 100, 'Confidence in range');
    assert(state.doubts >= 0 && state.doubts <= 100, 'Doubts in range');
  } catch (error) {
    assert(false, `InnerLoop execution: ${error.message}`);
  }
}

async function runAllTests() {
  console.log('═══════════════════════════════════════════════');
  console.log('🧪 CIPHERH CORE MODULE TESTS');
  console.log('═══════════════════════════════════════════════');
  
  await testSoulCore();
  await testStrategy();
  await testTaskManager();
  await testAnomalyDetector();
  await testInnerLoop();
  
  console.log('\n═══════════════════════════════════════════════');
  console.log('📊 TEST RESULTS');
  console.log('═══════════════════════════════════════════════');
  console.log(`✅ Passed: ${testsPassed}`);
  console.log(`❌ Failed: ${testsFailed}`);
  console.log(`Total: ${testsPassed + testsFailed}`);
  console.log(`Success Rate: ${((testsPassed / (testsPassed + testsFailed)) * 100).toFixed(1)}%`);
  console.log('═══════════════════════════════════════════════');
  
  process.exit(testsFailed > 0 ? 1 : 0);
}

if (require.main === module) {
  runAllTests().catch(error => {
    console.error('Test suite failed:', error);
    process.exit(1);
  });
}

module.exports = { runAllTests };
```

---

### **4. Services Tests**

Create `tests/services.test.js`:

```javascript
/**
 * Services Tests
 * Tests: loggerService, notionService, openAIService
 */

const loggerService = require('../src/services/loggerService');
const notionService = require('../src/services/notionService');
const openAIService = require('../src/services/openAIService');

let testsPassed = 0;
let testsFailed = 0;

function assert(condition, message) {
  if (condition) {
    console.log(`✅ PASS: ${message}`);
    testsPassed++;
  } else {
    console.log(`❌ FAIL: ${message}`);
    testsFailed++;
  }
}

async function testLogger() {
  console.log('\n📝 Testing LoggerService...');
  
  try {
    loggerService.info('Test info message');
    loggerService.warn('Test warn message');
    loggerService.error('Test error message');
    assert(true, 'Logger accepts all log levels');
  } catch (error) {
    assert(false, `Logger error: ${error.message}`);
  }
}

async function testNotionService() {
  console.log('\n📚 Testing NotionService...');
  
  try {
    const logs = await notionService.fetchRecentLogs(5);
    assert(Array.isArray(logs), 'fetchRecentLogs returns array');
    
    const result = await notionService.appendLog({
      action: 'Test',
      detail: 'Test detail',
      status: 'test'
    });
    assert(result.success, 'appendLog succeeds');
    
    const goals = await notionService.fetchGoals();
    assert(Array.isArray(goals), 'fetchGoals returns array');
  } catch (error) {
    assert(false, `Notion service error: ${error.message}`);
  }
}

async function testOpenAIService() {
  console.log('\n🤖 Testing OpenAIService...');
  
  try {
    const mockLogs = [{ id: 'log_1', action: 'Test' }];
    const analysis = await openAIService.analyzeLogs(mockLogs);
    assert(analysis, 'analyzeLogs returns result');
    assert(analysis.timestamp, 'Analysis has timestamp');
  } catch (error) {
    assert(false, `OpenAI service error: ${error.message}`);
  }
}

async function runAllTests() {
  console.log('═══════════════════════════════════════════════');
  console.log('🧪 CIPHERH SERVICES TESTS');
  console.log('═══════════════════════════════════════════════');
  
  await testLogger();
  await testNotionService();
  await testOpenAIService();
  
  console.log('\n═══════════════════════════════════════════════');
  console.log('📊 TEST RESULTS');
  console.log('═══════════════════════════════════════════════');
  console.log(`✅ Passed: ${testsPassed}`);
  console.log(`❌ Failed: ${testsFailed}`);
  console.log(`Total: ${testsPassed + testsFailed}`);
  console.log(`Success Rate: ${((testsPassed / (testsPassed + testsFailed)) * 100).toFixed(1)}%`);
  console.log('═══════════════════════════════════════════════');
  
  process.exit(testsFailed > 0 ? 1 : 0);
}

if (require.main === module) {
  runAllTests().catch(error => {
    console.error('Test suite failed:', error);
    process.exit(1);
  });
}

module.exports = { runAllTests };
```

---

## 🔧 ENHANCED SELF-HEALING

### **Advanced server.js with Recovery Strategies**

```javascript
require('dotenv').config();
const cron = require('node-cron');
const app = require('./app');
const { runInnerLoop } = require('./core/innerLoop');
const loggerService = require('./services/loggerService');
const notionService = require('./services/notionService');

const PORT = process.env.PORT || 3000;
const HEARTBEAT_CRON = process.env.HEARTBEAT_CRON || '*/10 * * * *';

let serverInstance = null;
let cronJob = null;
let failureCount = 0;
let totalRecoveries = 0;
const MAX_FAILURES = 3;

const recoveryStrategies = [
  'immediate_retry',
  'delayed_retry',
  'graceful_degradation',
  'full_restart'
];
let currentStrategyIndex = 0;

// Enhanced self-healing with recovery strategies
async function safeRunInnerLoop() {
  try {
    loggerService.info('=== Scheduled Inner Loop Execution ===');
    const result = await runInnerLoop();
    
    if (result.success) {
      failureCount = 0; // Reset on success
      currentStrategyIndex = 0; // Reset strategy
      loggerService.info('Inner loop completed successfully', { cycle: result.cycle });
    } else {
      failureCount++;
      loggerService.warn(`Inner loop failed (${failureCount}/${MAX_FAILURES})`, { 
        error: result.error 
      });
      
      if (failureCount >= MAX_FAILURES) {
        await executeRecoveryStrategy();
      }
    }
  } catch (error) {
    failureCount++;
    loggerService.error('Inner loop exception', { 
      error: error.message, 
      count: failureCount 
    });
    
    if (failureCount >= MAX_FAILURES) {
      await executeRecoveryStrategy();
    }
  }
}

// Execute recovery strategy
async function executeRecoveryStrategy() {
  const strategy = recoveryStrategies[currentStrategyIndex];
  
  loggerService.warn(`🔧 EXECUTING RECOVERY STRATEGY: ${strategy}`);
  
  await notionService.appendLog({
    action: 'Recovery Strategy',
    detail: `Executing ${strategy} after ${failureCount} failures`,
    status: 'healing'
  });
  
  switch (strategy) {
    case 'immediate_retry':
      loggerService.info('Strategy 1: Immediate retry');
      failureCount = 0;
      await safeRunInnerLoop();
      break;
      
    case 'delayed_retry':
      loggerService.info('Strategy 2: Delayed retry (30s)');
      await new Promise(resolve => setTimeout(resolve, 30000));
      failureCount = 0;
      await safeRunInnerLoop();
      break;
      
    case 'graceful_degradation':
      loggerService.info('Strategy 3: Graceful degradation mode');
      // Run simplified version
      failureCount = 0;
      await runSimplifiedLoop();
      break;
      
    case 'full_restart':
      loggerService.info('Strategy 4: Full system restart');
      await fullSystemRestart();
      break;
  }
  
  totalRecoveries++;
  currentStrategyIndex = (currentStrategyIndex + 1) % recoveryStrategies.length;
  
  await notionService.appendLog({
    action: 'Recovery Complete',
    detail: `Strategy ${strategy} executed. Total recoveries: ${totalRecoveries}`,
    status: 'recovered'
  });
}

// Simplified loop for degraded mode
async function runSimplifiedLoop() {
  try {
    loggerService.info('Running simplified loop (degraded mode)');
    
    // Basic health check and logging only
    await notionService.appendLog({
      action: 'Simplified Loop',
      detail: 'Running in degraded mode - basic operations only',
      status: 'degraded'
    });
    
    loggerService.info('Simplified loop completed');
  } catch (error) {
    loggerService.error('Simplified loop failed', error);
  }
}

// Full system restart
async function fullSystemRestart() {
  loggerService.warn('⚠️ FULL SYSTEM RESTART INITIATED');
  
  try {
    // Stop cron
    if (cronJob) {
      cronJob.stop();
      loggerService.info('Cron job stopped');
    }
    
    // Clear memory
    if (global.gc) {
      global.gc();
      loggerService.info('Garbage collection forced');
    }
    
    // Wait 10 seconds
    await new Promise(resolve => setTimeout(resolve, 10000));
    
    // Restart cron
    cronJob = cron.schedule(HEARTBEAT_CRON, safeRunInnerLoop);
    loggerService.info('Cron job restarted');
    
    // Reset counters
    failureCount = 0;
    currentStrategyIndex = 0;
    
    // Test run
    await safeRunInnerLoop();
    
    loggerService.info('✅ FULL SYSTEM RESTART COMPLETED');
  } catch (error) {
    loggerService.error('❌ FULL SYSTEM RESTART FAILED', error);
    // Last resort: exit and let process manager restart
    process.exit(1);
  }
}

// Health monitoring endpoint enhancement
app.get('/health/detailed', (req, res) => {
  const { getState } = require('./core/innerLoop');
  const state = getState();
  
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    innerLoop: {
      status: 'ready',
      cycles: state.cycles,
      confidence: state.confidence,
      doubts: state.doubts
    },
    selfHealing: {
      failureCount,
      totalRecoveries,
      currentStrategy: recoveryStrategies[currentStrategyIndex]
    },
    uptime: process.uptime(),
    memory: process.memoryUsage()
  });
});

// Schedule cron job
loggerService.info(`Scheduling inner loop with cron: ${HEARTBEAT_CRON}`);
cronJob = cron.schedule(HEARTBEAT_CRON, safeRunInnerLoop);

// Initial run
loggerService.info('Running initial inner loop cycle...');
safeRunInnerLoop();

// Graceful shutdown
process.on('SIGTERM', async () => {
  loggerService.info('SIGTERM received, shutting down gracefully');
  
  await notionService.appendLog({
    action: 'Server Shutdown',
    detail: 'Graceful shutdown initiated',
    status: 'shutting_down'
  });
  
  if (cronJob) cronJob.stop();
  if (serverInstance) {
    serverInstance.close(() => {
      loggerService.info('Server closed');
      process.exit(0);
    });
  }
});

// Start server
serverInstance = app.listen(PORT, () => {
  loggerService.info(`Server running on port ${PORT} (Advanced Self-Healing Mode)`);
  loggerService.info(`Health check: http://localhost:${PORT}/health`);
  loggerService.info(`Detailed health: http://localhost:${PORT}/health/detailed`);
});

module.exports = serverInstance;
```

---

## 📊 DEPLOYMENT ARCHITECTURE

```
┌─────────────────────────────────────────────────────────────┐
│         ADVANCED CI/CD + AUTO DEPLOY ARCHITECTURE            │
│                                                               │
│  DEVELOPER                                                    │
│      ↓                                                        │
│  git push origin main                                        │
│      ↓                                                        │
│  ┌──────────────────────────────────────────────────────┐   │
│  │  GITHUB ACTIONS                                      │   │
│  │                                                        │   │
│  │  Job 1: TEST                                          │   │
│  │  ├─ Checkout code                                    │   │
│  │  ├─ Install dependencies                             │   │
│  │  ├─ Run core tests (core.test.js)                   │   │
│  │  ├─ Run services tests (services.test.js)           │   │
│  │  └─ Run integration tests                           │   │
│  │      ↓                                                │   │
│  │  [PASS] ──→ Job 2: BUILD                            │   │
│  │  [FAIL] ──→ STOP (No deploy)                        │   │
│  │                                                        │   │
│  │  Job 2: BUILD                                         │   │
│  │  ├─ Checkout code                                    │   │
│  │  ├─ Install dependencies                             │   │
│  │  └─ Build application                                │   │
│  │      ↓                                                │   │
│  │  Job 3: DEPLOY                                        │   │
│  │  ├─ Trigger Render webhook                           │   │
│  │  ├─ Wait for deployment (60s)                        │   │
│  │  └─ Health check                                     │   │
│  │      ↓                                                │   │
│  │  [SUCCESS] ──→ Production Live                       │   │
│  │  [FAIL] ──→ Rollback + Notify                       │   │
│  └──────────────────────────────────────────────────────┘   │
│      ↓                                                        │
│  ┌──────────────────────────────────────────────────────┐   │
│  │  RENDER (Production)                                  │   │
│  │                                                        │   │
│  │  ├─ Auto pull from GitHub                            │   │
│  │  ├─ npm install                                       │   │
│  │  ├─ npm start                                         │   │
│  │  └─ Server running (port 3000)                       │   │
│  │      ↓                                                │   │
│  │  Inner Loop (14-19 steps) every 10 min              │   │
│  │      ↓                                                │   │
│  │  Self-Healing Active                                  │   │
│  │  ├─ Strategy 1: Immediate retry                      │   │
│  │  ├─ Strategy 2: Delayed retry                        │   │
│  │  ├─ Strategy 3: Graceful degradation                 │   │
│  │  └─ Strategy 4: Full restart                         │   │
│  │      ↓                                                │   │
│  │  24/7 Operation                                       │   │
│  └──────────────────────────────────────────────────────┘   │
│                                                               │
└─────────────────────────────────────────────────────────────┘
```

---

## 🎯 COMPLETE AUTOMATION CHECKLIST

### Phase 1: Setup
- ✅ Create GitHub repository
- ✅ Add `.github/workflows/ci-cd.yml`
- ✅ Add test files (`core.test.js`, `services.test.js`)
- ✅ Configure Render deploy hook
- ✅ Add GitHub secrets (RENDER_DEPLOY_HOOK, RENDER_URL)

### Phase 2: Testing
- ✅ Run tests locally: `npm test`
- ✅ Verify all tests pass
- ✅ Test GitHub Actions workflow
- ✅ Verify auto-deploy on push

### Phase 3: Self-Healing
- ✅ Enhanced server.js with 4 recovery strategies
- ✅ Health endpoint monitoring
- ✅ Failure tracking and recovery
- ✅ Notion logging for all recovery events

### Phase 4: Production
- ✅ Deploy to Render
- ✅ Verify cron job running
- ✅ Monitor health endpoints
- ✅ Test self-healing (simulate failures)
- ✅ Verify 24/7 operation

---

## 💰 COST BREAKDOWN

```
Monthly Costs:
- Render Starter: $7/month (always-on, auto-deploy)
- GitHub Actions: $0/month (2,000 free minutes)
- OpenAI API: ~$10/month (optional, with learning modules)
- Notion: $0/month (free tier)
────────────────────────────
Total: ~$17-19/month ✅ (under $25 budget)
```

---

## 🎊 FINAL OUTCOME

**Complete Automation Achieved:**

✅ **CI/CD Pipeline**: Test → Build → Deploy on every push
✅ **Auto Deploy**: Render auto-deploys from GitHub main
✅ **Test-Driven**: Deployment only if tests pass
✅ **Self-Healing**: 4 recovery strategies, automatic recovery
✅ **Stress Testing**: Continuous validation
✅ **Zero Downtime**: Graceful degradation on failures
✅ **Complete Logging**: All events logged to Notion
✅ **Budget Compliant**: ~$19/month (under $25)

**Replit now only needed for:**
- Writing new features
- Fixing critical bugs
- Everything else: FULLY AUTOMATED! 🚀

---

**PUSH CODE → TESTS RUN → AUTO DEPLOY → SELF-HEAL → OPERATE FOREVER! ✨**
