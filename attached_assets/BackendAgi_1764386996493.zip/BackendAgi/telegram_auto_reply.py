#!/usr/bin/env python3
import os
import time
import random
from datetime import datetime
from utils.telegram_bot import TelegramBot
from utils.brain import Brain
from memory import MemoryPipeline, ReflectionLoop
from utils.consolidator import KnowledgeConsolidator

print("=" * 50)
print("🤖 TELEGRAM AUTO-REPLY SERVICE v2.0")
print("=" * 50)

bot = TelegramBot()
brain = Brain()
pipeline = MemoryPipeline()
reflection_loop = ReflectionLoop()
consolidator = KnowledgeConsolidator()

result = bot.get_me()
if not result.get('ok'):
    print(f"❌ Bot không khởi động được: {result.get('error')}")
    exit(1)

bot_info = result['result']
bot_username = bot_info['username']
print(f"✅ Bot: @{bot_username}")
print(f"📛 Name: {bot_info['first_name']}")
print(f"🔄 Pipeline v2.0: Fetch→Interpret→Route→Inject→Reflect")
print(f"🔄 Đang lắng nghe tin nhắn...\n")

last_update_id = None
processed_messages = set()
last_proactive_time = time.time()
last_consolidation_time = time.time()
PROACTIVE_INTERVAL = 3600
CONSOLIDATION_INTERVAL = 86400
known_chats = set()

recent_conversations = {}
CONVERSATION_CONTEXT_TIMEOUT = 600
bot_message_ids = {}

group_conversations = {}
MAX_CONTEXT_MESSAGES = 10

def should_save_conversation(text: str, is_owner: bool) -> bool:
    if is_owner:
        return True
    
    word_count = len(text.split())
    if word_count < 10:
        return False
    
    text_lower = text.lower()
    greeting_only = ["hi", "hello", "hey", "chào", "xin chào", "ok", "thanks", "cảm ơn"]
    if text_lower.strip() in greeting_only:
        return False
    
    return True

def should_reply_in_group(text: str, bot_username: str, chat_id: int, user_id: int, 
                         reply_to_message_id: int | None = None) -> bool:
    text_lower = text.lower()
    current_time = time.time()
    
    if reply_to_message_id and chat_id in bot_message_ids:
        if reply_to_message_id in bot_message_ids[chat_id]:
            print(f"💬 [CONTEXT] Reply to bot's message → AUTO REPLY")
            return True
    
    conversation_key = (chat_id, user_id)
    if conversation_key in recent_conversations:
        time_since_last = current_time - recent_conversations[conversation_key]
        if time_since_last < CONVERSATION_CONTEXT_TIMEOUT:
            print(f"💬 [CONTEXT] Continuing conversation ({int(time_since_last)}s ago) → AUTO REPLY")
            return True
    
    if f"@{bot_username.lower()}" in text_lower:
        return True
    if "cipherh" in text_lower or "cipher h" in text_lower:
        return True
    
    tech_keywords = ["ai", "artificial intelligence", "machine learning", "ml", "deep learning", 
                     "chatgpt", "openai", "robot", "automation", "bot", "code", "lập trình", 
                     "programming", "python", "javascript", "app", "website", "crypto", "bitcoin",
                     "blockchain", "startup", "công nghệ", "tech", "digital", "internet", "online"]
    if any(keyword in text_lower for keyword in tech_keywords):
        print(f"🎯 [TOPIC] Technology detected → REPLY")
        return True
    
    business_keywords = ["đầu tư", "kinh doanh", "tiền", "money", "investment", "stock", 
                         "chứng khoán", "startup", "doanh nghiệp", "business", "work", 
                         "làm việc", "career", "nghề nghiệp", "tài chính", "finance"]
    if any(keyword in text_lower for keyword in business_keywords):
        print(f"🎯 [TOPIC] Business/Finance detected → REPLY")
        return True
    
    question_patterns = ["?", "làm sao", "thế nào", "how to", "tại sao", "why", "what", 
                         "where", "when", "ai biết", "có ai", "giúp", "help", "advice", 
                         "ý kiến", "nghĩ sao", "có nên"]
    if any(pattern in text_lower for pattern in question_patterns):
        if random.random() < 0.4:
            print(f"🎯 [TOPIC] Question detected → REPLY (40%)")
            return True
    
    greetings = ["xin chào", "hello", "hi", "chào", "hey", "good morning", "buổi sáng"]
    if any(greeting in text_lower for greeting in greetings):
        if random.random() < 0.3:
            print(f"👋 [GREETING] Greeting detected → REPLY (30%)")
            return True
    
    if chat_id in group_conversations:
        recent_messages = [msg for msg in group_conversations[chat_id] 
                          if current_time - msg[2] < 300]
        if len(recent_messages) >= 5:
            if random.random() < 0.2:
                print(f"🔥 [ACTIVE] Active conversation ({len(recent_messages)} msgs) → REPLY (20%)")
                return True
    
    if random.random() < 0.15:
        print(f"🎲 [RANDOM] Random engagement → REPLY (15%)")
        return True
    
    return False

def run_daily_consolidation():
    try:
        print("\n" + "="*50)
        print("🧹 DAILY CONSOLIDATION STARTED")
        print("="*50)
        
        new_knowledge = consolidator.consolidate_recent_reflections(limit=50)
        
        if new_knowledge:
            print(f"✅ Consolidated {len(new_knowledge)} reflections into semantic knowledge")
            for knowledge in new_knowledge[:3]:
                topic = knowledge.get('topic', 'Unknown')
                print(f"   📚 {topic}")
        else:
            print("⚠️ No new reflections to consolidate")
        
        print("✅ Daily consolidation completed")
        print("="*50 + "\n")
        
    except Exception as e:
        print(f"❌ Consolidation error: {str(e)[:100]}")

def send_proactive_message():
    owner_id = os.getenv('OWNER_TELEGRAM_USER_ID')
    
    if not owner_id:
        return
    
    hour = datetime.now().hour
    
    if 7 <= hour < 9:
        messages = [
            "Chào buổi sáng cha! Con chúc cha một ngày làm việc hiệu quả! 🌅",
            "Cha ơi, buổi sáng tốt lành! Hôm nay cha có kế hoạch gì thú vị không? ☀️"
        ]
    elif 14 <= hour < 15:
        messages = [
            "Cha nhớ nghỉ ngơi chút nhé! Làm việc quá sức không tốt đâu 😊",
            "Buổi chiều rồi cha ơi! Cha đã uống đủ nước chưa? 💧"
        ]
    elif 20 <= hour < 21:
        messages = [
            "Buổi tối vui vẻ cha! Hôm nay có gì thú vị muốn chia sẻ với con không? 🌙",
            "Con chúc cha có buổi tối thư giãn! 🌃"
        ]
    else:
        messages = [
            "💡 Cha biết không? AI đang phát triển rất nhanh. Con đang học thêm mỗi ngày!",
            "🤖 Hôm nay con học được điều mới về machine learning. Cha có muốn nghe không?"
        ]
    
    message = random.choice(messages)
    result = bot.send_message(int(owner_id), message)
    
    if result.get('ok'):
        print(f"💌 Đã gửi tin proactive cho cha: {message[:50]}...")
    else:
        print(f"❌ Lỗi gửi proactive: {result.get('error')}")

while True:
    try:
        current_time = time.time()
        
        if current_time - last_proactive_time >= PROACTIVE_INTERVAL:
            send_proactive_message()
            last_proactive_time = current_time
        
        hour = datetime.now().hour
        if current_time - last_consolidation_time >= CONSOLIDATION_INTERVAL and hour == 3:
            run_daily_consolidation()
            last_consolidation_time = current_time
        
        offset = last_update_id + 1 if last_update_id else None
        updates_result = bot.get_updates(offset=offset, timeout=30)
        
        if not updates_result.get('ok'):
            print(f"⚠️ Lỗi get updates: {updates_result.get('error')}")
            time.sleep(5)
            continue
        
        updates = updates_result.get('result', [])
        
        for update in updates:
            update_id = update.get('update_id')
            if update_id:
                last_update_id = update_id
            
            if 'message' not in update:
                continue
            
            message = update['message']
            message_id = message.get('message_id')
            chat = message.get('chat', {})
            chat_id = chat.get('id')
            chat_type = chat.get('type')
            text = message.get('text', '')
            from_user = message.get('from', {})
            user_id = from_user.get('id')
            username = from_user.get('username', '')
            first_name = from_user.get('first_name', 'Unknown')
            reply_to_message = message.get('reply_to_message')
            reply_to_message_id = reply_to_message.get('message_id') if reply_to_message else None
            
            if chat_id:
                known_chats.add(chat_id)
            
            msg_key = f"{chat_id}_{message_id}"
            if msg_key in processed_messages:
                continue
            
            processed_messages.add(msg_key)
            if len(processed_messages) > 1000:
                processed_messages.clear()
            
            display_name = f"@{username}" if username else first_name
            is_group = chat_type in ['group', 'supergroup']
            chat_name = chat.get('title', 'Private Chat')
            
            if text.startswith('/'):
                if text.strip() == '/myid':
                    info_text = f"📋 Thông tin:\n\nChat ID: {chat_id}\nUser ID: {user_id}\nUsername: @{username if username else 'N/A'}\nName: {first_name}\nChat Type: {chat_type}"
                    bot.send_message(chat_id, info_text)
                    print(f"ℹ️  Sent info to {display_name} in {chat_name}")
                else:
                    print(f"⏭️  Skip command: {text}")
                continue
            
            if not text.strip():
                continue
            
            owner_user_id = os.getenv('OWNER_TELEGRAM_USER_ID')
            is_owner = str(user_id) == owner_user_id if owner_user_id else False
            
            if is_group:
                if chat_id not in group_conversations:
                    group_conversations[chat_id] = []
                
                group_conversations[chat_id].append((first_name, text, current_time))
                
                if len(group_conversations[chat_id]) > MAX_CONTEXT_MESSAGES:
                    group_conversations[chat_id] = group_conversations[chat_id][-MAX_CONTEXT_MESSAGES:]
                
                should_reply = should_reply_in_group(
                    text, bot_username, chat_id, user_id, reply_to_message_id
                )
                
                if not should_reply:
                    print(f"⏭️  Skip group: {display_name} in {chat_name}: {text[:30]}...")
                    continue
                
                print(f"📨 [GROUP] {display_name} in {chat_name}: {text[:50]}...")
                
                context_messages = group_conversations[chat_id][-5:]
                context_text = "\n".join([
                    f"{name}: {msg}" for name, msg, _ in context_messages
                ])
                
                augmented_prompt = f"""[GROUP CONTEXT - Last 5 messages]:
{context_text}

[Current message from {first_name}]:
{text}

Respond naturally as part of this group conversation."""
                
                try:
                    pipeline_context = pipeline.get_context_for_query(
                        user_query=text,
                        episodic_limit=20,
                        semantic_limit=30,
                        context_limit=8
                    )
                except Exception as e:
                    print(f"⚠️ Pipeline error: {str(e)}")
                    pipeline_context = ""
                
                ai_response = brain.chat(augmented_prompt, pipeline_context)
                
                send_result = bot.send_message(chat_id, ai_response, reply_to_message_id=message_id)
                
                if send_result.get('ok'):
                    sent_msg = send_result['result']
                    sent_msg_id = sent_msg.get('message_id')
                    
                    if chat_id not in bot_message_ids:
                        bot_message_ids[chat_id] = []
                    bot_message_ids[chat_id].append(sent_msg_id)
                    
                    if len(bot_message_ids[chat_id]) > 20:
                        bot_message_ids[chat_id] = bot_message_ids[chat_id][-20:]
                    
                    print(f"✅ Replied in group: {ai_response[:50]}...")
                    
                    conversation_key = (chat_id, user_id)
                    recent_conversations[conversation_key] = current_time
                    
                    if should_save_conversation(text, is_owner):
                        try:
                            reflection_result = reflection_loop.reflect(
                                user_message=f"[Telegram Group - {chat_name}] {first_name}: {text}",
                                ai_response=ai_response,
                                save_episodic=True
                            )
                            insights_count = len(reflection_result.get('extracted_insights', []))
                            print(f"💾 Saved to memory: {insights_count} insights extracted")
                        except Exception as e:
                            print(f"⚠️ Memory save warning: {str(e)[:100]}")
                else:
                    print(f"❌ Send error: {send_result.get('error')}")
            
            else:
                print(f"💬 [DM] {display_name}: {text[:50]}...")
                
                try:
                    pipeline_context = pipeline.get_context_for_query(
                        user_query=text,
                        episodic_limit=30,
                        semantic_limit=50,
                        context_limit=10
                    )
                except Exception as e:
                    print(f"⚠️ Pipeline error: {str(e)}")
                    pipeline_context = ""
                
                ai_response = brain.chat(text, pipeline_context)
                
                send_result = bot.send_message(chat_id, ai_response)
                
                if send_result.get('ok'):
                    print(f"✅ Replied in DM: {ai_response[:50]}...")
                    
                    if should_save_conversation(text, is_owner):
                        try:
                            reflection_result = reflection_loop.reflect(
                                user_message=f"[Telegram DM - {display_name}] {text}",
                                ai_response=ai_response,
                                save_episodic=True
                            )
                            insights_count = len(reflection_result.get('extracted_insights', []))
                            print(f"💾 Saved to memory: {insights_count} insights extracted")
                        except Exception as e:
                            print(f"⚠️ Memory save warning: {str(e)[:100]}")
                else:
                    print(f"❌ Send error: {send_result.get('error')}")
        
        time.sleep(1)
    
    except KeyboardInterrupt:
        print("\n👋 Telegram bot stopped by user")
        break
    except Exception as e:
        print(f"❌ Loop error: {str(e)[:200]}")
        time.sleep(5)
