# 🏗️ CIPHERH BACKEND - ARCHITECTURE BLUEPRINT

**Visual guide to understand the complete CipherH backend architecture**

---

## 🎯 OVERVIEW

```
┌─────────────────────────────────────────────────────────────────┐
│                    CIPHERH SOUL LOOP BACKEND                     │
│                 Autonomous AI Agent 24/7 Operation               │
│                                                                   │
│  ┌──────────┐    ┌──────────┐    ┌──────────┐    ┌──────────┐  │
│  │  Notion  │ ←→ │   Inner  │ ←→ │  Modules │ ←→ │  OpenAI  │  │
│  │ Database │    │   Loop   │    │   Core   │    │  Service │  │
│  └──────────┘    └──────────┘    └──────────┘    └──────────┘  │
│                         ↕                                         │
│                   ┌──────────┐                                   │
│                   │  Logger  │                                   │
│                   │ Service  │                                   │
│                   └──────────┘                                   │
└─────────────────────────────────────────────────────────────────┘
```

**Budget:** $17-20/month | **Uptime:** 24/7 | **Cron:** Every 10 minutes

---

## 📊 COMPLETE ARCHITECTURE DIAGRAM

```
┌──────────────────────────────────────────────────────────────────────────┐
│                          EXTERNAL SERVICES                                │
│  ┌─────────────────────┐              ┌─────────────────────┐           │
│  │   Notion Database   │              │   OpenAI API        │           │
│  │  ─────────────────  │              │  ─────────────────  │           │
│  │  • Logs             │              │  • GPT-4            │           │
│  │  • Lessons          │              │  • Analysis         │           │
│  │  • Tasks            │              │  • Strategy Gen     │           │
│  │  • Strategy         │              │  • Improvements     │           │
│  │  • Anomalies        │              └─────────┬───────────┘           │
│  │  • Discrepancies    │                        │                        │
│  └──────────┬──────────┘                        │                        │
│             │                                    │                        │
└─────────────┼────────────────────────────────────┼────────────────────────┘
              │                                    │
              │ Read/Write                         │ Analyze/Generate
              ↓                                    ↓
┌──────────────────────────────────────────────────────────────────────────┐
│                            SERVICES LAYER                                 │
│                                                                           │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐         │
│  │ notionService   │  │ openAIService   │  │ loggerService   │         │
│  │ ─────────────── │  │ ─────────────── │  │ ─────────────── │         │
│  │ • fetchLogs()   │  │ • analyzeLogs() │  │ • info()        │         │
│  │ • writeLesson() │  │ • genStrategy() │  │ • warn()        │         │
│  │ • writeTasks()  │  │ • suggest()     │  │ • error()       │         │
│  │ • writeStrategy │  │ • placeholder   │  │ • debug()       │         │
│  │ • writeDiscrep  │  │   mode OK       │  │ • console+file  │         │
│  │ • fetchGoals()  │  └─────────────────┘  └─────────────────┘         │
│  │ • placeholder   │                                                     │
│  │   mode OK       │                                                     │
│  └────────┬────────┘                                                     │
│           │                                                               │
└───────────┼───────────────────────────────────────────────────────────────┘
            │
            │ Provide data & log everything
            ↓
┌──────────────────────────────────────────────────────────────────────────┐
│                          CORE LAYER - INNER LOOP                         │
│                         (Heart of CipherH - 14 Steps)                    │
│                                                                           │
│  ╔═══════════════════════════════════════════════════════════════════╗  │
│  ║                        INNER LOOP CYCLE                            ║  │
│  ║                       (Runs every 10 min)                          ║  │
│  ╠═══════════════════════════════════════════════════════════════════╣  │
│  ║                                                                     ║  │
│  ║  Step 1:  Đọc logs từ Notion (10 items)                           ║  │
│  ║           ↓                                                         ║  │
│  ║  Step 2:  Phân tích với SoulCore (8 methods)                      ║  │
│  ║           • learnFromLogs() → patterns, insights                   ║  │
│  ║           ↓                                                         ║  │
│  ║  Step 3:  Phát hiện bất thường (dual system)                      ║  │
│  ║           • System anomalies + Soul anomalies                      ║  │
│  ║           ↓                                                         ║  │
│  ║  Step 4:  Rút quy luật và bài học                                 ║  │
│  ║           • generateDailyLesson() → markdown                       ║  │
│  ║           ↓                                                         ║  │
│  ║  Step 5:  Viết bài học vào Notion                                 ║  │
│  ║           ↓                                                         ║  │
│  ║  Step 6:  Tự đánh giá (1-10 score)                               ║  │
│  ║           • evaluateSelf() → score, status, warnings               ║  │
│  ║           ↓                                                         ║  │
│  ║  Step 7:  So sánh với mục tiêu dài hạn                           ║  │
│  ║           • compareWithGoals() → alignment score, gaps             ║  │
│  ║           ↓                                                         ║  │
│  ║  Step 8:  Tạo chiến lược (dual: soul + system)                   ║  │
│  ║           • refineStrategy() + generateStrategy()                  ║  │
│  ║           ↓                                                         ║  │
│  ║  Step 9:  Tự tạo nhiệm vụ tuần/tháng                             ║  │
│  ║           • proposeNewTasks() + autoGenerateTasks()                ║  │
│  ║           ↓                                                         ║  │
│  ║  Step 10: Tự hoài nghi - phát hiện discrepancies                 ║  │
│  ║           • detectDiscrepancies() → check 5 conditions             ║  │
│  ║           ↓                                                         ║  │
│  ║  Step 11: Đánh giá hiệu quả modules                              ║  │
│  ║           • generateModuleReport() → health status                 ║  │
│  ║           ↓                                                         ║  │
│  ║  Step 12: Tự củng cố và cải thiện                                ║  │
│  ║           • selfReinforce() → improvement tasks                    ║  │
│  ║           ↓                                                         ║  │
│  ║  Step 13: So sánh với bài học vòng trước                         ║  │
│  ║           • compareProgress() → trend analysis                     ║  │
│  ║           ↓                                                         ║  │
│  ║  Step 14: Cập nhật trạng thái backend                            ║  │
│  ║           • updateState() → confidence, doubts, discrepancies      ║  │
│  ║           • Write all to Notion                                    ║  │
│  ║                                                                     ║  │
│  ╚═══════════════════════════════════════════════════════════════════╝  │
│                                                                           │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │                     CORE MODULES SUPPORT                         │   │
│  │                                                                   │   │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐          │   │
│  │  │  SoulCore    │  │  Strategy    │  │TaskManager   │          │   │
│  │  │  450 lines   │  │  Generator   │  │  CRUD ops    │          │   │
│  │  │  8 methods   │  │  Dual system │  │  In-memory   │          │   │
│  │  │  Pure JS     │  │              │  │              │          │   │
│  │  └──────────────┘  └──────────────┘  └──────────────┘          │   │
│  │                                                                   │   │
│  │  ┌──────────────┐  ┌──────────────┐                            │   │
│  │  │  Anomaly     │  │   Policy     │                            │   │
│  │  │  Detector    │  │  Evaluator   │                            │   │
│  │  │  Dual system │  │              │                            │   │
│  │  └──────────────┘  └──────────────┘                            │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                           │
└───────────────────────────────────────────┬───────────────────────────────┘
                                            │
                                            │ Expose via API
                                            ↓
┌──────────────────────────────────────────────────────────────────────────┐
│                       CONTROLLER & ROUTES LAYER                          │
│                                                                           │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │                      coreController.js                           │   │
│  │  ─────────────────────────────────────────────────────────────  │   │
│  │  • runLoop()       → Trigger Inner Loop manually                │   │
│  │  • getStatus()     → Return current state                       │   │
│  │  • getTasks()      → Return task list                           │   │
│  │  • getStrategy()   → Return current strategy                    │   │
│  │  • getAnomalies()  → Return anomaly detection results           │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                           │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │                        coreRoutes.js                             │   │
│  │  ─────────────────────────────────────────────────────────────  │   │
│  │  GET /core/run-loop   → coreController.runLoop                  │   │
│  │  GET /core/status     → coreController.getStatus                │   │
│  │  GET /core/tasks      → coreController.getTasks                 │   │
│  │  GET /core/strategy   → coreController.getStrategy              │   │
│  │  GET /core/anomalies  → coreController.getAnomalies             │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                           │
└───────────────────────────────────────┬───────────────────────────────────┘
                                        │
                                        │ Mount routes
                                        ↓
┌──────────────────────────────────────────────────────────────────────────┐
│                        APPLICATION LAYER                                 │
│                                                                           │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │                          app.js                                  │   │
│  │  ─────────────────────────────────────────────────────────────  │   │
│  │  • Express setup                                                 │   │
│  │  • Middleware (json parser)                                      │   │
│  │  • GET / → Welcome message                                       │   │
│  │  • GET /health → Health check + Inner Loop status               │   │
│  │  • Mount /core routes                                            │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                           │
└───────────────────────────────────────┬───────────────────────────────────┘
                                        │
                                        │ Start server
                                        ↓
┌──────────────────────────────────────────────────────────────────────────┐
│                          SERVER LAYER                                    │
│                                                                           │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │                        server.js                                 │   │
│  │  ─────────────────────────────────────────────────────────────  │   │
│  │  • Load .env configuration                                       │   │
│  │  • Setup cron job (node-cron):                                   │   │
│  │    ┌──────────────────────────────────────────────────────┐    │   │
│  │    │  HEARTBEAT_CRON = */10 * * * *                       │    │   │
│  │    │  ↓                                                    │    │   │
│  │    │  Execute: await runInnerLoop()                       │    │   │
│  │    │  ↓                                                    │    │   │
│  │    │  Log: "Scheduled Inner Loop Execution"               │    │   │
│  │    │  ↓                                                    │    │   │
│  │    │  Repeat every 10 minutes → 24/7 operation            │    │   │
│  │    └──────────────────────────────────────────────────────┘    │   │
│  │  • Run initial Inner Loop cycle on startup                      │   │
│  │  • Listen on PORT (default: 3000)                               │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                           │
└──────────────────────────────────────────────────────────────────────────┘
```

---

## 🔄 DATA FLOW DIAGRAM

### Complete Flow: From External → Processing → Storage

```
┌─────────────────────────────────────────────────────────────────────────┐
│                         DATA FLOW CYCLE                                  │
│                                                                           │
│  1. FETCH DATA                                                            │
│     Notion Database → notionService.fetchRecentLogs(10)                  │
│                    → [log1, log2, ..., log10]                            │
│                    → innerLoop (Step 1)                                  │
│                                                                           │
│  2. ANALYZE                                                               │
│     innerLoop → SoulCore.learnFromLogs(logs)                            │
│              → Extract patterns, insights, questions                     │
│              → { patterns: [], insights: [], skepticalQuestions: [] }   │
│                                                                           │
│  3. DETECT ANOMALIES (Dual System)                                       │
│     innerLoop → anomalyDetector.detectAnomalies(logs)                   │
│              → Check status !== 'success'                                │
│              → { anomalies: [], anomalyScore: 0.00 }                    │
│              +                                                            │
│              → SoulCore.detectAnomalies(logs)                           │
│              → Pure logic checks                                         │
│              → [anomaly1, anomaly2, ...]                                │
│                                                                           │
│  4. GENERATE LESSON                                                       │
│     innerLoop → SoulCore.generateDailyLesson(analysis)                  │
│              → Create markdown lesson                                    │
│              → "# Bài học rút ra hôm nay..."                            │
│                                                                           │
│  5. WRITE TO NOTION                                                       │
│     innerLoop → notionService.writeLesson(lesson)                       │
│              → appendLog({ action: 'Lesson Learned', ... })             │
│              → Notion Database [new entry]                               │
│                                                                           │
│  6. SELF-EVALUATION                                                       │
│     innerLoop → SoulCore.evaluateSelf(analysis)                         │
│              → Calculate score (1-10)                                    │
│              → { score: 7, status: 'good', warnings: [] }               │
│                                                                           │
│  7. GOAL ALIGNMENT                                                        │
│     innerLoop → notionService.fetchGoals()                              │
│              → ['Goal 1', 'Goal 2', 'Goal 3']                           │
│              → compareWithGoals(goals, analysis, evaluation)             │
│              → { alignmentScore: 85, gaps: [...], recommendations: [] } │
│                                                                           │
│  8. STRATEGY GENERATION (Dual System)                                    │
│     innerLoop → SoulCore.refineStrategy(analysis)                       │
│              → { shortTermPlan, longTermPlan, requiredActions }         │
│              +                                                            │
│              → strategy.generateStrategy(fullAnalysis)                   │
│              → { strategySummary, suggestedActions }                     │
│              → Combined Strategy                                         │
│                                                                           │
│  9. TASK GENERATION (Dual System)                                        │
│     innerLoop → SoulCore.proposeNewTasks(analysis)                      │
│              → [task1, task2, task3]                                    │
│              +                                                            │
│              → taskManager.autoGenerateTasks(strategy)                   │
│              → [task4, task5, task6]                                    │
│              → All tasks merged                                          │
│              → notionService.writeTasks(tasks)                          │
│                                                                           │
│  10. SELF-DOUBT (NEW)                                                     │
│     innerLoop → detectDiscrepancies(analysis, strategy, goals, ...)     │
│              → Check 5 conditions:                                       │
│                 • Goal alignment < 60%                                   │
│                 • Low score + high anomalies                             │
│                 • No tasks generated                                     │
│                 • Module success rate < 80%                              │
│                 • Doubts > 70                                            │
│              → [discrepancy1, discrepancy2, ...]                        │
│                                                                           │
│  11. MODULE EVALUATION (NEW)                                              │
│     innerLoop → generateModuleReport()                                   │
│              → Check state.modulePerformance                             │
│              → { strategy: {successRate, errors, status}, ... }         │
│                                                                           │
│  12. SELF-REINFORCEMENT (NEW)                                             │
│     innerLoop → selfReinforce(discrepancies, moduleReport)              │
│              → Critical → daily tasks                                    │
│              → High → weekly tasks                                       │
│              → Module degraded → debug tasks                             │
│              → [improvementTask1, improvementTask2, ...]                │
│              → notionService.writeTasks(improvementTasks)               │
│                                                                           │
│  13. PROGRESS COMPARISON (NEW)                                            │
│     innerLoop → compareProgress(currentLesson, lastLesson, evaluation)  │
│              → Calculate scoreDiff, confidenceDiff                       │
│              → Determine trend: improving/stable/degrading               │
│              → { trend, improvement, message, scoreDiff, ... }          │
│                                                                           │
│  14. STATE UPDATE                                                         │
│     innerLoop → SoulCore.updateSelfModel(analysis)                      │
│              → Bump version, increment cycle, update strengths/weaknesses│
│              → updateState(analysis, strategy, evaluation, ...)         │
│              → Adjust confidence (30-100)                                │
│              → Adjust doubts (0-100)                                     │
│              → Save discrepancies (last 20)                              │
│              → notionService.writeStrategy(strategy)                     │
│              → notionService.writeBehaviorUpdate(...)                    │
│              → notionService.writeDiscrepancies(...)                     │
│                                                                           │
│  15. SELF-QUESTIONING                                                     │
│     innerLoop → SoulCore.askSelfQuestions(analysis)                     │
│              → Generate 3-7 philosophical questions                      │
│              → Log questions                                             │
│                                                                           │
│  16. CYCLE COMPLETE                                                       │
│     innerLoop → loggerService.info('CYCLE N - COMPLETED')               │
│              → Return { success: true, cycle: N, stats: {...} }         │
│                                                                           │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## ⏰ CRON JOB FLOW

### 24/7 Autonomous Operation

```
┌─────────────────────────────────────────────────────────────┐
│                    CRON JOB TIMELINE                         │
│                                                               │
│  Time 00:00  →  Initial startup                              │
│      ↓                                                        │
│      └─→ Run Inner Loop Cycle 1                              │
│          (Takes ~1-2 seconds)                                │
│          ↓                                                    │
│          Success → Log "CYCLE 1 COMPLETED"                   │
│                                                               │
│  Time 00:10  →  Cron trigger (HEARTBEAT_CRON)                │
│      ↓                                                        │
│      └─→ Run Inner Loop Cycle 2                              │
│          ↓                                                    │
│          Success → Log "CYCLE 2 COMPLETED"                   │
│                                                               │
│  Time 00:20  →  Cron trigger                                 │
│      ↓                                                        │
│      └─→ Run Inner Loop Cycle 3                              │
│                                                               │
│  ...every 10 minutes...                                      │
│                                                               │
│  Time 23:50  →  Cron trigger                                 │
│      ↓                                                        │
│      └─→ Run Inner Loop Cycle 144 (last of day)             │
│                                                               │
│  ┌────────────────────────────────────────────────────┐     │
│  │  Total cycles per day: 144 (24 hours × 6/hour)     │     │
│  │  Total cycles per month: ~4,320                     │     │
│  │  Total cycles per year: ~52,560                     │     │
│  └────────────────────────────────────────────────────┘     │
│                                                               │
│  ERROR HANDLING:                                             │
│  ┌────────────────────────────────────────────────────┐     │
│  │  If Inner Loop fails:                               │     │
│  │    1. Log error with details                        │     │
│  │    2. Return {success: false, error: message}       │     │
│  │    3. Server continues running (no crash)           │     │
│  │    4. Next cron cycle tries again                   │     │
│  └────────────────────────────────────────────────────┘     │
│                                                               │
└─────────────────────────────────────────────────────────────┘
```

---

## 🌐 API ENDPOINTS FLOW

### Client → Server → Processing → Response

```
┌─────────────────────────────────────────────────────────────────┐
│                       API REQUEST FLOW                           │
│                                                                   │
│  CLIENT REQUEST                                                   │
│     ↓                                                             │
│  GET /health                                                      │
│     ↓                                                             │
│  Express Router (app.js)                                         │
│     ↓                                                             │
│  app.get('/health', (req, res) => {...})                        │
│     ↓                                                             │
│  Get state from innerLoop                                        │
│     ↓                                                             │
│  Response: {                                                      │
│    status: 'ok',                                                 │
│    innerLoopStatus: 'ready',                                    │
│    cycles: 42,                                                   │
│    confidence: 85                                                │
│  }                                                                │
│                                                                   │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  CLIENT REQUEST                                                   │
│     ↓                                                             │
│  GET /core/status                                                 │
│     ↓                                                             │
│  Express Router → coreRoutes                                     │
│     ↓                                                             │
│  coreController.getStatus()                                      │
│     ↓                                                             │
│  innerLoop.getState()                                            │
│     ↓                                                             │
│  Response: {                                                      │
│    success: true,                                                │
│    state: {                                                      │
│      cycles: 42,                                                 │
│      confidence: 85,                                             │
│      doubts: 20,                                                 │
│      modulePerformance: {...},                                   │
│      discrepancies: [...]                                        │
│    }                                                              │
│  }                                                                │
│                                                                   │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  CLIENT REQUEST                                                   │
│     ↓                                                             │
│  GET /core/run-loop                                               │
│     ↓                                                             │
│  coreController.runLoop()                                        │
│     ↓                                                             │
│  await innerLoop.runInnerLoop()                                  │
│     ↓                                                             │
│  Execute all 14 steps                                            │
│     ↓                                                             │
│  Response: {                                                      │
│    success: true,                                                │
│    cycle: 43,                                                    │
│    stats: {                                                      │
│      anomalyScore: 0.1,                                          │
│      confidence: 87,                                             │
│      score: 8,                                                   │
│      tasksGenerated: 6,                                          │
│      discrepancies: 1                                            │
│    }                                                              │
│  }                                                                │
│                                                                   │
└─────────────────────────────────────────────────────────────────┘
```

---

## 🧩 MODULE INTERACTIONS

### How Components Work Together

```
┌────────────────────────────────────────────────────────────────┐
│                    MODULE INTERACTION MAP                       │
│                                                                  │
│                  ┌──────────────────┐                          │
│                  │   innerLoop.js   │                          │
│                  │   (Orchestrator) │                          │
│                  └────────┬─────────┘                          │
│                           │                                     │
│        ┌──────────────────┼──────────────────┬─────────────┐  │
│        │                  │                  │             │  │
│        ↓                  ↓                  ↓             ↓  │
│  ┌──────────┐      ┌──────────┐      ┌──────────┐  ┌──────────┐
│  │SoulCore  │      │Strategy  │      │TaskMgr   │  │Anomaly   │
│  │          │      │          │      │          │  │Detector  │
│  └────┬─────┘      └────┬─────┘      └────┬─────┘  └────┬─────┘
│       │                 │                  │             │  │
│       │  Patterns       │  Strategy        │  Tasks      │  Anomalies
│       │  Insights       │  Actions         │  CRUD       │  Score
│       │  Questions      │  Summary         │             │  │
│       │                 │                  │             │  │
│       └─────────────────┴──────────────────┴─────────────┘  │
│                           │                                  │
│                           │ All feed back to                 │
│                           ↓                                  │
│                  ┌──────────────────┐                        │
│                  │   innerLoop.js   │                        │
│                  │  (Aggregates &   │                        │
│                  │   Decides)       │                        │
│                  └────────┬─────────┘                        │
│                           │                                  │
│        ┌──────────────────┼──────────────────┐              │
│        │                  │                  │              │
│        ↓                  ↓                  ↓              │
│  ┌──────────┐      ┌──────────┐      ┌──────────┐         │
│  │ Notion   │      │ OpenAI   │      │ Logger   │         │
│  │ Service  │      │ Service  │      │ Service  │         │
│  └──────────┘      └──────────┘      └──────────┘         │
│       ↓                  ↓                  ↓              │
│   Write data         Analyze           Log everything      │
│   to database        & suggest         to console+file     │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## 📦 STATE MANAGEMENT

### How State Evolves Over Time

```
┌────────────────────────────────────────────────────────────────┐
│                     STATE EVOLUTION                             │
│                                                                  │
│  INITIAL STATE (Cycle 0)                                        │
│  ┌──────────────────────────────────────────────────────┐      │
│  │ state = {                                             │      │
│  │   lastRun: null,                                      │      │
│  │   cycles: 0,                                          │      │
│  │   confidence: 80,         ← Starting value            │      │
│  │   doubts: 0,              ← Starting value            │      │
│  │   goals: [],                                          │      │
│  │   lastLesson: null,                                   │      │
│  │   modulePerformance: {                                │      │
│  │     strategy: { successRate: 100, errors: 0 },       │      │
│  │     taskManager: { successRate: 100, errors: 0 },    │      │
│  │     anomalyDetector: { successRate: 100, errors: 0 } │      │
│  │   },                                                  │      │
│  │   discrepancies: []                                   │      │
│  │ }                                                     │      │
│  └──────────────────────────────────────────────────────┘      │
│                           ↓                                     │
│                    Run Cycle 1                                  │
│                           ↓                                     │
│  AFTER CYCLE 1                                                  │
│  ┌──────────────────────────────────────────────────────┐      │
│  │ state = {                                             │      │
│  │   lastRun: "2025-11-16T16:34:39Z",                   │      │
│  │   cycles: 1,              ← Incremented               │      │
│  │   confidence: 70,         ← Decreased (low score)     │      │
│  │   doubts: 15,             ← Increased                 │      │
│  │   goals: [...],                                       │      │
│  │   lastLesson: "# Bài học...",  ← Saved              │      │
│  │   modulePerformance: {                                │      │
│  │     strategy: { successRate: 100, errors: 0 },       │      │
│  │     taskManager: { successRate: 100, errors: 0 },    │      │
│  │     anomalyDetector: { successRate: 100, errors: 0 } │      │
│  │   },                                                  │      │
│  │   discrepancies: [                ← New               │      │
│  │     {                                                 │      │
│  │       type: 'goal_misalignment',                      │      │
│  │       severity: 'high',                               │      │
│  │       description: "Goal alignment 50%"               │      │
│  │     }                                                 │      │
│  │   ]                                                   │      │
│  │ }                                                     │      │
│  └──────────────────────────────────────────────────────┘      │
│                           ↓                                     │
│                    Run Cycle 2                                  │
│                           ↓                                     │
│  AFTER CYCLE 2 (Improvement)                                    │
│  ┌──────────────────────────────────────────────────────┐      │
│  │ state = {                                             │      │
│  │   cycles: 2,              ← Incremented               │      │
│  │   confidence: 75,         ← Increased (better score)  │      │
│  │   doubts: 10,             ← Decreased                 │      │
│  │   lastLesson: "# Bài học cycle 2...",                │      │
│  │   discrepancies: [...]    ← Updated                   │      │
│  │ }                                                     │      │
│  └──────────────────────────────────────────────────────┘      │
│                                                                  │
│  CONFIDENCE ADJUSTMENTS:                                        │
│  • Score < 5: confidence -15, doubts +20                       │
│  • Score ≥ 7: confidence +10, doubts -10                       │
│  • Anomaly > 0.5: confidence -10, doubts +15                   │
│  • Anomaly < 0.2: confidence +5, doubts -5                     │
│  • Discrepancies > 5: doubts +10                               │
│  • Progress improving: confidence +5, doubts -5                │
│  • Progress degrading: doubts +10                              │
│                                                                  │
│  Range limits: confidence [30-100], doubts [0-100]             │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

---

## 🎨 COMPONENT DESCRIPTIONS

### Detailed Component Functions

```
┌────────────────────────────────────────────────────────────────┐
│                    COMPONENT GLOSSARY                           │
│                                                                  │
│  📁 CORE MODULES                                                │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ innerLoop.js (521 lines - Heart)                         │  │
│  │ • Orchestrates entire Soul Loop cycle                    │  │
│  │ • Executes 14 steps sequentially                         │  │
│  │ • Manages state (confidence, doubts, performance)        │  │
│  │ • Coordinates all other modules                          │  │
│  │ • Runs every 10 minutes via cron                         │  │
│  │ • Writes results to Notion                               │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ soulCore.js (450 lines - Brain)                          │  │
│  │ • Pure JavaScript logic (no external AI)                 │  │
│  │ • 8 methods for self-learning & evolution                │  │
│  │ • Patterns extraction, insights generation               │  │
│  │ • Self-evaluation (1-10 scoring)                         │  │
│  │ • Strategy refinement                                    │  │
│  │ • Task proposals                                         │  │
│  │ • Philosophical self-questioning                         │  │
│  │ • Self-model tracking (version, evolution history)       │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ strategy.js (Strategy Generator)                         │  │
│  │ • Analyzes anomaly scores                                │  │
│  │ • Generates strategic summary                            │  │
│  │ • Suggests concrete actions                              │  │
│  │ • Complements SoulCore strategy                          │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ taskManager.js (Task Management)                         │  │
│  │ • In-memory task storage                                 │  │
│  │ • Auto-generates tasks from strategy                     │  │
│  │ • CRUD operations (get, update, delete)                  │  │
│  │ • Priority & schedule management                         │  │
│  │ • Status tracking (pending/completed)                    │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ anomalyDetector.js (Anomaly Detection)                   │  │
│  │ • Scans logs for failures (status !== 'success')        │  │
│  │ • Calculates anomaly score (0.0 - 1.0)                  │  │
│  │ • Generates anomaly summary                              │  │
│  │ • Complements SoulCore anomaly detection                 │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ policy.js (Policy Evaluation)                            │  │
│  │ • Evaluates current strategy vs state                    │  │
│  │ • Recommends policy adjustments                          │  │
│  │ • Checks confidence thresholds                           │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                  │
│  📁 SERVICES                                                    │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ loggerService.js (Winston Logger)                        │  │
│  │ • Console + file logging                                 │  │
│  │ • Log levels: info, warn, error, debug                   │  │
│  │ • Timestamp + formatted output                           │  │
│  │ • Creates logs/app.log automatically                     │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ notionService.js (Notion Integration)                    │  │
│  │ • Placeholder mode if credentials missing                │  │
│  │ • fetchRecentLogs() - read from database                 │  │
│  │ • writeLesson() - save daily lessons                     │  │
│  │ • writeTasks() - save generated tasks                    │  │
│  │ • writeStrategy() - save strategies                      │  │
│  │ • writeBehaviorUpdate() - save state changes             │  │
│  │ • writeDiscrepancies() - save detected issues            │  │
│  │ • fetchGoals() - read long-term goals                    │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ openAIService.js (OpenAI Integration)                    │  │
│  │ • Placeholder mode if API key missing                    │  │
│  │ • analyzeLogs() - deep log analysis with GPT-4          │  │
│  │ • generateStrategy() - AI-powered strategy               │  │
│  │ • suggestImprovements() - module optimization ideas      │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                  │
│  📁 API LAYER                                                   │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ coreController.js (Controllers)                          │  │
│  │ • Handles HTTP requests                                  │  │
│  │ • Calls core modules                                     │  │
│  │ • Returns JSON responses                                 │  │
│  │ • Error handling for all endpoints                       │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ coreRoutes.js (Express Routes)                           │  │
│  │ • Maps URLs to controller methods                        │  │
│  │ • GET /core/run-loop, /status, /tasks, etc.             │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ app.js (Express Application)                             │  │
│  │ • Express setup & middleware                             │  │
│  │ • Health check endpoint                                  │  │
│  │ • Mounts /core routes                                    │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ server.js (Application Server)                           │  │
│  │ • Loads environment variables                            │  │
│  │ • Sets up cron job (HEARTBEAT_CRON)                     │  │
│  │ • Runs initial Inner Loop cycle                         │  │
│  │ • Starts Express server on PORT                          │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

---

## 🎓 QUICK REFERENCE FOR NEW DEVELOPERS

### Understanding the Architecture in 5 Minutes

**1. What is CipherH?**
- Autonomous AI agent that runs 24/7
- Self-learning, self-doubting, self-improving
- Like JARVIS from Iron Man

**2. How does it work?**
- Every 10 minutes: Run Inner Loop (14 steps)
- Read logs → Analyze → Learn → Generate strategy → Create tasks
- Write everything to Notion for long-term memory

**3. What is Inner Loop?**
- The "heartbeat" of CipherH
- 14 steps that execute sequentially
- Steps 1-9: Original (learning, strategy, tasks)
- Steps 10-14: NEW (self-doubt, evaluation, reinforcement)

**4. What is SoulCore?**
- The "brain" of CipherH
- 8 pure JavaScript methods
- No external AI needed
- Handles: learning, evaluation, strategy, tasks, questions

**5. How to interact with it?**
- REST API: 6 endpoints
- GET /health - Check if alive
- GET /core/status - See current state
- GET /core/run-loop - Trigger cycle manually
- GET /core/tasks - See generated tasks
- GET /core/strategy - See current strategy
- GET /core/anomalies - See detected issues

**6. How does it improve itself?**
- Step 10: Detects discrepancies (goal misalignment, performance issues)
- Step 11: Evaluates module health (success rates, errors)
- Step 12: Creates improvement tasks automatically
- Step 13: Compares progress with previous cycles
- Step 14: Adjusts confidence/doubts based on performance

**7. Where is the data stored?**
- Short-term: In-memory (state object)
- Long-term: Notion database (lessons, tasks, strategy, discrepancies)
- Logs: File system (logs/app.log)

**8. How to deploy?**
- Local: npm install → npm start
- Production: Push to GitHub → Render auto-deploys
- Budget: ~$17/month (Render $7 + OpenAI ~$10)

---

## 🎯 SUCCESS INDICATORS

**Backend is working correctly when you see:**

✅ Server running on port 3000
✅ Initial Inner Loop cycle completes
✅ Logs show "SOUL LOOP CYCLE N - COMPLETED"
✅ Cron job executes every 10 minutes
✅ Cycles increment: 1 → 2 → 3 → ...
✅ Confidence adjusts (30-100 range)
✅ Doubts adjust (0-100 range)
✅ Discrepancies detected and logged
✅ Module performance tracked
✅ All API endpoints respond
✅ No errors in logs

---

**This blueprint provides complete visual understanding of CipherH backend architecture! 🎨✨**
