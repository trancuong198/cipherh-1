"""
Context Injector - Format và inject memory vào LLM context
Builds clean, structured context from filtered memories
"""

from typing import List, Dict, Any, Optional

class ContextInjector:
    """
    Format filtered memories into clean, structured context for LLM
    
    Output format:
    === IDENTITY & RULES ===
    [Core memories about self and behavioral rules]
    
    === RELEVANT KNOWLEDGE ===
    [Facts and knowledge related to current query]
    
    === RECENT CONTEXT ===
    [Recent conversations and logs]
    """
    
    def __init__(self):
        self.section_headers = {
            'identity': '🧬 IDENTITY & CORE RULES',
            'fact': '📚 RELEVANT KNOWLEDGE',
            'plan': '🎯 ACTIVE PLANS & GOALS',
            'preference': '💝 USER PREFERENCES',
            'log': '📝 RECENT ACTIVITY',
            'rule': '⚖️ BEHAVIORAL RULES'
        }
    
    def inject(
        self,
        core_memories: List[Dict[str, Any]],
        contextual_memories: List[Dict[str, Any]],
        recent_memories: Optional[List[Dict[str, Any]]] = None
    ) -> str:
        """
        Build structured context from filtered memories
        
        Args:
            core_memories: Always-include memories (identity, rules)
            contextual_memories: Query-relevant memories
            recent_memories: Recent conversations (optional)
        
        Returns:
            Formatted context string ready for LLM injection
        """
        sections = []
        
        if core_memories:
            core_section = self._build_section('core', core_memories)
            if core_section:
                sections.append(core_section)
        
        if contextual_memories:
            contextual_section = self._build_section('contextual', contextual_memories)
            if contextual_section:
                sections.append(contextual_section)
        
        if recent_memories:
            recent_section = self._build_section('recent', recent_memories)
            if recent_section:
                sections.append(recent_section)
        
        if not sections:
            return ""
        
        header = "=== 🧠 CipherH's MEMORY SYSTEM ===\n"
        header += f"(Feeding {len(core_memories) + len(contextual_memories)} relevant memories)\n\n"
        
        return header + "\n\n".join(sections)
    
    def _build_section(self, section_type: str, memories: List[Dict[str, Any]]) -> str:
        """Build a single context section"""
        if not memories:
            return ""
        
        if section_type == 'core':
            header = "=== 🧬 IDENTITY & CORE RULES (Always Active) ===\n"
            items = []
            for mem in memories:
                type_icon = self._get_type_icon(mem['type'])
                priority_stars = "⭐" * min(mem['priority'], 3)
                content = mem['content'][:200]
                items.append(f"{type_icon} [{mem['type'].upper()}] {priority_stars}\n{content}")
            
            return header + "\n\n".join(items)
        
        elif section_type == 'contextual':
            header = "=== 📚 RELEVANT KNOWLEDGE (For Current Query) ===\n"
            items = []
            for mem in memories:
                type_icon = self._get_type_icon(mem['type'])
                content = mem['content'][:200]
                tags = ", ".join(mem.get('tags', []))[:50]
                items.append(f"{type_icon} [{mem['type']}] {content}\n   Tags: {tags}")
            
            return header + "\n\n".join(items)
        
        elif section_type == 'recent':
            header = "=== 💭 RECENT CONTEXT ===\n"
            items = []
            for mem in memories[:5]:
                content = mem['content'][:150]
                items.append(f"• {content}")
            
            return header + "\n".join(items)
        
        return ""
    
    def _get_type_icon(self, mem_type: str) -> str:
        """Get emoji icon for memory type"""
        icons = {
            'identity': '🧬',
            'rule': '⚖️',
            'fact': '📚',
            'plan': '🎯',
            'preference': '💝',
            'log': '📝'
        }
        return icons.get(mem_type, '•')
    
    def build_system_message(
        self,
        personality: str,
        context: str,
        datetime_info: Optional[str] = None
    ) -> Dict[str, str]:
        """
        Build complete system message with personality + context + datetime
        
        Returns:
            {"role": "system", "content": "..."}
        """
        parts = []
        
        if datetime_info:
            parts.append(datetime_info)
        
        parts.append(personality)
        
        if context:
            parts.append(context)
        
        return {
            "role": "system",
            "content": "\n\n".join(parts)
        }
    
    def format_for_reflection(self, user_message: str, ai_response: str) -> str:
        """
        Format conversation for reflection
        Used by reflection_loop to extract insights
        """
        return f"""
=== CONVERSATION ===
User: {user_message}

CipherH: {ai_response}
=== END ===

Extract key insights, learnings, or important facts from this conversation.
"""
