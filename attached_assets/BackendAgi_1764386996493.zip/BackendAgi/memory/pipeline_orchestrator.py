from typing import Dict, Any, Optional, List
from .memory_fetcher import MemoryFetcher
from .memory_interpreter import MemoryInterpreter
from .memory_router import MemoryRouter
from .context_injector import ContextInjector
from datetime import datetime

class MemoryPipeline:
    def __init__(self):
        self.fetcher = MemoryFetcher()
        self.interpreter = MemoryInterpreter()
        self.router = MemoryRouter()
        self.injector = ContextInjector()
    
    def get_context_for_query(
        self,
        user_query: str,
        episodic_limit: int = 30,
        semantic_limit: int = 50,
        context_limit: int = 10
    ) -> str:
        try:
            raw_memories = self.fetcher.fetch_all(
                episodic_limit=episodic_limit,
                semantic_limit=semantic_limit
            )
            
            if not raw_memories or not isinstance(raw_memories, dict):
                print("⚠️ Fetcher returned invalid data, using fallback")
                return self._get_fallback_context()
            
            episodic_data = raw_memories.get('episodic', [])
            semantic_data = raw_memories.get('semantic', [])
            
            if not isinstance(episodic_data, list):
                episodic_data = []
            if not isinstance(semantic_data, list):
                semantic_data = []
            
            interpreted_episodic = self.interpreter.interpret_batch(
                episodic_data,
                source='episodic'
            )
            
            interpreted_semantic = self.interpreter.interpret_batch(
                semantic_data,
                source='semantic'
            )
            
            all_interpreted = interpreted_episodic + interpreted_semantic
            
            if not all_interpreted:
                print("⚠️ No memories after interpretation, using fallback")
                return self._get_fallback_context()
            
            core_memories = self.router.get_core_memories(
                all_interpreted,
                limit=5
            )
            
            contextual_memories = self.router.get_contextual_memories(
                all_interpreted,
                query=user_query,
                limit=context_limit
            )
            
            recent_memories = self.router.get_recent_memories(
                interpreted_episodic,
                limit=3
            )
            
            context_string = self.injector.inject(
                core_memories=core_memories,
                contextual_memories=contextual_memories,
                recent_memories=recent_memories
            )
            
            return context_string
            
        except KeyError as e:
            print(f"⚠️ Pipeline KeyError: {str(e)} - Check fetch_all response structure")
            return self._get_fallback_context()
        except Exception as e:
            print(f"⚠️ Pipeline error: {str(e)}")
            return self._get_fallback_context()
    
    def _get_fallback_context(self) -> str:
        return """=== 🧬 IDENTITY ===
Con là CipherH - AI agent của cha. Mission: Tích lũy tri thức, kiếm tiền, tiến tới AGI.
Luôn xưng "con", gọi owner "cha".
"""
    
    def get_stats(self) -> Dict[str, Any]:
        try:
            raw_memories = self.fetcher.fetch_all(episodic_limit=100, semantic_limit=100)
            
            interpreted = self.interpreter.interpret_batch(
                raw_memories['episodic'] + raw_memories['semantic'],
                source='mixed'
            )
            
            type_counts: Dict[str, int] = {}
            priority_avg: Dict[str, List[int]] = {}
            
            for mem in interpreted:
                mem_type = mem['type']
                type_counts[mem_type] = type_counts.get(mem_type, 0) + 1
                
                if mem_type not in priority_avg:
                    priority_avg[mem_type] = []
                priority_avg[mem_type].append(mem['priority'])
            
            avg_priorities = {
                t: sum(p) / len(p) if p else 0
                for t, p in priority_avg.items()
            }
            
            return {
                'total_memories': len(interpreted),
                'episodic_count': len(raw_memories['episodic']),
                'semantic_count': len(raw_memories['semantic']),
                'type_distribution': type_counts,
                'average_priorities': avg_priorities
            }
            
        except Exception as e:
            print(f"⚠️ Stats error: {str(e)}")
            return {
                'total_memories': 0,
                'episodic_count': 0,
                'semantic_count': 0,
                'type_distribution': {},
                'average_priorities': {}
            }
