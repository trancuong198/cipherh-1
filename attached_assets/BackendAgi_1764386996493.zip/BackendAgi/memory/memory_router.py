"""
Memory Router - Chọn memory phù hợp theo context
Smart filtering based on relevance, priority, and query
"""

import re
from typing import List, Dict, Any, Optional
from collections import Counter

class MemoryRouter:
    """
    Route và filter memory để chỉ feed những gì relevant vào context
    
    Routing strategies:
    1. Query-based: Match keywords trong user query
    2. Priority-based: Ưu tiên memory có priority cao
    3. Type-based: Chọn memory types phù hợp
    4. Tag-based: Match tags với query topics
    5. Recency-based: Ưu tiên memory mới
    """
    
    def __init__(self):
        self.default_memory_limit = 10
    
    def route(
        self,
        interpreted_memories: List[Dict[str, Any]],
        user_query: Optional[str] = None,
        memory_types: Optional[List[str]] = None,
        min_priority: int = 1,
        limit: int = 10
    ) -> List[Dict[str, Any]]:
        """
        Main routing function - chọn memory phù hợp nhất
        
        Args:
            interpreted_memories: List of interpreted memory objects
            user_query: Current user question/input
            memory_types: Filter by specific types (e.g., ['identity', 'rule'])
            min_priority: Minimum priority threshold
            limit: Max number of memories to return
        
        Returns:
            Filtered and ranked list of memories
        """
        if not interpreted_memories:
            return []
        
        filtered = interpreted_memories.copy()
        
        if memory_types:
            filtered = [m for m in filtered if m['type'] in memory_types]
        
        if min_priority > 1:
            filtered = [m for m in filtered if m['priority'] >= min_priority]
        
        if user_query:
            filtered = self._rank_by_relevance(filtered, user_query)
        else:
            filtered = sorted(filtered, key=lambda m: (-m['priority'], m.get('created_at', '')), reverse=True)
        
        return filtered[:limit]
    
    def _rank_by_relevance(self, memories: List[Dict[str, Any]], query: str) -> List[Dict[str, Any]]:
        """
        Rank memories by relevance to query
        Uses keyword matching + priority weighting
        """
        query_lower = query.lower()
        query_words = self._extract_keywords(query_lower)
        
        scored_memories = []
        
        for mem in memories:
            content = mem.get('content', '').lower()
            tags = mem.get('tags', [])
            priority = mem.get('priority', 1)
            
            keyword_score = sum(1 for word in query_words if word in content)
            
            tag_score = sum(1 for tag in tags if tag in query_lower or any(word in tag for word in query_words))
            
            type_boost = self._get_type_boost(mem['type'], query_lower)
            
            relevance_score = (keyword_score * 2) + (tag_score * 1.5) + type_boost
            
            final_score = relevance_score + (priority / 10.0)
            
            scored_memories.append((mem, final_score))
        
        scored_memories.sort(key=lambda x: x[1], reverse=True)
        
        return [mem for mem, score in scored_memories]
    
    def _extract_keywords(self, text: str) -> List[str]:
        """Extract meaningful keywords from text"""
        stop_words = {'là', 'của', 'và', 'có', 'trong', 'cho', 'để', 'với', 'một', 
                     'the', 'is', 'of', 'and', 'to', 'a', 'in', 'for', 'on'}
        
        words = re.findall(r'\b\w+\b', text.lower())
        
        keywords = [w for w in words if len(w) > 2 and w not in stop_words]
        
        return keywords
    
    def _get_type_boost(self, mem_type: str, query: str) -> float:
        """
        Boost score based on memory type relevance to query
        
        E.g., if query asks "tôi là ai?", boost 'identity' memories
        """
        type_triggers = {
            'identity': ['ai', 'tôi', 'bạn', 'cipherh', 'là gì', 'giới thiệu'],
            'rule': ['phải', 'nên', 'quy tắc', 'rule', 'làm thế nào'],
            'plan': ['kế hoạch', 'mục tiêu', 'sẽ làm', 'tiếp theo', 'plan'],
            'preference': ['thích', 'ưa', 'quan tâm', 'preference'],
            'fact': ['thông tin', 'là gì', 'có phải', 'fact', 'định nghĩa'],
            'log': ['đã làm', 'lịch sử', 'history', 'trước đây']
        }
        
        triggers = type_triggers.get(mem_type, [])
        
        if any(trigger in query for trigger in triggers):
            return 3.0
        
        return 0.0
    
    def get_core_memories(
        self,
        interpreted_memories: List[Dict[str, Any]],
        limit: int = 5
    ) -> List[Dict[str, Any]]:
        """
        Get core memories - highest priority, most important
        Always include these regardless of query
        """
        core_types = ['identity', 'rule']
        
        core = [m for m in interpreted_memories if m['type'] in core_types and m['priority'] >= 8]
        
        core.sort(key=lambda m: -m['priority'])
        
        return core[:limit]
    
    def get_contextual_memories(
        self,
        interpreted_memories: List[Dict[str, Any]],
        query: str,
        limit: int = 5
    ) -> List[Dict[str, Any]]:
        """
        Get contextual memories - relevant to current query
        """
        return self.route(
            interpreted_memories,
            user_query=query,
            min_priority=4,
            limit=limit
        )
    
    def get_recent_memories(
        self,
        interpreted_memories: List[Dict[str, Any]],
        limit: int = 3
    ) -> List[Dict[str, Any]]:
        """Get most recent memories (by created_at)"""
        sorted_mem = sorted(
            interpreted_memories,
            key=lambda m: m.get('created_at', ''),
            reverse=True
        )
        return sorted_mem[:limit]
    
    def analyze_query_intent(self, query: str) -> Dict[str, Any]:
        """
        Analyze user query to determine memory routing strategy
        
        Returns:
            {
                'needs_identity': bool,
                'needs_facts': bool,
                'needs_history': bool,
                'suggested_types': List[str],
                'keywords': List[str]
            }
        """
        query_lower = query.lower()
        
        needs_identity = any(word in query_lower for word in ['ai', 'tôi', 'bạn', 'cipherh', 'là gì'])
        needs_facts = any(word in query_lower for word in ['thông tin', 'là gì', 'có phải', 'định nghĩa'])
        needs_history = any(word in query_lower for word in ['đã', 'trước đây', 'lịch sử', 'nhớ'])
        
        suggested_types = []
        if needs_identity:
            suggested_types.extend(['identity', 'rule'])
        if needs_facts:
            suggested_types.append('fact')
        if needs_history:
            suggested_types.extend(['log', 'plan'])
        
        if not suggested_types:
            suggested_types = ['fact', 'preference']
        
        keywords = self._extract_keywords(query_lower)
        
        return {
            'needs_identity': needs_identity,
            'needs_facts': needs_facts,
            'needs_history': needs_history,
            'suggested_types': list(set(suggested_types)),
            'keywords': keywords
        }
