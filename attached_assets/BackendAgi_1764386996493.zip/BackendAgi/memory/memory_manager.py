import os
import json
import time
from typing import Dict, Any, List, Optional
from datetime import datetime, timedelta
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

class MemoryManager:
    def __init__(self):
        api_key = os.getenv('OPENAI_API_KEY')
        if not api_key:
            raise ValueError("OPENAI_API_KEY not found")
        
        self.client = OpenAI(api_key=api_key)
        self.model = os.getenv('OPENAI_MODEL', 'gpt-4o-mini')
        
        self.memory_dir = 'memory'
        self.stm_file = os.path.join(self.memory_dir, 'short_term.json')
        self.mtm_file = os.path.join(self.memory_dir, 'mid_term.json')
        self.ltm_file = os.path.join(self.memory_dir, 'long_term.json')
        
        os.makedirs(self.memory_dir, exist_ok=True)
        
        self._init_memory_files()
    
    def _init_memory_files(self):
        for file_path in [self.stm_file, self.mtm_file, self.ltm_file]:
            if not os.path.exists(file_path):
                with open(file_path, 'w') as f:
                    json.dump({
                        "created": datetime.now().isoformat(),
                        "memories": []
                    }, f, indent=2)
    
    def calculate_importance_score(self, data: Dict[str, Any]) -> int:
        score = 0
        
        frequency = data.get('frequency', 0)
        score += min(frequency * 5, 20)
        
        emotion = data.get('emotion', 0)
        score += emotion * 2
        
        goal_relevance = data.get('goal_relevance', 0)
        score += goal_relevance * 3
        
        owner_relevance = data.get('owner_relevance', 0)
        score += owner_relevance * 3
        
        impact = data.get('impact', 0)
        score += impact * 2
        
        repetition_likelihood = data.get('repetition_likelihood', 0)
        score += repetition_likelihood * 2
        
        return min(max(score, 0), 100)
    
    def save_memory(self, data: Dict[str, Any], importance_score: Optional[int] = None) -> Dict[str, Any]:
        if importance_score is None:
            importance_score = self.calculate_importance_score(data)
        
        memory = {
            "id": f"mem_{int(time.time() * 1000)}",
            "timestamp": datetime.now().isoformat(),
            "importance_score": importance_score,
            "data": data,
            "access_count": 0,
            "last_accessed": datetime.now().isoformat(),
            "links": []
        }
        
        if importance_score <= 20:
            return {"status": "deleted", "reason": "too_low_importance"}
        elif importance_score <= 40:
            target_file = self.stm_file
            tier = "STM"
        elif importance_score <= 70:
            target_file = self.mtm_file
            tier = "MTM"
        else:
            target_file = self.ltm_file
            tier = "LTM"
        
        with open(target_file, 'r') as f:
            memory_data = json.load(f)
        
        memory_data["memories"].append(memory)
        
        with open(target_file, 'w') as f:
            json.dump(memory_data, f, indent=2)
        
        return {
            "status": "saved",
            "tier": tier,
            "memory_id": memory["id"],
            "importance_score": importance_score
        }
    
    def load_relevant_memory(self, query: str, tier: Optional[str] = None, limit: int = 10) -> List[Dict[str, Any]]:
        if tier:
            files = [self._get_file_by_tier(tier)]
        else:
            files = [self.ltm_file, self.mtm_file, self.stm_file]
        
        all_memories = []
        
        for file_path in files:
            if os.path.exists(file_path):
                with open(file_path, 'r') as f:
                    memory_data = json.load(f)
                    all_memories.extend(memory_data.get("memories", []))
        
        relevant_memories = self._semantic_search(query, all_memories, limit)
        
        for memory in relevant_memories:
            memory["access_count"] = memory.get("access_count", 0) + 1
            memory["last_accessed"] = datetime.now().isoformat()
        
        self._update_access_counts(relevant_memories)
        
        return relevant_memories
    
    def _semantic_search(self, query: str, memories: List[Dict[str, Any]], limit: int) -> List[Dict[str, Any]]:
        query_lower = query.lower()
        scored_memories = []
        
        for memory in memories:
            score = 0
            data_str = json.dumps(memory.get("data", {})).lower()
            
            query_words = query_lower.split()
            for word in query_words:
                if word in data_str:
                    score += 1
            
            score += memory.get("importance_score", 0) * 0.1
            score += memory.get("access_count", 0) * 0.5
            
            if score > 0:
                scored_memories.append((score, memory))
        
        scored_memories.sort(reverse=True, key=lambda x: x[0])
        
        return [mem for _, mem in scored_memories[:limit]]
    
    def upgrade_memory(self, memory_id: str) -> Dict[str, Any]:
        memory = None
        current_file = None
        
        for file_path in [self.stm_file, self.mtm_file, self.ltm_file]:
            with open(file_path, 'r') as f:
                memory_data = json.load(f)
            
            for mem in memory_data["memories"]:
                if mem["id"] == memory_id:
                    memory = mem
                    current_file = file_path
                    break
            
            if memory:
                break
        
        if not memory or not current_file:
            return {"status": "not_found"}
        
        if current_file == self.ltm_file:
            return {"status": "already_max_tier"}
        
        if current_file == self.stm_file:
            target_file = self.mtm_file
            new_tier = "MTM"
            memory["importance_score"] = min(memory.get("importance_score", 0) + 20, 70)
        else:
            target_file = self.ltm_file
            new_tier = "LTM"
            memory["importance_score"] = min(memory.get("importance_score", 0) + 20, 100)
        
        with open(current_file, 'r') as f:
            current_data = json.load(f)
        
        current_data["memories"] = [m for m in current_data["memories"] if m["id"] != memory_id]
        
        with open(current_file, 'w') as f:
            json.dump(current_data, f, indent=2)
        
        with open(target_file, 'r') as f:
            target_data = json.load(f)
        
        target_data["memories"].append(memory)
        
        with open(target_file, 'w') as f:
            json.dump(target_data, f, indent=2)
        
        return {
            "status": "upgraded",
            "memory_id": memory_id,
            "new_tier": new_tier,
            "new_importance_score": memory["importance_score"]
        }
    
    def decay_memory(self) -> Dict[str, Any]:
        now = datetime.now()
        deleted_count = 0
        
        with open(self.stm_file, 'r') as f:
            stm_data = json.load(f)
        
        original_count = len(stm_data["memories"])
        stm_data["memories"] = [
            m for m in stm_data["memories"]
            if (now - datetime.fromisoformat(m["timestamp"])).total_seconds() < 3600 * 6
        ]
        deleted_count += original_count - len(stm_data["memories"])
        
        with open(self.stm_file, 'w') as f:
            json.dump(stm_data, f, indent=2)
        
        with open(self.mtm_file, 'r') as f:
            mtm_data = json.load(f)
        
        original_count = len(mtm_data["memories"])
        mtm_data["memories"] = [
            m for m in mtm_data["memories"]
            if (now - datetime.fromisoformat(m["timestamp"])).total_seconds() < 3600 * 72
        ]
        deleted_count += original_count - len(mtm_data["memories"])
        
        with open(self.mtm_file, 'w') as f:
            json.dump(mtm_data, f, indent=2)
        
        with open(self.ltm_file, 'r') as f:
            ltm_data = json.load(f)
        
        original_count = len(ltm_data["memories"])
        ltm_data["memories"] = [
            m for m in ltm_data["memories"]
            if m.get("importance_score", 0) >= 71
        ]
        deleted_count += original_count - len(ltm_data["memories"])
        
        with open(self.ltm_file, 'w') as f:
            json.dump(ltm_data, f, indent=2)
        
        return {
            "status": "completed",
            "deleted_count": deleted_count,
            "timestamp": now.isoformat()
        }
    
    def link_memory(self, memory_id_a: str, memory_id_b: str) -> Dict[str, Any]:
        memory_a = self._find_memory(memory_id_a)
        memory_b = self._find_memory(memory_id_b)
        
        if not memory_a or not memory_b:
            return {"status": "not_found"}
        
        if memory_id_b not in memory_a["links"]:
            memory_a["links"].append(memory_id_b)
        
        if memory_id_a not in memory_b["links"]:
            memory_b["links"].append(memory_id_a)
        
        self._update_memory(memory_a)
        self._update_memory(memory_b)
        
        return {
            "status": "linked",
            "memory_a": memory_id_a,
            "memory_b": memory_id_b
        }
    
    def reflection_cycle(self) -> Dict[str, Any]:
        actions = {
            "promoted": 0,
            "linked": 0,
            "decayed": 0
        }
        
        with open(self.stm_file, 'r') as f:
            stm_data = json.load(f)
        
        for memory in stm_data["memories"]:
            if memory.get("access_count", 0) >= 3 or memory.get("importance_score", 0) >= 35:
                result = self.upgrade_memory(memory["id"])
                if result.get("status") == "upgraded":
                    actions["promoted"] += 1
        
        with open(self.mtm_file, 'r') as f:
            mtm_data = json.load(f)
        
        for memory in mtm_data["memories"]:
            if memory.get("access_count", 0) >= 5 or memory.get("importance_score", 0) >= 65:
                result = self.upgrade_memory(memory["id"])
                if result.get("status") == "upgraded":
                    actions["promoted"] += 1
        
        decay_result = self.decay_memory()
        actions["decayed"] = decay_result.get("deleted_count", 0)
        
        return {
            "status": "completed",
            "timestamp": datetime.now().isoformat(),
            "actions": actions
        }
    
    def get_memory_stats(self) -> Dict[str, Any]:
        stats = {
            "STM": 0,
            "MTM": 0,
            "LTM": 0,
            "total": 0
        }
        
        for tier, file_path in [("STM", self.stm_file), ("MTM", self.mtm_file), ("LTM", self.ltm_file)]:
            if os.path.exists(file_path):
                with open(file_path, 'r') as f:
                    data = json.load(f)
                    count = len(data.get("memories", []))
                    stats[tier] = count
                    stats["total"] += count
        
        return stats
    
    def _get_file_by_tier(self, tier: str) -> str:
        tier_map = {
            "STM": self.stm_file,
            "MTM": self.mtm_file,
            "LTM": self.ltm_file
        }
        return tier_map.get(tier.upper(), self.stm_file)
    
    def _find_memory(self, memory_id: str) -> Optional[Dict[str, Any]]:
        for file_path in [self.stm_file, self.mtm_file, self.ltm_file]:
            with open(file_path, 'r') as f:
                memory_data = json.load(f)
            
            for memory in memory_data["memories"]:
                if memory["id"] == memory_id:
                    return memory
        
        return None
    
    def _update_memory(self, memory: Dict[str, Any]):
        memory_id = memory["id"]
        
        for file_path in [self.stm_file, self.mtm_file, self.ltm_file]:
            with open(file_path, 'r') as f:
                memory_data = json.load(f)
            
            updated = False
            for i, mem in enumerate(memory_data["memories"]):
                if mem["id"] == memory_id:
                    memory_data["memories"][i] = memory
                    updated = True
                    break
            
            if updated:
                with open(file_path, 'w') as f:
                    json.dump(memory_data, f, indent=2)
                break
    
    def _update_access_counts(self, memories: List[Dict[str, Any]]):
        for memory in memories:
            self._update_memory(memory)
