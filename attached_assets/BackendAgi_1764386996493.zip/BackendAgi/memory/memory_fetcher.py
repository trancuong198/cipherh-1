"""
Memory Fetcher - Lấy dữ liệu từ Notion
Wrapper cho existing Memory và SemanticMemory classes
"""

import os
from typing import List, Dict, Any, Optional
from utils.memory import Memory
from utils.semantic_memory import SemanticMemory

class MemoryFetcher:
    """
    Fetch all memory from Notion: episodic + semantic
    Returns raw data for further processing
    """
    
    def __init__(self):
        self.episodic_memory = Memory()
        self.semantic_memory = SemanticMemory()
    
    def fetch_all(self, episodic_limit: int = 50, semantic_limit: int = 100) -> Dict[str, Any]:
        """
        Fetch ALL memory from Notion
        
        Returns:
            {
                'episodic': List[Dict],  # Raw conversations
                'semantic': List[Dict],  # Knowledge entries
                'total_count': int
            }
        """
        print(f"📥 Fetching memory: {episodic_limit} episodic + {semantic_limit} semantic...")
        
        episodic_data = self.episodic_memory.retrieve_context(limit=episodic_limit)
        semantic_data = self.semantic_memory.retrieve_knowledge(limit=semantic_limit)
        
        result = {
            'episodic': episodic_data,
            'semantic': semantic_data,
            'total_count': len(episodic_data) + len(semantic_data)
        }
        
        print(f"✅ Fetched: {len(episodic_data)} episodic + {len(semantic_data)} semantic = {result['total_count']} total")
        
        return result
    
    def fetch_episodic(self, limit: int = 20) -> List[Dict[str, str]]:
        """Fetch episodic memories only"""
        return self.episodic_memory.retrieve_context(limit=limit)
    
    def fetch_semantic(self, topic: Optional[str] = None, limit: int = 20) -> List[Dict[str, str]]:
        """Fetch semantic knowledge, optionally filtered by topic"""
        return self.semantic_memory.retrieve_knowledge(topic=topic, limit=limit)
    
    def fetch_by_topic(self, topic: str, limit: int = 10) -> List[Dict[str, str]]:
        """Fetch semantic knowledge for a specific topic"""
        return self.semantic_memory.retrieve_knowledge(topic=topic, limit=limit)
    
    def get_all_topics(self) -> List[str]:
        """Get list of all unique knowledge topics"""
        return self.semantic_memory.get_all_topics()
