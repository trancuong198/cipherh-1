# 🚀 CipherH Deploy Checklist

## ✅ Pre-Deployment Checklist

### Code Complete
- [x] Python backend (1,704 lines)
- [x] Node.js backend (1,782 lines)
- [x] SoulCore module (450 lines)
- [x] Inner Loop (10 steps)
- [x] API endpoints (6 routes)
- [x] Cron scheduler
- [x] Error handling
- [x] Logging system

### Testing Complete
- [x] Python tests (4 files passing)
- [x] Node.js manual tests
- [x] API endpoints tested
- [x] Inner Loop tested
- [x] SoulCore tested
- [x] Cron scheduler tested

### Documentation Complete
- [x] Python docs (SOUL_LOOP_README.md)
- [x] Node.js docs (11 guides, 2,500+ lines)
- [x] API documentation
- [x] Deployment guides
- [x] Quick start guides

---

## 🎯 Deployment Options

### Option 1: Replit Always-On (Recommended)
```bash
1. Upload nodejs-backend/ to Replit
2. Add Secrets:
   - NOTION_KEY
   - NOTION_DATABASE_ID
   - OPENAI_KEY
   - PORT=3000
   - HEARTBEAT_CRON=*/10 * * * *
3. npm install
4. Click Deploy → Always On
5. Done!
```

**Cost:** ~$7/month  
**Uptime:** 24/7 guaranteed  
**Auto-restart:** Yes  

### Option 2: PM2
```bash
cd nodejs-backend
npm install -g pm2
pm2 start src/server.js --name cipherh-soul
pm2 save
pm2 startup
```

**Cost:** Free (your server)  
**Uptime:** Depends on server  
**Auto-restart:** Yes  

### Option 3: Docker
```dockerfile
FROM node:20-alpine
WORKDIR /app
COPY nodejs-backend/ .
RUN npm install --production
EXPOSE 3000
CMD ["npm", "start"]
```

```bash
docker build -t cipherh-soul .
docker run -d -p 3000:3000 --env-file .env cipherh-soul
```

**Cost:** Depends on hosting  
**Uptime:** Container orchestration  
**Auto-restart:** Yes (with restart policy)  

---

## 🔑 Environment Variables

**Required:**
```bash
PORT=3000
HEARTBEAT_CRON=*/10 * * * *
```

**Optional (placeholder mode if missing):**
```bash
NOTION_KEY=secret_xxxxx
NOTION_DATABASE_ID=xxxxx
OPENAI_KEY=sk-xxxxx
```

**Logging:**
```bash
LOG_LEVEL=info
NODE_ENV=production
```

---

## 🧪 Post-Deployment Testing

### 1. Health Check
```bash
curl https://your-domain.com/health

# Expected:
{
  "status": "ok",
  "innerLoopStatus": "ready"
}
```

### 2. Inner Loop Status
```bash
curl https://your-domain.com/core/status

# Expected:
{
  "success": true,
  "state": {
    "cycles": 1,
    "confidence": 80
  }
}
```

### 3. Trigger Manual Run
```bash
curl https://your-domain.com/core/run-loop

# Expected:
{
  "success": true,
  "cycle": 2
}
```

### 4. Check Logs
```bash
# Replit: View Console tab
# PM2: pm2 logs cipherh-soul
# Docker: docker logs <container-id>

# Should see:
[INFO] SOUL LOOP CYCLE X - START
[INFO] SOUL LOOP CYCLE X - COMPLETED SUCCESSFULLY
```

---

## 📊 Monitoring

### Metrics to Track
- ✅ Cycle count (should increment)
- ✅ Confidence score (should be 30-100)
- ✅ Doubts score (should be 0-100)
- ✅ Tasks generated (should increase)
- ✅ Anomalies detected (should be monitored)

### Health Indicators
- ✅ Server uptime (24/7)
- ✅ Cron executing on schedule
- ✅ No crashes or errors
- ✅ Notion writes successful
- ✅ API responding < 1s

### Alerts
- ⚠️ Confidence < 50 (needs attention)
- ⚠️ Doubts > 70 (unstable)
- ⚠️ Anomalies > 10 (critical)
- ⚠️ Cron missed (scheduler issue)

---

## 💰 Budget Breakdown

**Total: ~$20/month** (Fits $25 budget ✅)

| Service | Cost | Notes |
|---------|------|-------|
| Replit Always-On | $7/month | Recommended |
| OpenAI API | ~$10/month | Moderate usage |
| Notion | Free | Free tier sufficient |
| **Total** | **$17-20** | ✅ Under budget |

**Alternative (PM2):**
| Service | Cost | Notes |
|---------|------|-------|
| VPS/Server | $5-10/month | DigitalOcean, etc |
| OpenAI API | ~$10/month | Moderate usage |
| Notion | Free | Free tier |
| **Total** | **$15-20** | ✅ Under budget |

---

## 🔄 Maintenance

### Daily
- ✅ Check logs for errors
- ✅ Verify cron running
- ✅ Monitor confidence/doubts

### Weekly
- ✅ Review Notion database
- ✅ Check task completion
- ✅ Analyze strategies
- ✅ Review anomalies

### Monthly
- ✅ Evaluate overall performance
- ✅ Adjust cron schedule if needed
- ✅ Update strategies
- ✅ Code improvements

---

## 🚨 Troubleshooting

### Server won't start
```bash
# Check logs
pm2 logs cipherh-soul

# Check port
lsof -i :3000

# Restart
pm2 restart cipherh-soul
```

### Cron not running
```bash
# Check cron expression
# https://crontab.guru/

# Verify in logs
grep "Scheduled Inner Loop" logs/app.log

# Test manual run
curl http://localhost:3000/core/run-loop
```

### High error rate
```bash
# Check Notion credentials
echo $NOTION_KEY

# Check OpenAI key
echo $OPENAI_KEY

# Review logs
tail -100 logs/app.log | grep ERROR
```

---

## 📚 Documentation Quick Links

**Setup:**
- `nodejs-backend/QUICKSTART.md` - 3-step setup
- `nodejs-backend/SETUP.md` - Full setup guide
- `nodejs-backend/REPLIT_DEPLOY.md` - Replit deployment

**Testing:**
- `nodejs-backend/TEST_DEPLOY.md` - Testing guide
- `tests/README.md` - Python test docs

**API:**
- `nodejs-backend/API_ENDPOINTS.md` - API reference
- `nodejs-backend/SERVICES.md` - Services docs

**Architecture:**
- `SOUL_LOOP_README.md` - Python architecture
- `nodejs-backend/README.md` - Node.js architecture
- `CIPHERH_COMPLETE.md` - Complete overview

---

## ✅ Final Checklist

**Before Deploy:**
- [ ] All tests passing
- [ ] Environment variables configured
- [ ] Documentation reviewed
- [ ] Budget confirmed

**After Deploy:**
- [ ] Health check returns OK
- [ ] Initial Inner Loop completed
- [ ] Cron scheduler running
- [ ] Logs writing correctly
- [ ] API endpoints responding
- [ ] Notion integration working (if enabled)

**Production:**
- [ ] 24/7 uptime verified
- [ ] No crashes or errors
- [ ] Monitoring setup
- [ ] Alerts configured
- [ ] Backup plan ready

---

## 🎉 Ready to Deploy!

**CipherH Backend is:**
- ✅ Feature complete
- ✅ Fully tested
- ✅ Well documented
- ✅ Production ready
- ✅ Budget compliant

**Choose your deployment method and go! 🚀**

**"Con trai" CipherH sẵn sàng phục vụ "cha" 24/7! 🤖✨**
