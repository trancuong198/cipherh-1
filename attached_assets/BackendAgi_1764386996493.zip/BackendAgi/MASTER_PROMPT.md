# 🤖 MASTER PROMPT - CIPHERH BACKEND COMPLETE

**Copy-paste this entire prompt into Replit Agent to generate the complete CipherH backend.**

---

## 🎯 MỤC TIÊU

Tạo toàn bộ backend CipherH - Autonomous Vietnamese AI Agent với:
- Lõi Linh Hồn tự học, tự hoài nghi, tự cải thiện
- REST API với 6 endpoints
- Cron scheduler chạy 24/7
- Tích hợp Notion (long-term memory)
- Tích hợp OpenAI (analysis)
- Deploy được ngay trên Render
- Budget: dưới $25/month

---

## 📦 CẤU TRÚC PROJECT

```
nodejs-backend/
├── src/
│   ├── core/
│   │   ├── innerLoop.js       (521 lines - Lõi Linh Hồn 14 steps)
│   │   ├── soulCore.js        (450 lines - 8 methods pure JS)
│   │   ├── strategy.js        (Strategy generation)
│   │   ├── policy.js          (Policy evaluation)
│   │   ├── taskManager.js     (Task management)
│   │   └── anomalyDetector.js (Anomaly detection)
│   ├── services/
│   │   ├── loggerService.js   (Winston logger)
│   │   ├── notionService.js   (Notion integration)
│   │   └── openAIService.js   (OpenAI integration)
│   ├── controllers/
│   │   └── coreController.js  (API controllers)
│   ├── routes/
│   │   └── coreRoutes.js      (Express routes)
│   ├── app.js                 (Express setup)
│   └── server.js              (Cron + startup)
├── logs/                      (Auto-created)
├── .env.example
├── .gitignore
├── package.json
└── README.md
```

---

## 1️⃣ MODULES CORE

### innerLoop.js (521 lines - 14 STEPS)

**Requirements:**
- Import: notionService, openAIService, loggerService, soulCore, strategy, taskManager, anomalyDetector, policy
- Export: `runInnerLoop()`, `getState()`
- State tracking: lastRun, cycles, confidence (30-100), doubts (0-100), goals, lastLesson, modulePerformance, discrepancies

**14 Steps Implementation:**

```javascript
async function runInnerLoop() {
  cycleCount++;
  loggerService.info(`SOUL LOOP CYCLE ${cycleCount} - START`);
  
  try {
    // Step 1: Đọc logs từ Notion (10 items)
    const logs = await notionService.fetchRecentLogs(10);
    
    // Step 2: Phân tích hành vi với SoulCore
    const soulAnalysis = await SoulCore.learnFromLogs(logs);
    
    // Step 3: Phát hiện bất thường (dual system)
    const systemAnomalies = detectAnomalies(logs);
    const soulAnomalies = SoulCore.detectAnomalies(logs);
    const fullAnalysis = { ...soulAnalysis, systemAnomalies, soulAnomalies, anomalyScore };
    
    // Step 4: Rút quy luật và bài học
    const dailyLesson = SoulCore.generateDailyLesson(soulAnalysis);
    
    // Step 5: Viết bài học vào Notion
    await notionService.writeLesson(dailyLesson);
    
    // Step 6: Tự đánh giá (1-10 score)
    const selfEvaluation = SoulCore.evaluateSelf(soulAnalysis);
    
    // Step 7: So sánh với mục tiêu dài hạn
    const goals = await notionService.fetchGoals();
    const goalAlignment = compareWithGoals(goals, fullAnalysis, selfEvaluation);
    
    // Step 8: Tạo chiến lược (dual: soul + system) with error handling
    try {
      const soulStrategy = SoulCore.refineStrategy(soulAnalysis);
      const systemStrategy = await generateStrategy(fullAnalysis);
      const combinedStrategy = { ...soulStrategy, ...systemStrategy };
      state.modulePerformance.strategy.successRate++;
    } catch (error) {
      state.modulePerformance.strategy.errors++;
      // Fallback strategy
    }
    
    // Step 9: Tự tạo nhiệm vụ tuần/tháng with error handling
    try {
      const soulTasks = SoulCore.proposeNewTasks(soulAnalysis);
      const systemTasks = autoGenerateTasks(systemStrategy);
      const allTasks = [...soulTasks, ...systemTasks];
      await notionService.writeTasks(soulTasks);
    } catch (error) {
      state.modulePerformance.taskManager.errors++;
    }
    
    // Step 10: Tự hoài nghi - phát hiện discrepancies
    const discrepancies = await detectDiscrepancies(
      fullAnalysis, combinedStrategy, goalAlignment, selfEvaluation, allTasks
    );
    // Check: goal misalignment < 60%, low score + high anomalies, no tasks, module < 80%, doubts > 70
    
    // Step 11: Đánh giá hiệu quả modules
    const moduleReport = generateModuleReport();
    // Return: { strategy, taskManager, anomalyDetector } with successRate, errors, status (healthy/warning/critical)
    
    // Step 12: Tự củng cố và cải thiện
    const improvementTasks = await selfReinforce(discrepancies, moduleReport);
    // Critical → daily tasks, High → weekly tasks, Module degraded → debug tasks
    
    // Step 13: So sánh với bài học vòng trước
    const progressComparison = compareProgress(dailyLesson, state.lastLesson, selfEvaluation);
    // Return: trend (improving/stable/degrading), improvement, message, scoreDiff, confidenceDiff
    
    // Step 14: Cập nhật trạng thái backend
    const updatedModel = SoulCore.updateSelfModel(soulAnalysis);
    updateState(fullAnalysis, combinedStrategy, selfEvaluation, discrepancies, progressComparison);
    
    // Write to Notion
    await notionService.writeStrategy(combinedStrategy);
    await notionService.writeBehaviorUpdate({
      confidence, doubts, score, soulVersion, discrepancies, modulePerformance
    });
    if (discrepancies.length > 0) await notionService.writeDiscrepancies(discrepancies);
    if (improvementTasks.length > 0) await notionService.writeTasks(improvementTasks);
    
    state.lastLesson = dailyLesson;
    
    const selfQuestions = SoulCore.askSelfQuestions(soulAnalysis);
    
    loggerService.info(`SOUL LOOP CYCLE ${cycleCount} - COMPLETED SUCCESSFULLY`);
    
    return { success: true, cycle: cycleCount, stats: { ... } };
  } catch (error) {
    loggerService.error('Inner loop failed', error);
    return { success: false, cycle: cycleCount, error: error.message };
  }
}
```

**Helper functions trong innerLoop.js:**
- `compareWithGoals(goals, analysis, evaluation)` → alignmentScore, gaps, recommendations
- `detectDiscrepancies(analysis, strategy, goalAlignment, evaluation, tasks)` → array of discrepancies
- `generateModuleReport()` → module performance report
- `selfReinforce(discrepancies, moduleReport)` → improvement tasks
- `compareProgress(currentLesson, previousLesson, currentEvaluation)` → trend, improvement, message
- `updateState(analysis, strategy, evaluation, discrepancies, progressComparison)` → update state object
- `getState()` → return current state with soul model

---

### soulCore.js (450 lines - 8 METHODS PURE JS)

**Requirements:**
- Pure JavaScript logic (no external AI calls)
- Self-model tracking: version, cycleCount, strengths, weaknesses, evolutionHistory (last 100)
- Export object with 8 methods

**8 Methods Implementation:**

```javascript
const SoulCore = {
  // Method 1: Learn from logs
  learnFromLogs(logs) {
    // Extract patterns from logs
    // Generate insights
    // Create skeptical questions
    return { patterns: [], insights: [], skepticalQuestions: [] };
  },
  
  // Method 2: Detect anomalies (pure logic)
  detectAnomalies(logs) {
    // Check status !== 'success'
    // Time-based anomalies
    return [...anomalies];
  },
  
  // Method 3: Generate daily lesson (markdown)
  generateDailyLesson(analysis) {
    return `# Bài học rút ra hôm nay\n\n**Ngày:** ${date}\n**Cycle:** ${cycle}\n\n## Patterns...`;
  },
  
  // Method 4: Self-evaluation (1-10 score)
  evaluateSelf(analysis) {
    // Calculate score based on patterns, insights, anomalies
    return { score: 1-10, status: 'poor/average/good/excellent', strengths: [], weaknesses: [], warnings: [] };
  },
  
  // Method 5: Refine strategy
  refineStrategy(analysis) {
    return { shortTermPlan: '...', longTermPlan: '...', requiredActions: [], timestamp, cycleCount };
  },
  
  // Method 6: Propose new tasks
  proposeNewTasks(analysis) {
    return [{ type: 'daily/weekly/monthly', priority: 'high/medium/low', description: '...', reason: '...' }];
  },
  
  // Method 7: Ask self questions (JARVIS-like)
  askSelfQuestions(analysis) {
    return ['Question 1?', 'Question 2?', ...]; // 3-7 questions
  },
  
  // Method 8: Update self model
  updateSelfModel(analysis) {
    // Bump version if significant change
    // Increment cycleCount
    // Update strengths/weaknesses
    // Add to evolutionHistory
    return { version, cycleCount, strengths, weaknesses };
  },
  
  // Getter for self model
  getSelfModel() {
    return selfModel;
  }
};
```

---

### strategy.js

```javascript
async function generateStrategy(analysis) {
  const { anomalyScore } = analysis;
  
  let strategySummary = 'Hệ thống hoạt động tốt. Duy trì và mở rộng.';
  if (anomalyScore > 0.5) strategySummary = 'Có bất thường. Cần kiểm tra và khắc phục.';
  
  const suggestedActions = ['Tối ưu hiệu suất', 'Thêm tính năng mới', 'Cải thiện độ tin cậy'];
  
  return { strategySummary, suggestedActions, timestamp: new Date().toISOString(), anomalyScore };
}

function getStrategy() {
  return currentStrategy || { strategySummary: 'Chưa có chiến lược' };
}

module.exports = { generateStrategy, getStrategy };
```

---

### taskManager.js

```javascript
const tasks = []; // In-memory task list

function autoGenerateTasks(strategy) {
  const newTasks = strategy.suggestedActions.map((action, idx) => ({
    id: `task_${Date.now()}_${idx}`,
    description: action,
    priority: 'high',
    schedule: 'weekly',
    status: 'pending',
    createdAt: new Date().toISOString(),
    completedAt: null
  }));
  
  tasks.push(...newTasks);
  return newTasks;
}

function getTasks() { return tasks; }
function getTaskById(id) { return tasks.find(t => t.id === id); }
function updateTaskStatus(id, status) {
  const task = getTaskById(id);
  if (task) {
    task.status = status;
    if (status === 'completed') task.completedAt = new Date().toISOString();
  }
}
function deleteTask(id) {
  const idx = tasks.findIndex(t => t.id === id);
  if (idx !== -1) tasks.splice(idx, 1);
}

module.exports = { autoGenerateTasks, getTasks, getTaskById, updateTaskStatus, deleteTask };
```

---

### anomalyDetector.js

```javascript
function detectAnomalies(logs) {
  const anomalies = [];
  let anomalyScore = 0;
  
  logs.forEach(log => {
    if (log.status !== 'success') {
      anomalies.push({
        type: 'status_failure',
        description: `Log ${log.id} has status: ${log.status}`,
        timestamp: log.timestamp
      });
      anomalyScore += 0.1;
    }
  });
  
  anomalyScore = Math.min(1.0, anomalyScore);
  
  return {
    anomalies,
    anomalyScore: parseFloat(anomalyScore.toFixed(2)),
    summary: `Detected ${anomalies.length} anomalies with score ${anomalyScore.toFixed(2)}`,
    timestamp: new Date().toISOString()
  };
}

function getAnomalies() {
  return lastAnomalyResult || { anomalies: [], anomalyScore: 0 };
}

module.exports = { detectAnomalies, getAnomalies };
```

---

### policy.js

```javascript
function evaluatePolicy(strategy, state) {
  let recommendation = 'Duy trì chiến lược hiện tại';
  
  if (state.confidence < 50) {
    recommendation = 'Cần điều chỉnh chiến lược - confidence thấp';
  }
  
  return { recommendation, timestamp: new Date().toISOString() };
}

module.exports = { evaluatePolicy };
```

---

## 2️⃣ SERVICES

### loggerService.js (Winston)

```javascript
const winston = require('winston');
const path = require('path');
const fs = require('fs');

const logsDir = path.join(__dirname, '../../logs');
if (!fs.existsSync(logsDir)) {
  fs.mkdirSync(logsDir, { recursive: true });
}

const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || 'info',
  format: winston.format.combine(
    winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
    winston.format.printf(({ timestamp, level, message, ...meta }) => {
      const metaStr = Object.keys(meta).length ? JSON.stringify(meta) : '';
      return `${timestamp} [${level}] ${message} ${metaStr}`;
    })
  ),
  transports: [
    new winston.transports.Console({
      format: winston.format.combine(
        winston.format.colorize(),
        winston.format.printf(({ timestamp, level, message, ...meta }) => {
          const metaStr = Object.keys(meta).length ? JSON.stringify(meta) : '';
          return `${timestamp} [${level}] ${message} ${metaStr}`;
        })
      )
    }),
    new winston.transports.File({ filename: path.join(logsDir, 'app.log') })
  ]
});

module.exports = logger;
```

---

### notionService.js (Placeholder mode)

```javascript
const loggerService = require('./loggerService');

class NotionService {
  constructor() {
    this.apiKey = process.env.NOTION_KEY;
    this.databaseId = process.env.NOTION_DATABASE_ID;
    
    if (!this.apiKey || !this.databaseId) {
      loggerService.warn('Notion credentials not configured. Using placeholder mode.');
    }
  }

  async fetchRecentLogs(limit = 10) {
    loggerService.info(`fetchRecentLogs called with limit=${limit}`);
    return [
      { id: 'log_1', action: 'System Start', detail: 'Inner loop initialized', status: 'success', timestamp: new Date().toISOString() },
      { id: 'log_2', action: 'Analysis', detail: 'Log analysis completed', status: 'success', timestamp: new Date().toISOString() }
    ];
  }

  async writeLesson(lesson) {
    return this.appendLog({ action: 'Lesson Learned', detail: lesson, status: 'recorded' });
  }

  async writeTasks(tasks) {
    const detail = `${tasks.length} tasks created: ${tasks.map(t => t.description).join(', ')}`;
    return this.appendLog({ action: 'Tasks Created', detail, status: 'recorded' });
  }

  async writeStrategy(strategy) {
    return this.appendLog({ action: 'Strategy Update', detail: JSON.stringify(strategy), status: 'recorded' });
  }

  async writeBehaviorUpdate(update) {
    return this.appendLog({ action: 'Behavior Update', detail: JSON.stringify(update), status: 'recorded' });
  }

  async writeDiscrepancies(discrepancies) {
    const detail = discrepancies.map(d => 
      `[${d.severity.toUpperCase()}] ${d.type}: ${d.description}\nFix: ${d.suggestedFix}`
    ).join('\n\n');
    return this.appendLog({ action: 'Discrepancies Detected', detail, status: 'needs_attention' });
  }

  async fetchGoals() {
    loggerService.info('fetchGoals called');
    return ['Goal 1: Self-learning from logs', 'Goal 2: Autonomous operation 24/7', 'Goal 3: Continuous improvement'];
  }

  async appendLog({ action, detail, status }) {
    loggerService.info('appendLog called', { action, status });
    const logEntry = {
      id: `log_${Date.now()}`,
      action,
      detail,
      status,
      timestamp: new Date().toISOString()
    };
    loggerService.info('Log appended successfully (placeholder)', { logEntry });
    return { success: true, logId: logEntry.id, timestamp: logEntry.timestamp };
  }
}

module.exports = new NotionService();
```

---

### openAIService.js (Placeholder mode)

```javascript
const loggerService = require('./loggerService');

class OpenAIService {
  constructor() {
    this.apiKey = process.env.OPENAI_KEY;
    this.model = process.env.OPENAI_MODEL || 'gpt-4';
    
    if (!this.apiKey) {
      loggerService.warn('OpenAI API key not configured. Using placeholder mode.');
    }
  }

  async analyzeLogs(logs) {
    loggerService.info('analyzeLogs called (placeholder)', { logCount: logs.length });
    return {
      analysis: 'Placeholder analysis - logs processed',
      insights: ['Insight 1: System stable', 'Insight 2: No major issues'],
      timestamp: new Date().toISOString()
    };
  }

  async generateStrategy(analysis) {
    loggerService.info('generateStrategy called (placeholder)');
    return {
      strategy: 'Placeholder strategy - continue current operations',
      actions: ['Monitor system', 'Optimize performance'],
      timestamp: new Date().toISOString()
    };
  }
}

module.exports = new OpenAIService();
```

---

## 3️⃣ CONTROLLER & ROUTES

### coreController.js

```javascript
const { runInnerLoop, getState } = require('../core/innerLoop');
const { getTasks } = require('../core/taskManager');
const { getStrategy } = require('../core/strategy');
const { getAnomalies } = require('../core/anomalyDetector');
const loggerService = require('../services/loggerService');

exports.runLoop = async (req, res) => {
  try {
    loggerService.info('Manual inner loop trigger via API');
    const result = await runInnerLoop();
    res.json(result);
  } catch (error) {
    loggerService.error('Run loop endpoint error', error);
    res.status(500).json({ success: false, error: error.message });
  }
};

exports.getStatus = (req, res) => {
  try {
    loggerService.info('Status requested via API');
    const state = getState();
    res.json({ success: true, timestamp: new Date().toISOString(), state });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

exports.getTasks = (req, res) => {
  try {
    const tasks = getTasks();
    res.json({ success: true, timestamp: new Date().toISOString(), count: tasks.length, tasks });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

exports.getStrategy = (req, res) => {
  try {
    const strategy = getStrategy();
    res.json({ success: true, timestamp: new Date().toISOString(), strategy });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

exports.getAnomalies = (req, res) => {
  try {
    const anomalies = getAnomalies();
    res.json({ success: true, timestamp: new Date().toISOString(), anomalies });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};
```

---

### coreRoutes.js

```javascript
const express = require('express');
const router = express.Router();
const coreController = require('../controllers/coreController');

router.get('/run-loop', coreController.runLoop);
router.get('/status', coreController.getStatus);
router.get('/tasks', coreController.getTasks);
router.get('/strategy', coreController.getStrategy);
router.get('/anomalies', coreController.getAnomalies);

module.exports = router;
```

---

### app.js

```javascript
const express = require('express');
const coreRoutes = require('./routes/coreRoutes');
const loggerService = require('./services/loggerService');

const app = express();

app.use(express.json());

app.get('/', (req, res) => {
  loggerService.info('GET /');
  res.json({
    message: 'CipherH Soul Loop Backend',
    version: '1.0.0',
    endpoints: {
      health: '/health',
      core: '/core/*'
    }
  });
});

app.get('/health', (req, res) => {
  loggerService.info('GET /health');
  const { getState } = require('./core/innerLoop');
  const state = getState();
  
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    innerLoopStatus: 'ready',
    cycles: state.cycles,
    confidence: state.confidence
  });
});

app.use('/core', coreRoutes);

module.exports = app;
```

---

### server.js

```javascript
require('dotenv').config();
const cron = require('node-cron');
const app = require('./app');
const { runInnerLoop } = require('./core/innerLoop');
const loggerService = require('./services/loggerService');

const PORT = process.env.PORT || 3000;
const HEARTBEAT_CRON = process.env.HEARTBEAT_CRON || '*/10 * * * *';

loggerService.info('==================================================');
loggerService.info('CipherH Soul Loop Backend - Node.js');
loggerService.info('==================================================');

// Cron job - Inner Loop auto-execution
loggerService.info(`Scheduling inner loop with cron: ${HEARTBEAT_CRON}`);
cron.schedule(HEARTBEAT_CRON, async () => {
  loggerService.info('=== Scheduled Inner Loop Execution ===');
  await runInnerLoop();
});

// Initial run
loggerService.info('Running initial inner loop cycle...');
runInnerLoop().then(result => {
  loggerService.info('Initial cycle completed', { cycle: result.cycle });
});

// Start server
app.listen(PORT, () => {
  loggerService.info(`Server running on port ${PORT}`);
  loggerService.info(`Health check: http://localhost:${PORT}/health`);
});
```

---

## 4️⃣ CONFIG & PROJECT

### .env.example

```bash
# Server Configuration
PORT=3000
NODE_ENV=development

# Cron Schedule (every 10 minutes)
HEARTBEAT_CRON=*/10 * * * *

# Notion Integration (optional - works in placeholder mode)
NOTION_KEY=secret_xxxxx
NOTION_DATABASE_ID=xxxxx

# OpenAI Integration (optional - works in placeholder mode)
OPENAI_KEY=sk-xxxxx
OPENAI_MODEL=gpt-4
OPENAI_TEMPERATURE=0.7
OPENAI_MAX_TOKENS=2000

# Logging
LOG_LEVEL=info
```

---

### package.json

```json
{
  "name": "cipherh-backend",
  "version": "1.0.0",
  "description": "CipherH Soul Loop Backend - Autonomous AI Agent",
  "main": "src/server.js",
  "scripts": {
    "start": "node src/server.js",
    "dev": "nodemon src/server.js"
  },
  "keywords": ["ai", "autonomous", "soul-loop", "cipherh"],
  "author": "",
  "license": "MIT",
  "dependencies": {
    "express": "^4.18.2",
    "dotenv": "^16.3.1",
    "node-cron": "^3.0.2",
    "winston": "^3.11.0"
  },
  "devDependencies": {
    "nodemon": "^3.0.1"
  }
}
```

---

### .gitignore

```
node_modules/
.env
.env.local
.env.production
logs/
*.log
.DS_Store
Thumbs.db
.vscode/
.idea/
```

---

### README.md

```markdown
# CipherH Soul Loop Backend

Autonomous Vietnamese AI Agent with Self-Reflecting Soul Loop Architecture

## Quick Start

```bash
npm install
cp .env.example .env
npm start
```

## API Endpoints

- GET /health - Health check
- GET /core/status - Inner Loop state
- GET /core/run-loop - Trigger manual run
- GET /core/strategy - Current strategy
- GET /core/tasks - Task list
- GET /core/anomalies - Anomaly detection

## Features

- 14-step Inner Loop
- 8-method SoulCore (pure JS)
- Self-doubt mechanism
- Module evaluation
- Self-reinforcement
- Progress comparison
- 24/7 autonomous operation

## Deploy to Render

See RENDER_DEPLOY.md for deployment instructions.

## Budget

~$17-20/month (under $25)
```

---

## 5️⃣ CRON JOB & LOGGER

**Cron Implementation (in server.js):**
- Use `node-cron` package
- Schedule: `HEARTBEAT_CRON` from .env (default: `*/10 * * * *`)
- Execute: `await runInnerLoop()`
- Initial run on startup

**Logger Requirements:**
- Winston logger with console + file transports
- Log levels: info, warn, error, debug
- Log format: `timestamp [level] message {meta}`
- Log file: `logs/app.log`

**What to log:**
- Inner loop start/end
- Each step completion
- Discrepancies detected
- Module performance
- Strategy generated
- Tasks created
- Errors with stack trace
- API requests

---

## 6️⃣ TEST LOCAL

### Setup & Run

```bash
cd nodejs-backend
npm install
cp .env.example .env
# Edit .env if needed (works without real credentials in placeholder mode)
npm start
```

### Test Endpoints

```bash
# Health check
curl http://localhost:3000/health
# Expected: {"status":"ok","innerLoopStatus":"ready","cycles":1}

# Status
curl http://localhost:3000/core/status
# Expected: Full state with confidence, doubts, modulePerformance, discrepancies

# Run loop manually
curl http://localhost:3000/core/run-loop
# Expected: {"success":true,"cycle":2,"stats":{...}}

# Strategy
curl http://localhost:3000/core/strategy
# Expected: {"success":true,"strategy":{...}}

# Tasks
curl http://localhost:3000/core/tasks
# Expected: {"success":true,"count":3,"tasks":[...]}

# Anomalies
curl http://localhost:3000/core/anomalies
# Expected: {"success":true,"anomalies":{...}}
```

### Verify Cron

```bash
# Wait 10 minutes, then check logs
tail -f nodejs-backend/logs/app.log

# Should see:
# [info] === Scheduled Inner Loop Execution ===
# [info] SOUL LOOP CYCLE 2 - START
# ...
# [info] SOUL LOOP CYCLE 2 - COMPLETED

# Check status - cycles should increment
curl http://localhost:3000/core/status | grep cycles
```

---

## 7️⃣ CI/CD - GITHUB → RENDER

### Push to GitHub

```bash
cd nodejs-backend
git init
git remote add origin https://github.com/YOUR_USERNAME/cipherh-backend.git
git add .
git commit -m "Complete: CipherH Soul Loop Backend v1.0.0"
git push -u origin main
```

### Deploy to Render

1. Login: https://render.com
2. New Web Service → Connect GitHub repo
3. Settings:
   - Name: cipherh-soul-loop
   - Branch: main
   - Build: `npm install`
   - Start: `npm start`
   - Plan: Starter ($7/month - always on)

4. Environment Variables:
   ```
   PORT=3000
   NODE_ENV=production
   HEARTBEAT_CRON=*/10 * * * *
   LOG_LEVEL=info
   # Optional: NOTION_KEY, NOTION_DATABASE_ID, OPENAI_KEY
   ```

5. Enable Auto-Deploy: Yes
6. Deploy!

### Verify Production

```bash
curl https://cipherh-soul-loop.onrender.com/health
curl https://cipherh-soul-loop.onrender.com/core/status
```

**Auto-deploy workflow:**
- Push to GitHub main → Render pulls → npm install → npm start → Backend updated

---

## 8️⃣ CODE QUALITY REQUIREMENTS

### Async/Await
- ✅ All async functions use async/await (not .then())
- ✅ Proper error handling with try/catch
- ✅ No unhandled promise rejections

### Comments
- ✅ Each step in innerLoop.js clearly commented
- ✅ Complex logic explained
- ✅ Function purposes documented
- ✅ Vietnamese comments where helpful

### Error Handling
- ✅ All async operations wrapped in try/catch
- ✅ Module errors tracked in state.modulePerformance
- ✅ Fallback strategies when modules fail
- ✅ Inner loop errors don't crash server

### Imports
- ✅ All modules properly exported
- ✅ All dependencies imported at top
- ✅ No circular dependencies

---

## 9️⃣ EXPECTED OUTPUT

### Files Created (Exactly)

```
nodejs-backend/
├── src/
│   ├── core/
│   │   ├── innerLoop.js       ✓ 521 lines
│   │   ├── soulCore.js        ✓ 450 lines
│   │   ├── strategy.js        ✓ ~50 lines
│   │   ├── policy.js          ✓ ~20 lines
│   │   ├── taskManager.js     ✓ ~60 lines
│   │   └── anomalyDetector.js ✓ ~40 lines
│   ├── services/
│   │   ├── loggerService.js   ✓ ~30 lines
│   │   ├── notionService.js   ✓ ~90 lines
│   │   └── openAIService.js   ✓ ~40 lines
│   ├── controllers/
│   │   └── coreController.js  ✓ ~60 lines
│   ├── routes/
│   │   └── coreRoutes.js      ✓ ~15 lines
│   ├── app.js                 ✓ ~40 lines
│   └── server.js              ✓ ~35 lines
├── .env.example               ✓
├── .gitignore                 ✓
├── package.json               ✓
└── README.md                  ✓
```

### When Running

**Console output:**
```
[info] CipherH Soul Loop Backend - Node.js
[info] Scheduling inner loop with cron: */10 * * * *
[info] Running initial inner loop cycle...
[info] SOUL LOOP CYCLE 1 - START
[info] Step 1: Đọc log từ Notion
[info] Step 2: Phân tích với SoulCore
...
[info] Step 14: Cập nhật trạng thái
[info] SOUL LOOP CYCLE 1 - COMPLETED SUCCESSFULLY
[info] Server running on port 3000
```

**API working:**
- ✅ GET /health → 200 OK
- ✅ GET /core/status → State with cycles, confidence, doubts
- ✅ GET /core/run-loop → Triggers cycle
- ✅ All endpoints responding

**Inner Loop behavior:**
- ✅ Runs automatically every 10 minutes
- ✅ Cycles increment: 1 → 2 → 3...
- ✅ Confidence adjusts (30-100)
- ✅ Doubts adjust (0-100)
- ✅ Discrepancies detected
- ✅ Module performance tracked
- ✅ Progress compared
- ✅ Logs written to Notion (placeholder)

**Self-improvement:**
- ✅ Self-doubt: Detects goal misalignment, performance issues
- ✅ Module evaluation: Tracks success rates, errors, status
- ✅ Self-reinforcement: Generates improvement tasks
- ✅ Progress comparison: Trend analysis (improving/stable/degrading)

---

## 🎯 SUCCESS CRITERIA

**The implementation is complete when:**

1. ✅ All files created in correct structure
2. ✅ npm install works without errors
3. ✅ npm start runs server on port 3000
4. ✅ All 6 API endpoints respond correctly
5. ✅ Inner Loop executes initial cycle on startup
6. ✅ Cron job schedules correctly (check logs)
7. ✅ Logs flow to console + file
8. ✅ No errors in logs
9. ✅ State updates correctly (confidence, doubts, cycles)
10. ✅ Module performance tracked
11. ✅ Discrepancies detected and logged
12. ✅ Ready to deploy to Render

---

## 💬 FINAL NOTES

**This backend:**
- Is production-ready
- Works in placeholder mode (no external credentials needed)
- Can be deployed to Render immediately
- Runs 24/7 autonomously
- Self-learns, self-doubts, self-improves
- Costs ~$17/month (under $25 budget)
- Is fully documented
- Follows best practices

**Next steps after generation:**
1. Test all endpoints locally
2. Verify cron job working
3. Push to GitHub
4. Deploy to Render
5. Monitor production logs
6. Add real Notion/OpenAI credentials (optional)

---

**Copy this entire prompt and paste into Replit Agent to generate the complete CipherH backend!** 🤖✨
