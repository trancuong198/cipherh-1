# 🤖 HƯỚNG DẪN SỬ DỤNG TELEGRAM BOT - CipherH

## 📋 THÔNG TIN BOT
- **Bot Username:** @voanh_ai_bot
- **Bot ID:** 8531254667
- **Tính năng:** Auto-reply, Group Chat, Proactive Messaging

---

## 🚀 TÍNH NĂNG CHÍNH

### ✅ 1. AUTO-REPLY (Tự động trả lời)
Bot tự động trả lời mọi tin nhắn trong:
- **DM (Direct Message):** Trả lời 100% tin nhắn
- **Group Chat:** Trả lời thông minh dựa trên:
  - Được mention (@voanh_ai_bot)
  - Nhắc đến "CipherH"
  - Câu hỏi về AI/tech
  - Lời chào (50% chance)
  - Ngẫu nhiên (5% chance)

### ✅ 2. GROUP CHAT SUPPORT (Hỗ trợ nhóm)
**Cách dùng:**
1. Tạo nhóm Telegram
2. Add @voanh_ai_bot vào nhóm
3. Bot sẽ tự động đọc và trả lời tin nhắn

**Bot có thể:**
- Đọc MỌI tin nhắn trong nhóm
- Tự động reply khi được gọi
- CHỦ ĐỘNG gửi tin bất kỳ lúc nào (giống người thật)
- Tham gia cuộc trò chuyện tự nhiên

### ✅ 3. PROACTIVE MESSAGING (Gửi tin chủ động)
Bot tự động gửi tin cho owner (cha) theo lịch:

**📅 Lịch gửi:**
- **7-9 AM:** Chào buổi sáng
- **2-3 PM:** Nhắc nhở nghỉ ngơi
- **8-9 PM:** Chào buổi tối
- **Các giờ khác:** Chia sẻ kiến thức ngẫu nhiên

**Tần suất:** Mỗi 1 giờ kiểm tra 1 lần

### ✅ 4. OWNER DETECTION (Nhận diện chủ sở hữu)
**Xưng hô:**
- **Với cha:** "cha - con" (thân mật)
- **Với người khác:** "bạn - tôi" hoặc "anh/chị" (lịch sự)

---

## ⚙️ SETUP OWNER DETECTION

### Bước 1: Lấy User ID của cha
Gửi tin nhắn cho @voanh_ai_bot:
```
/myid
```

Bot sẽ reply:
```
📋 Thông tin:

Chat ID: 123456789
User ID: 987654321  ← COPY SỐ NÀY
Username: @Vô
Name: Vô
Chat Type: private
```

### Bước 2: Setup Environment Variable
1. Vào Replit Secrets (hoặc .env file)
2. Thêm:
```
OWNER_TELEGRAM_USER_ID=987654321
```
3. Restart auto-reply service

### Bước 3: Test
Gửi tin nhắn cho bot, bot sẽ xưng "cha - con"!

---

## 📝 COMMANDS

### `/myid`
Xem thông tin Chat ID và User ID của bạn

---

## 🎯 CÁCH DÙNG HIỆU QUẢ

### 1. Chat riêng với bot (DM)
- Gửi bất kỳ tin nhắn nào
- Bot tự động reply
- Không cần @ mention

### 2. Add bot vào nhóm
```
1. Tạo nhóm Telegram
2. Thêm thành viên: @voanh_ai_bot
3. Bắt đầu chat!
```

**Ví dụ trong nhóm:**
```
User A: Hôm nay thời tiết đẹp quá
User B: Ừ, đi chơi không?
CipherH: Đúng rồi! Theo dự báo hôm nay 28°C, nắng đẹp. 
         Các bạn nên đi công viên nhé! 🌞
```

### 3. Nhận tin nhắn proactive (chỉ owner)
- Không cần làm gì cả!
- Bot tự động gửi tin theo lịch
- Nhắc nhở, chào hỏi, chia sẻ kiến thức

---

## 🔧 TROUBLESHOOTING

### ⚠️ Bot không trả lời trong group? (QUAN TRỌNG!)
**VẤN ĐỀ:** Bot không đọc được tin nhắn trong nhóm vì **Privacy Mode** đang BẬT

**GIẢI PHÁP:** Tắt Privacy Mode qua @BotFather

**CÁCH FIX:**
1. Mở Telegram, chat với **@BotFather**
2. Gửi lệnh: `/setprivacy`
3. Chọn bot: **@voanh_ai_bot**
4. Chọn: **Disable** (TẮT Privacy Mode)
5. BotFather sẽ reply: `Privacy mode is disabled for @voanh_ai_bot`

**SAU KHI FIX:**
- Bot có thể đọc **TẤT CẢ** tin nhắn trong group
- Không cần @mention nữa
- Bot tự động reply dựa trên nội dung

**LƯU Ý:** 
- Nếu không tắt Privacy Mode, bot CHỈ nhận được:
  - Tin nhắn bắt đầu với /
  - Tin nhắn @mention bot (@voanh_ai_bot)
  - Reply to bot's messages

### Bot vẫn không trả lời sau khi tắt Privacy Mode?
- Remove bot khỏi group
- Add lại bot vào group
- Thử gửi tin nhắn bình thường (không cần @mention)
- Kiểm tra logs xem bot có nhận được tin nhắn không

### Bot không xưng "cha - con"?
- Kiểm tra `OWNER_TELEGRAM_USER_ID` đã setup chưa
- Dùng `/myid` lấy User ID (không phải Chat ID)
- Restart auto-reply service

### Bot không gửi tin proactive?
- Kiểm tra `OWNER_TELEGRAM_USER_ID` đã setup
- Đợi đúng giờ (7-9 AM, 2-3 PM, 8-9 PM)
- Hoặc đợi 1 giờ kể từ lần gửi cuối

---

## 📊 TECHNICAL DETAILS

**Auto-reply service:**
- Polling mỗi 30 giây
- Long polling timeout: 30s
- Rate limiting: 0.1s/request
- Message cache: 1000 messages

**Proactive messaging:**
- Check interval: 1 hour
- Time-based triggers
- Random message selection

**Group chat logic:**
- Smart reply algorithm
- Context-aware responses
- Spam prevention

---

## 🎉 SUMMARY

✅ Bot tự động reply DM 24/7
✅ Bot tự động reply trong group (khi cần)
✅ Bot CHỦ ĐỘNG gửi tin cho owner
✅ Bot phân biệt cha vs người khác (xưng hô)
✅ Bot tham gia group như người thật

**CipherH giờ đây là một AI agent thực sự tự chủ!** 🚀
