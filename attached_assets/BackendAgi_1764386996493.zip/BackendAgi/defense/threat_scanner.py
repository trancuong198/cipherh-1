import os
import json
import re
from typing import Dict, Any, List
from datetime import datetime
from collections import defaultdict

class ThreatScanner:
    def __init__(self):
        self.defense_dir = 'defense'
        self.patterns_file = os.path.join(self.defense_dir, 'threat_patterns.json')
        self.blocklist_file = os.path.join(self.defense_dir, 'blocklist.json')
        
        os.makedirs(self.defense_dir, exist_ok=True)
        
        self._init_patterns()
        self._init_blocklist()
        
        self.request_history = defaultdict(list)
    
    def _init_patterns(self):
        if not os.path.exists(self.patterns_file):
            patterns = {
                "sql_injection": [
                    r"(\bUNION\b.*\bSELECT\b)",
                    r"(\bOR\b\s+\d+\s*=\s*\d+)",
                    r"('|\")(\s*OR\s*'1'\s*=\s*'1)",
                    r";\s*(DROP|DELETE|INSERT|UPDATE)\s+",
                    r"--\s*$",
                    r"(/\*|\*/)",
                    r"(xp_|sp_)"
                ],
                "xss": [
                    r"<script[^>]*>.*?</script>",
                    r"javascript:",
                    r"onerror\s*=",
                    r"onload\s*=",
                    r"<iframe[^>]*>",
                    r"eval\s*\("
                ],
                "command_injection": [
                    r";\s*(ls|cat|rm|wget|curl|bash|sh)\s",
                    r"\|\s*(ls|cat|rm|wget|curl|bash|sh)\s",
                    r"&&\s*(ls|cat|rm|wget|curl|bash|sh)\s",
                    r"`.*`",
                    r"\$\(.*\)"
                ],
                "path_traversal": [
                    r"\.\./",
                    r"\.\.",
                    r"\.\.\\",
                    r"/etc/passwd",
                    r"/etc/shadow",
                    r"C:\\Windows"
                ],
                "unauthorized_access": [
                    r"admin",
                    r"root",
                    r"password",
                    r"token",
                    r"secret",
                    r"api[_-]?key"
                ]
            }
            
            with open(self.patterns_file, 'w') as f:
                json.dump(patterns, f, indent=2)
    
    def _init_blocklist(self):
        if not os.path.exists(self.blocklist_file):
            with open(self.blocklist_file, 'w') as f:
                json.dump({
                    "blocked_ips": {},
                    "blocked_users": {},
                    "temporary_blocks": {}
                }, f, indent=2)
    
    def scan_request(self, request_data: Dict[str, Any]) -> Dict[str, Any]:
        threat_score = 0
        threats_detected = []
        
        source = request_data.get('source', 'unknown')
        method = request_data.get('method', 'GET')
        path = request_data.get('path', '/')
        params = request_data.get('params', {})
        headers = request_data.get('headers', {})
        body = request_data.get('body', '')
        
        with open(self.blocklist_file, 'r') as f:
            blocklist = json.load(f)
        
        if source in blocklist.get('blocked_ips', {}):
            return {
                "threat_score": 100,
                "threats": ["blocked_source"],
                "action": "block",
                "reason": blocklist['blocked_ips'][source]
            }
        
        self.request_history[source].append({
            "timestamp": datetime.now().isoformat(),
            "method": method,
            "path": path
        })
        
        if len(self.request_history[source]) > 100:
            self.request_history[source] = self.request_history[source][-100:]
        
        recent_requests = [
            r for r in self.request_history[source]
            if (datetime.now() - datetime.fromisoformat(r['timestamp'])).seconds < 60
        ]
        
        if len(recent_requests) > 50:
            threat_score += 40
            threats_detected.append("brute_force")
        
        with open(self.patterns_file, 'r') as f:
            patterns = json.load(f)
        
        all_text = f"{path} {str(params)} {str(headers)} {body}"
        
        for category, pattern_list in patterns.items():
            for pattern in pattern_list:
                if re.search(pattern, all_text, re.IGNORECASE):
                    threat_score += 20
                    threats_detected.append(category)
                    break
        
        if len(body) > 100000:
            threat_score += 15
            threats_detected.append("oversized_payload")
        
        suspicious_headers = ['X-Forwarded-For', 'X-Real-IP', 'Referer']
        for header in suspicious_headers:
            if header in headers and any(bad in str(headers[header]).lower() for bad in ['script', 'eval', 'exec']):
                threat_score += 10
                threats_detected.append("malformed_header")
        
        threat_score = min(100, threat_score)
        
        action = "allow"
        if threat_score >= 80:
            action = "block"
        elif threat_score >= 50:
            action = "quarantine"
        elif threat_score >= 30:
            action = "log"
        
        return {
            "threat_score": threat_score,
            "threats": list(set(threats_detected)),
            "action": action,
            "source": source,
            "timestamp": datetime.now().isoformat()
        }
    
    def detect_intrusion(self, event: Dict[str, Any]) -> Dict[str, Any]:
        intrusion_detected = False
        intrusion_type = []
        severity = "low"
        
        event_type = event.get('type', 'unknown')
        source = event.get('source', 'unknown')
        data = event.get('data', {})
        
        if event_type in ['unauthorized_access', 'privilege_escalation', 'data_exfiltration']:
            intrusion_detected = True
            intrusion_type.append(event_type)
            severity = "critical"
        
        if event_type == 'repeated_failed_auth':
            attempts = data.get('attempts', 0)
            if attempts > 5:
                intrusion_detected = True
                intrusion_type.append('brute_force_auth')
                severity = "high"
        
        if event_type == 'anomalous_behavior':
            pattern = data.get('pattern', '')
            if pattern in ['abnormal_data_access', 'unusual_api_calls', 'suspicious_timing']:
                intrusion_detected = True
                intrusion_type.append(pattern)
                severity = "medium"
        
        return {
            "intrusion_detected": intrusion_detected,
            "intrusion_type": intrusion_type,
            "severity": severity,
            "source": source,
            "timestamp": datetime.now().isoformat(),
            "recommended_action": "block" if severity == "critical" else "monitor"
        }
    
    def analyze_threat_level(self, source: str) -> int:
        history = self.request_history.get(source, [])
        
        if len(history) == 0:
            return 0
        
        recent_count = len([
            r for r in history
            if (datetime.now() - datetime.fromisoformat(r['timestamp'])).seconds < 300
        ])
        
        threat_level = min(100, (recent_count / 20) * 100)
        
        return int(threat_level)
