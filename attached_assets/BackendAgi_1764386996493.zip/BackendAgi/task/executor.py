import os
import json
import time
from typing import Dict, Any, List, Optional
from datetime import datetime
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

class TaskExecutor:
    def __init__(self):
        api_key = os.getenv('OPENAI_API_KEY')
        if not api_key:
            raise ValueError("OPENAI_API_KEY not found")
        
        self.client = OpenAI(api_key=api_key)
        self.model = os.getenv('OPENAI_MODEL', 'gpt-4o-mini')
        
        self.task_dir = 'task'
        self.task_repo_file = os.path.join(self.task_dir, 'task_repo.json')
        self.scheduler_file = os.path.join(self.task_dir, 'scheduler.json')
        
        os.makedirs(self.task_dir, exist_ok=True)
        
        self._init_task_files()
    
    def _init_task_files(self):
        if not os.path.exists(self.task_repo_file):
            with open(self.task_repo_file, 'w') as f:
                json.dump({
                    "initialized": datetime.now().isoformat(),
                    "total_tasks": 0,
                    "tasks": {}
                }, f, indent=2)
        
        if not os.path.exists(self.scheduler_file):
            with open(self.scheduler_file, 'w') as f:
                json.dump({
                    "initialized": datetime.now().isoformat(),
                    "queue": [],
                    "running": [],
                    "completed": [],
                    "failed": []
                }, f, indent=2)
    
    def create_task(self, description: str, priority: int = 50, dependencies: Optional[List[str]] = None) -> Dict[str, Any]:
        task_id = f"task_{int(time.time() * 1000)}"
        
        task = {
            "task_id": task_id,
            "description": description,
            "priority": priority,
            "status": "pending",
            "dependencies": dependencies or [],
            "created_at": datetime.now().isoformat(),
            "updated_at": datetime.now().isoformat(),
            "attempts": 0,
            "max_attempts": 3,
            "result": None,
            "error": None
        }
        
        with open(self.task_repo_file, 'r') as f:
            repo = json.load(f)
        
        repo["tasks"][task_id] = task
        repo["total_tasks"] += 1
        
        with open(self.task_repo_file, 'w') as f:
            json.dump(repo, f, indent=2)
        
        self._add_to_scheduler(task)
        
        return task
    
    def _add_to_scheduler(self, task: Dict[str, Any]):
        with open(self.scheduler_file, 'r') as f:
            scheduler = json.load(f)
        
        scheduler["queue"].append(task["task_id"])
        
        with open(self.scheduler_file, 'w') as f:
            json.dump(scheduler, f, indent=2)
    
    def update_task_status(self, task_id: str, status: str, result: Optional[Any] = None, error: Optional[str] = None) -> Dict[str, Any]:
        with open(self.task_repo_file, 'r') as f:
            repo = json.load(f)
        
        if task_id not in repo["tasks"]:
            return {"error": "Task not found"}
        
        task = repo["tasks"][task_id]
        task["status"] = status
        task["updated_at"] = datetime.now().isoformat()
        
        if result:
            task["result"] = result
        
        if error:
            task["error"] = error
        
        with open(self.task_repo_file, 'w') as f:
            json.dump(repo, f, indent=2)
        
        self._update_scheduler(task_id, status)
        
        return task
    
    def _update_scheduler(self, task_id: str, status: str):
        with open(self.scheduler_file, 'r') as f:
            scheduler = json.load(f)
        
        if task_id in scheduler["queue"]:
            scheduler["queue"].remove(task_id)
        
        if task_id in scheduler["running"]:
            scheduler["running"].remove(task_id)
        
        if status == "running":
            if task_id not in scheduler["running"]:
                scheduler["running"].append(task_id)
        elif status == "completed":
            if task_id not in scheduler["completed"]:
                scheduler["completed"].append(task_id)
        elif status == "failed":
            if task_id not in scheduler["failed"]:
                scheduler["failed"].append(task_id)
        
        with open(self.scheduler_file, 'w') as f:
            json.dump(scheduler, f, indent=2)
    
    def schedule_tasks(self) -> List[str]:
        with open(self.task_repo_file, 'r') as f:
            repo = json.load(f)
        
        with open(self.scheduler_file, 'r') as f:
            scheduler = json.load(f)
        
        pending_tasks = []
        
        for task_id in scheduler["queue"]:
            if task_id in repo["tasks"]:
                task = repo["tasks"][task_id]
                
                can_run = True
                for dep_id in task.get("dependencies", []):
                    if dep_id not in scheduler["completed"]:
                        can_run = False
                        break
                
                if can_run:
                    pending_tasks.append(task)
        
        try:
            from emotions.emotional_model import EmotionalModel
            emotion = EmotionalModel()
            emotional_state = emotion.get_current_state()
            
            stress_boost = emotional_state.get("stress_level", 0) * 0.2
            alertness_boost = emotional_state.get("alertness", 0) * 0.1
        except:
            stress_boost = 0
            alertness_boost = 0
        
        for task in pending_tasks:
            adjusted_priority = task["priority"] + stress_boost + alertness_boost
            task["_adjusted_priority"] = adjusted_priority
        
        pending_tasks.sort(key=lambda x: x.get("_adjusted_priority", x["priority"]), reverse=True)
        
        return [t["task_id"] for t in pending_tasks]
    
    def execute_task(self, task_id: str) -> Dict[str, Any]:
        with open(self.task_repo_file, 'r') as f:
            repo = json.load(f)
        
        if task_id not in repo["tasks"]:
            return {"error": "Task not found"}
        
        task = repo["tasks"][task_id]
        
        if task["status"] == "running":
            return {"error": "Task already running"}
        
        if task["attempts"] >= task["max_attempts"]:
            return {"error": "Max attempts reached"}
        
        task["attempts"] += 1
        self.update_task_status(task_id, "running")
        
        try:
            result = self._execute_task_logic(task)
            
            self.update_task_status(task_id, "completed", result=result)
            
            self.reflect_task_outcome(task_id, success=True)
            
            return {
                "task_id": task_id,
                "status": "completed",
                "result": result
            }
        
        except Exception as e:
            error_msg = str(e)
            
            self.update_task_status(task_id, "failed", error=error_msg)
            
            self.reflect_task_outcome(task_id, success=False, error=error_msg)
            
            return {
                "task_id": task_id,
                "status": "failed",
                "error": error_msg
            }
    
    def _execute_task_logic(self, task: Dict[str, Any]) -> Any:
        description = task.get("description", "")
        
        prompt = f"""Thực hiện task sau:
{description}

Trả về kết quả rõ ràng, ngắn gọn."""
        
        response = self.client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": "Bạn là task executor, thực hiện task chính xác và hiệu quả."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.3,
            max_tokens=500
        )
        
        content = response.choices[0].message.content
        return content.strip() if content else "Task completed"
    
    def reflect_task_outcome(self, task_id: str, success: bool, error: Optional[str] = None) -> Dict[str, Any]:
        with open(self.task_repo_file, 'r') as f:
            repo = json.load(f)
        
        if task_id not in repo["tasks"]:
            return {"error": "Task not found"}
        
        task = repo["tasks"][task_id]
        
        reflection = {
            "task_id": task_id,
            "timestamp": datetime.now().isoformat(),
            "success": success,
            "description": task["description"],
            "attempts": task["attempts"]
        }
        
        if success:
            try:
                from emotions.emotional_model import EmotionalModel
                emotion = EmotionalModel()
                emotion.update_emotion({"type": "success"})
            except:
                pass
            
            try:
                from memory.memory_manager import MemoryManager
                memory = MemoryManager()
                memory.save_memory({
                    "type": "task_success",
                    "task_id": task_id,
                    "description": task["description"],
                    "result": task.get("result")
                }, importance_score=60)
            except:
                pass
        
        else:
            try:
                from emotions.emotional_model import EmotionalModel
                emotion = EmotionalModel()
                emotion.update_emotion({"type": "error"})
            except:
                pass
            
            reflection["error"] = error
            
            if task["attempts"] < task["max_attempts"]:
                self.update_task_status(task_id, "pending")
                self._add_to_scheduler(task)
                reflection["action"] = "retry_scheduled"
        
        return reflection
    
    def learn_task_patterns(self) -> Dict[str, Any]:
        with open(self.task_repo_file, 'r') as f:
            repo = json.load(f)
        
        with open(self.scheduler_file, 'r') as f:
            scheduler = json.load(f)
        
        patterns = {
            "total_tasks": repo["total_tasks"],
            "completed": len(scheduler["completed"]),
            "failed": len(scheduler["failed"]),
            "success_rate": 0,
            "avg_attempts": 0,
            "common_failures": []
        }
        
        if repo["total_tasks"] > 0:
            patterns["success_rate"] = (len(scheduler["completed"]) / repo["total_tasks"]) * 100
        
        total_attempts = 0
        failure_reasons = {}
        
        for task_id, task in repo["tasks"].items():
            total_attempts += task.get("attempts", 0)
            
            if task["status"] == "failed" and task.get("error"):
                error = task["error"]
                if error in failure_reasons:
                    failure_reasons[error] += 1
                else:
                    failure_reasons[error] = 1
        
        if repo["total_tasks"] > 0:
            patterns["avg_attempts"] = total_attempts / repo["total_tasks"]
        
        patterns["common_failures"] = sorted(
            [{"error": k, "count": v} for k, v in failure_reasons.items()],
            key=lambda x: x["count"],
            reverse=True
        )[:5]
        
        return patterns
    
    def get_task(self, task_id: str) -> Optional[Dict[str, Any]]:
        with open(self.task_repo_file, 'r') as f:
            repo = json.load(f)
        
        return repo["tasks"].get(task_id)
    
    def get_all_tasks(self, status: Optional[str] = None) -> List[Dict[str, Any]]:
        with open(self.task_repo_file, 'r') as f:
            repo = json.load(f)
        
        tasks = list(repo["tasks"].values())
        
        if status:
            tasks = [t for t in tasks if t.get("status") == status]
        
        return tasks
    
    def get_scheduler_status(self) -> Dict[str, Any]:
        with open(self.scheduler_file, 'r') as f:
            scheduler = json.load(f)
        
        return {
            "queue_size": len(scheduler["queue"]),
            "running": len(scheduler["running"]),
            "completed": len(scheduler["completed"]),
            "failed": len(scheduler["failed"])
        }
