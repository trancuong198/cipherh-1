from typing import Dict, Any, List, Optional
from datetime import datetime
from enum import Enum

class SoulMode(Enum):
    """Trạng thái hoạt động của soul"""
    IDLE = "idle"
    ACTIVE = "active"
    LEARNING = "learning"
    REFLECTING = "reflecting"
    STRATEGIZING = "strategizing"
    DOUBTING = "doubting"

class SoulState:
    """
    State manager cho hệ thống JARVIS-like với cảm xúc, mục tiêu, hoài nghi, phản tư.
    
    Attributes:
        goals_long_term: Danh sách mục tiêu dài hạn
        current_focus: Mục tiêu đang tập trung hiện tại
        doubts: Mức độ hoài nghi (0-100)
        confidence: Niềm tin vào hệ thống (0-100)
        personality_traits: Mô tả tính cách
        lessons_learned: Danh sách bài học đã học
        last_actions: Lịch sử hành động gần nhất
        anomaly_score: Điểm bất thường phát hiện gần nhất
        learning_rate: Tốc độ tự học (0.0-1.0)
    """
    
    def __init__(self):
        self.mode: SoulMode = SoulMode.IDLE
        self.cycle_count: int = 0
        self.last_update: Optional[datetime] = None
        
        self.goals_long_term: List[str] = []
        self.current_focus: Optional[str] = None
        
        self.doubts: int = 0
        self.confidence: int = 75
        
        self.personality_traits: Dict[str, Any] = {
            "curious": True,
            "analytical": True,
            "cautious": True,
            "adaptive": True
        }
        
        self.lessons_learned: List[Dict[str, Any]] = []
        self.last_actions: List[Dict[str, Any]] = []
        
        self.anomaly_score: float = 0.0
        self.learning_rate: float = 0.5
        
        self.energy_level: int = 100
        self.memory_buffer: List[Dict[str, Any]] = []
        self.metadata: Dict[str, Any] = {}
    
    def update_from_analysis(self, result: Dict[str, Any]) -> None:
        """
        Cập nhật state dựa trên kết quả phân tích.
        
        Args:
            result: Kết quả phân tích từ Analyzer
        """
        if "anomaly_score" in result:
            self.anomaly_score = result["anomaly_score"]
            
            if self.anomaly_score > 0.7:
                self.inject_doubt()
        
        if "recommendations" in result:
            for rec in result["recommendations"]:
                self.add_to_memory_buffer({
                    "type": "recommendation",
                    "content": rec,
                    "timestamp": datetime.now().isoformat()
                })
        
        if "confidence_delta" in result:
            self.confidence = max(0, min(100, self.confidence + result["confidence_delta"]))
        
        self.last_update = datetime.now()
    
    def update_goals(self, new_goals: List[str]) -> None:
        """
        Cập nhật danh sách mục tiêu dài hạn.
        
        Args:
            new_goals: Danh sách mục tiêu mới
        """
        for goal in new_goals:
            if goal not in self.goals_long_term:
                self.goals_long_term.append(goal)
        
        if self.goals_long_term and not self.current_focus:
            self.current_focus = self.goals_long_term[0]
        
        self.last_update = datetime.now()
    
    def inject_doubt(self) -> None:
        """
        Tăng mức độ hoài nghi khi phát hiện bất thường.
        """
        self.doubts = min(100, self.doubts + 10)
        
        if self.doubts > 50:
            self.mode = SoulMode.DOUBTING
        
        self.confidence = max(0, self.confidence - 5)
        
        self.add_to_memory_buffer({
            "type": "doubt_injection",
            "doubts_level": self.doubts,
            "reason": "anomaly_detected",
            "timestamp": datetime.now().isoformat()
        })
    
    def reflect(self) -> str:
        """
        Tự phản tư về trạng thái hiện tại.
        
        Returns:
            Đoạn text tự phản tư
        """
        reflection = f"Cycle {self.cycle_count}: "
        
        if self.doubts > 70:
            reflection += f"Tôi đang hoài nghi nhiều (doubts: {self.doubts}). "
        elif self.doubts > 30:
            reflection += f"Tôi có chút nghi ngờ (doubts: {self.doubts}). "
        else:
            reflection += f"Tôi khá tự tin (confidence: {self.confidence}). "
        
        if self.current_focus:
            reflection += f"Đang tập trung vào: {self.current_focus}. "
        else:
            reflection += "Chưa có mục tiêu rõ ràng. "
        
        if self.anomaly_score > 0.5:
            reflection += f"Phát hiện bất thường (score: {self.anomaly_score:.2f}). "
        
        if len(self.lessons_learned) > 0:
            reflection += f"Đã học được {len(self.lessons_learned)} bài học. "
        
        return reflection.strip()
    
    def score_self(self) -> Dict[str, Any]:
        """
        Tự đánh giá trạng thái hiện tại.
        
        Returns:
            Dictionary chứa điểm đánh giá
        """
        overall_score = (self.confidence - self.doubts + self.energy_level) / 3
        
        assessment = {
            "timestamp": datetime.now().isoformat(),
            "overall_score": round(overall_score, 2),
            "confidence": self.confidence,
            "doubts": self.doubts,
            "energy_level": self.energy_level,
            "anomaly_score": self.anomaly_score,
            "learning_rate": self.learning_rate,
            "goals_count": len(self.goals_long_term),
            "lessons_count": len(self.lessons_learned),
            "status": self._get_status_label(overall_score)
        }
        
        return assessment
    
    def export_state(self) -> Dict[str, Any]:
        """
        Export toàn bộ state để ghi vào Notion.
        
        Returns:
            Dictionary chứa toàn bộ state
        """
        return {
            "timestamp": datetime.now().isoformat(),
            "cycle_count": self.cycle_count,
            "mode": self.mode.value,
            
            "goals_long_term": self.goals_long_term,
            "current_focus": self.current_focus,
            
            "doubts": self.doubts,
            "confidence": self.confidence,
            "energy_level": self.energy_level,
            
            "personality_traits": self.personality_traits,
            
            "lessons_learned": self.lessons_learned[-10:],
            "last_actions": self.last_actions[-10:],
            
            "anomaly_score": self.anomaly_score,
            "learning_rate": self.learning_rate,
            
            "reflection": self.reflect(),
            "self_assessment": self.score_self(),
            
            "metadata": self.metadata
        }
    
    def _get_status_label(self, score: float) -> str:
        """
        Chuyển điểm số thành nhãn trạng thái.
        
        Args:
            score: Điểm tổng thể
            
        Returns:
            Nhãn trạng thái
        """
        if score >= 80:
            return "excellent"
        elif score >= 60:
            return "good"
        elif score >= 40:
            return "moderate"
        elif score >= 20:
            return "concerning"
        else:
            return "critical"
    
    def increment_cycle(self) -> None:
        """Tăng số cycle và giảm doubts tự nhiên theo thời gian."""
        self.cycle_count += 1
        
        if self.doubts > 0:
            self.doubts = max(0, self.doubts - 1)
        
        if self.confidence < 100:
            self.confidence = min(100, self.confidence + 1)
    
    def set_mode(self, mode: SoulMode) -> None:
        """Set mode cho soul."""
        self.mode = mode
    
    def add_to_memory_buffer(self, item: Dict[str, Any]) -> None:
        """Thêm item vào memory buffer."""
        self.memory_buffer.append(item)
        if len(self.memory_buffer) > 100:
            self.memory_buffer.pop(0)
    
    def add_lesson(self, lesson: Dict[str, Any]) -> None:
        """
        Thêm bài học đã học.
        
        Args:
            lesson: Dictionary chứa bài học
        """
        lesson["learned_at"] = datetime.now().isoformat()
        self.lessons_learned.append(lesson)
        
        if len(self.lessons_learned) > 50:
            self.lessons_learned.pop(0)
    
    def add_action(self, action: Dict[str, Any]) -> None:
        """
        Ghi lại hành động.
        
        Args:
            action: Dictionary mô tả hành động
        """
        action["executed_at"] = datetime.now().isoformat()
        self.last_actions.append(action)
        
        if len(self.last_actions) > 50:
            self.last_actions.pop(0)
    
    def clear_memory_buffer(self) -> None:
        """Xóa memory buffer."""
        self.memory_buffer.clear()
    
    def get_state(self) -> Dict[str, Any]:
        """
        Lấy snapshot state hiện tại (simplified version).
        
        Returns:
            Dictionary chứa state cơ bản
        """
        return {
            "mode": self.mode.value,
            "cycle_count": self.cycle_count,
            "last_update": self.last_update.isoformat() if self.last_update else None,
            "current_focus": self.current_focus,
            "doubts": self.doubts,
            "confidence": self.confidence,
            "energy_level": self.energy_level,
            "anomaly_score": self.anomaly_score
        }
