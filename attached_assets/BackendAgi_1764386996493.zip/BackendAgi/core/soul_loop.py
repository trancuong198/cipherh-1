import time
import logging
from typing import Dict, Any
from datetime import datetime

from core.soul_state import SoulState, SoulMode
from core.analyzer import LogAnalyzer
from core.strategist import Strategist
from core.memory import MemoryBridge

logger = logging.getLogger(__name__)

class SoulLoop:
    """
    Lõi quan trọng nhất: Vòng lặp linh hồn tự trị.
    
    Quy trình mỗi vòng:
    Đọc log → phân tích → phản tư → cập nhật trạng thái → 
    sinh nhiệm vụ → viết vào Notion → lặp lại.
    """
    
    def __init__(self, sleep_minutes: int = 5):
        self.state = SoulState()
        self.analyzer = LogAnalyzer()
        self.strategist = Strategist()
        self.memory = MemoryBridge()
        
        self.sleep_minutes = sleep_minutes
        self.sleep_seconds = sleep_minutes * 60
        
        logger.info("Soul Loop initialized")
        logger.info(f"Cycle interval: {sleep_minutes} minutes ({self.sleep_seconds} seconds)")
    
    def run(self) -> Dict[str, Any]:
        """
        Chạy một vòng lặp hoàn chỉnh.
        
        Returns:
            Dictionary chứa kết quả vòng lặp
        """
        try:
            # Increment cycle counter
            self.state.increment_cycle()
            cycle = self.state.cycle_count
            
            logger.info("=" * 60)
            logger.info(f"SOUL LOOP CYCLE {cycle} - START")
            logger.info("=" * 60)
            
            # ===== BƯỚC 1: Đọc logs từ analyzer =====
            logger.info("Step 1: Reading and analyzing logs...")
            try:
                logs = self.analyzer.read_logs()
                logger.info(f"Read {len(logs)} log lines")
            except Exception as e:
                logger.error(f"Error reading logs: {e}")
                logs = []
            
            # ===== BƯỚC 2: Phân tích → pattern/anomaly/questions =====
            logger.info("Step 2: Detecting patterns and anomalies...")
            try:
                analysis_result = self.analyzer.return_analysis()
                
                anomaly_score = analysis_result.get('anomaly_score', 0)
                pattern_summary = analysis_result.get('pattern_summary', {})
                suggested_questions = analysis_result.get('suggested_questions', [])
                day_summary = analysis_result.get('day_summary', '')
                
                logger.info(f"Analysis complete: anomaly_score={anomaly_score}, trend={pattern_summary.get('trend', 'unknown')}")
                logger.info(f"Generated {len(suggested_questions)} questions")
                
            except Exception as e:
                logger.error(f"Error during analysis: {e}")
                analysis_result = {
                    'anomaly_score': 0,
                    'pattern_summary': {'trend': 'unknown'},
                    'suggested_questions': [],
                    'day_summary': 'Analysis failed'
                }
                anomaly_score = 0
                pattern_summary = {}
                suggested_questions = []
                day_summary = 'Analysis failed'
            
            # ===== BƯỚC 3: state.reflect() → tạo đoạn tự phản tư =====
            logger.info("Step 3: Self-reflection...")
            try:
                reflection = self.state.reflect()
                logger.info(f"Reflection: {reflection}")
            except Exception as e:
                logger.error(f"Error during reflection: {e}")
                reflection = "Unable to reflect"
            
            # ===== BƯỚC 4: state.update_from_analysis() =====
            logger.info("Step 4: Updating state from analysis...")
            
            # Export state for strategist (needed in steps 5, 6, 7)
            state_export = self.state.export_state()
            
            try:
                self.state.update_from_analysis(analysis_result)
                
                # Add lesson if needed
                if anomaly_score > 30:
                    self.state.add_lesson({
                        "lesson": f"Phát hiện anomaly score {anomaly_score}: cần cảnh giác",
                        "context": pattern_summary.get('trend', 'unknown')
                    })
                
                # Add action record
                self.state.add_action({
                    "action": "analyzed_logs",
                    "cycle": cycle,
                    "anomaly_score": anomaly_score
                })
                
                # Re-export state after updates
                state_export = self.state.export_state()
                logger.info(f"State updated: doubts={self.state.doubts}, confidence={self.state.confidence}")
                
            except Exception as e:
                logger.error(f"Error updating state: {e}")
            
            # ===== BƯỚC 5: strategist.propose_weekly_tasks() =====
            logger.info("Step 5: Proposing weekly tasks...")
            try:
                state_export = self.state.export_state()
                weekly_tasks = self.strategist.propose_weekly_tasks(state_export, analysis_result)
                logger.info(f"Proposed {len(weekly_tasks)} weekly tasks")
                
                if weekly_tasks:
                    logger.info(f"Top task: {weekly_tasks[0]['task'][:60]}...")
                
            except Exception as e:
                logger.error(f"Error proposing weekly tasks: {e}")
                weekly_tasks = []
            
            # ===== BƯỚC 6: strategist.propose_monthly_plan() =====
            logger.info("Step 6: Proposing monthly plan...")
            try:
                monthly_plan = self.strategist.propose_monthly_plan(state_export)
                focus_areas = len(monthly_plan.get('focus_areas', []))
                logger.info(f"Monthly plan created with {focus_areas} focus areas")
                
            except Exception as e:
                logger.error(f"Error proposing monthly plan: {e}")
                monthly_plan = {}
            
            # ===== BƯỚC 7: Tạo chiến lược dài hạn (prompt) =====
            logger.info("Step 7: Generating long-term strategy prompt...")
            try:
                strategy_prompt = self.strategist.generate_strategy_prompt(state_export, analysis_result)
                logger.info(f"Strategy prompt generated ({len(strategy_prompt)} chars)")
                
                # Placeholder: Nếu có OpenAI API key, sẽ gọi ở đây
                # openai_response = call_openai(strategy_prompt)
                # strategist.integrate_openai_response(openai_response)
                logger.info("OpenAI integration: placeholder (not implemented)")
                
            except Exception as e:
                logger.error(f"Error generating strategy prompt: {e}")
                strategy_prompt = ""
            
            # ===== BƯỚC 8: Ghi vào Notion =====
            logger.info("Step 8: Writing to Notion memory...")
            
            # 8.1: Bài học hôm nay
            try:
                if day_summary:
                    self.memory.write_daily_summary(day_summary)
                    logger.info("Daily summary written to Notion")
            except Exception as e:
                logger.error(f"Error writing daily summary: {e}")
            
            # 8.2: Snapshot state
            try:
                self.memory.write_state_snapshot(state_export)
                logger.info("State snapshot written to Notion")
            except Exception as e:
                logger.error(f"Error writing state snapshot: {e}")
            
            # 8.3: Câu hỏi tự đặt
            try:
                if suggested_questions:
                    questions_text = "\n".join(f"- {q}" for q in suggested_questions[:5])
                    self.memory.write_lesson(f"Pending Questions (Cycle {cycle}):\n{questions_text}")
                    logger.info(f"Questions written to Notion ({len(suggested_questions)} questions)")
            except Exception as e:
                logger.error(f"Error writing questions: {e}")
            
            # 8.4: Weekly tasks
            try:
                if weekly_tasks:
                    tasks_text = "\n".join(
                        f"- [{task['priority'].upper()}] {task['task']}"
                        for task in weekly_tasks[:5]
                    )
                    self.memory.write_strategy_note(
                        f"Weekly Tasks (Cycle {cycle}):\n{tasks_text}",
                        strategy_type="weekly"
                    )
                    logger.info("Weekly tasks written to Notion")
            except Exception as e:
                logger.error(f"Error writing weekly tasks: {e}")
            
            # ===== BƯỚC 9: Ghi log hoàn tất =====
            logger.info("=" * 60)
            logger.info(f"SOUL LOOP CYCLE {cycle} - COMPLETED SUCCESSFULLY")
            logger.info(f"Next cycle in {self.sleep_minutes} minutes")
            logger.info("=" * 60)
            
            # ===== BƯỚC 10: Sleep (handled by main.py) =====
            # time.sleep(self.sleep_seconds)  # Không sleep ở đây, để main.py handle
            
            return {
                "success": True,
                "cycle": cycle,
                "timestamp": datetime.now().isoformat(),
                "stats": {
                    "logs_read": len(logs),
                    "anomaly_score": anomaly_score,
                    "doubts": self.state.doubts,
                    "confidence": self.state.confidence,
                    "weekly_tasks": len(weekly_tasks),
                    "questions_generated": len(suggested_questions)
                }
            }
            
        except Exception as e:
            logger.critical(f"CRITICAL ERROR in Soul Loop Cycle {self.state.cycle_count}: {str(e)}")
            logger.exception("Full traceback:")
            
            return {
                "success": False,
                "error": str(e),
                "cycle": self.state.cycle_count,
                "timestamp": datetime.now().isoformat()
            }
    
    def get_status(self) -> Dict[str, Any]:
        """
        Lấy status hiện tại của Soul Loop.
        
        Returns:
            Dictionary chứa status info
        """
        return {
            "cycle_count": self.state.cycle_count,
            "current_mode": self.state.mode.value,
            "doubts": self.state.doubts,
            "confidence": self.state.confidence,
            "energy_level": self.state.energy_level,
            "goals_count": len(self.state.goals_long_term),
            "current_focus": self.state.current_focus,
            "memory_connected": self.memory.connected,
            "sleep_interval_minutes": self.sleep_minutes
        }
