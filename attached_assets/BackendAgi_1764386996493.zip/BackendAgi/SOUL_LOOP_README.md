# Soul Loop Backend - Autonomous Self-Reflecting AI System

## 🎯 Mục tiêu
Hệ thống AI tự trị với khả năng:
- Tự phân tích logs
- Tự phản tư về hành vi
- Tự đặt câu hỏi
- Tự đề xuất chiến lược
- Tự ghi nhớ vào Notion
- Chạy 24/7 không ngừng nghỉ

## 📁 Cấu trúc

```
/core
  soul_state.py      # JARVIS-like state với emotions, goals, doubts, confidence
  analyzer.py        # Rule-based log analysis, pattern detection
  strategist.py      # Self-proposing strategies & tasks
  memory.py          # Notion memory bridge
  soul_loop.py       # Main orchestration loop

/logs
  system.log         # System logs
  memory/            # Analysis logs

/config
  env.example        # Environment template

main.py              # 24/7 runner
requirements_soul.txt
```

## 🔄 Vòng lặp Soul Loop

Mỗi cycle (mặc định 5 phút):

1. **Đọc logs** - Analyzer đọc logs/system.log
2. **Phân tích** - Detect patterns, anomalies, generate questions
3. **Phản tư** - State tự reflect về trạng thái hiện tại
4. **Cập nhật** - Update doubts, confidence từ analysis
5. **Đề xuất tasks** - Strategist propose weekly tasks
6. **Đề xuất plan** - Strategist propose monthly plan
7. **Tạo prompt** - Generate strategy prompt cho OpenAI (placeholder)
8. **Ghi Notion** - Write daily summary, state snapshot, questions, tasks
9. **Log completion** - Ghi nhận hoàn tất cycle
10. **Sleep** - Chờ đến cycle tiếp theo

## 🚀 Chạy hệ thống

```bash
# Install dependencies
pip install -r requirements_soul.txt

# Set environment variables
export NOTION_TOKEN="your_token"
export NOTION_DATABASE_ID="your_database_id"
export CYCLE_DELAY=5  # minutes

# Run
python main.py
```

## 🧠 Soul State (JARVIS-like)

```python
state = SoulState()

# Attributes
state.goals_long_term      # Danh sách mục tiêu dài hạn
state.current_focus        # Mục tiêu đang tập trung
state.doubts              # Mức độ hoài nghi (0-100)
state.confidence          # Niềm tin hệ thống (0-100)
state.personality_traits  # Tính cách: curious, analytical, cautious, adaptive
state.lessons_learned     # Bài học đã học
state.anomaly_score       # Điểm bất thường gần nhất
state.learning_rate       # Tốc độ tự học

# Methods
state.reflect()                    # → "Cycle X: Tôi đang..."
state.score_self()                 # → overall_score, status
state.update_from_analysis(result) # Auto inject_doubt nếu anomaly >0.7
state.inject_doubt()               # Tăng doubts, giảm confidence
state.export_state()               # → Full state cho Notion
```

## 📊 LogAnalyzer (Rule-Based)

```python
analyzer = LogAnalyzer()

# Methods
analyzer.read_logs()           # Đọc logs/system.log
analyzer.detect_patterns()     # → errors, warnings, trend, repeated
analyzer.detect_anomalies()    # → anomalies list, score (0-100)
analyzer.summarize_day()       # → "Bài học rút ra hôm nay: ..."
analyzer.extract_questions()   # → ["Tại sao...", "Làm thế nào..."]
analyzer.return_analysis()     # → Full analysis object
```

**Heuristics:**
- Error count >10 → anomaly +30
- Repeated errors → anomaly +20
- Warnings >20 → anomaly +15
- Declining trend → anomaly +25

## 🎯 Strategist (Self-Proposing)

```python
strategist = Strategist()

# Methods
strategist.propose_weekly_tasks(state, analysis)
# → Tasks với priority (critical/high/medium/low)

strategist.propose_monthly_plan(state)
# → Plan với focus_areas, milestones, risk_mitigation

strategist.align_with_goals(state)
# → alignment_score, gaps, recommendations

strategist.generate_strategy_prompt(state, analysis)
# → OpenAI prompt (1000+ chars)

strategist.integrate_openai_response(response)
# → Parse & integrate AI suggestions
```

**Logic:**
- Anomaly >50 → Focus stability
- Trend declining → Quality control
- Doubts >50 → Trust building
- Trend improving + confidence >80 → Expand capabilities

## 💾 MemoryBridge (Notion)

```python
memory = MemoryBridge()

# Methods
memory.write_lesson(text)
memory.write_daily_summary(summary)
memory.write_state_snapshot(state)
memory.write_strategy_note(note, strategy_type)
memory.read_recent_memories(limit=10, memory_type="Lesson")
memory.search_memory(query)
```

**Security:**
- Dùng environment variables (NOTION_TOKEN, NOTION_DATABASE_ID)
- **KHÔNG** nhận API key qua constructor
- Tất cả functions hiện là placeholders (safe for testing)

## ⚙️ Configuration

`.env` file:
```
NOTION_TOKEN=secret_xxxxx
NOTION_DATABASE_ID=xxxxx
CYCLE_DELAY=5
LOG_LEVEL=INFO
```

## 🛡️ Error Handling

- Tất cả steps wrapped trong try/except
- Không crash dù có lỗi
- Log đầy đủ traceback
- Continue next cycle nếu fail

## 📝 Logs

```
logs/system.log                    # Main system log
logs/memory/analysis_*.json        # Analysis snapshots
```

## 🔮 Tương lai

Để enable OpenAI integration:
1. Add OpenAI API key to environment
2. Uncomment OpenAI call in soul_loop.py step 7
3. Implement response parsing

Để enable real Notion calls:
1. Uncomment requests code trong memory.py
2. Ensure NOTION_TOKEN và DATABASE_ID correct
3. Test with small writes first

## ✅ Status

- ✅ Soul State - JARVIS-like với emotions
- ✅ LogAnalyzer - Rule-based analysis
- ✅ Strategist - Self-proposing strategies
- ✅ MemoryBridge - Notion integration (placeholders)
- ✅ Soul Loop - Full orchestration
- ✅ 24/7 Runner - Infinite loop với proper error handling
- ✅ LSP Clean - 0 errors

**Test result:** 1 cycle completed successfully in 20 seconds.
