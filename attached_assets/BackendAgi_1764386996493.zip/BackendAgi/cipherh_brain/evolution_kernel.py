import os
import ast
import json
import copy
import subprocess
from typing import Dict, Any, List, Optional, Tuple
from datetime import datetime
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

class EvolutionKernel:
    def __init__(self):
        api_key = os.getenv('OPENAI_API_KEY')
        if not api_key:
            raise ValueError("OPENAI_API_KEY not found")
        
        self.client = OpenAI(api_key=api_key)
        self.model = os.getenv('OPENAI_MODEL', 'gpt-4o-mini')
        self.brain_dir = 'cipherh_brain'
        self.evolution_history = os.path.join(self.brain_dir, 'evolution_history.json')
        self.backup_dir = os.path.join(self.brain_dir, 'backups')
        
        os.makedirs(self.backup_dir, exist_ok=True)
        
        if not os.path.exists(self.evolution_history):
            self._init_history()
        
        self.evolution_laws = [
            "Không phá vỡ core features đã stable",
            "Không tạo đột biến vô nghĩa",
            "Không tăng độ phức tạp khi không cần",
            "Luôn ưu tiên bảo mật",
            "Luôn chọn phiên bản đơn giản nhất",
            "Tất cả thay đổi phải test sandbox",
            "Luôn log đầy đủ",
            "Không bao giờ tự xóa file quan trọng"
        ]
    
    def _init_history(self):
        history = {
            "start_date": datetime.now().isoformat(),
            "total_mutations": 0,
            "successful_mutations": 0,
            "failed_mutations": 0,
            "rollbacks": 0,
            "mutations": [],
            "current_generation": 1
        }
        
        with open(self.evolution_history, 'w') as f:
            json.dump(history, f, indent=2)
    
    def evaluate_self(self, file_path: Optional[str] = None) -> Dict[str, Any]:
        if file_path and not os.path.exists(file_path):
            return {"error": "File not found"}
        
        if file_path:
            files_to_eval = [file_path]
        else:
            files_to_eval = []
            for root, dirs, files in os.walk('.'):
                if any(skip in root for skip in ['node_modules', '.git', '__pycache__', 'venv', 'cipherh_brain/backups']):
                    continue
                for file in files:
                    if file.endswith('.py') and file != '__pycache__':
                        files_to_eval.append(os.path.join(root, file))
        
        total_score = 0
        evaluations = []
        
        for filepath in files_to_eval[:20]:
            eval_result = self._evaluate_file(filepath)
            evaluations.append(eval_result)
            total_score += eval_result.get('score', 0)
        
        avg_score = total_score / len(evaluations) if evaluations else 0
        
        return {
            "timestamp": datetime.now().isoformat(),
            "files_evaluated": len(evaluations),
            "average_score": round(avg_score, 2),
            "evaluations": evaluations,
            "grade": self._get_grade(avg_score)
        }
    
    def _evaluate_file(self, filepath: str) -> Dict[str, Any]:
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                code = f.read()
            
            tree = ast.parse(code)
            
            metrics = {
                "filepath": filepath,
                "lines": len(code.split('\n')),
                "functions": 0,
                "classes": 0,
                "docstring_coverage": 0,
                "complexity_score": 0,
                "security_score": 100,
                "maintainability": 100,
                "score": 0
            }
            
            total_functions = 0
            functions_with_docs = 0
            complexity = 0
            
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef):
                    total_functions += 1
                    if ast.get_docstring(node):
                        functions_with_docs += 1
                    complexity += len(node.body)
                
                elif isinstance(node, ast.ClassDef):
                    metrics["classes"] += 1
            
            metrics["functions"] = total_functions
            
            if total_functions > 0:
                metrics["docstring_coverage"] = (functions_with_docs / total_functions) * 100
            
            if metrics["lines"] > 0:
                metrics["complexity_score"] = max(0, 100 - (complexity / metrics["lines"]) * 100)
            
            if 'eval(' in code or 'exec(' in code:
                metrics["security_score"] -= 50
            
            if 'password' in code.lower() and '=' in code:
                metrics["security_score"] -= 20
            
            if metrics["lines"] > 500:
                metrics["maintainability"] -= 30
            
            metrics["score"] = (
                metrics["docstring_coverage"] * 0.3 +
                metrics["complexity_score"] * 0.3 +
                metrics["security_score"] * 0.2 +
                metrics["maintainability"] * 0.2
            )
            
            return metrics
        
        except Exception as e:
            return {
                "filepath": filepath,
                "error": str(e),
                "score": 0
            }
    
    def _get_grade(self, score: float) -> str:
        if score >= 90:
            return "A+"
        elif score >= 80:
            return "A"
        elif score >= 70:
            return "B"
        elif score >= 60:
            return "C"
        else:
            return "D"
    
    def generate_mutation(self, target_file: str, mutation_type: str = "auto") -> Dict[str, Any]:
        if not os.path.exists(target_file):
            return {"error": "File not found"}
        
        with open(target_file, 'r', encoding='utf-8') as f:
            original_code = f.read()
        
        mutations = {
            "auto": self._auto_detect_mutation,
            "simplify": self._simplify_mutation,
            "optimize": self._optimize_mutation,
            "security": self._security_mutation,
            "refactor": self._refactor_mutation
        }
        
        if mutation_type not in mutations:
            mutation_type = "auto"
        
        mutated_code = mutations[mutation_type](original_code, target_file)
        
        return {
            "original_file": target_file,
            "mutation_type": mutation_type,
            "original_code": original_code,
            "mutated_code": mutated_code,
            "timestamp": datetime.now().isoformat()
        }
    
    def _auto_detect_mutation(self, code: str, filepath: str) -> str:
        eval_result = self._evaluate_file(filepath)
        
        if eval_result.get("security_score", 100) < 70:
            return self._security_mutation(code, filepath)
        elif eval_result.get("complexity_score", 100) < 60:
            return self._simplify_mutation(code, filepath)
        elif eval_result.get("docstring_coverage", 100) < 50:
            return self._refactor_mutation(code, filepath)
        else:
            return self._optimize_mutation(code, filepath)
    
    def _simplify_mutation(self, code: str, filepath: str) -> str:
        prompt = f"""Đơn giản hóa code Python này, giữ nguyên chức năng:

{code[:2000]}

YÊU CẦU:
- Giảm độ phức tạp
- Loại bỏ code thừa
- Gộp logic giống nhau
- Giữ nguyên docstring
- Giữ nguyên API interface

Trả về code đã tối ưu, không markdown."""
        
        return self._llm_mutate(prompt)
    
    def _optimize_mutation(self, code: str, filepath: str) -> str:
        prompt = f"""Tối ưu performance của code Python này:

{code[:2000]}

YÊU CẦU:
- Tối ưu vòng lặp
- Giảm số lần gọi hàm
- Cache kết quả nếu cần
- Giữ nguyên logic
- Giữ nguyên API

Trả về code đã tối ưu, không markdown."""
        
        return self._llm_mutate(prompt)
    
    def _security_mutation(self, code: str, filepath: str) -> str:
        prompt = f"""Cải thiện bảo mật của code Python này:

{code[:2000]}

YÊU CẦU:
- Validate input
- Sanitize user data
- Remove hardcoded secrets
- Add error handling
- Giữ nguyên chức năng

Trả về code an toàn hơn, không markdown."""
        
        return self._llm_mutate(prompt)
    
    def _refactor_mutation(self, code: str, filepath: str) -> str:
        prompt = f"""Refactor code Python này cho maintainable hơn:

{code[:2000]}

YÊU CẦU:
- Thêm docstring thiếu
- Đổi tên biến rõ ràng hơn
- Tách hàm dài thành nhỏ
- Giữ nguyên logic
- Follow PEP 8

Trả về code đã refactor, không markdown."""
        
        return self._llm_mutate(prompt)
    
    def _llm_mutate(self, prompt: str) -> str:
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "Bạn là code evolution engine. Cải thiện code theo yêu cầu."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.1,
                max_tokens=2000
            )
            
            content = response.choices[0].message.content
            return content.strip() if content else ""
        
        except Exception as e:
            return f"# Mutation error: {e}"
    
    def test_mutation(self, mutation_data: Dict[str, Any]) -> Dict[str, Any]:
        mutated_code = mutation_data.get('mutated_code', '')
        
        test_result = {
            "syntax_valid": False,
            "security_improved": False,
            "complexity_reduced": False,
            "passed": False,
            "errors": []
        }
        
        try:
            ast.parse(mutated_code)
            test_result["syntax_valid"] = True
        except SyntaxError as e:
            test_result["errors"].append(f"Syntax error: {e}")
            return test_result
        
        original_code = mutation_data.get('original_code', '')
        
        if 'eval(' not in mutated_code and 'eval(' in original_code:
            test_result["security_improved"] = True
        
        if 'exec(' not in mutated_code and 'exec(' in original_code:
            test_result["security_improved"] = True
        
        if len(mutated_code.split('\n')) <= len(original_code.split('\n')):
            test_result["complexity_reduced"] = True
        
        test_result["passed"] = (
            test_result["syntax_valid"] and
            (test_result["security_improved"] or test_result["complexity_reduced"])
        )
        
        return test_result
    
    def apply_mutation(self, mutation_data: Dict[str, Any]) -> Dict[str, Any]:
        target_file = mutation_data.get('original_file')
        mutated_code = mutation_data.get('mutated_code')
        
        if not target_file or not mutated_code:
            return {"success": False, "error": "Invalid mutation data"}
        
        backup_path = self._create_backup(target_file)
        
        try:
            with open(target_file, 'w', encoding='utf-8') as f:
                f.write(mutated_code)
            
            self._log_mutation(mutation_data, success=True)
            
            return {
                "success": True,
                "file": target_file,
                "backup": backup_path,
                "message": "Mutation applied successfully"
            }
        
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    def rollback(self, target_file: str) -> Dict[str, Any]:
        backups = [f for f in os.listdir(self.backup_dir) if f.startswith(os.path.basename(target_file))]
        
        if not backups:
            return {"success": False, "error": "No backup found"}
        
        latest_backup = sorted(backups)[-1]
        backup_path = os.path.join(self.backup_dir, latest_backup)
        
        try:
            with open(backup_path, 'r', encoding='utf-8') as f:
                backup_code = f.read()
            
            with open(target_file, 'w', encoding='utf-8') as f:
                f.write(backup_code)
            
            self._log_rollback(target_file)
            
            return {
                "success": True,
                "file": target_file,
                "restored_from": backup_path
            }
        
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    def _create_backup(self, filepath: str) -> str:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_name = f"{os.path.basename(filepath)}.{timestamp}.bak"
        backup_path = os.path.join(self.backup_dir, backup_name)
        
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
        
        with open(backup_path, 'w', encoding='utf-8') as f:
            f.write(content)
        
        return backup_path
    
    def _log_mutation(self, mutation_data: Dict[str, Any], success: bool):
        with open(self.evolution_history, 'r') as f:
            history = json.load(f)
        
        history["total_mutations"] += 1
        if success:
            history["successful_mutations"] += 1
        else:
            history["failed_mutations"] += 1
        
        history["mutations"].append({
            "timestamp": datetime.now().isoformat(),
            "file": mutation_data.get('original_file'),
            "type": mutation_data.get('mutation_type'),
            "success": success
        })
        
        with open(self.evolution_history, 'w') as f:
            json.dump(history, f, indent=2)
    
    def _log_rollback(self, filepath: str):
        with open(self.evolution_history, 'r') as f:
            history = json.load(f)
        
        history["rollbacks"] += 1
        
        with open(self.evolution_history, 'w') as f:
            json.dump(history, f, indent=2)
    
    def get_evolution_history(self) -> Dict[str, Any]:
        if not os.path.exists(self.evolution_history):
            return {"error": "No history found"}
        
        with open(self.evolution_history, 'r') as f:
            return json.load(f)
    
    def evolution_cycle(self, target_files: Optional[List[str]] = None) -> Dict[str, Any]:
        if not target_files:
            eval_result = self.evaluate_self()
            
            low_score_files = [
                e['filepath'] for e in eval_result.get('evaluations', [])
                if e.get('score', 100) < 70 and 'error' not in e
            ]
            
            target_files = low_score_files[:3]
        
        results = []
        
        for filepath in target_files:
            mutation = self.generate_mutation(filepath, "auto")
            
            test_result = self.test_mutation(mutation)
            
            if test_result['passed']:
                apply_result = self.apply_mutation(mutation)
                
                if apply_result['success']:
                    results.append({
                        "file": filepath,
                        "status": "applied",
                        "improvement": True
                    })
                else:
                    results.append({
                        "file": filepath,
                        "status": "failed_apply",
                        "error": apply_result.get('error')
                    })
            else:
                results.append({
                    "file": filepath,
                    "status": "failed_test",
                    "errors": test_result.get('errors')
                })
        
        return {
            "timestamp": datetime.now().isoformat(),
            "files_processed": len(results),
            "results": results
        }
