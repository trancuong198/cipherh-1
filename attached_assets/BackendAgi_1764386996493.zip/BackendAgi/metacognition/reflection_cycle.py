import os
import json
from typing import Dict, Any, List, Optional
from datetime import datetime
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

class Metacognition:
    def __init__(self):
        api_key = os.getenv('OPENAI_API_KEY')
        if not api_key:
            raise ValueError("OPENAI_API_KEY not found")
        
        self.client = OpenAI(api_key=api_key)
        self.model = os.getenv('OPENAI_MODEL', 'gpt-4o-mini')
        
        self.meta_dir = 'metacognition'
        self.analysis_file = os.path.join(self.meta_dir, 'self_analysis.json')
        self.suggestions_file = os.path.join(self.meta_dir, 'improvement_suggestions.json')
        
        os.makedirs(self.meta_dir, exist_ok=True)
        
        self._init_files()
    
    def _init_files(self):
        if not os.path.exists(self.analysis_file):
            with open(self.analysis_file, 'w') as f:
                json.dump({
                    "task_review": [],
                    "logic_errors": [],
                    "emotional_bias": [],
                    "pattern_learning": [],
                    "total_analyses": 0
                }, f, indent=2)
        
        if not os.path.exists(self.suggestions_file):
            with open(self.suggestions_file, 'w') as f:
                json.dump({
                    "suggestions": [],
                    "implemented": [],
                    "total_suggestions": 0
                }, f, indent=2)
    
    def analyze_self(self, task_id: str) -> Dict[str, Any]:
        with open(self.analysis_file, 'r') as f:
            analysis = json.load(f)
        
        task_data = self._get_task_data(task_id)
        
        if not task_data:
            return {"error": "Task not found"}
        
        emotional_state = self._get_emotional_state()
        personality_traits = self._get_personality_traits()
        
        review = {
            "task_id": task_id,
            "timestamp": datetime.now().isoformat(),
            "task_status": task_data.get('status', 'unknown'),
            "success": task_data.get('status') == 'completed',
            "logic_quality": self._assess_logic_quality(task_data),
            "emotional_impact": self._assess_emotional_impact(task_data, emotional_state),
            "personality_influence": self._assess_personality_influence(task_data, personality_traits),
            "areas_for_improvement": []
        }
        
        if not review["success"]:
            review["areas_for_improvement"].append("task_execution")
        
        if review["emotional_impact"]["bias_detected"]:
            review["areas_for_improvement"].append("emotional_regulation")
            
            emotional_bias = {
                "task_id": task_id,
                "timestamp": datetime.now().isoformat(),
                "bias_type": review["emotional_impact"]["bias_type"],
                "severity": review["emotional_impact"]["severity"]
            }
            analysis["emotional_bias"].append(emotional_bias)
        
        if review["logic_quality"]["score"] < 60:
            review["areas_for_improvement"].append("logic_refinement")
            
            logic_error = {
                "task_id": task_id,
                "timestamp": datetime.now().isoformat(),
                "error_type": "low_quality_logic",
                "score": review["logic_quality"]["score"]
            }
            analysis["logic_errors"].append(logic_error)
        
        analysis["task_review"].append(review)
        analysis["total_analyses"] += 1
        
        if len(analysis["task_review"]) > 200:
            analysis["task_review"] = analysis["task_review"][-200:]
        
        with open(self.analysis_file, 'w') as f:
            json.dump(analysis, f, indent=2)
        
        return review
    
    def _get_task_data(self, task_id: str) -> Optional[Dict[str, Any]]:
        task_repo_file = 'task/task_repo.json'
        
        if not os.path.exists(task_repo_file):
            return None
        
        with open(task_repo_file, 'r') as f:
            repo = json.load(f)
        
        return repo.get('tasks', {}).get(task_id)
    
    def _get_emotional_state(self) -> Dict[str, Any]:
        emotions_file = 'emotions/state.json'
        
        if not os.path.exists(emotions_file):
            return {}
        
        with open(emotions_file, 'r') as f:
            return json.load(f)
    
    def _get_personality_traits(self) -> Dict[str, Any]:
        traits_file = 'personality/core_traits.json'
        
        if not os.path.exists(traits_file):
            return {}
        
        with open(traits_file, 'r') as f:
            return json.load(f)
    
    def _assess_logic_quality(self, task_data: Dict[str, Any]) -> Dict[str, Any]:
        attempts = task_data.get('attempts', 0)
        max_attempts = task_data.get('max_attempts', 3)
        
        score = 100
        
        if attempts > 1:
            score -= (attempts - 1) * 15
        
        if task_data.get('status') == 'failed':
            score -= 30
        
        score = max(0, score)
        
        return {
            "score": score,
            "attempts_needed": attempts,
            "quality_level": "high" if score > 80 else "medium" if score > 50 else "low"
        }
    
    def _assess_emotional_impact(self, task_data: Dict[str, Any], emotional_state: Dict[str, Any]) -> Dict[str, Any]:
        stress = emotional_state.get('stress_level', 0)
        confidence = emotional_state.get('confidence', 0)
        
        bias_detected = False
        bias_type = None
        severity = "low"
        
        if stress > 80 and task_data.get('status') == 'failed':
            bias_detected = True
            bias_type = "stress_induced_failure"
            severity = "high"
        
        if confidence < 30 and task_data.get('attempts', 0) > 2:
            bias_detected = True
            bias_type = "low_confidence_hesitation"
            severity = "medium"
        
        return {
            "bias_detected": bias_detected,
            "bias_type": bias_type,
            "severity": severity,
            "stress_level": stress,
            "confidence_level": confidence
        }
    
    def _assess_personality_influence(self, task_data: Dict[str, Any], traits: Dict[str, Any]) -> Dict[str, Any]:
        skepticism = traits.get('skepticism', 0)
        hacker_instinct = traits.get('hacker_instinct', 0)
        
        influence = []
        
        if skepticism > 90 and task_data.get('attempts', 0) > 2:
            influence.append("over_skepticism_paralysis")
        
        if hacker_instinct > 90:
            influence.append("unconventional_approach")
        
        return {
            "influences": influence,
            "positive_traits": [k for k, v in traits.items() if v > 80 and k != 'last_updated'],
            "negative_traits": [k for k, v in traits.items() if v < 40 and k != 'last_updated']
        }
    
    def detect_patterns(self) -> Dict[str, Any]:
        with open(self.analysis_file, 'r') as f:
            analysis = json.load(f)
        
        patterns = {
            "recurring_errors": [],
            "emotional_patterns": [],
            "success_patterns": [],
            "failure_patterns": []
        }
        
        logic_errors = analysis.get('logic_errors', [])
        error_types = {}
        
        for error in logic_errors:
            error_type = error.get('error_type', 'unknown')
            if error_type in error_types:
                error_types[error_type] += 1
            else:
                error_types[error_type] = 1
        
        for error_type, count in error_types.items():
            if count > 3:
                patterns["recurring_errors"].append({
                    "type": error_type,
                    "frequency": count,
                    "severity": "high" if count > 10 else "medium"
                })
        
        emotional_biases = analysis.get('emotional_bias', [])
        bias_types = {}
        
        for bias in emotional_biases:
            bias_type = bias.get('bias_type')
            if bias_type:
                if bias_type in bias_types:
                    bias_types[bias_type] += 1
                else:
                    bias_types[bias_type] = 1
        
        for bias_type, count in bias_types.items():
            if count > 2:
                patterns["emotional_patterns"].append({
                    "type": bias_type,
                    "frequency": count,
                    "recommendation": "emotional_regulation_needed"
                })
        
        task_reviews = analysis.get('task_review', [])
        
        successful = [r for r in task_reviews if r.get('success', False)]
        failed = [r for r in task_reviews if not r.get('success', False)]
        
        if len(successful) > 5:
            avg_logic_quality = sum(r.get('logic_quality', {}).get('score', 0) for r in successful) / len(successful)
            patterns["success_patterns"].append({
                "average_logic_quality": avg_logic_quality,
                "total_successes": len(successful)
            })
        
        if len(failed) > 3:
            common_issues = []
            for review in failed:
                common_issues.extend(review.get('areas_for_improvement', []))
            
            issue_counts = {}
            for issue in common_issues:
                if issue in issue_counts:
                    issue_counts[issue] += 1
                else:
                    issue_counts[issue] = 1
            
            patterns["failure_patterns"].append({
                "common_issues": issue_counts,
                "total_failures": len(failed)
            })
        
        pattern_learning = {
            "timestamp": datetime.now().isoformat(),
            "patterns_detected": patterns,
            "total_reviews": len(task_reviews)
        }
        
        analysis['pattern_learning'].append(pattern_learning)
        
        if len(analysis['pattern_learning']) > 50:
            analysis['pattern_learning'] = analysis['pattern_learning'][-50:]
        
        with open(self.analysis_file, 'w') as f:
            json.dump(analysis, f, indent=2)
        
        return patterns
    
    def suggest_improvement(self) -> Dict[str, Any]:
        patterns = self.detect_patterns()
        
        with open(self.suggestions_file, 'r') as f:
            suggestions_data = json.load(f)
        
        suggestions = []
        
        for error in patterns.get('recurring_errors', []):
            suggestions.append({
                "type": "refactor_logic",
                "issue": error['type'],
                "priority": "high" if error['severity'] == 'high' else "medium",
                "action": f"Refactor logic to avoid {error['type']}",
                "timestamp": datetime.now().isoformat()
            })
        
        for emotion_pattern in patterns.get('emotional_patterns', []):
            suggestions.append({
                "type": "emotional_regulation",
                "issue": emotion_pattern['type'],
                "priority": "high",
                "action": f"Implement emotional regulation for {emotion_pattern['type']}",
                "timestamp": datetime.now().isoformat()
            })
        
        failure_patterns = patterns.get('failure_patterns', [])
        if failure_patterns:
            for pattern in failure_patterns:
                common_issues = pattern.get('common_issues', {})
                if common_issues:
                    top_issue = max(common_issues.items(), key=lambda x: x[1])
                    suggestions.append({
                        "type": "workflow_optimization",
                        "issue": top_issue[0],
                        "priority": "high",
                        "action": f"Optimize workflow to address {top_issue[0]}",
                        "timestamp": datetime.now().isoformat()
                    })
        
        for suggestion in suggestions:
            suggestion['id'] = f"sug_{suggestions_data['total_suggestions'] + 1}"
            suggestions_data['suggestions'].append(suggestion)
            suggestions_data['total_suggestions'] += 1
        
        if len(suggestions_data['suggestions']) > 100:
            suggestions_data['suggestions'] = suggestions_data['suggestions'][-100:]
        
        with open(self.suggestions_file, 'w') as f:
            json.dump(suggestions_data, f, indent=2)
        
        return {
            "new_suggestions": suggestions,
            "total_suggestions": len(suggestions)
        }
    
    def reflect_cycle(self) -> Dict[str, Any]:
        patterns = self.detect_patterns()
        suggestions = self.suggest_improvement()
        
        emotional_state = self._get_emotional_state()
        personality_traits = self._get_personality_traits()
        
        adjustments = {
            "timestamp": datetime.now().isoformat(),
            "emotional_adjustments": [],
            "personality_adjustments": [],
            "task_adjustments": []
        }
        
        if patterns.get('emotional_patterns'):
            for pattern in patterns['emotional_patterns']:
                if pattern['type'] == 'stress_induced_failure':
                    adjustments['emotional_adjustments'].append({
                        "action": "reduce_stress",
                        "target": "stress_level",
                        "delta": -10
                    })
        
        if patterns.get('recurring_errors'):
            adjustments['personality_adjustments'].append({
                "action": "increase_caution",
                "target": "caution",
                "delta": +5
            })
        
        if patterns.get('success_patterns'):
            adjustments['personality_adjustments'].append({
                "action": "boost_confidence",
                "target": "confidence",
                "delta": +3
            })
        
        return {
            "reflection_complete": True,
            "patterns_detected": patterns,
            "suggestions_generated": len(suggestions.get('new_suggestions', [])),
            "adjustments_recommended": adjustments
        }
    
    def adaptive_evolution(self) -> Dict[str, Any]:
        reflection = self.reflect_cycle()
        
        evolution_actions = []
        
        adjustments = reflection.get('adjustments_recommended', {})
        
        for emotional_adj in adjustments.get('emotional_adjustments', []):
            evolution_actions.append({
                "module": "emotional_model",
                "action": emotional_adj['action'],
                "target": emotional_adj['target'],
                "delta": emotional_adj['delta']
            })
        
        for personality_adj in adjustments.get('personality_adjustments', []):
            evolution_actions.append({
                "module": "personality_core",
                "action": personality_adj['action'],
                "target": personality_adj['target'],
                "delta": personality_adj['delta']
            })
        
        patterns = reflection.get('patterns_detected', {})
        if patterns.get('recurring_errors'):
            evolution_actions.append({
                "module": "auto_evolution_engine",
                "action": "optimize_logic",
                "target": "code_quality",
                "priority": "high"
            })
        
        return {
            "evolution_triggered": True,
            "actions_count": len(evolution_actions),
            "actions": evolution_actions,
            "reflection_summary": reflection
        }
    
    def get_analysis_stats(self) -> Dict[str, Any]:
        with open(self.analysis_file, 'r') as f:
            analysis = json.load(f)
        
        return {
            "total_analyses": analysis.get('total_analyses', 0),
            "task_reviews": len(analysis.get('task_review', [])),
            "logic_errors": len(analysis.get('logic_errors', [])),
            "emotional_biases": len(analysis.get('emotional_bias', [])),
            "patterns_learned": len(analysis.get('pattern_learning', []))
        }
    
    def get_suggestions(self) -> List[Dict[str, Any]]:
        with open(self.suggestions_file, 'r') as f:
            suggestions_data = json.load(f)
        
        return suggestions_data.get('suggestions', [])[-20:]
