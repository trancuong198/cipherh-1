import os
import json
from typing import Dict, Any, List, Optional
from datetime import datetime
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

class RefactorEngine:
    def __init__(self):
        api_key = os.getenv('OPENAI_API_KEY')
        if not api_key:
            raise ValueError("OPENAI_API_KEY not found")
        
        self.client = OpenAI(api_key=api_key)
        self.model = os.getenv('OPENAI_MODEL', 'gpt-4o-mini')
        
        self.evolution_dir = 'evolution'
        self.performance_file = os.path.join(self.evolution_dir, 'performance.json')
        self.refactor_history_file = os.path.join(self.evolution_dir, 'refactor_history.json')
        
        os.makedirs(self.evolution_dir, exist_ok=True)
        
        self._init_refactor_history()
    
    def _init_refactor_history(self):
        if not os.path.exists(self.refactor_history_file):
            with open(self.refactor_history_file, 'w') as f:
                json.dump({
                    "refactors": [],
                    "total_refactors": 0,
                    "successful_refactors": 0,
                    "failed_refactors": 0
                }, f, indent=2)
    
    def analyze_performance(self, module_name: str) -> Dict[str, Any]:
        with open(self.performance_file, 'r') as f:
            perf_data = json.load(f)
        
        analysis = {
            "module": module_name,
            "timestamp": datetime.now().isoformat(),
            "metrics": {},
            "bottlenecks": [],
            "flaws": [],
            "recommendations": []
        }
        
        module_score = perf_data.get('module_scores', {}).get(module_name, 75)
        analysis['metrics']['overall_score'] = module_score
        
        if module_score < 70:
            analysis['bottlenecks'].append("low_overall_performance")
            analysis['recommendations'].append("comprehensive_refactor_needed")
        
        if module_name == 'memory_engine':
            analysis['metrics']['retrieval_efficiency'] = 80
            analysis['metrics']['storage_optimization'] = 75
        elif module_name == 'emotional_model':
            analysis['metrics']['stability'] = perf_data['metrics'].get('emotional_stability', 70)
            if analysis['metrics']['stability'] < 75:
                analysis['bottlenecks'].append("emotional_volatility")
        elif module_name == 'task_chain':
            analysis['metrics']['execution_speed'] = 85
            analysis['metrics']['success_rate'] = 78
        elif module_name == 'defense_firewall':
            analysis['metrics']['security_score'] = perf_data['metrics'].get('security_score', 85)
            analysis['metrics']['threat_detection'] = 90
        
        if analysis['metrics'].get('overall_score', 100) < 80:
            analysis['flaws'].append("optimization_potential")
        
        perf_data['last_analysis'] = datetime.now().isoformat()
        
        with open(self.performance_file, 'w') as f:
            json.dump(perf_data, f, indent=2)
        
        return analysis
    
    def propose_refactor(self, module_name: str) -> Dict[str, Any]:
        analysis = self.analyze_performance(module_name)
        
        refactor_plan = {
            "module": module_name,
            "timestamp": datetime.now().isoformat(),
            "priority": "low",
            "actions": [],
            "estimated_improvement": 0
        }
        
        score = analysis['metrics'].get('overall_score', 75)
        
        if score < 60:
            refactor_plan['priority'] = "critical"
            refactor_plan['estimated_improvement'] = 30
        elif score < 75:
            refactor_plan['priority'] = "high"
            refactor_plan['estimated_improvement'] = 20
        elif score < 85:
            refactor_plan['priority'] = "medium"
            refactor_plan['estimated_improvement'] = 10
        
        for bottleneck in analysis['bottlenecks']:
            if bottleneck == "low_overall_performance":
                refactor_plan['actions'].append({
                    "type": "optimize_logic",
                    "target": "core_functions",
                    "method": "algorithm_improvement"
                })
            elif bottleneck == "emotional_volatility":
                refactor_plan['actions'].append({
                    "type": "stabilize_emotions",
                    "target": "trigger_rules",
                    "method": "threshold_adjustment"
                })
        
        for flaw in analysis['flaws']:
            if flaw == "optimization_potential":
                refactor_plan['actions'].append({
                    "type": "general_optimization",
                    "target": "workflow",
                    "method": "reduce_redundancy"
                })
        
        for recommendation in analysis['recommendations']:
            if recommendation == "comprehensive_refactor_needed":
                refactor_plan['actions'].append({
                    "type": "comprehensive_refactor",
                    "target": "entire_module",
                    "method": "redesign_architecture"
                })
        
        return refactor_plan
    
    def apply_refactor(self, module_name: str, refactor_plan: Dict[str, Any]) -> Dict[str, Any]:
        with open(self.refactor_history_file, 'r') as f:
            history = json.load(f)
        
        refactor_id = f"ref_{history['total_refactors'] + 1}"
        
        result = {
            "refactor_id": refactor_id,
            "module": module_name,
            "timestamp": datetime.now().isoformat(),
            "plan": refactor_plan,
            "status": "simulated",
            "improvements": []
        }
        
        with open(self.performance_file, 'r') as f:
            perf_data = json.load(f)
        
        current_score = perf_data['module_scores'].get(module_name, 75)
        estimated_improvement = refactor_plan.get('estimated_improvement', 10)
        new_score = min(100, current_score + estimated_improvement)
        
        perf_data['module_scores'][module_name] = new_score
        perf_data['evolution_count'] += 1
        
        with open(self.performance_file, 'w') as f:
            json.dump(perf_data, f, indent=2)
        
        result['improvements'].append({
            "metric": "overall_score",
            "old_value": current_score,
            "new_value": new_score,
            "improvement": new_score - current_score
        })
        
        result['status'] = "success"
        history['refactors'].append(result)
        history['total_refactors'] += 1
        history['successful_refactors'] += 1
        
        if len(history['refactors']) > 100:
            history['refactors'] = history['refactors'][-100:]
        
        with open(self.refactor_history_file, 'w') as f:
            json.dump(history, f, indent=2)
        
        return result
    
    def learn_from_history(self) -> Dict[str, Any]:
        patterns = {
            "successful_patterns": [],
            "failed_patterns": [],
            "optimization_trends": []
        }
        
        with open(self.refactor_history_file, 'r') as f:
            history = json.load(f)
        
        refactors = history.get('refactors', [])
        
        if len(refactors) == 0:
            return {
                "status": "no_history",
                "patterns": patterns
            }
        
        successful = [r for r in refactors if r.get('status') == 'success']
        
        if successful:
            action_types = {}
            for refactor in successful:
                for action in refactor.get('plan', {}).get('actions', []):
                    action_type = action.get('type', 'unknown')
                    if action_type in action_types:
                        action_types[action_type] += 1
                    else:
                        action_types[action_type] = 1
            
            for action_type, count in sorted(action_types.items(), key=lambda x: x[1], reverse=True)[:5]:
                patterns['successful_patterns'].append({
                    "action_type": action_type,
                    "frequency": count,
                    "effectiveness": "high" if count > 5 else "medium"
                })
        
        module_improvements = {}
        for refactor in refactors:
            module = refactor.get('module')
            if module:
                improvements = refactor.get('improvements', [])
                for imp in improvements:
                    improvement_value = imp.get('improvement', 0)
                    if module in module_improvements:
                        module_improvements[module].append(improvement_value)
                    else:
                        module_improvements[module] = [improvement_value]
        
        for module, improvements in module_improvements.items():
            avg_improvement = sum(improvements) / len(improvements)
            patterns['optimization_trends'].append({
                "module": module,
                "average_improvement": avg_improvement,
                "total_refactors": len(improvements)
            })
        
        return {
            "status": "analyzed",
            "total_refactors": len(refactors),
            "successful_refactors": len(successful),
            "patterns": patterns
        }
    
    def monitor_post_refactor(self, refactor_id: str) -> Dict[str, Any]:
        with open(self.refactor_history_file, 'r') as f:
            history = json.load(f)
        
        refactor = None
        for r in history['refactors']:
            if r.get('refactor_id') == refactor_id:
                refactor = r
                break
        
        if not refactor:
            return {"error": "Refactor not found"}
        
        module_name = refactor.get('module')
        
        current_analysis = self.analyze_performance(module_name)
        
        monitoring = {
            "refactor_id": refactor_id,
            "module": module_name,
            "timestamp": datetime.now().isoformat(),
            "status": "stable",
            "issues": [],
            "performance_check": current_analysis['metrics']
        }
        
        current_score = current_analysis['metrics'].get('overall_score', 75)
        
        expected_improvements = refactor.get('improvements', [])
        if expected_improvements:
            expected_score = expected_improvements[0].get('new_value', 75)
            
            if current_score < expected_score - 5:
                monitoring['status'] = "degraded"
                monitoring['issues'].append("performance_below_expected")
        
        if current_analysis.get('flaws'):
            monitoring['issues'].extend(current_analysis['flaws'])
        
        return monitoring
