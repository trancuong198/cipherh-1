import os
import json
from typing import Dict, Any, List, Optional
from datetime import datetime

class EventDispatcher:
    def __init__(self):
        self.realtime_dir = 'realtime'
        self.dispatch_log_file = os.path.join(self.realtime_dir, 'dispatch_log.json')
        
        os.makedirs(self.realtime_dir, exist_ok=True)
        
        self._init_dispatch_log()
    
    def _init_dispatch_log(self):
        if not os.path.exists(self.dispatch_log_file):
            with open(self.dispatch_log_file, 'w') as f:
                json.dump({
                    "dispatches": [],
                    "total_dispatches": 0
                }, f, indent=2)
    
    def dispatch_event(self, event_id: str, priority: int) -> Dict[str, Any]:
        event = self._get_event(event_id)
        
        if not event:
            return {"error": "Event not found"}
        
        dispatch = {
            "id": f"dispatch_{self._get_next_id()}",
            "event_id": event_id,
            "timestamp": datetime.now().isoformat(),
            "priority": priority,
            "urgency": event.get('urgency', 'medium'),
            "target_modules": [],
            "routing": {}
        }
        
        source = event.get('source', '')
        data = event.get('data', {})
        
        if source == 'security' or data.get('threat_level', 0) > 60:
            dispatch['target_modules'].append('hacker_mindset')
            dispatch['target_modules'].append('defense_firewall')
            dispatch['routing']['security'] = {
                "action": "scan_and_defend",
                "priority": "critical"
            }
        
        if source == 'social':
            dispatch['target_modules'].append('social_interface')
            dispatch['target_modules'].append('personality_core')
            dispatch['target_modules'].append('emotional_model')
            dispatch['routing']['social'] = {
                "action": "analyze_and_respond",
                "priority": "high"
            }
        
        if source == 'task' or data.get('requires_task'):
            dispatch['target_modules'].append('task_chain')
            dispatch['routing']['task'] = {
                "action": "create_and_execute",
                "priority": "medium"
            }
        
        if source == 'evolution' or data.get('flaw_detected'):
            dispatch['target_modules'].append('auto_evolution')
            dispatch['target_modules'].append('metacognition2')
            dispatch['routing']['evolution'] = {
                "action": "analyze_and_evolve",
                "priority": "high"
            }
        
        if source == 'system':
            dispatch['target_modules'].append('metacognition2')
            dispatch['routing']['system'] = {
                "action": "monitor_and_correct",
                "priority": "medium"
            }
        
        dispatch['target_modules'].append('memory_engine')
        
        with open(self.dispatch_log_file, 'r') as f:
            log_data = json.load(f)
        
        log_data['dispatches'].append(dispatch)
        log_data['total_dispatches'] += 1
        
        if len(log_data['dispatches']) > 200:
            log_data['dispatches'] = log_data['dispatches'][-200:]
        
        with open(self.dispatch_log_file, 'w') as f:
            json.dump(log_data, f, indent=2)
        
        return dispatch
    
    def _get_event(self, event_id: str) -> Optional[Dict[str, Any]]:
        events_file = 'realtime/events.json'
        
        if not os.path.exists(events_file):
            return None
        
        try:
            with open(events_file, 'r') as f:
                events_data = json.load(f)
            
            for event in events_data['events']:
                if event['id'] == event_id:
                    return event
            
            return None
        except Exception:
            return None
    
    def _get_next_id(self) -> int:
        with open(self.dispatch_log_file, 'r') as f:
            log_data = json.load(f)
        return log_data['total_dispatches'] + 1
    
    def get_dispatch_stats(self) -> Dict[str, Any]:
        with open(self.dispatch_log_file, 'r') as f:
            log_data = json.load(f)
        
        recent = log_data['dispatches'][-50:]
        
        module_counts = {}
        for dispatch in recent:
            for module in dispatch.get('target_modules', []):
                module_counts[module] = module_counts.get(module, 0) + 1
        
        return {
            "total_dispatches": log_data['total_dispatches'],
            "recent_count": len(recent),
            "module_usage": module_counts
        }
