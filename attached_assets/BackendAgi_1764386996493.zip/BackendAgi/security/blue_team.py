import os
import json
from typing import Dict, Any, List, Optional
from datetime import datetime

class BlueTeam:
    def __init__(self):
        self.security_dir = 'security'
        self.patches_file = os.path.join(self.security_dir, 'security_patches.json')
        self.firewall_rules_file = os.path.join(self.security_dir, 'firewall_rules.json')
        
        os.makedirs(self.security_dir, exist_ok=True)
        
        self._init_files()
    
    def _init_files(self):
        if not os.path.exists(self.patches_file):
            with open(self.patches_file, 'w') as f:
                json.dump({
                    "patches": [],
                    "total_patches": 0,
                    "successful_patches": 0
                }, f, indent=2)
        
        if not os.path.exists(self.firewall_rules_file):
            with open(self.firewall_rules_file, 'w') as f:
                json.dump({
                    "rules": [],
                    "blocked_ips": [],
                    "blocked_patterns": [],
                    "alert_level": 50
                }, f, indent=2)
    
    def apply_patch(self, vulnerability: Dict[str, Any]) -> Dict[str, Any]:
        patch = {
            "id": f"patch_{self._get_next_patch_id()}",
            "timestamp": datetime.now().isoformat(),
            "vulnerability_type": vulnerability.get('type'),
            "target_module": vulnerability.get('module'),
            "severity": vulnerability.get('severity', 'medium'),
            "actions_taken": [],
            "status": "applied"
        }
        
        vuln_type = vulnerability.get('type')
        
        if vuln_type == "sql_injection":
            patch['actions_taken'].append("sanitize_input_layer")
            patch['actions_taken'].append("parameterize_queries")
            patch['actions_taken'].append("add_input_validation")
        
        elif vuln_type == "xss":
            patch['actions_taken'].append("escape_html_entities")
            patch['actions_taken'].append("content_security_policy")
            patch['actions_taken'].append("output_encoding")
        
        elif vuln_type == "token_hijacking":
            patch['actions_taken'].append("rotate_tokens")
            patch['actions_taken'].append("add_token_expiry")
            patch['actions_taken'].append("secure_token_storage")
        
        elif vuln_type == "brute_force":
            patch['actions_taken'].append("rate_limiting")
            patch['actions_taken'].append("account_lockout")
            patch['actions_taken'].append("captcha_challenge")
        
        elif vuln_type == "api_abuse":
            patch['actions_taken'].append("implement_rate_limiter")
            patch['actions_taken'].append("api_key_rotation")
            patch['actions_taken'].append("request_throttling")
        
        else:
            patch['actions_taken'].append("general_hardening")
        
        with open(self.patches_file, 'r') as f:
            patches_data = json.load(f)
        
        patches_data['patches'].append(patch)
        patches_data['total_patches'] += 1
        patches_data['successful_patches'] += 1
        
        if len(patches_data['patches']) > 100:
            patches_data['patches'] = patches_data['patches'][-100:]
        
        with open(self.patches_file, 'w') as f:
            json.dump(patches_data, f, indent=2)
        
        return patch
    
    def update_firewall_rules(self, threat_score: int) -> Dict[str, Any]:
        with open(self.firewall_rules_file, 'r') as f:
            firewall_data = json.load(f)
        
        new_rule = {
            "id": f"rule_{len(firewall_data['rules']) + 1}",
            "timestamp": datetime.now().isoformat(),
            "threat_score_threshold": threat_score,
            "action": "block" if threat_score > 70 else "monitor",
            "alert_level": firewall_data['alert_level']
        }
        
        if threat_score > 80:
            firewall_data['alert_level'] = min(100, firewall_data['alert_level'] + 10)
            new_rule['additional_actions'] = ["increase_monitoring", "alert_admin", "log_detailed"]
        
        elif threat_score > 60:
            new_rule['additional_actions'] = ["increase_logging", "monitor_closely"]
        
        else:
            firewall_data['alert_level'] = max(10, firewall_data['alert_level'] - 5)
        
        firewall_data['rules'].append(new_rule)
        
        if len(firewall_data['rules']) > 50:
            firewall_data['rules'] = firewall_data['rules'][-50:]
        
        with open(self.firewall_rules_file, 'w') as f:
            json.dump(firewall_data, f, indent=2)
        
        return {
            "rule_added": new_rule,
            "current_alert_level": firewall_data['alert_level']
        }
    
    def block_pattern(self, pattern: str, reason: str) -> Dict[str, Any]:
        with open(self.firewall_rules_file, 'r') as f:
            firewall_data = json.load(f)
        
        block_entry = {
            "pattern": pattern,
            "reason": reason,
            "timestamp": datetime.now().isoformat()
        }
        
        firewall_data['blocked_patterns'].append(block_entry)
        
        if len(firewall_data['blocked_patterns']) > 200:
            firewall_data['blocked_patterns'] = firewall_data['blocked_patterns'][-200:]
        
        with open(self.firewall_rules_file, 'w') as f:
            json.dump(firewall_data, f, indent=2)
        
        return {
            "success": True,
            "pattern": pattern,
            "blocked_at": block_entry['timestamp']
        }
    
    def _get_next_patch_id(self) -> int:
        with open(self.patches_file, 'r') as f:
            patches_data = json.load(f)
        return patches_data['total_patches'] + 1
    
    def get_patch_history(self) -> Dict[str, Any]:
        with open(self.patches_file, 'r') as f:
            return json.load(f)
    
    def get_firewall_status(self) -> Dict[str, Any]:
        with open(self.firewall_rules_file, 'r') as f:
            return json.load(f)
