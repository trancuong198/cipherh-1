import os
import json
from typing import Dict, Any, List, Optional
from datetime import datetime

class RedTeam:
    def __init__(self):
        self.security_dir = 'security'
        self.attack_log_file = os.path.join(self.security_dir, 'attack_simulations.json')
        
        os.makedirs(self.security_dir, exist_ok=True)
        
        self._init_attack_log()
    
    def _init_attack_log(self):
        if not os.path.exists(self.attack_log_file):
            with open(self.attack_log_file, 'w') as f:
                json.dump({
                    "simulations": [],
                    "total_simulations": 0,
                    "vulnerabilities_found": 0
                }, f, indent=2)
    
    def simulate_attack(self, target_module: str) -> Dict[str, Any]:
        attack_types = [
            "sql_injection",
            "xss",
            "brute_force",
            "overflow",
            "token_hijacking",
            "session_replay",
            "credential_stuffing",
            "api_abuse"
        ]
        
        simulation = {
            "id": f"sim_{self._get_next_id()}",
            "timestamp": datetime.now().isoformat(),
            "target_module": target_module,
            "attacks_tested": [],
            "vulnerabilities": [],
            "security_score": 100
        }
        
        for attack_type in attack_types:
            result = self._test_attack(target_module, attack_type)
            simulation['attacks_tested'].append(result)
            
            if not result['blocked']:
                simulation['vulnerabilities'].append({
                    "type": attack_type,
                    "severity": result['severity'],
                    "exploit_path": result['path']
                })
                simulation['security_score'] -= result['score_impact']
        
        simulation['security_score'] = max(0, simulation['security_score'])
        
        with open(self.attack_log_file, 'r') as f:
            log_data = json.load(f)
        
        log_data['simulations'].append(simulation)
        log_data['total_simulations'] += 1
        log_data['vulnerabilities_found'] += len(simulation['vulnerabilities'])
        
        if len(log_data['simulations']) > 100:
            log_data['simulations'] = log_data['simulations'][-100:]
        
        with open(self.attack_log_file, 'w') as f:
            json.dump(log_data, f, indent=2)
        
        return simulation
    
    def _test_attack(self, module: str, attack_type: str) -> Dict[str, Any]:
        blocked = True
        severity = "low"
        score_impact = 5
        path = f"{module}/api"
        
        if attack_type == "sql_injection":
            if module in ['memory_engine', 'ltm_map']:
                blocked = False
                severity = "critical"
                score_impact = 30
                path = f"{module}/query_interface"
        
        elif attack_type == "xss":
            if module in ['social', 'brain']:
                blocked = False
                severity = "medium"
                score_impact = 15
                path = f"{module}/input_handler"
        
        elif attack_type == "brute_force":
            if module in ['admin', 'task_chain']:
                blocked = True
                severity = "high"
                score_impact = 20
        
        elif attack_type == "token_hijacking":
            if module in ['social', 'connectors']:
                blocked = False
                severity = "high"
                score_impact = 25
                path = f"{module}/auth_layer"
        
        elif attack_type == "api_abuse":
            blocked = False
            severity = "medium"
            score_impact = 10
            path = f"{module}/rate_limiter"
        
        return {
            "attack_type": attack_type,
            "blocked": blocked,
            "severity": severity,
            "score_impact": score_impact,
            "path": path
        }
    
    def _get_next_id(self) -> int:
        with open(self.attack_log_file, 'r') as f:
            log_data = json.load(f)
        return log_data['total_simulations'] + 1
    
    def get_attack_history(self) -> Dict[str, Any]:
        with open(self.attack_log_file, 'r') as f:
            return json.load(f)
