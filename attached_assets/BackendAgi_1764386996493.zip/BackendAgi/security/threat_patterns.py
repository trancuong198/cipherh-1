import os
import json
from typing import Dict, Any, List, Optional
from datetime import datetime

class ThreatPatterns:
    def __init__(self):
        self.security_dir = 'security'
        self.patterns_file = os.path.join(self.security_dir, 'threat_patterns_db.json')
        
        os.makedirs(self.security_dir, exist_ok=True)
        
        self._init_patterns()
    
    def _init_patterns(self):
        if not os.path.exists(self.patterns_file):
            default_patterns = {
                "signatures": [
                    {
                        "name": "sql_injection",
                        "pattern": ["' OR '1'='1", "DROP TABLE", "UNION SELECT"],
                        "severity": "critical"
                    },
                    {
                        "name": "xss_attack",
                        "pattern": ["<script>", "javascript:", "onerror="],
                        "severity": "high"
                    },
                    {
                        "name": "path_traversal",
                        "pattern": ["../", "..\\", "%2e%2e"],
                        "severity": "high"
                    },
                    {
                        "name": "command_injection",
                        "pattern": ["; cat /etc/passwd", "| ls -la", "&& whoami"],
                        "severity": "critical"
                    },
                    {
                        "name": "brute_force",
                        "pattern": ["rapid_login_attempts", "multiple_failed_auth"],
                        "severity": "high"
                    }
                ],
                "suspicious_patterns": [
                    "unusual_user_agent",
                    "rapid_api_calls",
                    "invalid_token_usage",
                    "unauthorized_endpoint_access"
                ],
                "traffic_signatures": {
                    "ddos": "high_volume_from_single_source",
                    "bot": "automated_pattern_detected",
                    "scraper": "systematic_data_extraction"
                },
                "incident_history": [],
                "last_updated": datetime.now().isoformat()
            }
            
            with open(self.patterns_file, 'w') as f:
                json.dump(default_patterns, f, indent=2)
    
    def load_threat_signatures(self) -> Dict[str, Any]:
        with open(self.patterns_file, 'r') as f:
            patterns_data = json.load(f)
        
        return {
            "signatures": patterns_data['signatures'],
            "suspicious_patterns": patterns_data['suspicious_patterns'],
            "traffic_signatures": patterns_data['traffic_signatures'],
            "total_signatures": len(patterns_data['signatures'])
        }
    
    def match_pattern(self, request_data: Dict[str, Any]) -> Dict[str, Any]:
        with open(self.patterns_file, 'r') as f:
            patterns_data = json.load(f)
        
        matched = []
        
        request_content = str(request_data.get('content', '')).lower()
        
        for signature in patterns_data['signatures']:
            for pattern in signature['pattern']:
                if pattern.lower() in request_content:
                    matched.append({
                        "signature": signature['name'],
                        "pattern": pattern,
                        "severity": signature['severity']
                    })
        
        if matched:
            return {
                "threat_detected": True,
                "matches": matched,
                "highest_severity": self._get_highest_severity(matched)
            }
        
        return {
            "threat_detected": False,
            "matches": []
        }
    
    def _get_highest_severity(self, matches: List[Dict[str, Any]]) -> str:
        severity_order = {'critical': 3, 'high': 2, 'medium': 1, 'low': 0}
        
        highest = 'low'
        for match in matches:
            severity = match.get('severity', 'low')
            if severity_order.get(severity, 0) > severity_order.get(highest, 0):
                highest = severity
        
        return highest
    
    def update_threat_database(self, new_pattern: Dict[str, Any]) -> Dict[str, Any]:
        with open(self.patterns_file, 'r') as f:
            patterns_data = json.load(f)
        
        if 'signature' in new_pattern:
            patterns_data['signatures'].append({
                "name": new_pattern['name'],
                "pattern": new_pattern['pattern'],
                "severity": new_pattern.get('severity', 'medium')
            })
        
        if 'incident' in new_pattern:
            patterns_data['incident_history'].append({
                "timestamp": datetime.now().isoformat(),
                "type": new_pattern['type'],
                "severity": new_pattern.get('severity', 'medium'),
                "data": new_pattern.get('data', {})
            })
            
            if len(patterns_data['incident_history']) > 100:
                patterns_data['incident_history'] = patterns_data['incident_history'][-100:]
        
        patterns_data['last_updated'] = datetime.now().isoformat()
        
        with open(self.patterns_file, 'w') as f:
            json.dump(patterns_data, f, indent=2)
        
        return {
            "success": True,
            "action": "threat_database_updated"
        }
    
    def get_incident_history(self) -> List[Dict[str, Any]]:
        with open(self.patterns_file, 'r') as f:
            patterns_data = json.load(f)
        
        return patterns_data.get('incident_history', [])[-50:]
