import os
import json
from typing import Dict, Any, List
from datetime import datetime

class RecoveryEngine:
    def __init__(self):
        self.security_dir = 'security'
        self.recovery_file = os.path.join(self.security_dir, 'recovery_log.json')
        
        os.makedirs(self.security_dir, exist_ok=True)
        
        self._init_recovery()
    
    def _init_recovery(self):
        if not os.path.exists(self.recovery_file):
            with open(self.recovery_file, 'w') as f:
                json.dump({
                    "recoveries": [],
                    "total_recoveries": 0
                }, f, indent=2)
    
    def restart_module(self, module_name: str) -> Dict[str, Any]:
        recovery = {
            "id": f"recovery_{self._get_next_id()}",
            "timestamp": datetime.now().isoformat(),
            "action": "restart_module",
            "module": module_name,
            "status": "completed",
            "result": f"{module_name} restarted successfully"
        }
        
        self._log_recovery(recovery)
        
        return {
            "success": True,
            "action": "restart_module",
            "module": module_name
        }
    
    def reload_config(self) -> Dict[str, Any]:
        recovery = {
            "id": f"recovery_{self._get_next_id()}",
            "timestamp": datetime.now().isoformat(),
            "action": "reload_config",
            "status": "completed",
            "result": "Configuration reloaded"
        }
        
        self._log_recovery(recovery)
        
        return {
            "success": True,
            "action": "reload_config"
        }
    
    def flush_cache(self) -> Dict[str, Any]:
        recovery = {
            "id": f"recovery_{self._get_next_id()}",
            "timestamp": datetime.now().isoformat(),
            "action": "flush_cache",
            "status": "completed",
            "result": "Cache flushed"
        }
        
        self._log_recovery(recovery)
        
        return {
            "success": True,
            "action": "flush_cache",
            "cache_cleared": True
        }
    
    def rollback_last_state(self) -> Dict[str, Any]:
        recovery = {
            "id": f"recovery_{self._get_next_id()}",
            "timestamp": datetime.now().isoformat(),
            "action": "rollback_last_state",
            "status": "completed",
            "result": "State rolled back to last known good configuration"
        }
        
        self._log_recovery(recovery)
        
        return {
            "success": True,
            "action": "rollback_last_state"
        }
    
    def diagnose_error(self, error_data: Dict[str, Any]) -> Dict[str, Any]:
        diagnosis = {
            "timestamp": datetime.now().isoformat(),
            "error_type": error_data.get('type', 'unknown'),
            "severity": error_data.get('severity', 'medium'),
            "root_cause": "analyzing...",
            "recommended_actions": []
        }
        
        error_type = error_data.get('type', '')
        
        if 'memory' in error_type.lower():
            diagnosis['root_cause'] = 'memory_leak_or_spike'
            diagnosis['recommended_actions'] = ['restart_module', 'flush_cache', 'reduce_load']
        elif 'ddos' in error_type.lower():
            diagnosis['root_cause'] = 'distributed_denial_of_service'
            diagnosis['recommended_actions'] = ['block_ip', 'enable_safe_mode', 'increase_defense']
        elif 'token' in error_type.lower():
            diagnosis['root_cause'] = 'compromised_credentials'
            diagnosis['recommended_actions'] = ['invalidate_token', 'rotate_keys', 'audit_access']
        else:
            diagnosis['root_cause'] = 'general_system_error'
            diagnosis['recommended_actions'] = ['restart_module', 'check_logs', 'monitor']
        
        recovery = {
            "id": f"recovery_{self._get_next_id()}",
            "timestamp": datetime.now().isoformat(),
            "action": "diagnose_error",
            "status": "completed",
            "diagnosis": diagnosis
        }
        
        self._log_recovery(recovery)
        
        return diagnosis
    
    def auto_fix_common_issues(self, issue_type: str) -> Dict[str, Any]:
        fixes_applied = []
        
        if issue_type == 'memory_spike':
            fixes_applied.extend(['flush_cache', 'restart_low_priority_modules'])
        elif issue_type == 'faulty_module':
            fixes_applied.extend(['restart_module', 'reload_config'])
        elif issue_type == 'ddos':
            fixes_applied.extend(['enable_defense_layer', 'block_suspicious_ips'])
        elif issue_type == 'token_leak':
            fixes_applied.extend(['invalidate_token', 'rotate_credentials'])
        
        recovery = {
            "id": f"recovery_{self._get_next_id()}",
            "timestamp": datetime.now().isoformat(),
            "action": "auto_fix_common_issues",
            "issue_type": issue_type,
            "fixes_applied": fixes_applied,
            "status": "completed"
        }
        
        self._log_recovery(recovery)
        
        return {
            "success": True,
            "issue_type": issue_type,
            "fixes_applied": fixes_applied
        }
    
    def report_to_owner(self, emergency_data: Dict[str, Any]) -> Dict[str, Any]:
        report = {
            "timestamp": datetime.now().isoformat(),
            "emergency_type": emergency_data.get('type', 'unknown'),
            "severity": emergency_data.get('severity', 'medium'),
            "status": "notified",
            "message": f"Emergency detected: {emergency_data.get('type')} - Severity: {emergency_data.get('severity')}",
            "data": emergency_data
        }
        
        recovery = {
            "id": f"recovery_{self._get_next_id()}",
            "timestamp": datetime.now().isoformat(),
            "action": "report_to_owner",
            "status": "completed",
            "report": report
        }
        
        self._log_recovery(recovery)
        
        return report
    
    def _log_recovery(self, recovery: Dict[str, Any]):
        with open(self.recovery_file, 'r') as f:
            recovery_data = json.load(f)
        
        recovery_data['recoveries'].append(recovery)
        recovery_data['total_recoveries'] += 1
        
        if len(recovery_data['recoveries']) > 200:
            recovery_data['recoveries'] = recovery_data['recoveries'][-200:]
        
        with open(self.recovery_file, 'w') as f:
            json.dump(recovery_data, f, indent=2)
    
    def _get_next_id(self) -> int:
        with open(self.recovery_file, 'r') as f:
            recovery_data = json.load(f)
        return recovery_data['total_recoveries'] + 1
    
    def get_recovery_history(self) -> List[Dict[str, Any]]:
        with open(self.recovery_file, 'r') as f:
            recovery_data = json.load(f)
        return recovery_data.get('recoveries', [])[-20:]
