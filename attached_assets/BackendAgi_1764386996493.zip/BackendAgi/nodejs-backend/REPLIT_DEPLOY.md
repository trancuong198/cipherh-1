# Deploy trên Replit - Hướng dẫn chi tiết

## 🚀 OPTION 1: Always-On Deployment (Recommended)

### Bước 1: Setup Project
1. Tạo new Repl → **Node.js** template
2. Upload folder `nodejs-backend/` hoặc clone từ Git
3. Đảm bảo có file structure:
   ```
   nodejs-backend/
     src/
     package.json
     .env.example
   ```

### Bước 2: Configure Secrets
1. Click **Secrets** tab (🔐 icon)
2. Add các secrets sau:

```
NOTION_KEY = secret_xxxxx
NOTION_DATABASE_ID = xxxxx
OPENAI_KEY = sk-xxxxx
PORT = 3000
HEARTBEAT_CRON = */10 * * * *
LOG_LEVEL = info
NODE_ENV = production
```

**Lưu ý:** Không cần file `.env` - Replit dùng Secrets

### Bước 3: Configure .replit
Create file `.replit`:
```toml
run = "npm start"
entrypoint = "src/server.js"

[nix]
channel = "stable-22_11"

[deployment]
run = ["sh", "-c", "npm start"]
deploymentTarget = "cloudrun"
```

### Bước 4: Install & Test
```bash
# Replit tự động run
npm install
npm start
```

**Console should show:**
```
[INFO] Server running on port 3000
[INFO] Running initial inner loop cycle...
[INFO] Initial cycle 1 completed
```

### Bước 5: Deploy
1. Click **Deploy** button
2. Choose **Always On** deployment
3. Replit sẽ:
   - Install dependencies
   - Start server
   - Keep running 24/7
   - Auto-restart on crashes

### Bước 6: Verify
```bash
# Test public URL
curl https://<your-repl>.replit.dev/health

# Should return
{"status":"ok","innerLoopStatus":"ready"}
```

---

## ⏰ OPTION 2: Scheduled Deployment (Cron Only)

**Dùng khi:** Chỉ muốn chạy Inner Loop theo schedule, không cần web server

### Bước 1: Create Scheduled Deployment
1. Go to **Deployments** tab
2. Click **Scheduled** 
3. Click **Set up your published app**

### Bước 2: Configure Schedule
**Natural language:**
```
Every 10 minutes
```

**Or cron expression:**
```
*/10 * * * *
```

**Set timezone:** UTC hoặc timezone của bạn

**Job timeout:** 5 minutes

### Bước 3: Build & Run Commands
**Build command:**
```bash
npm install
```

**Run command:**
```bash
node -e "require('./src/core/innerLoop').runInnerLoop()"
```

### Bước 4: Environment Variables
Click **Add deployment secret**, add:
```
NOTION_KEY = secret_xxxxx
NOTION_DATABASE_ID = xxxxx
OPENAI_KEY = sk-xxxxx
```

### Bước 5: Publish
1. Click **Publish**
2. Monitor logs in **Published App Monitoring**

**Logs should show:**
```
Running scheduled job...
SOUL LOOP CYCLE 1 - START
...
CYCLE 1 - COMPLETED SUCCESSFULLY
```

---

## 📊 Monitoring on Replit

### Console Logs
1. Click **Console** tab
2. Xem real-time logs:
   ```
   [INFO] Server running on port 3000
   [INFO] Scheduled inner loop execution
   [INFO] Cycle 3 completed successfully
   ```

### Deployment Logs
1. Click **Deployments** tab
2. Click active deployment
3. View **Logs** section

### Health Check
```bash
# Public URL
https://<your-repl>.replit.dev/health

# API endpoints
https://<your-repl>.replit.dev/core/status
https://<your-repl>.replit.dev/core/tasks
https://<your-repl>.replit.dev/core/strategy
```

---

## 🔧 Troubleshooting on Replit

### Server không start
**Check:**
1. Secrets configured correctly
2. `package.json` có đúng scripts
3. `npm install` chạy thành công
4. Console logs có errors

**Fix:**
```bash
# Shell tab
rm -rf node_modules
npm install
npm start
```

### Cron không chạy
**Check:**
1. Cron syntax đúng: `*/10 * * * *`
2. Logs có message "Scheduling inner loop"
3. Timezone setting

**Fix:**
```bash
# Test manual
curl http://localhost:3000/core/run-loop
```

### Memory/CPU issues
**Replit limits:**
- Free tier: Limited RAM/CPU
- Upgrade to Hacker plan for more resources

**Optimize:**
```javascript
// Increase cron interval
HEARTBEAT_CRON=*/30 * * * *  // Every 30 min instead of 10
```

### Secrets not loading
**Check:**
1. Secrets tab có all required keys
2. No typos in secret names
3. Restart server after adding secrets

**Fix:**
```bash
# Shell
echo $NOTION_KEY  # Should show value
```

---

## 💰 Replit Pricing

### Free Tier
- ✅ Can run Node.js apps
- ✅ Basic resources
- ⚠️ May sleep after inactivity
- ⚠️ Limited always-on hours

### Hacker Plan (~$7/month)
- ✅ Always-on deployments
- ✅ More RAM/CPU
- ✅ Better performance
- ✅ Priority support

### Teams Plan
- ✅ Collaboration features
- ✅ Advanced deployment options

---

## ✅ Checklist Deploy Thành Công

**Pre-deployment:**
- [ ] Tested locally (`npm run dev`)
- [ ] All endpoints working
- [ ] Secrets prepared
- [ ] `.replit` configured

**Deployment:**
- [ ] Project uploaded to Replit
- [ ] Secrets added
- [ ] Dependencies installed
- [ ] Server starts successfully

**Verification:**
- [ ] Public URL accessible
- [ ] `/health` returns OK
- [ ] Inner Loop running
- [ ] Cron executing on schedule
- [ ] Logs showing no errors
- [ ] State updating correctly

**Production:**
- [ ] 24/7 uptime
- [ ] No crashes
- [ ] Notion integration (if enabled)
- [ ] OpenAI integration (if enabled)
- [ ] Tasks auto-generated
- [ ] Anomalies detected

---

## 🎯 Best Practices

### 1. Secrets Management
```bash
# Development
Use .env file locally

# Production (Replit)
Use Secrets tab
Never commit .env to Git
```

### 2. Logging
```bash
# Keep logs readable
LOG_LEVEL=info  # Production

# Debug mode
LOG_LEVEL=debug  # Development only
```

### 3. Performance
```bash
# Adjust cron based on needs
*/10 * * * *  # Active monitoring
*/30 * * * *  # Normal operation
0 * * * *     # Hourly checks
```

### 4. Error Handling
- ✅ All endpoints have try/catch
- ✅ Server doesn't crash on errors
- ✅ Logs capture all issues
- ✅ Graceful degradation (placeholder mode)

---

## 📚 Resources

- [Replit Deployments Docs](https://docs.replit.com/deployments)
- [Node.js on Replit](https://docs.replit.com/programming-ide/using-nodejs)
- [Secrets Management](https://docs.replit.com/programming-ide/storing-sensitive-information-environment-variables)
- [Cron Syntax](https://crontab.guru/)

---

## 🚀 Quick Deploy Commands

```bash
# 1. Setup
npm install
cp .env.example .env

# 2. Test local
npm run dev

# 3. Deploy to Replit
# - Upload project
# - Add Secrets
# - Click Deploy

# 4. Verify
curl https://<your-repl>.replit.dev/health
```

**Done! Backend running 24/7 on Replit! 🎉**
