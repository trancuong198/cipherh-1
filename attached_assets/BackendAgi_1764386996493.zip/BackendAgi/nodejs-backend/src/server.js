require('dotenv').config();
const app = require('./app');
const cron = require('node-cron');
const { runInnerLoop } = require('./core/innerLoop');
const loggerService = require('./services/loggerService');
const fs = require('fs');

const PORT = process.env.PORT || 3000;
const HEARTBEAT_CRON = process.env.HEARTBEAT_CRON || '*/10 * * * *';

if (!fs.existsSync('logs')) {
  fs.mkdirSync('logs');
}

loggerService.info('==================================================');
loggerService.info('CipherH Soul Loop Backend - Node.js');
loggerService.info('==================================================');

if (!process.env.NOTION_KEY) {
  loggerService.warn('NOTION_KEY not configured - running in placeholder mode');
}

if (!process.env.NOTION_DATABASE_ID) {
  loggerService.warn('NOTION_DATABASE_ID not configured - running in placeholder mode');
}

if (!process.env.OPENAI_KEY) {
  loggerService.warn('OPENAI_KEY not configured - running in placeholder mode');
}

app.listen(PORT, () => {
  loggerService.info(`Server running on port ${PORT}`);
  loggerService.info(`Health check: http://localhost:${PORT}/health`);
});

loggerService.info(`Scheduling inner loop with cron: ${HEARTBEAT_CRON}`);

cron.schedule(HEARTBEAT_CRON, async () => {
  loggerService.info('=== Scheduled Inner Loop Execution ===');
  
  try {
    const result = await runInnerLoop();
    
    if (result.success) {
      loggerService.info(`Inner loop cycle ${result.cycle} completed successfully`);
    } else {
      loggerService.error(`Inner loop cycle failed: ${result.error}`);
    }
  } catch (error) {
    loggerService.error('Inner loop execution error', error);
  }
});

loggerService.info('Running initial inner loop cycle...');

(async () => {
  try {
    const result = await runInnerLoop();
    
    if (result.success) {
      loggerService.info(`Initial cycle ${result.cycle} completed`);
    }
  } catch (error) {
    loggerService.error('Initial inner loop failed', error);
  }
})();

process.on('SIGTERM', () => {
  loggerService.info('SIGTERM received, shutting down gracefully');
  process.exit(0);
});

process.on('SIGINT', () => {
  loggerService.info('SIGINT received, shutting down gracefully');
  process.exit(0);
});

process.on('unhandledRejection', (reason, promise) => {
  loggerService.error('Unhandled Rejection', { reason, promise });
});

process.on('uncaughtException', (error) => {
  loggerService.error('Uncaught Exception', error);
  process.exit(1);
});
