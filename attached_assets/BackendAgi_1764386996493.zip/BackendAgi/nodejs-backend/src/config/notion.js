require('dotenv').config();

const notionConfig = {
  key: process.env.NOTION_KEY,
  databaseId: process.env.NOTION_DATABASE_ID
};

module.exports = notionConfig;
