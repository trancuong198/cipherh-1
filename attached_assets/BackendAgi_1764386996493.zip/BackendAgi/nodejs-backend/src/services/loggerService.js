const winston = require('winston');
const path = require('path');

const logDir = 'logs';

const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || 'info',
  format: winston.format.combine(
    winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
    winston.format.errors({ stack: true }),
    winston.format.splat(),
    winston.format.printf(({ timestamp, level, message, ...meta }) => {
      let msg = `${timestamp} [${level.toUpperCase()}] ${message}`;
      if (Object.keys(meta).length > 0) {
        msg += ` ${JSON.stringify(meta)}`;
      }
      return msg;
    })
  ),
  transports: [
    new winston.transports.File({ 
      filename: path.join(logDir, 'app.log'),
      maxsize: 5242880,
      maxFiles: 5
    }),
    new winston.transports.Console({
      format: winston.format.combine(
        winston.format.colorize(),
        winston.format.printf(({ timestamp, level, message, ...meta }) => {
          let msg = `${timestamp} [${level}] ${message}`;
          if (Object.keys(meta).length > 0 && meta.service !== 'cipherh-soul') {
            msg += ` ${JSON.stringify(meta)}`;
          }
          return msg;
        })
      )
    })
  ]
});

function info(message, meta = {}) {
  logger.info(message, meta);
}

function warn(message, meta = {}) {
  logger.warn(message, meta);
}

function error(message, errorObj = null, meta = {}) {
  if (errorObj) {
    logger.error(message, { 
      error: errorObj.message, 
      stack: errorObj.stack,
      ...meta 
    });
  } else {
    logger.error(message, meta);
  }
}

function debug(message, meta = {}) {
  logger.debug(message, meta);
}

module.exports = {
  info,
  warn,
  error,
  debug
};
