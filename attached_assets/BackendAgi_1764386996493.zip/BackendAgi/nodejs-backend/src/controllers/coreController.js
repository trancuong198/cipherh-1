const { runInnerLoop, getState } = require('../core/innerLoop');
const { generateStrategy } = require('../core/strategy');
const { getTasks } = require('../core/taskManager');
const { detectAnomalies } = require('../core/anomalyDetector');
const loggerService = require('../services/loggerService');
const notionService = require('../services/notionService');

async function runInnerLoopController(req, res) {
  try {
    loggerService.info('Inner loop execution requested via API');
    
    const result = await runInnerLoop();
    
    if (result.success) {
      loggerService.info('Inner loop completed successfully', { cycle: result.cycle });
      
      res.json({
        success: true,
        timestamp: new Date().toISOString(),
        cycle: result.cycle,
        stats: result.stats
      });
    } else {
      loggerService.warn('Inner loop execution failed', { error: result.error });
      
      res.status(500).json({
        success: false,
        timestamp: new Date().toISOString(),
        error: result.error
      });
    }
  } catch (error) {
    loggerService.error('runInnerLoopController error', error);
    
    res.status(500).json({
      success: false,
      timestamp: new Date().toISOString(),
      error: error.message
    });
  }
}

async function getStrategy(req, res) {
  try {
    loggerService.info('Strategy requested via API');
    
    const logs = await notionService.fetchRecentLogs(10);
    
    const logAnalysis = {
      patterns: ['Pattern 1', 'Pattern 2'],
      insights: 'Current insights',
      anomalyScore: 0.1
    };
    
    const strategy = await generateStrategy(logAnalysis);
    
    loggerService.info('Strategy retrieved', { strategy });
    
    res.json({
      success: true,
      timestamp: new Date().toISOString(),
      strategy
    });
  } catch (error) {
    loggerService.error('getStrategy error', error);
    
    res.status(500).json({
      success: false,
      timestamp: new Date().toISOString(),
      error: error.message
    });
  }
}

async function getTasksController(req, res) {
  try {
    loggerService.info('Tasks requested via API');
    
    const filter = {
      status: req.query.status,
      priority: req.query.priority
    };
    
    const tasks = getTasks(filter);
    
    loggerService.info('Tasks retrieved', { count: tasks.length, filter });
    
    res.json({
      success: true,
      timestamp: new Date().toISOString(),
      count: tasks.length,
      tasks
    });
  } catch (error) {
    loggerService.error('getTasks error', error);
    
    res.status(500).json({
      success: false,
      timestamp: new Date().toISOString(),
      error: error.message
    });
  }
}

async function getAnomalies(req, res) {
  try {
    loggerService.info('Anomalies requested via API');
    
    const logs = await notionService.fetchRecentLogs(10);
    
    const anomalyResult = detectAnomalies(logs);
    
    loggerService.info('Anomalies retrieved', { 
      count: anomalyResult.anomalies.length,
      score: anomalyResult.anomalyScore 
    });
    
    res.json({
      success: true,
      timestamp: new Date().toISOString(),
      anomalyScore: anomalyResult.anomalyScore,
      anomalies: anomalyResult.anomalies,
      summary: anomalyResult.summary
    });
  } catch (error) {
    loggerService.error('getAnomalies error', error);
    
    res.status(500).json({
      success: false,
      timestamp: new Date().toISOString(),
      error: error.message
    });
  }
}

async function getStatus(req, res) {
  try {
    loggerService.info('Status requested via API');
    
    const state = getState();
    
    res.json({
      success: true,
      timestamp: new Date().toISOString(),
      state
    });
  } catch (error) {
    loggerService.error('getStatus error', error);
    
    res.status(500).json({
      success: false,
      timestamp: new Date().toISOString(),
      error: error.message
    });
  }
}

module.exports = {
  runInnerLoopController,
  getStrategy,
  getTasks: getTasksController,
  getAnomalies,
  getStatus
};
