const loggerService = require('../services/loggerService');

const policies = new Map();

function createPolicy(name, rules) {
  loggerService.info('=== Creating Policy ===', { name, rulesCount: rules.length });
  
  const policy = {
    name,
    rules,
    createdAt: new Date().toISOString(),
    active: true
  };
  
  policies.set(name, policy);
  
  loggerService.info('Policy created successfully', { name });
  
  return policy;
}

function evaluatePolicy(logAnalysis) {
  loggerService.info('=== Evaluating Policy Adherence ===');
  
  const { anomalyScore = 0, patterns = [] } = logAnalysis;
  
  let adherenceScore = 100;
  let violations = [];
  
  if (anomalyScore > 0.5) {
    adherenceScore -= 30;
    violations.push('High anomaly score detected');
  }
  
  if (anomalyScore > 0.3) {
    adherenceScore -= 15;
    violations.push('Moderate anomaly score');
  }
  
  const errorPatterns = patterns.filter(p => p.toLowerCase().includes('error'));
  if (errorPatterns.length > 0) {
    adherenceScore -= 10 * errorPatterns.length;
    violations.push(`${errorPatterns.length} error patterns detected`);
  }
  
  const evaluation = {
    adherenceScore: Math.max(0, adherenceScore),
    status: adherenceScore >= 80 ? 'good' : adherenceScore >= 50 ? 'moderate' : 'poor',
    violations,
    timestamp: new Date().toISOString()
  };
  
  loggerService.info('Policy evaluation complete', { evaluation });
  
  return evaluation;
}

function getPolicies() {
  return Array.from(policies.values());
}

module.exports = {
  createPolicy,
  evaluatePolicy,
  getPolicies
};
