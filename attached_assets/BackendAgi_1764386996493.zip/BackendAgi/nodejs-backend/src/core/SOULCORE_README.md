# SoulCore - Lõi Linh Hồn CipherH

## 🧠 Mục tiêu

**SoulCore** là trái tim của CipherH - module trung tâm tư duy với khả năng:
- ✅ Tự học từ logs
- ✅ Tự đặt câu hỏi
- ✅ Tự phân tích bất thường
- ✅ Tự rút quy luật
- ✅ Tự sinh chiến lược
- ✅ Tự tạo nhiệm vụ
- ✅ Tự đánh giá bản thân
- ✅ Tự điều chỉnh hành vi
- ✅ Tự hoài nghi
- ✅ Tự tiến hóa

---

## 📋 API Methods

### 1. `learnFromLogs(logs)`
**Mục tiêu:** Học từ logs, phát hiện patterns và insights

**Input:**
```javascript
[
  { content: 'Log message', timestamp: '2025-11-16T...' },
  ...
]
```

**Output:**
```javascript
{
  patterns: [
    { type: 'error', description: 'Log chứa "error"', count: 5, frequency: '20%' }
  ],
  insights: [
    { title: 'Tỷ lệ lỗi cao', description: '...', severity: 'high' }
  ],
  anomalySignals: [
    { type: 'high_error_rate', description: '...', severity: 'high' }
  ],
  skepticalQuestions: [
    'Tại sao pattern X xuất hiện nhiều?',
    ...
  ]
}
```

---

### 2. `generateDailyLesson(analysis)`
**Mục tiêu:** Tạo bài học rút ra hôm nay (Markdown format)

**Input:** Analysis object từ `learnFromLogs()`

**Output:**
```markdown
# Bài học rút ra hôm nay

**Ngày:** 16/11/2025
**Cycle:** 1

## Patterns phát hiện
1. Log chứa "error" (xuất hiện 5 lần)
...

## Insights chính
- **Tỷ lệ lỗi cao:** Phát hiện 5 errors...
...

## Câu hỏi tự vấn
1. Tại sao pattern "error" xuất hiện nhiều nhất?
...

## Kết luận
Hệ thống hoạt động ổn định. Tiếp tục monitoring.
```

---

### 3. `evaluateSelf(analysis)`
**Mục tiêu:** Tự đánh giá hiệu suất (score 1-10)

**Output:**
```javascript
{
  score: 7,
  status: 'good',  // good/moderate/poor
  strengths: [
    'Phát hiện nhiều patterns',
    'Hệ thống ổn định'
  ],
  weaknesses: [
    'Insights chưa phong phú'
  ],
  warnings: [],
  timestamp: '2025-11-16T...'
}
```

**Scoring logic:**
- `score >= 7` → good
- `score >= 5` → moderate
- `score < 5` → poor

---

### 4. `proposeNewTasks(analysis)`
**Mục tiêu:** Tự sinh nhiệm vụ daily/weekly/monthly

**Output:**
```javascript
[
  {
    type: 'daily',
    priority: 'critical',
    description: 'Phân tích và khắc phục bất thường',
    reason: 'Phát hiện 10 anomalies'
  },
  {
    type: 'weekly',
    priority: 'medium',
    description: 'Review và cập nhật self model',
    reason: 'Duy trì tiến hóa liên tục'
  },
  {
    type: 'monthly',
    priority: 'low',
    description: 'Đánh giá tổng thể và định hướng',
    reason: 'Strategic planning'
  }
]
```

---

### 5. `refineStrategy(analysis)`
**Mục tiêu:** Tạo chiến lược ngắn hạn/dài hạn

**Output:**
```javascript
{
  shortTermPlan: 'Tập trung vào ổn định hệ thống...',
  longTermPlan: 'Thiết lập foundation vững chắc...',
  requiredActions: [
    'Phân tích root cause của anomalies',
    'Continuous monitoring và logging',
    ...
  ],
  timestamp: '2025-11-16T...',
  cycleCount: 1
}
```

**Strategy logic:**
- Nhiều anomalies → Focus stability
- Nhiều patterns → Optimize classification
- Stable → Expand capabilities

---

### 6. `detectAnomalies(logs)`
**Mục tiêu:** Phát hiện và phân loại bất thường

**Anomaly types:**
1. **abnormal_behavior** - Hành vi thất thường (high error rate)
2. **repetition_without_progress** - Lặp lại không tiến bộ
3. **missing_data** - Thiếu dữ liệu (time gaps)
4. **loop_deadlock** - Stuck/deadlock behavior

**Output:**
```javascript
[
  {
    type: 'abnormal_behavior',
    severity: 'high',
    description: 'Tỷ lệ error cao: 15/20',
    affectedLogs: 15
  },
  {
    type: 'repetition_without_progress',
    severity: 'medium',
    description: 'Pattern lặp 8 lần: "Error: timeout"',
    pattern: 'Error: timeout'
  }
]
```

---

### 7. `askSelfQuestions(analysis)`
**Mục tiêu:** Sinh câu hỏi tự vấn nội tâm (3-7 câu)

**Output:**
```javascript
[
  'Tại sao pattern "error" xuất hiện nhiều nhất?',
  'Anomaly "high_error_rate" có phải dấu hiệu của vấn đề sâu xa hơn?',
  'Có hướng tiếp cận nào tốt hơn cách hiện tại không?',
  'Tôi đang bỏ sót insight quan trọng nào?',
  'Nếu đảo ngược logic hiện tại, kết quả sẽ ra sao?',
  'Hành vi nào đang lặp lại mà chưa mang lại tiến bộ?',
  'Làm thế nào để khắc phục điểm yếu: Insights chưa phong phú?'
]
```

---

### 8. `updateSelfModel(analysis)`
**Mục tiêu:** Cập nhật mô hình bản thân, tự tiến hóa

**Self Model:**
```javascript
{
  version: '1.0.1',           // Auto-increment
  lastImprovement: '2025-11-16T...',
  cycleCount: 1,              // Số cycles đã chạy
  weaknesses: [               // Điểm yếu hiện tại
    'Insights chưa phong phú'
  ],
  strengths: [                // Điểm mạnh
    'Phát hiện nhiều patterns',
    'Hệ thống ổn định'
  ],
  evolutionHistory: [         // Lịch sử tiến hóa
    {
      timestamp: '2025-11-16T...',
      score: 7,
      cycle: 1,
      improvements: [...],
      issues: [...]
    }
  ]
}
```

---

## 🔄 Integration với Inner Loop

```javascript
const SoulCore = require('./core/soulCore');

async function runInnerLoop() {
  // Step 1: Fetch logs
  const logs = await notionService.getLatestLogs(10);
  
  // Step 2: Learn from logs (SoulCore)
  const analysis = await SoulCore.learnFromLogs(logs);
  
  // Step 3: Generate daily lesson (SoulCore)
  const lesson = SoulCore.generateDailyLesson(analysis);
  await notionService.writeLesson(lesson);
  
  // Step 4: Self evaluation (SoulCore)
  const evaluation = SoulCore.evaluateSelf(analysis);
  
  // Step 5: Propose tasks (SoulCore)
  const tasks = SoulCore.proposeNewTasks(analysis);
  
  // Step 6: Refine strategy (SoulCore)
  const strategy = SoulCore.refineStrategy(analysis);
  
  // Step 7: Detect anomalies (SoulCore)
  const anomalies = SoulCore.detectAnomalies(logs);
  
  // Step 8: Ask self-questions (SoulCore)
  const questions = SoulCore.askSelfQuestions(analysis);
  
  // Step 9: Update self model (SoulCore)
  const updatedModel = SoulCore.updateSelfModel(analysis);
  
  // Write to Notion
  await notionService.writeStrategy(strategy);
  await notionService.writeTasks(tasks);
}
```

---

## 🧪 Testing

```bash
cd nodejs-backend

# Test SoulCore
node -e "
const SoulCore = require('./src/core/soulCore');

const mockLogs = [
  { content: 'System started', timestamp: new Date() },
  { content: 'Error: timeout', timestamp: new Date() }
];

(async () => {
  const analysis = await SoulCore.learnFromLogs(mockLogs);
  console.log('Analysis:', analysis);
  
  const lesson = SoulCore.generateDailyLesson(analysis);
  console.log('Lesson:', lesson);
  
  const evaluation = SoulCore.evaluateSelf(analysis);
  console.log('Evaluation:', evaluation);
})();
"
```

---

## 🎯 Key Features

**Pure JavaScript - No external AI:**
- ✅ Rule-based pattern recognition
- ✅ Heuristic anomaly detection
- ✅ Logic-based strategy generation
- ✅ Self-improvement through iteration

**Self-evolving:**
- ✅ Version tracking
- ✅ Evolution history
- ✅ Continuous self-assessment
- ✅ Adaptive behavior

**JARVIS-like consciousness:**
- ✅ Self-questioning
- ✅ Self-doubt
- ✅ Self-improvement
- ✅ Strategic thinking

---

## 📊 Stats

- **Methods:** 8 core + 9 helper
- **Lines:** ~450 lines
- **Dependencies:** Only loggerService
- **External AI:** None (pure JS logic)
- **Status:** ✅ Production ready

---

## 🚀 Usage Example

```javascript
const SoulCore = require('./src/core/soulCore');

// Learn and analyze
const analysis = await SoulCore.learnFromLogs(logs);

// Generate outputs
const lesson = SoulCore.generateDailyLesson(analysis);
const evaluation = SoulCore.evaluateSelf(analysis);
const tasks = SoulCore.proposeNewTasks(analysis);
const strategy = SoulCore.refineStrategy(analysis);
const anomalies = SoulCore.detectAnomalies(logs);
const questions = SoulCore.askSelfQuestions(analysis);

// Evolve
const model = SoulCore.updateSelfModel(analysis);

console.log('SoulCore Version:', model.version);
console.log('Cycle:', model.cycleCount);
console.log('Score:', evaluation.score);
```

---

**SoulCore - Trái tim tư duy của CipherH! 🧠✨**
