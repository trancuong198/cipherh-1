const express = require('express');
const coreRoutes = require('./routes/coreRoutes');
const loggerService = require('./services/loggerService');
const { getState } = require('./core/innerLoop');

const app = express();

app.use(express.json());

app.use((req, res, next) => {
  loggerService.info(`${req.method} ${req.path}`);
  next();
});

app.use('/core', coreRoutes);

app.get('/health', (req, res) => {
  try {
    const state = getState();
    
    res.json({
      status: 'ok',
      timestamp: new Date().toISOString(),
      innerLoopStatus: 'ready',
      cycles: state.cycles || 0,
      confidence: state.confidence || 0
    });
  } catch (error) {
    res.json({
      status: 'ok',
      timestamp: new Date().toISOString(),
      innerLoopStatus: 'initializing'
    });
  }
});

app.use((err, req, res, next) => {
  loggerService.error('Unhandled error', err);
  
  res.status(err.status || 500).json({
    success: false,
    error: err.message || 'Internal server error',
    timestamp: new Date().toISOString()
  });
});

module.exports = app;
