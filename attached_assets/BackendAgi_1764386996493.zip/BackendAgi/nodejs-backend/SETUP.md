# CipherH Backend - Setup Guide

## 🚀 Quick Setup (3 bước)

### Bước 1: Install dependencies
```bash
cd nodejs-backend
npm install
```

### Bước 2: Configure environment
```bash
cp .env.example .env

# Edit .env:
# - Thay your_notion_api_key bằng Notion key thật (optional)
# - Thay your_openai_api_key bằng OpenAI key thật (optional)
# - Có thể chạy placeholder mode mà không cần API keys
```

### Bước 3: Start server
```bash
npm start           # Production mode
# hoặc
npm run dev         # Development mode (auto-reload)
```

**Server sẽ:**
- ✅ Start trên port 3000
- ✅ Chạy initial Inner Loop cycle ngay lập tức
- ✅ Schedule cron job mỗi 10 phút
- ✅ API sẵn sàng tại `http://localhost:3000`

---

## 📋 Environment Variables

**File: `.env`** (copy từ `.env.example`)

```bash
# === API Keys (Optional - placeholder mode nếu thiếu) ===
NOTION_KEY=your_notion_api_key
NOTION_DATABASE_ID=your_notion_database_id
OPENAI_KEY=your_openai_api_key

# === Server Config ===
PORT=3000

# === Scheduler (Cron format) ===
HEARTBEAT_CRON=*/10 * * * *    # Chạy mỗi 10 phút

# === OpenAI Settings ===
OPENAI_MODEL=gpt-4
OPENAI_TEMPERATURE=0.7
OPENAI_MAX_TOKENS=2000

# === Logging ===
LOG_LEVEL=info                 # debug/info/warn/error

# === Environment ===
NODE_ENV=development           # development/production
```

---

## 🧪 Testing

### Test server startup
```bash
npm start
# Should see:
# Server running on port 3000
# Running initial inner loop cycle...
# Initial cycle 1 completed
```

### Test API endpoints
```bash
# Health check
curl http://localhost:3000/health

# Status
curl http://localhost:3000/core/status

# Tasks
curl http://localhost:3000/core/tasks

# Strategy
curl http://localhost:3000/core/strategy

# Anomalies
curl http://localhost:3000/core/anomalies

# Run Inner Loop manually
curl http://localhost:3000/core/run-loop
```

---

## 📦 Dependencies

**Production:**
- `express` - Web framework
- `dotenv` - Environment variables
- `@notionhq/client` - Notion API client
- `node-cron` - Scheduler
- `winston` - Logger
- `axios` - HTTP client

**Development:**
- `nodemon` - Auto-reload on file changes

**Install:**
```bash
npm install              # All dependencies
npm install --production # Production only
```

---

## 🔄 Inner Loop Schedule

**Cron format examples:**
```bash
*/5 * * * *    # Every 5 minutes
*/10 * * * *   # Every 10 minutes (default)
*/30 * * * *   # Every 30 minutes
0 * * * *      # Every hour
0 0 * * *      # Daily at midnight
```

**Change schedule:**
1. Edit `.env`
2. Update `HEARTBEAT_CRON=*/5 * * * *`
3. Restart server

---

## 🛡️ Placeholder Mode

**Nếu thiếu API keys:**
- ✅ Server vẫn chạy bình thường
- ✅ Inner Loop vẫn execute
- ✅ Dùng mock data cho Notion/OpenAI
- ⚠️ Warnings trong logs

**Logs:**
```
[WARN] Notion credentials not configured - running in placeholder mode
[WARN] OpenAI API key not configured - running in placeholder mode
```

---

## 📊 Monitoring

### Log files
```bash
# View logs
tail -f logs/app.log

# Search logs
grep ERROR logs/app.log
grep "Inner loop" logs/app.log
```

### Console output
```
2025-11-16 16:10:00 [INFO] Server running on port 3000
2025-11-16 16:10:01 [INFO] Initial cycle 1 completed
2025-11-16 16:20:00 [INFO] Scheduled inner loop execution
2025-11-16 16:20:01 [INFO] Inner loop cycle 2 completed successfully
```

---

## 🚀 Production Deployment

### PM2 (Recommended)
```bash
# Install PM2
npm install -g pm2

# Start
pm2 start src/server.js --name cipherh-soul

# Monitor
pm2 logs cipherh-soul
pm2 monit

# Restart
pm2 restart cipherh-soul

# Auto-start on boot
pm2 startup
pm2 save
```

### Docker
```dockerfile
FROM node:20-alpine

WORKDIR /app

COPY package*.json ./
RUN npm install --production

COPY . .

EXPOSE 3000

CMD ["npm", "start"]
```

**Build & Run:**
```bash
docker build -t cipherh-soul .
docker run -d -p 3000:3000 --env-file .env cipherh-soul
```

### Systemd
```ini
[Unit]
Description=CipherH Soul Loop Backend
After=network.target

[Service]
Type=simple
User=node
WorkingDirectory=/path/to/nodejs-backend
ExecStart=/usr/bin/node src/server.js
Restart=always
EnvironmentFile=/path/to/nodejs-backend/.env

[Install]
WantedBy=multi-user.target
```

**Enable:**
```bash
sudo systemctl enable cipherh-soul
sudo systemctl start cipherh-soul
sudo systemctl status cipherh-soul
```

---

## 🔧 Troubleshooting

### Port already in use
```bash
# Find process
lsof -i :3000

# Kill process
kill -9 <PID>

# Or change port in .env
PORT=3001
```

### Dependencies not found
```bash
# Clean install
rm -rf node_modules package-lock.json
npm install
```

### Logs not showing
```bash
# Check logs directory exists
ls -la logs/

# Create if missing
mkdir -p logs
```

### Cron not running
```bash
# Check cron syntax
# Use https://crontab.guru/

# Test manual run
curl http://localhost:3000/core/run-loop
```

---

## 📚 Documentation

- `README.md` - Full documentation
- `API_ENDPOINTS.md` - API documentation
- `SERVICES.md` - Services documentation
- `DEPENDENCIES.md` - Dependencies documentation
- `START.md` - Quick start guide
- `SETUP.md` - This file

---

## ✅ Checklist

**Before first run:**
- [ ] `npm install` completed
- [ ] `.env` created từ `.env.example`
- [ ] API keys configured (optional)
- [ ] Port 3000 available

**Verify working:**
- [ ] Server starts without errors
- [ ] Health check returns OK
- [ ] Initial cycle completes
- [ ] API endpoints respond
- [ ] Logs writing to `logs/app.log`

---

## 🎯 Next Steps

1. **Enable Notion:**
   - Get API key from https://www.notion.so/my-integrations
   - Add to `.env`
   - Restart server

2. **Enable OpenAI:**
   - Get API key from https://platform.openai.com/api-keys
   - Add to `.env`
   - Restart server

3. **Customize:**
   - Adjust cron schedule
   - Modify strategy logic
   - Add custom endpoints
   - Implement database persistence
