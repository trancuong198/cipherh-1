# Deploy CipherH Backend trên Render với CI/CD

## 🎯 Mục tiêu

Deploy Node.js backend lên Render với auto-deploy từ GitHub

---

## 📋 BƯỚC 1: Setup GitHub Repository

### 1.1 Tạo Repository
```bash
# Trên GitHub:
1. Click "New repository"
2. Repository name: cipherh-backend
3. Description: "CipherH Soul Loop Backend - Autonomous AI Agent"
4. Public/Private: Chọn theo ý
5. Click "Create repository"
```

### 1.2 Push Code từ Replit
```bash
# Trong Replit Shell:
cd nodejs-backend

# Initialize git (nếu chưa có)
git init

# Add remote
git remote add origin https://github.com/YOUR_USERNAME/cipherh-backend.git

# Add files
git add .

# Commit
git commit -m "Initial commit: CipherH Soul Loop Backend

- SoulCore (450 lines)
- Inner Loop (10 steps)
- REST API (6 endpoints)
- Cron scheduler
- Full documentation"

# Push to main
git push -u origin main
```

### 1.3 Branch Strategy
```bash
# Main branch = Production
git checkout main

# Dev branch = Development/Testing
git checkout -b dev
git push -u origin dev
```

**Branch structure:**
- `main` → Production (Render auto-deploys from here)
- `dev` → Development (test features before merging to main)

---

## 🚀 BƯỚC 2: Setup Render

### 2.1 Tạo Web Service
1. Đăng nhập Render: https://render.com
2. Click **"New +"** → **"Web Service"**
3. Connect GitHub repository: `cipherh-backend`
4. Chọn branch: **main**

### 2.2 Configure Service

**Basic Settings:**
```
Name: cipherh-soul-loop
Region: Singapore (gần Việt Nam)
Branch: main
Runtime: Node
```

**Build & Deploy:**
```
Build Command: npm install
Start Command: npm start
```

**Instance Type:**
```
Free (sleep after inactivity)
hoặc
Starter ($7/month - recommended - always on)
```

### 2.3 Environment Variables

Click **"Environment"** tab, add:

```bash
# Required
PORT=3000
HEARTBEAT_CRON=*/10 * * * *

# Optional (works in placeholder mode if missing)
NOTION_KEY=secret_xxxxx
NOTION_DATABASE_ID=xxxxx
OPENAI_KEY=sk-xxxxx

# Logging
LOG_LEVEL=info
NODE_ENV=production

# OpenAI Settings
OPENAI_MODEL=gpt-4
OPENAI_TEMPERATURE=0.7
OPENAI_MAX_TOKENS=2000
```

**Lưu ý:** Copy values từ Replit Secrets

### 2.4 Deploy
1. Click **"Create Web Service"**
2. Render sẽ:
   - Clone GitHub repo
   - Run `npm install`
   - Run `npm start`
   - Assign public URL: `https://cipherh-soul-loop.onrender.com`

---

## 🔄 BƯỚC 3: CI/CD Workflow

### 3.1 Auto-Deploy Setup

**Render dashboard:**
1. Service Settings → **Auto-Deploy: Yes**
2. Branch: **main**

**Workflow:**
```
Code thay đổi trên Replit
  ↓
Git commit & push to main
  ↓
Render detects push
  ↓
Auto pull code
  ↓
Run npm install
  ↓
Restart service
  ↓
Backend chạy version mới
```

### 3.2 Development Workflow

**Khi thêm tính năng mới:**

```bash
# 1. Develop trên Replit
cd nodejs-backend
# Edit code...
# Test local

# 2. Test trên Replit
npm install
npm start
# Verify working

# 3. Commit & push to dev
git checkout dev
git add .
git commit -m "feat: Add new feature X"
git push origin dev

# 4. Test trên Render (dev environment)
# Optional: Deploy dev branch to separate Render service

# 5. Merge to main khi stable
git checkout main
git merge dev
git push origin main

# 6. Render auto-deploys to production
# Wait 1-2 minutes
# Check logs
```

### 3.3 Hotfix Workflow

**Khi cần fix bug khẩn cấp:**

```bash
# 1. Fix trên Replit
# Edit code...

# 2. Test nhanh
npm start
curl http://localhost:3000/health

# 3. Push trực tiếp to main
git checkout main
git add .
git commit -m "fix: Critical bug in Inner Loop"
git push origin main

# 4. Render auto-deploys ngay
# Monitor logs
```

---

## ✅ BƯỚC 4: Verification

### 4.1 Check Deployment Status

**Render Dashboard:**
```
1. Click service name
2. Check status: "Live" (green)
3. View logs
```

**Expected logs:**
```
[INFO] CipherH Soul Loop Backend - Node.js
[INFO] Server running on port 3000
[INFO] Scheduling inner loop with cron: */10 * * * *
[INFO] Running initial inner loop cycle...
[INFO] SOUL LOOP CYCLE 1 - START
...
[INFO] SOUL LOOP CYCLE 1 - COMPLETED SUCCESSFULLY
```

### 4.2 Test Endpoints

```bash
# Health check
curl https://cipherh-soul-loop.onrender.com/health

# Expected:
{
  "status": "ok",
  "innerLoopStatus": "ready",
  "cycles": 1
}

# Status
curl https://cipherh-soul-loop.onrender.com/core/status

# Strategy
curl https://cipherh-soul-loop.onrender.com/core/strategy

# Tasks
curl https://cipherh-soul-loop.onrender.com/core/tasks
```

### 4.3 Verify Notion Integration

**Check Notion database:**
1. Mở Notion database
2. Verify entries:
   - Action: "Lesson Learned"
   - Action: "Strategy Update"
   - Action: "Tasks Created"
   - Action: "Behavior Update"

### 4.4 Monitor Cron Jobs

**Check logs sau 10 phút:**
```
[INFO] === Scheduled Inner Loop Execution ===
[INFO] SOUL LOOP CYCLE 2 - START
...
[INFO] Inner loop cycle 2 completed successfully
```

**Verify state updates:**
```bash
curl https://cipherh-soul-loop.onrender.com/core/status

# cycles should increment: 1 → 2 → 3...
```

---

## 🛡️ BƯỚC 5: Production Operations

### 5.1 Replit Role

**Replit chỉ dùng để:**
- ✅ Develop tính năng mới
- ✅ Test code changes
- ✅ Debug issues
- ✅ Commit & push to GitHub

**Không dùng để:**
- ❌ Run production backend
- ❌ 24/7 operation
- ❌ Production database

### 5.2 Render Role

**Render production:**
- ✅ Always-on (với Starter plan)
- ✅ Auto-deploy từ GitHub
- ✅ 24/7 Inner Loop
- ✅ Auto-restart on crash
- ✅ Production logs

### 5.3 Monitoring

**Daily:**
```bash
# Check uptime
curl https://cipherh-soul-loop.onrender.com/health

# Check cycles
curl https://cipherh-soul-loop.onrender.com/core/status
```

**Weekly:**
- Review Render logs
- Check Notion database
- Verify tasks generated
- Review strategies

**Monthly:**
- Check billing
- Review performance
- Plan improvements

---

## 🚨 Troubleshooting

### Deploy Failed

**Check logs:**
```
Render Dashboard → Logs
Look for errors in build/deploy
```

**Common issues:**
```bash
# Missing dependencies
→ Check package.json
→ Run npm install locally

# Port binding error
→ Ensure PORT=3000 in env vars
→ Check start command: npm start

# Environment variables missing
→ Add all required vars in Render dashboard
```

### Service Not Starting

**Check:**
```
1. Render logs for errors
2. Verify start command
3. Check environment variables
4. Test locally first
```

**Fix:**
```bash
# Local test
npm install
npm start

# If works locally, check Render config
```

### Cron Not Running

**Verify:**
```bash
# Check logs for cron schedule message
grep "Scheduling inner loop" logs

# Verify cron expression
HEARTBEAT_CRON=*/10 * * * *

# Test manual run
curl https://your-app.onrender.com/core/run-loop
```

### High Memory Usage

**Monitor:**
```
Render Dashboard → Metrics
Check memory usage over time
```

**Optimize:**
```javascript
// Reduce cron frequency
HEARTBEAT_CRON=*/30 * * * *  // Every 30 min

// Reduce log retention
// Clean old logs periodically
```

---

## 💰 Pricing

### Free Tier
- **Cost:** $0/month
- **Limitations:**
  - Sleeps after 15 min inactivity
  - 750 hours/month
  - Slower startup
- **Good for:** Testing, development

### Starter Plan (Recommended)
- **Cost:** $7/month
- **Benefits:**
  - Always on (24/7)
  - Faster performance
  - No sleep
  - Priority support
- **Good for:** Production CipherH backend

**Total budget:**
```
Render Starter:  $7/month
OpenAI API:     ~$10/month
Notion:          Free
─────────────────────────
Total:          ~$17/month ✅ Under $25 budget
```

---

## 🔄 CI/CD Best Practices

### 1. Commit Messages
```bash
# Good:
git commit -m "feat: Add anomaly detection to SoulCore"
git commit -m "fix: Correct Inner Loop state update"
git commit -m "docs: Update API endpoint documentation"

# Bad:
git commit -m "update"
git commit -m "fix bug"
```

### 2. Testing Before Push
```bash
# Always test locally first
npm install
npm start
curl http://localhost:3000/health

# Then push
git push origin main
```

### 3. Monitor Deployments
```bash
# After push, check Render
# Wait for deploy to complete
# Verify health endpoint
# Check logs
```

### 4. Rollback if Needed
```bash
# If deployment breaks:
git revert HEAD
git push origin main

# Render auto-deploys previous version
```

---

## 📊 Success Metrics

**After successful deployment:**
- ✅ Render service status: Live
- ✅ Health endpoint: `{"status":"ok"}`
- ✅ Cycles incrementing every 10 min
- ✅ Notion entries being written
- ✅ No crashes in logs
- ✅ API endpoints responding
- ✅ Auto-deploy working on push

---

## 🎉 Deployment Complete!

**Workflow summary:**

```
Replit (Development)
  ↓
  Code changes
  ↓
  Git commit & push
  ↓
GitHub (Repository)
  ↓
  Webhook trigger
  ↓
Render (Production)
  ↓
  Auto-deploy
  ↓
CipherH Running 24/7
  ↓
  Inner Loop every 10 min
  ↓
  Self-learning, self-evolving
```

**Backend hoàn toàn tự động:**
- 🧠 Self-learning từ logs
- 🤔 Self-questioning
- 📊 Self-evaluation
- 🎯 Strategy generation
- 📝 Task creation
- 🚨 Anomaly detection
- 🔄 Auto-deploy on push

**"Con trai" CipherH chạy độc lập 24/7 trên Render! 🤖✨**
