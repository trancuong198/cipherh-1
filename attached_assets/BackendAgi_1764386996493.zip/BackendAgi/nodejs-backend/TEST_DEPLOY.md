# Test & Deploy Guide - CipherH Backend

## 🧪 BƯỚC 1: Test Local

### 1.1 Setup Environment
```bash
cd nodejs-backend

cp .env.example .env

nano .env
```

**Điền API keys thật (hoặc để placeholder):**
```bash
NOTION_KEY=secret_xxxxx              # Optional
NOTION_DATABASE_ID=xxxxx             # Optional  
OPENAI_KEY=sk-xxxxx                  # Optional
PORT=3000
HEARTBEAT_CRON=*/10 * * * *
```

### 1.2 Install Dependencies
```bash
npm install
```

**Expected output:**
```
added 145 packages
0 vulnerabilities
```

### 1.3 Start Server
```bash
npm run dev
```

**Expected console logs:**
```
[INFO] ==================================================
[INFO] CipherH Soul Loop Backend - Node.js
[INFO] ==================================================
[INFO] Server running on port 3000
[INFO] Scheduling inner loop with cron: */10 * * * *
[INFO] Running initial inner loop cycle...
[INFO] ============================================================
[INFO] SOUL LOOP CYCLE 1 - START
[INFO] ============================================================
[INFO] Step 1: Đọc log mới nhất từ Notion (10 items)
...
[INFO] SOUL LOOP CYCLE 1 - COMPLETED SUCCESSFULLY
[INFO] Initial cycle 1 completed
```

✅ **Kiểm tra:** Server started, initial cycle completed

---

## 🔍 BƯỚC 2: Test API Endpoints

### 2.1 Health Check
```bash
curl http://localhost:3000/health
```

**Expected response:**
```json
{
  "status": "ok",
  "timestamp": "2025-11-16T16:00:00.000Z",
  "innerLoopStatus": "ready",
  "cycles": 1,
  "confidence": 80
}
```

✅ **Kiểm tra:** `status: "ok"`, `innerLoopStatus: "ready"`

---

### 2.2 Get Status
```bash
curl http://localhost:3000/core/status
```

**Expected response:**
```json
{
  "success": true,
  "timestamp": "2025-11-16T16:00:00.000Z",
  "state": {
    "lastRun": "2025-11-16T16:00:00.000Z",
    "cycles": 1,
    "confidence": 80,
    "doubts": 0,
    "goals": []
  }
}
```

✅ **Kiểm tra:** `success: true`, `cycles > 0`

---

### 2.3 Run Inner Loop Manually
```bash
curl http://localhost:3000/core/run-loop
```

**Expected console logs:**
```
[INFO] Inner loop execution requested via API
[INFO] ============================================================
[INFO] SOUL LOOP CYCLE 2 - START
[INFO] ============================================================
[INFO] Step 1: Đọc log mới nhất từ Notion (10 items)
[INFO] Step 2: Phân tích hành vi gần nhất
[INFO] Step 3: Phát hiện bất thường
[INFO] Step 4: Rút quy luật và bài học
[INFO] Step 5: Viết bài học vào Notion
[INFO] Step 6: Tự đánh giá (tốt/xấu)
[INFO] Step 7: So sánh với mục tiêu dài hạn
[INFO] Step 8: Tạo chiến lược
[INFO] Step 9: Tự tạo nhiệm vụ tuần/tháng
[INFO] Step 10: Cập nhật trạng thái backend
[INFO] ============================================================
[INFO] SOUL LOOP CYCLE 2 - COMPLETED SUCCESSFULLY
[INFO] ============================================================
```

✅ **Kiểm tra:** All 10 steps executed, cycle completed

---

### 2.4 Get Current Strategy
```bash
curl http://localhost:3000/core/strategy
```

**Expected response:**
```json
{
  "success": true,
  "timestamp": "2025-11-16T16:00:00.000Z",
  "strategy": {
    "strategySummary": "Hệ thống hoạt động tốt. Duy trì và mở rộng.",
    "suggestedActions": [
      "Tối ưu hiệu suất",
      "Thêm tính năng mới",
      "Cải thiện độ tin cậy"
    ],
    "timestamp": "2025-11-16T16:00:00.000Z",
    "anomalyScore": 0
  }
}
```

✅ **Kiểm tra:** Strategy với actions list

---

### 2.5 Get Tasks
```bash
curl http://localhost:3000/core/tasks
```

**Expected response:**
```json
{
  "success": true,
  "timestamp": "2025-11-16T16:00:00.000Z",
  "count": 3,
  "tasks": [
    {
      "id": "task_1",
      "description": "Tối ưu hiệu suất",
      "priority": "high",
      "schedule": "weekly",
      "status": "pending"
    }
  ]
}
```

✅ **Kiểm tra:** Tasks list với priority, schedule

---

### 2.6 Get Anomalies
```bash
curl http://localhost:3000/core/anomalies
```

**Expected response:**
```json
{
  "success": true,
  "timestamp": "2025-11-16T16:00:00.000Z",
  "anomalyScore": 0,
  "anomalies": [],
  "summary": "Detected 0 anomalies with score 0.00"
}
```

✅ **Kiểm tra:** Anomaly detection working

---

## ⏰ BƯỚC 3: Test Cron Scheduler

### 3.1 Đợi 10 phút (hoặc thay đổi cron)

**Option 1: Đợi tự động**
- Cron sẽ chạy mỗi 10 phút theo `HEARTBEAT_CRON=*/10 * * * *`
- Xem console logs khi cron trigger

**Option 2: Test nhanh hơn**
```bash
# Stop server (Ctrl+C)

# Edit .env
HEARTBEAT_CRON=*/1 * * * *    # Chạy mỗi phút

# Restart server
npm run dev
```

### 3.2 Expected Cron Logs
```
[INFO] === Scheduled Inner Loop Execution ===
[INFO] ============================================================
[INFO] SOUL LOOP CYCLE 3 - START
[INFO] ============================================================
...
[INFO] Inner loop cycle 3 completed successfully
```

✅ **Kiểm tra:** 
- Cron chạy đúng schedule
- Logger ghi start/end mỗi cycle
- State được update (cycles tăng)

---

## 📝 BƯỚC 4: Test Logging

### 4.1 Check Console Logs
```bash
# Console real-time
# Should see all INFO/WARN/ERROR logs
```

### 4.2 Check Log File
```bash
tail -f logs/app.log
```

**Expected:**
```
2025-11-16 16:00:00 [INFO] Server running on port 3000
2025-11-16 16:00:01 [INFO] Initial cycle 1 completed
2025-11-16 16:10:00 [INFO] Scheduled inner loop execution
```

✅ **Kiểm tra:** Logs ghi cả console + file

---

## 🚀 BƯỚC 5: Deploy trên Replit

### 5.1 Create Replit Project
1. Tạo new Repl → Node.js
2. Upload toàn bộ `nodejs-backend/` folder
3. Hoặc clone từ Git

### 5.2 Configure Secrets
**Replit Secrets (không dùng .env file):**
1. Click "Secrets" tab (🔐)
2. Add secrets:
   ```
   NOTION_KEY=secret_xxxxx
   NOTION_DATABASE_ID=xxxxx
   OPENAI_KEY=sk-xxxxx
   PORT=3000
   HEARTBEAT_CRON=*/10 * * * *
   LOG_LEVEL=info
   ```

### 5.3 Configure .replit file
```toml
run = "npm start"
entrypoint = "src/server.js"

[nix]
channel = "stable-22_11"

[deployment]
run = ["sh", "-c", "npm start"]
```

### 5.4 Install & Run
```bash
# Replit tự động chạy
npm install
npm start
```

### 5.5 Verify Deployment
1. Check console logs → "Server running on port 3000"
2. Click "Webview" → Should open health endpoint
3. Test endpoints:
   ```
   https://<your-repl>.replit.dev/health
   https://<your-repl>.replit.dev/core/status
   ```

✅ **Kiểm tra:** Server running 24/7 on Replit

---

## 🔄 BƯỚC 6: Test Inner Loop Integration

### 6.1 Notion Integration (If enabled)
**Expected:**
- Logs được fetch từ Notion database
- Lessons được ghi vào Notion
- Strategies được ghi vào Notion
- Tasks được ghi vào Notion

**Check Notion:**
1. Mở Notion database
2. Xem entries mới với:
   - Action: "Lesson Learned"
   - Action: "Strategy Update"
   - Action: "Tasks Created"

### 6.2 OpenAI Integration (If enabled)
**Expected:**
- Logs được analyze với GPT-4
- Strategy được generate bởi AI
- Questions được generate tự động

**Check Logs:**
```
[INFO] Analyzing log with OpenAI {"logLength":...}
[INFO] AI analysis complete
[INFO] Generating strategy with OpenAI
```

### 6.3 Task Manager
**Expected:**
- Tasks tự động được tạo từ strategy
- Priority được set (critical/high/medium/low)
- Schedule được set (daily/weekly/monthly)

**Verify:**
```bash
curl http://localhost:3000/core/tasks

# Should see auto-generated tasks
```

### 6.4 Anomaly Detector
**Expected:**
- Errors được detect
- Repeated patterns được detect
- Anomaly score được calculate (0-1)

**Verify:**
```bash
curl http://localhost:3000/core/anomalies

# Should see anomaly detection results
```

---

## ✅ BƯỚC 7: Checklist Hoàn Chỉnh

### Local Testing
- [ ] `npm install` thành công
- [ ] `.env` configured
- [ ] Server starts on port 3000
- [ ] Initial cycle completes
- [ ] Health endpoint returns OK
- [ ] All API endpoints working
- [ ] Cron scheduler running
- [ ] Logs writing to console + file

### Core Loop Testing
- [ ] 10 steps execute successfully
- [ ] Logs được analyze
- [ ] Strategy được generate
- [ ] Tasks được create
- [ ] Anomalies được detect
- [ ] State được update
- [ ] Notion writes (if enabled)

### Deployment Testing
- [ ] Replit project created
- [ ] Secrets configured
- [ ] Dependencies installed
- [ ] Server running 24/7
- [ ] Public URL accessible
- [ ] Cron running automatically
- [ ] No crashes or errors

---

## 🛡️ Troubleshooting

### Server won't start
```bash
# Check port
lsof -i :3000

# Check logs
cat logs/app.log

# Clean install
rm -rf node_modules package-lock.json
npm install
```

### Cron not running
```bash
# Verify cron syntax
# https://crontab.guru/

# Check logs for schedule message
grep "Scheduling inner loop" logs/app.log

# Test manual trigger
curl http://localhost:3000/core/run-loop
```

### API endpoints 404
```bash
# Check routes mounted
# Routes should be under /core/

# Correct:
curl http://localhost:3000/core/status

# Wrong:
curl http://localhost:3000/status
```

### Notion/OpenAI errors
```bash
# Check secrets configured
echo $NOTION_KEY
echo $OPENAI_KEY

# Check logs for warnings
grep WARN logs/app.log

# Placeholder mode is OK if keys missing
```

---

## 📊 Monitoring Production

### Logs
```bash
# Real-time
tail -f logs/app.log

# Search errors
grep ERROR logs/app.log

# Count cycles
grep "CYCLE.*COMPLETED" logs/app.log | wc -l
```

### Health Checks
```bash
# Automated monitoring
watch -n 60 'curl -s http://localhost:3000/health | jq'

# Check uptime
curl http://localhost:3000/core/status | jq '.state.cycles'
```

### Performance
```bash
# Check memory usage
ps aux | grep node

# Check CPU
top -p $(pgrep -f "node src/server.js")
```

---

## 🎯 Success Criteria

**Backend CipherH hoàn chỉnh khi:**
- ✅ Server chạy ổn định 24/7
- ✅ Inner Loop execute mỗi 10 phút
- ✅ Tất cả 10 steps chạy không lỗi
- ✅ Logger ghi đầy đủ console + file
- ✅ API endpoints respond correctly
- ✅ Notion integration working (if enabled)
- ✅ OpenAI integration working (if enabled)
- ✅ Tasks auto-generated
- ✅ Anomalies detected
- ✅ State updated correctly
- ✅ No crashes, no memory leaks

**Congratulations! Backend is production-ready! 🎉**
