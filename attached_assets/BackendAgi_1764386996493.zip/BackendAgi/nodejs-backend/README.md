# CipherH Soul Loop - Node.js Backend

Autonomous AI backend với khả năng tự học, tự phản tư, tự đề xuất chiến lược.

## 📁 Cấu trúc

```
nodejs-backend/
  /src
    /config
      logger.js           # Winston logger config
      notion.js           # Notion API config
      openai.js           # OpenAI config
    
    /core
      innerLoop.js        # Vòng lặp chính 10 bước
      strategy.js         # Sinh chiến lược
      policy.js           # Tạo và đánh giá policy
      taskManager.js      # Quản lý tasks tự động
      anomalyDetector.js  # Phát hiện bất thường
    
    /services
      loggerService.js    # Logging service
      notionService.js    # Notion integration
      openAIService.js    # OpenAI integration
    
    /controllers
      coreController.js   # API controller
    
    /routes
      coreRoutes.js       # API routes
    
    app.js                # Express app
    server.js             # Server + scheduler
  
  /logs                   # Log files
  .env.example            # Environment template
  .env                    # Environment variables (create from .env.example)
  package.json
  
  API_ENDPOINTS.md        # API documentation
  SERVICES.md             # Services documentation
  START.md                # Quick start guide
  README.md               # This file
```

## 🚀 Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Configure environment
cp .env.example .env
# Edit .env với API keys (optional - works in placeholder mode without)

# 3. Start server
npm start
```

**Server sẽ:**
- Start trên port 3000
- Chạy initial Inner Loop cycle ngay lập tức
- Schedule cron job chạy mỗi 10 phút (configurable)

## 🔄 Inner Loop (10 bước)

Mỗi cycle:

1. **Đọc logs** từ Notion (10 items)
2. **Phân tích** với OpenAI
3. **Phát hiện bất thường** (anomaly detection)
4. **Rút bài học** từ analysis
5. **Viết bài học** vào Notion
6. **Tự đánh giá** (good/moderate/poor)
7. **So sánh** với mục tiêu dài hạn
8. **Sinh chiến lược** mới
9. **Tự tạo tasks** tuần/tháng
10. **Cập nhật state** và ghi Notion

## 📡 API Endpoints

```bash
# Health check
GET /health

# Core endpoints
GET /core/status        # Get Inner Loop status
GET /core/run-loop      # Trigger Inner Loop manually
GET /core/strategy      # Get current strategy
GET /core/tasks         # Get task list
GET /core/anomalies     # Get detected anomalies
```

**Examples:**
```bash
curl http://localhost:3000/health
curl http://localhost:3000/core/status
curl http://localhost:3000/core/run-loop
```

## ⚙️ Configuration

**Environment Variables** (`.env`):
```bash
PORT=3000
NODE_ENV=development

# Optional - placeholder mode if missing
NOTION_KEY=secret_xxxxx
NOTION_DATABASE_ID=xxxxx
OPENAI_KEY=sk-xxxxx

# OpenAI settings
OPENAI_MODEL=gpt-4
OPENAI_TEMPERATURE=0.7
OPENAI_MAX_TOKENS=2000

# Logging
LOG_LEVEL=info

# Scheduler (cron format)
HEARTBEAT_CRON=*/10 * * * *    # Every 10 minutes
```

**Cron Schedule Examples:**
- `*/5 * * * *` - Every 5 minutes
- `*/10 * * * *` - Every 10 minutes (default)
- `*/30 * * * *` - Every 30 minutes
- `0 * * * *` - Every hour

## 🧠 Core Modules

### Strategy.js
- Sinh chiến lược dựa trên anomaly score
- Đề xuất actions cụ thể
- Priority levels: critical/high/medium/low

### Policy.js
- Tạo policies với rules
- Đánh giá adherence score
- Track violations

### TaskManager.js
- Auto-generate tasks từ strategy
- Priority: critical/high/medium/low
- Schedule: daily/weekly/monthly

### AnomalyDetector.js
- Detect error patterns
- Find repeated patterns
- Calculate anomaly score (0-1)

## 📊 Services

### loggerService
- Winston-based logging
- Console + file output (`logs/app.log`)
- Format: `YYYY-MM-DD HH:mm:ss [LEVEL] message`

### notionService
- Fetch/write logs từ Notion
- Write lessons, strategies, tasks
- **Placeholder mode** if credentials missing

### openAIService
- Analyze logs với OpenAI
- Generate strategies
- **Placeholder mode** if API key missing

## 🛡️ Security

- ✅ API keys từ environment variables
- ✅ Không hardcode secrets
- ✅ Placeholder mode nếu thiếu config
- ✅ Graceful degradation
- ✅ Full error handling

## 📝 Logs

```
logs/app.log            # All logs
Console                 # Real-time colored output
```

**Log format:**
```
2025-11-16 16:10:00 [INFO] Inner loop cycle 1 completed
2025-11-16 16:10:01 [WARN] Notion credentials not configured
2025-11-16 16:10:02 [ERROR] Failed to fetch logs: Connection timeout
```

## 🔮 Enabling Real Integrations

### Notion:
1. Get API key: https://www.notion.so/my-integrations
2. Get Database ID from Notion URL
3. Add to `.env`:
   ```
   NOTION_KEY=secret_xxxxx
   NOTION_DATABASE_ID=xxxxx
   ```
4. Restart server

### OpenAI:
1. Get API key: https://platform.openai.com/api-keys
2. Add to `.env`:
   ```
   OPENAI_KEY=sk-xxxxx
   ```
3. Restart server

## 🚀 Production Deployment

### PM2
```bash
pm2 start src/server.js --name cipherh-soul
pm2 logs cipherh-soul
pm2 restart cipherh-soul
```

### Docker
```bash
docker build -t cipherh-soul .
docker run -d -p 3000:3000 --env-file .env cipherh-soul
```

### Systemd
```ini
[Unit]
Description=CipherH Soul Loop Backend
After=network.target

[Service]
Type=simple
User=node
WorkingDirectory=/path/to/nodejs-backend
ExecStart=/usr/bin/node src/server.js
Restart=always
Environment="NODE_ENV=production"

[Install]
WantedBy=multi-user.target
```

## ✅ Status

**Total lines:** 1,159

- ✅ Express server with API
- ✅ Winston logger
- ✅ Inner loop 10 steps
- ✅ Strategy generator
- ✅ Policy evaluator
- ✅ Task manager
- ✅ Anomaly detector
- ✅ Notion service (placeholders)
- ✅ OpenAI service (placeholders)
- ✅ Scheduled execution (cron)
- ✅ Manual trigger API
- ✅ Health check endpoint
- ✅ Error handling
- ✅ Security best practices

## 📚 Documentation

- `API_ENDPOINTS.md` - API documentation với curl examples
- `SERVICES.md` - Services documentation
- `START.md` - Quick start guide
- `README.md` - This file

## 🎯 Next Steps

1. Add real Notion API key → enable real Notion integration
2. Add real OpenAI API key → enable AI analysis
3. Setup database persistence for state
4. Add more sophisticated anomaly detection
5. Implement frontend dashboard
