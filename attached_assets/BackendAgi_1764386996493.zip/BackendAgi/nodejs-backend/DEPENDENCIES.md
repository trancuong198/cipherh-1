# Dependencies Documentation

## 📦 Production Dependencies

### express (^4.18.2)
**Dùng ở:** `src/app.js`, `src/routes/coreRoutes.js`
**Chức năng:** Web framework cho API endpoints
**Modules:**
- `app.js` - Express app initialization
- `routes/coreRoutes.js` - API routing

---

### dotenv (^16.3.1)
**Dùng ở:** `src/server.js`
**Chức năng:** Load environment variables từ `.env` file
**Usage:**
```javascript
require('dotenv').config();
const apiKey = process.env.NOTION_KEY;
```

---

### @notionhq/client (^2.2.15)
**Dùng ở:** `src/services/notionService.js`
**Chức năng:** Official Notion API client
**Usage:**
```javascript
// Placeholder hiện tại
// Khi enable: uncomment real API calls
const { Client } = require('@notionhq/client');
const notion = new Client({ auth: process.env.NOTION_KEY });
```

---

### node-cron (^3.0.3)
**Dùng ở:** `src/server.js`
**Chức năng:** Schedule Inner Loop execution
**Usage:**
```javascript
cron.schedule('*/10 * * * *', async () => {
  await runInnerLoop();
});
```

---

### winston (^3.11.0)
**Dùng ở:** `src/config/logger.js`, `src/services/loggerService.js`
**Chức năng:** Advanced logging library
**Features:**
- Multiple transports (console + file)
- Log levels (info, warn, error, debug)
- Formatted output
- File rotation

---

### axios (^1.6.2)
**Dùng ở:** `src/services/openAIService.js`, `src/services/notionService.js`
**Chức năng:** HTTP client cho API calls
**Usage:**
```javascript
// For OpenAI API calls (when enabled)
// For Notion API calls (when enabled)
const response = await axios.post(url, data, config);
```

---

## 🛠️ Development Dependencies

### nodemon (^3.0.2)
**Dùng ở:** `npm run dev` script
**Chức năng:** Auto-restart server on file changes
**Usage:**
```bash
npm run dev  # Start with auto-reload
```

---

## 📝 Scripts

### `npm start`
```bash
node src/server.js
```
**Production mode** - Start server without auto-reload

### `npm run dev`
```bash
nodemon src/server.js
```
**Development mode** - Auto-reload on file changes

---

## 🔧 Installation

```bash
# Install all dependencies
npm install

# Install production only
npm install --production

# Update dependencies
npm update
```

---

## 📊 Dependency Tree

```
cipherh-backend
├── express          → API server
│   └── Used by: app.js, routes/
├── dotenv           → Environment variables
│   └── Used by: server.js
├── @notionhq/client → Notion API
│   └── Used by: services/notionService.js
├── node-cron        → Scheduler
│   └── Used by: server.js
├── winston          → Logger
│   └── Used by: config/logger.js, services/loggerService.js
└── axios            → HTTP client
    └── Used by: services/openAIService.js, services/notionService.js
```

---

## ⚙️ Environment Variables

Required in `.env`:
```bash
NOTION_KEY=secret_xxxxx              # Notion API key
NOTION_DATABASE_ID=xxxxx             # Notion database ID
OPENAI_KEY=sk-xxxxx                  # OpenAI API key
PORT=3000                            # Server port
HEARTBEAT_CRON=*/10 * * * *          # Cron schedule
LOG_LEVEL=info                       # Log level
```

---

## 🔮 Future Dependencies (Optional)

### When enabling real integrations:

**OpenAI SDK:**
```bash
npm install openai
```

**Database (if needed):**
```bash
npm install mongoose  # MongoDB
npm install pg        # PostgreSQL
```

**Testing:**
```bash
npm install --save-dev jest supertest
```
