"""
Logging Template - Học từ CipherH AI gốc
Style: Structured logging, log levels, context information
"""

import logging
import sys
from typing import Dict, Any, Optional
from datetime import datetime
import json
import traceback

class StructuredFormatter(logging.Formatter):
    """Custom formatter for structured JSON logs"""
    
    def format(self, record: logging.LogRecord) -> str:
        log_data = {
            'timestamp': datetime.fromtimestamp(record.created).isoformat(),
            'level': record.levelname,
            'logger': record.name,
            'message': record.getMessage(),
            'module': record.module,
            'function': record.funcName,
            'line': record.lineno
        }
        
        if hasattr(record, 'extra_data'):
            log_data['extra'] = getattr(record, 'extra_data')
        
        if record.exc_info and record.exc_info[0]:
            log_data['exception'] = {
                'type': record.exc_info[0].__name__,
                'message': str(record.exc_info[1]),
                'traceback': traceback.format_exception(*record.exc_info)
            }
        
        return json.dumps(log_data, ensure_ascii=False)

class ColoredFormatter(logging.Formatter):
    """Colored console output formatter"""
    
    COLORS = {
        'DEBUG': '\033[36m',
        'INFO': '\033[32m',
        'WARNING': '\033[33m',
        'ERROR': '\033[31m',
        'CRITICAL': '\033[35m',
        'RESET': '\033[0m'
    }
    
    def format(self, record: logging.LogRecord) -> str:
        color = self.COLORS.get(record.levelname, self.COLORS['RESET'])
        reset = self.COLORS['RESET']
        
        record.levelname = f"{color}{record.levelname}{reset}"
        
        return super().format(record)

def setup_logger(
    name: str,
    level: int = logging.INFO,
    log_file: Optional[str] = None,
    use_json: bool = False,
    use_colors: bool = True
) -> logging.Logger:
    """
    Setup logger với custom configuration
    
    Args:
        name: Logger name
        level: Log level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        log_file: Optional file path for file logging
        use_json: Use JSON structured logging
        use_colors: Use colored console output
    
    Returns:
        Configured logger instance
    """
    logger = logging.getLogger(name)
    logger.setLevel(level)
    logger.handlers = []
    
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(level)
    
    if use_json:
        console_formatter = StructuredFormatter()
    elif use_colors:
        console_formatter = ColoredFormatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
    else:
        console_formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
    
    console_handler.setFormatter(console_formatter)
    logger.addHandler(console_handler)
    
    if log_file:
        file_handler = logging.FileHandler(log_file, encoding='utf-8')
        file_handler.setLevel(level)
        
        if use_json:
            file_formatter = StructuredFormatter()
        else:
            file_formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
        
        file_handler.setFormatter(file_formatter)
        logger.addHandler(file_handler)
    
    return logger

class LogContext:
    """Context manager for logging with extra data"""
    
    def __init__(self, logger: logging.Logger, **context):
        self.logger = logger
        self.context = context
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type:
            self.logger.error(
                f"Exception in context: {exc_val}",
                extra={'extra_data': self.context},
                exc_info=(exc_type, exc_val, exc_tb)
            )
        
        return False
    
    def info(self, message: str, **extra):
        """Log info with context"""
        combined = {**self.context, **extra}
        self.logger.info(message, extra={'extra_data': combined})
    
    def warning(self, message: str, **extra):
        """Log warning with context"""
        combined = {**self.context, **extra}
        self.logger.warning(message, extra={'extra_data': combined})
    
    def error(self, message: str, **extra):
        """Log error with context"""
        combined = {**self.context, **extra}
        self.logger.error(message, extra={'extra_data': combined})

def log_function_execution(logger: logging.Logger):
    """
    Decorator to log function execution
    
    Usage:
        logger = setup_logger('myapp')
        
        @log_function_execution(logger)
        def my_function(arg1, arg2):
            ...
    """
    def decorator(func):
        def wrapper(*args, **kwargs):
            logger.info(
                f"Executing {func.__name__}",
                extra={
                    'extra_data': {
                        'function': func.__name__,
                        'args_count': len(args),
                        'kwargs_keys': list(kwargs.keys())
                    }
                }
            )
            
            try:
                result = func(*args, **kwargs)
                
                logger.info(
                    f"{func.__name__} completed successfully",
                    extra={'extra_data': {'function': func.__name__}}
                )
                
                return result
            
            except Exception as e:
                logger.error(
                    f"{func.__name__} failed: {str(e)}",
                    extra={
                        'extra_data': {
                            'function': func.__name__,
                            'error_type': type(e).__name__
                        }
                    },
                    exc_info=True
                )
                raise
        
        return wrapper
    
    return decorator

class PerformanceLogger:
    """Log performance metrics"""
    
    def __init__(self, logger: logging.Logger, operation_name: str):
        self.logger = logger
        self.operation_name = operation_name
        self.start_time: Optional[float] = None
    
    def __enter__(self):
        import time
        self.start_time = time.time()
        
        self.logger.debug(
            f"Starting: {self.operation_name}",
            extra={'extra_data': {'operation': self.operation_name}}
        )
        
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        import time
        if self.start_time is None:
            return False
        
        duration = time.time() - self.start_time
        
        log_data = {
            'operation': self.operation_name,
            'duration_seconds': round(duration, 3),
            'success': exc_type is None
        }
        
        if exc_type:
            log_data['error'] = str(exc_val)
        
        self.logger.info(
            f"Completed: {self.operation_name} in {duration:.3f}s",
            extra={'extra_data': log_data}
        )
        
        return False
