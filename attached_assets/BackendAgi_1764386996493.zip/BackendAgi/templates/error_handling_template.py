"""
Error Handling Template - Học từ CipherH AI gốc
Style: Custom exceptions, error logging, graceful degradation
"""

import logging
from typing import Dict, Any, Optional, Callable
from functools import wraps
import traceback

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class CipherHException(Exception):
    """Base exception cho tất cả CipherH errors"""
    
    def __init__(self, message: str, code: Optional[str] = None, details: Optional[Dict[str, Any]] = None):
        self.message = message
        self.code = code or "GENERAL_ERROR"
        self.details = details or {}
        super().__init__(self.message)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "error": self.message,
            "code": self.code,
            "details": self.details
        }

class ValidationError(CipherHException):
    """Validation error"""
    
    def __init__(self, message: str, field: Optional[str] = None):
        super().__init__(
            message=message,
            code="VALIDATION_ERROR",
            details={"field": field} if field else {}
        )

class DatabaseError(CipherHException):
    """Database operation error"""
    
    def __init__(self, message: str, operation: Optional[str] = None):
        super().__init__(
            message=message,
            code="DATABASE_ERROR",
            details={"operation": operation} if operation else {}
        )

class APIError(CipherHException):
    """External API error"""
    
    def __init__(self, message: str, api_name: Optional[str] = None, status_code: Optional[int] = None):
        super().__init__(
            message=message,
            code="API_ERROR",
            details={
                "api_name": api_name,
                "status_code": status_code
            }
        )

class AuthenticationError(CipherHException):
    """Authentication error"""
    
    def __init__(self, message: str = "Authentication failed"):
        super().__init__(
            message=message,
            code="AUTH_ERROR"
        )

def handle_errors(fallback_value: Any = None, log_error: bool = True):
    """
    Decorator để handle errors gracefully
    
    Args:
        fallback_value: Value to return on error
        log_error: Whether to log the error
    
    Usage:
        @handle_errors(fallback_value={})
        def risky_function():
            ...
    """
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            
            except CipherHException as e:
                if log_error:
                    logger.error(f"{func.__name__} failed: {e.message}", extra=e.details)
                return fallback_value
            
            except Exception as e:
                if log_error:
                    logger.error(f"{func.__name__} failed: {str(e)}", exc_info=True)
                return fallback_value
        
        return wrapper
    
    return decorator

def safe_execute(
    func: Callable,
    fallback: Any = None,
    on_error: Optional[Callable[[Exception], None]] = None
) -> Any:
    """
    Execute function safely with error handling
    
    Args:
        func: Function to execute
        fallback: Fallback value on error
        on_error: Callback function on error
    
    Returns:
        Function result or fallback
    """
    try:
        return func()
    
    except Exception as e:
        logger.error(f"safe_execute failed: {str(e)}")
        
        if on_error:
            try:
                on_error(e)
            except Exception:
                pass
        
        return fallback

def validate_input(data: Dict[str, Any], required_fields: list, validators: Optional[Dict[str, Callable]] = None) -> None:
    """
    Validate input data
    
    Args:
        data: Input data dict
        required_fields: List of required field names
        validators: Dict of field_name -> validator_function
    
    Raises:
        ValidationError: If validation fails
    """
    if not isinstance(data, dict):
        raise ValidationError("Input must be dictionary")
    
    for field in required_fields:
        if field not in data:
            raise ValidationError(f"{field} is required", field=field)
        
        if data[field] is None or data[field] == "":
            raise ValidationError(f"{field} cannot be empty", field=field)
    
    if validators:
        for field, validator in validators.items():
            if field in data:
                try:
                    if not validator(data[field]):
                        raise ValidationError(f"{field} validation failed", field=field)
                
                except Exception as e:
                    raise ValidationError(f"{field} validation error: {str(e)}", field=field)

def log_function_call(func: Callable) -> Callable:
    """
    Decorator to log function calls
    
    Usage:
        @log_function_call
        def my_function(arg1, arg2):
            ...
    """
    @wraps(func)
    def wrapper(*args, **kwargs):
        logger.info(f"Calling {func.__name__} with args={args}, kwargs={kwargs}")
        
        try:
            result = func(*args, **kwargs)
            logger.info(f"{func.__name__} completed successfully")
            return result
        
        except Exception as e:
            logger.error(f"{func.__name__} failed: {str(e)}")
            raise
    
    return wrapper

class ErrorContext:
    """Context manager for error handling"""
    
    def __init__(self, operation_name: str, raise_error: bool = False):
        self.operation_name = operation_name
        self.raise_error = raise_error
    
    def __enter__(self):
        logger.info(f"Starting operation: {self.operation_name}")
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type:
            logger.error(
                f"Operation '{self.operation_name}' failed: {exc_val}",
                exc_info=(exc_type, exc_val, exc_tb)
            )
            
            if not self.raise_error:
                return True
        else:
            logger.info(f"Operation '{self.operation_name}' completed successfully")
        
        return False
