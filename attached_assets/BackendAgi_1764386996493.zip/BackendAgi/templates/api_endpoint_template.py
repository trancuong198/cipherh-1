"""
API Endpoint Template - Học từ CipherH AI gốc
Style: Flask Blueprint, error handling, input validation, docstring
"""

from flask import Blueprint, request, jsonify
from typing import Dict, Any, Optional
import json

template_bp = Blueprint('template', __name__)

@template_bp.route('/api/template/example', methods=['POST'])
def example_endpoint():
    """
    Template endpoint với full validation và error handling
    
    Request body:
    {
        "field1": "required_string",
        "field2": "optional_string"
    }
    
    Response:
    {
        "success": true,
        "data": {...},
        "message": "..."
    }
    """
    try:
        data = request.json
        
        if not data:
            return jsonify({"error": "Request body required"}), 400
        
        if 'field1' not in data:
            return jsonify({"error": "field1 is required"}), 400
        
        field1 = data['field1']
        field2 = data.get('field2', 'default_value')
        
        result = process_data(field1, field2)
        
        return jsonify({
            "success": True,
            "data": result,
            "message": "Processed successfully"
        })
    
    except ValueError as e:
        return jsonify({"error": f"Validation error: {str(e)}"}), 400
    
    except Exception as e:
        return jsonify({"error": f"Server error: {str(e)}"}), 500

def process_data(field1: str, field2: str) -> Dict[str, Any]:
    """
    Business logic function - tách riêng khỏi endpoint
    
    Args:
        field1: Required input
        field2: Optional input
    
    Returns:
        Dict với processed data
    
    Raises:
        ValueError: Nếu validation fail
    """
    if not isinstance(field1, str) or len(field1) == 0:
        raise ValueError("field1 must be non-empty string")
    
    return {
        "processed_field1": field1.upper(),
        "processed_field2": field2.lower(),
        "status": "completed"
    }

@template_bp.route('/api/template/list', methods=['GET'])
def list_items():
    """
    GET endpoint với query parameters
    
    Query params:
    - limit: int (default 10)
    - offset: int (default 0)
    - filter: str (optional)
    """
    try:
        limit = request.args.get('limit', 10, type=int)
        offset = request.args.get('offset', 0, type=int)
        filter_str = request.args.get('filter', '', type=str)
        
        if limit < 1 or limit > 100:
            return jsonify({"error": "limit must be between 1 and 100"}), 400
        
        if offset < 0:
            return jsonify({"error": "offset must be >= 0"}), 400
        
        items = fetch_items(limit, offset, filter_str)
        
        return jsonify({
            "success": True,
            "data": items,
            "count": len(items),
            "limit": limit,
            "offset": offset
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

def fetch_items(limit: int, offset: int, filter_str: str) -> list:
    """Mock data fetcher - thay bằng DB query thực tế"""
    all_items = [{"id": i, "name": f"Item {i}"} for i in range(100)]
    
    if filter_str:
        all_items = [item for item in all_items if filter_str.lower() in item['name'].lower()]
    
    return all_items[offset:offset+limit]
