"""
Authentication Template - Học từ CipherH AI gốc
Style: Session-based auth, password hashing, decorator protection
"""

from flask import session, request, jsonify
from functools import wraps
from typing import Callable, Optional, Dict, Any
import hashlib
import secrets
import os

def hash_password(password: str, salt: Optional[str] = None) -> tuple[str, str]:
    """
    Hash password with salt
    
    Args:
        password: Plain text password
        salt: Optional salt (generated if not provided)
    
    Returns:
        Tuple of (hashed_password, salt)
    """
    if salt is None:
        salt = secrets.token_hex(16)
    
    hashed = hashlib.pbkdf2_hmac(
        'sha256',
        password.encode('utf-8'),
        salt.encode('utf-8'),
        100000
    )
    
    return hashed.hex(), salt

def verify_password(password: str, hashed: str, salt: str) -> bool:
    """
    Verify password against hash
    
    Args:
        password: Plain text password to verify
        hashed: Stored password hash
        salt: Salt used for hashing
    
    Returns:
        True if password matches
    """
    new_hash, _ = hash_password(password, salt)
    return new_hash == hashed

def require_auth(func: Callable) -> Callable:
    """
    Decorator để require authentication
    
    Usage:
        @app.route('/api/protected')
        @require_auth
        def protected_endpoint():
            ...
    """
    @wraps(func)
    def wrapper(*args, **kwargs):
        if 'authenticated' not in session or not session['authenticated']:
            return jsonify({"error": "Authentication required"}), 401
        
        return func(*args, **kwargs)
    
    return wrapper

def require_admin(func: Callable) -> Callable:
    """
    Decorator để require admin privileges
    
    Usage:
        @app.route('/api/admin/action')
        @require_admin
        def admin_endpoint():
            ...
    """
    @wraps(func)
    def wrapper(*args, **kwargs):
        if 'authenticated' not in session or not session['authenticated']:
            return jsonify({"error": "Authentication required"}), 401
        
        if 'role' not in session or session['role'] != 'admin':
            return jsonify({"error": "Admin privileges required"}), 403
        
        return func(*args, **kwargs)
    
    return wrapper

def login_user(username: str, password: str, stored_hash: str, stored_salt: str) -> bool:
    """
    Login user và set session
    
    Args:
        username: Username
        password: Plain text password
        stored_hash: Stored password hash from database
        stored_salt: Stored salt from database
    
    Returns:
        True if login successful
    """
    if not verify_password(password, stored_hash, stored_salt):
        return False
    
    session['authenticated'] = True
    session['username'] = username
    session.permanent = True
    
    return True

def logout_user() -> None:
    """Logout user và clear session"""
    session.clear()

def get_current_user() -> Optional[Dict[str, Any]]:
    """
    Get current authenticated user from session
    
    Returns:
        User dict or None
    """
    if 'authenticated' in session and session['authenticated']:
        return {
            'username': session.get('username'),
            'role': session.get('role', 'user')
        }
    
    return None

def generate_api_key(user_id: str) -> str:
    """
    Generate API key for user
    
    Args:
        user_id: User identifier
    
    Returns:
        API key string
    """
    random_part = secrets.token_urlsafe(32)
    return f"ck_{user_id}_{random_part}"

def verify_api_key(api_key: str) -> Optional[str]:
    """
    Verify API key và return user_id
    
    Args:
        api_key: API key to verify
    
    Returns:
        user_id if valid, None otherwise
    """
    if not api_key or not api_key.startswith('ck_'):
        return None
    
    try:
        parts = api_key.split('_')
        if len(parts) >= 3:
            user_id = parts[1]
            return user_id
    
    except Exception:
        pass
    
    return None

def require_api_key(func: Callable) -> Callable:
    """
    Decorator để require API key authentication
    
    Usage:
        @app.route('/api/data')
        @require_api_key
        def api_endpoint():
            ...
    """
    @wraps(func)
    def wrapper(*args, **kwargs):
        api_key = request.headers.get('X-API-Key')
        
        if not api_key:
            return jsonify({"error": "API key required"}), 401
        
        user_id = verify_api_key(api_key)
        
        if not user_id:
            return jsonify({"error": "Invalid API key"}), 401
        
        kwargs['user_id'] = user_id
        
        return func(*args, **kwargs)
    
    return wrapper

class RateLimiter:
    """Simple in-memory rate limiter"""
    
    def __init__(self, max_requests: int = 100, time_window: int = 60):
        self.max_requests = max_requests
        self.time_window = time_window
        self.requests = {}
    
    def is_allowed(self, identifier: str) -> bool:
        """
        Check if request is allowed
        
        Args:
            identifier: User/IP identifier
        
        Returns:
            True if allowed
        """
        import time
        
        now = time.time()
        
        if identifier not in self.requests:
            self.requests[identifier] = []
        
        self.requests[identifier] = [
            ts for ts in self.requests[identifier]
            if now - ts < self.time_window
        ]
        
        if len(self.requests[identifier]) >= self.max_requests:
            return False
        
        self.requests[identifier].append(now)
        return True

def rate_limit(max_requests: int = 100, time_window: int = 60):
    """
    Decorator for rate limiting
    
    Args:
        max_requests: Maximum requests allowed
        time_window: Time window in seconds
    """
    limiter = RateLimiter(max_requests, time_window)
    
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs):
            identifier = request.remote_addr or 'unknown'
            
            if not limiter.is_allowed(identifier):
                return jsonify({"error": "Rate limit exceeded"}), 429
            
            return func(*args, **kwargs)
        
        return wrapper
    
    return decorator
