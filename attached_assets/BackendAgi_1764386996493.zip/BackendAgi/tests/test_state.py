#!/usr/bin/env python3
"""
Test SoulState module
"""

import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

print("Testing SoulState...")

# Test 1: Import
try:
    from core.soul_state import SoulState, SoulMode
    print("✓ Import successful")
except Exception as e:
    print(f"✗ Import failed: {e}")
    exit(1)

# Test 2: Create object
try:
    state = SoulState()
    print("✓ Object created")
except Exception as e:
    print(f"✗ Object creation failed: {e}")
    exit(1)

# Test 3: Basic functions
try:
    state.update_goals(['Test goal 1', 'Test goal 2'])
    print("✓ update_goals() works")
except Exception as e:
    print(f"✗ update_goals() failed: {e}")
    exit(1)

try:
    state.inject_doubt()
    print("✓ inject_doubt() works")
except Exception as e:
    print(f"✗ inject_doubt() failed: {e}")
    exit(1)

try:
    reflection = state.reflect()
    print(f"✓ reflect() works: {reflection[:50]}...")
except Exception as e:
    print(f"✗ reflect() failed: {e}")
    exit(1)

try:
    score = state.score_self()
    print(f"✓ score_self() works: score={score['overall_score']}")
except Exception as e:
    print(f"✗ score_self() failed: {e}")
    exit(1)

try:
    export = state.export_state()
    print(f"✓ export_state() works: {len(export)} keys")
except Exception as e:
    print(f"✗ export_state() failed: {e}")
    exit(1)

print("\n✅ All SoulState tests passed!")
