# Soul Loop Tests

Simple test scripts để debug trên Replit.

## 📝 Test Files

- `test_state.py` - Test SoulState module
- `test_analyzer.py` - Test LogAnalyzer module
- `test_strategist.py` - Test Strategist module
- `test_loop.py` - Test SoulLoop module
- `run_all_tests.py` - Run tất cả tests

## 🚀 Chạy Tests

```bash
# Run all tests
python tests/run_all_tests.py

# Run individual test
python tests/test_state.py
python tests/test_analyzer.py
python tests/test_strategist.py
python tests/test_loop.py
```

## ✅ Test Coverage

Mỗi test check:
1. ✓ Import module thành công
2. ✓ Tạo object không crash
3. ✓ Chạy functions không crash

Không dùng pytest framework phức tạp - chỉ pure Python scripts.

## 📊 Test Results

```
Testing SoulState...
✓ Import successful
✓ Object created
✓ update_goals() works
✓ inject_doubt() works
✓ reflect() works
✓ score_self() works
✓ export_state() works
✅ All SoulState tests passed!

Testing LogAnalyzer...
✓ Import successful
✓ Object created
✓ read_logs() works
✓ detect_patterns() works
✓ detect_anomalies() works
✓ summarize_day() works
✓ extract_questions() works
✓ return_analysis() works
✅ All LogAnalyzer tests passed!

Testing Strategist...
✓ Import successful
✓ Object created
✓ propose_weekly_tasks() works
✓ propose_monthly_plan() works
✓ align_with_goals() works
✓ generate_strategy_prompt() works
✓ integrate_openai_response() works
✅ All Strategist tests passed!

Testing SoulLoop...
✓ Import successful
✓ Object created
✓ get_status() works
✓ run() works: cycle 1 completed
✓ State updated
✅ All SoulLoop tests passed!

Total: 4 tests
Passed: 4
Failed: 0
```
