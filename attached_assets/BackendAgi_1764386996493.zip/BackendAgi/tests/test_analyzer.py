#!/usr/bin/env python3
"""
Test LogAnalyzer module
"""

import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

print("Testing LogAnalyzer...")

# Test 1: Import
try:
    from core.analyzer import LogAnalyzer
    print("✓ Import successful")
except Exception as e:
    print(f"✗ Import failed: {e}")
    exit(1)

# Test 2: Create object
try:
    analyzer = LogAnalyzer()
    print("✓ Object created")
except Exception as e:
    print(f"✗ Object creation failed: {e}")
    exit(1)

# Test 3: Basic functions
try:
    logs = analyzer.read_logs()
    print(f"✓ read_logs() works: {len(logs)} lines")
except Exception as e:
    print(f"✗ read_logs() failed: {e}")
    exit(1)

try:
    patterns = analyzer.detect_patterns()
    print(f"✓ detect_patterns() works: trend={patterns['trend']}")
except Exception as e:
    print(f"✗ detect_patterns() failed: {e}")
    exit(1)

try:
    anomalies, score = analyzer.detect_anomalies()
    print(f"✓ detect_anomalies() works: score={score}")
except Exception as e:
    print(f"✗ detect_anomalies() failed: {e}")
    exit(1)

try:
    summary = analyzer.summarize_day()
    print(f"✓ summarize_day() works: {len(summary)} chars")
except Exception as e:
    print(f"✗ summarize_day() failed: {e}")
    exit(1)

try:
    questions = analyzer.extract_questions()
    print(f"✓ extract_questions() works: {len(questions)} questions")
except Exception as e:
    print(f"✗ extract_questions() failed: {e}")
    exit(1)

try:
    analysis = analyzer.return_analysis()
    print(f"✓ return_analysis() works: {len(analysis)} keys")
except Exception as e:
    print(f"✗ return_analysis() failed: {e}")
    exit(1)

print("\n✅ All LogAnalyzer tests passed!")
