#!/usr/bin/env python3
"""
Test Strategist module
"""

import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

print("Testing Strategist...")

# Test 1: Import
try:
    from core.strategist import Strategist
    print("✓ Import successful")
except Exception as e:
    print(f"✗ Import failed: {e}")
    exit(1)

# Test 2: Create object
try:
    strategist = Strategist()
    print("✓ Object created")
except Exception as e:
    print(f"✗ Object creation failed: {e}")
    exit(1)

# Test 3: Mock data
mock_state = {
    'doubts': 30,
    'confidence': 75,
    'goals_long_term': ['Test goal'],
    'current_focus': 'Test goal',
    'reflection': 'Test reflection',
    'lessons_learned': [],
    'last_actions': []
}

mock_analysis = {
    'anomaly_score': 20,
    'pattern_summary': {'trend': 'stable'},
    'suggested_questions': ['Test question?'],
    'day_summary': 'Test summary'
}

# Test 4: Basic functions
try:
    tasks = strategist.propose_weekly_tasks(mock_state, mock_analysis)
    print(f"✓ propose_weekly_tasks() works: {len(tasks)} tasks")
except Exception as e:
    print(f"✗ propose_weekly_tasks() failed: {e}")
    exit(1)

try:
    plan = strategist.propose_monthly_plan(mock_state)
    print(f"✓ propose_monthly_plan() works: {len(plan)} keys")
except Exception as e:
    print(f"✗ propose_monthly_plan() failed: {e}")
    exit(1)

try:
    alignment = strategist.align_with_goals(mock_state)
    print(f"✓ align_with_goals() works: score={alignment['alignment_score']}")
except Exception as e:
    print(f"✗ align_with_goals() failed: {e}")
    exit(1)

try:
    prompt = strategist.generate_strategy_prompt(mock_state, mock_analysis)
    print(f"✓ generate_strategy_prompt() works: {len(prompt)} chars")
except Exception as e:
    print(f"✗ generate_strategy_prompt() failed: {e}")
    exit(1)

try:
    mock_response = {
        'weekly_actions': ['Action 1', 'Action 2'],
        'goal_adjustments': ['Adjust X'],
        'assessment': 'Test assessment'
    }
    integration = strategist.integrate_openai_response(mock_response)
    print(f"✓ integrate_openai_response() works: {len(integration['actions_integrated'])} actions")
except Exception as e:
    print(f"✗ integrate_openai_response() failed: {e}")
    exit(1)

print("\n✅ All Strategist tests passed!")
