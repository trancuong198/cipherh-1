import os
import json
from typing import Dict, Any, List, Optional
from datetime import datetime
import time

class TaskExecutor:
    def __init__(self):
        self.task_chain_dir = 'task_chain'
        self.execution_log_file = os.path.join(self.task_chain_dir, 'execution_log.json')
        
        os.makedirs(self.task_chain_dir, exist_ok=True)
        
        self._init_execution_log()
    
    def _init_execution_log(self):
        if not os.path.exists(self.execution_log_file):
            with open(self.execution_log_file, 'w') as f:
                json.dump({
                    "executions": [],
                    "total_executions": 0,
                    "successful_executions": 0,
                    "failed_executions": 0
                }, f, indent=2)
    
    def execute_task(self, task_id: str) -> Dict[str, Any]:
        queue_file = 'task_chain/task_queue.json'
        
        if not os.path.exists(queue_file):
            return {"error": "Task queue not found"}
        
        with open(queue_file, 'r') as f:
            queue_data = json.load(f)
        
        if task_id not in queue_data['tasks']:
            return {"error": "Task not found"}
        
        task = queue_data['tasks'][task_id]
        
        execution = {
            "id": f"exec_{self._get_next_exec_id()}",
            "task_id": task_id,
            "start_time": datetime.now().isoformat(),
            "end_time": None,
            "status": "running",
            "result": None,
            "error": None,
            "execution_time_ms": 0
        }
        
        start_time = time.time()
        
        try:
            task['status'] = 'running'
            task['start_time'] = datetime.now().isoformat()
            
            with open(queue_file, 'w') as f:
                json.dump(queue_data, f, indent=2)
            
            result = self._execute_action(task)
            
            end_time = time.time()
            execution_time = (end_time - start_time) * 1000
            
            execution['end_time'] = datetime.now().isoformat()
            execution['status'] = 'completed'
            execution['result'] = result
            execution['execution_time_ms'] = execution_time
            
            task['status'] = 'completed'
            task['end_time'] = datetime.now().isoformat()
            task['outcome'] = 'success'
            
            with open(queue_file, 'w') as f:
                json.dump(queue_data, f, indent=2)
            
            self._log_execution(execution, success=True)
            
            return {
                "success": True,
                "task_id": task_id,
                "execution": execution,
                "result": result
            }
        
        except Exception as e:
            end_time = time.time()
            execution_time = (end_time - start_time) * 1000
            
            execution['end_time'] = datetime.now().isoformat()
            execution['status'] = 'failed'
            execution['error'] = str(e)
            execution['execution_time_ms'] = execution_time
            
            task['status'] = 'failed'
            task['end_time'] = datetime.now().isoformat()
            task['outcome'] = f'error: {str(e)}'
            
            with open(queue_file, 'w') as f:
                json.dump(queue_data, f, indent=2)
            
            self._log_execution(execution, success=False)
            
            return {
                "success": False,
                "task_id": task_id,
                "execution": execution,
                "error": str(e)
            }
    
    def _execute_action(self, task: Dict[str, Any]) -> Dict[str, Any]:
        action = task.get('action', '')
        module = task.get('module_origin', '')
        
        result = {
            "action": action,
            "module": module,
            "executed_at": datetime.now().isoformat(),
            "simulated": True
        }
        
        if "refactor" in action.lower():
            result['changes'] = ["code_optimized", "logic_improved"]
        
        elif "scan" in action.lower():
            result['threats_found'] = 0
            result['scan_complete'] = True
        
        elif "memory" in action.lower():
            result['memories_processed'] = 10
        
        elif "social" in action.lower():
            result['messages_sent'] = 1
        
        elif "evolution" in action.lower():
            result['modules_evolved'] = 1
        
        return result
    
    def _log_execution(self, execution: Dict[str, Any], success: bool):
        with open(self.execution_log_file, 'r') as f:
            log_data = json.load(f)
        
        log_data['executions'].append(execution)
        log_data['total_executions'] += 1
        
        if success:
            log_data['successful_executions'] += 1
        else:
            log_data['failed_executions'] += 1
        
        if len(log_data['executions']) > 200:
            log_data['executions'] = log_data['executions'][-200:]
        
        with open(self.execution_log_file, 'w') as f:
            json.dump(log_data, f, indent=2)
    
    def _get_next_exec_id(self) -> int:
        with open(self.execution_log_file, 'r') as f:
            log_data = json.load(f)
        return log_data['total_executions'] + 1
    
    def get_execution_stats(self) -> Dict[str, Any]:
        with open(self.execution_log_file, 'r') as f:
            log_data = json.load(f)
        
        total = log_data['total_executions']
        success_rate = (log_data['successful_executions'] / total * 100) if total > 0 else 0
        
        return {
            "total_executions": total,
            "successful_executions": log_data['successful_executions'],
            "failed_executions": log_data['failed_executions'],
            "success_rate": round(success_rate, 2)
        }
