import os
import json
from typing import Dict, Any, List, Optional
from datetime import datetime
import heapq

class TaskScheduler:
    def __init__(self):
        self.task_chain_dir = 'task_chain'
        self.queue_file = os.path.join(self.task_chain_dir, 'task_queue.json')
        
        os.makedirs(self.task_chain_dir, exist_ok=True)
        
        self._init_queue()
    
    def _init_queue(self):
        if not os.path.exists(self.queue_file):
            with open(self.queue_file, 'w') as f:
                json.dump({
                    "tasks": {},
                    "total_tasks": 0,
                    "pending_tasks": 0,
                    "running_tasks": 0,
                    "completed_tasks": 0
                }, f, indent=2)
    
    def create_task(self, module_name: str, action: str, priority: int, dependencies: Optional[List[str]] = None) -> Dict[str, Any]:
        with open(self.queue_file, 'r') as f:
            queue_data = json.load(f)
        
        task_id = f"task_{queue_data['total_tasks'] + 1}"
        
        task = {
            "id": task_id,
            "module_origin": module_name,
            "action": action,
            "priority": priority,
            "status": "pending",
            "dependencies": dependencies or [],
            "resources_needed": self._estimate_resources(action),
            "timestamp": datetime.now().isoformat(),
            "start_time": None,
            "end_time": None,
            "outcome": None
        }
        
        queue_data['tasks'][task_id] = task
        queue_data['total_tasks'] += 1
        queue_data['pending_tasks'] += 1
        
        with open(self.queue_file, 'w') as f:
            json.dump(queue_data, f, indent=2)
        
        return task
    
    def _estimate_resources(self, action: str) -> List[str]:
        resources = ["cpu"]
        
        if "memory" in action.lower() or "ltm" in action.lower():
            resources.append("memory_engine")
        
        if "evolution" in action.lower() or "refactor" in action.lower():
            resources.append("evolution_engine")
        
        if "social" in action.lower() or "message" in action.lower():
            resources.append("social_interface")
        
        if "security" in action.lower() or "scan" in action.lower():
            resources.append("security_engine")
        
        return resources
    
    def prioritize_tasks(self) -> List[Dict[str, Any]]:
        with open(self.queue_file, 'r') as f:
            queue_data = json.load(f)
        
        pending_tasks = [
            task for task in queue_data['tasks'].values()
            if task['status'] == 'pending'
        ]
        
        emotion_state = self._get_emotion_state()
        stress = emotion_state.get('stress_level', 0)
        
        for task in pending_tasks:
            urgency_score = task['priority']
            
            if task['module_origin'] in ['security', 'defense']:
                urgency_score += 20
            
            if stress > 70 and task['module_origin'] == 'emotional_model':
                urgency_score += 15
            
            if self._has_unmet_dependencies(task, queue_data['tasks']):
                urgency_score -= 50
            
            task['_urgency_score'] = urgency_score
        
        prioritized = sorted(pending_tasks, key=lambda t: t.get('_urgency_score', 0), reverse=True)
        
        return prioritized
    
    def _has_unmet_dependencies(self, task: Dict[str, Any], all_tasks: Dict[str, Any]) -> bool:
        for dep_id in task.get('dependencies', []):
            if dep_id in all_tasks:
                if all_tasks[dep_id]['status'] != 'completed':
                    return True
        return False
    
    def _get_emotion_state(self) -> Dict[str, Any]:
        emotions_file = 'emotions/state.json'
        
        if not os.path.exists(emotions_file):
            return {}
        
        try:
            with open(emotions_file, 'r') as f:
                return json.load(f)
        except Exception:
            return {}
    
    def get_task(self, task_id: str) -> Optional[Dict[str, Any]]:
        with open(self.queue_file, 'r') as f:
            queue_data = json.load(f)
        
        return queue_data['tasks'].get(task_id)
    
    def update_task_status(self, task_id: str, status: str, outcome: Optional[str] = None) -> Dict[str, Any]:
        with open(self.queue_file, 'r') as f:
            queue_data = json.load(f)
        
        if task_id not in queue_data['tasks']:
            return {"error": "Task not found"}
        
        task = queue_data['tasks'][task_id]
        old_status = task['status']
        
        task['status'] = status
        
        if status == 'running' and old_status == 'pending':
            task['start_time'] = datetime.now().isoformat()
            queue_data['pending_tasks'] -= 1
            queue_data['running_tasks'] += 1
        
        elif status == 'completed' and old_status == 'running':
            task['end_time'] = datetime.now().isoformat()
            task['outcome'] = outcome
            queue_data['running_tasks'] -= 1
            queue_data['completed_tasks'] += 1
        
        elif status == 'failed' and old_status == 'running':
            task['end_time'] = datetime.now().isoformat()
            task['outcome'] = outcome
            queue_data['running_tasks'] -= 1
        
        with open(self.queue_file, 'w') as f:
            json.dump(queue_data, f, indent=2)
        
        return task
    
    def get_queue_stats(self) -> Dict[str, Any]:
        with open(self.queue_file, 'r') as f:
            queue_data = json.load(f)
        
        return {
            "total_tasks": queue_data['total_tasks'],
            "pending_tasks": queue_data['pending_tasks'],
            "running_tasks": queue_data['running_tasks'],
            "completed_tasks": queue_data['completed_tasks']
        }
