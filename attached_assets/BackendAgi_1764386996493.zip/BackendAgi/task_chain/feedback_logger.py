import os
import json
from typing import Dict, Any, List, Optional
from datetime import datetime

class FeedbackLogger:
    def __init__(self):
        self.task_chain_dir = 'task_chain'
        self.feedback_file = os.path.join(self.task_chain_dir, 'task_feedback.json')
        
        os.makedirs(self.task_chain_dir, exist_ok=True)
        
        self._init_feedback()
    
    def _init_feedback(self):
        if not os.path.exists(self.feedback_file):
            with open(self.feedback_file, 'w') as f:
                json.dump({
                    "feedback_entries": [],
                    "total_feedback": 0
                }, f, indent=2)
    
    def feedback_to_memory(self, task_id: str, outcome: str) -> Dict[str, Any]:
        feedback = {
            "id": f"feedback_{self._get_next_id()}",
            "task_id": task_id,
            "outcome": outcome,
            "timestamp": datetime.now().isoformat(),
            "stored_to": []
        }
        
        task = self._get_task(task_id)
        
        if task:
            if self._store_to_stm(task, outcome):
                feedback['stored_to'].append("memory_engine_stm")
            
            if self._store_to_ltm(task, outcome):
                feedback['stored_to'].append("ltm_map")
            
            if self._store_to_metacognition(task, outcome):
                feedback['stored_to'].append("metacognition")
        
        with open(self.feedback_file, 'r') as f:
            feedback_data = json.load(f)
        
        feedback_data['feedback_entries'].append(feedback)
        feedback_data['total_feedback'] += 1
        
        if len(feedback_data['feedback_entries']) > 100:
            feedback_data['feedback_entries'] = feedback_data['feedback_entries'][-100:]
        
        with open(self.feedback_file, 'w') as f:
            json.dump(feedback_data, f, indent=2)
        
        return feedback
    
    def _get_task(self, task_id: str) -> Optional[Dict[str, Any]]:
        queue_file = 'task_chain/task_queue.json'
        
        if not os.path.exists(queue_file):
            return None
        
        try:
            with open(queue_file, 'r') as f:
                queue_data = json.load(f)
            return queue_data['tasks'].get(task_id)
        except Exception:
            return None
    
    def _store_to_stm(self, task: Dict[str, Any], outcome: str) -> bool:
        stm_file = 'memory/stm.json'
        
        if not os.path.exists(stm_file):
            return False
        
        try:
            with open(stm_file, 'r') as f:
                stm = json.load(f)
            
            stm['memories'].append({
                "timestamp": datetime.now().isoformat(),
                "type": "task_execution",
                "content": f"Task {task['id']} from {task['module_origin']}: {task['action']} - {outcome}",
                "importance": 60 if outcome == 'success' else 75
            })
            
            if len(stm['memories']) > 100:
                stm['memories'] = stm['memories'][-100:]
            
            with open(stm_file, 'w') as f:
                json.dump(stm, f, indent=2)
            
            return True
        except Exception:
            return False
    
    def _store_to_ltm(self, task: Dict[str, Any], outcome: str) -> bool:
        ltm_file = 'long_term/events.json'
        
        if not os.path.exists(ltm_file):
            return False
        
        try:
            with open(ltm_file, 'r') as f:
                ltm = json.load(f)
            
            ltm['events'].append({
                "timestamp": datetime.now().isoformat(),
                "type": "task_completion",
                "task_id": task['id'],
                "module": task['module_origin'],
                "action": task['action'],
                "outcome": outcome,
                "importance": 70
            })
            
            if len(ltm['events']) > 100:
                ltm['events'] = ltm['events'][-100:]
            
            with open(ltm_file, 'w') as f:
                json.dump(ltm, f, indent=2)
            
            return True
        except Exception:
            return False
    
    def _store_to_metacognition(self, task: Dict[str, Any], outcome: str) -> bool:
        metacog_file = 'metacognition/self_analysis.json'
        
        if not os.path.exists(metacog_file):
            return False
        
        try:
            with open(metacog_file, 'r') as f:
                metacog = json.load(f)
            
            if outcome == 'success':
                success_pattern = {
                    "timestamp": datetime.now().isoformat(),
                    "module": task['module_origin'],
                    "action": task['action'],
                    "success": True
                }
                
                if 'pattern_learning' not in metacog:
                    metacog['pattern_learning'] = []
                
                metacog['pattern_learning'].append(success_pattern)
                
                if len(metacog['pattern_learning']) > 50:
                    metacog['pattern_learning'] = metacog['pattern_learning'][-50:]
            
            with open(metacog_file, 'w') as f:
                json.dump(metacog, f, indent=2)
            
            return True
        except Exception:
            return False
    
    def _get_next_id(self) -> int:
        with open(self.feedback_file, 'r') as f:
            feedback_data = json.load(f)
        return feedback_data['total_feedback'] + 1
    
    def get_feedback_stats(self) -> Dict[str, Any]:
        with open(self.feedback_file, 'r') as f:
            feedback_data = json.load(f)
        
        return {
            "total_feedback": feedback_data['total_feedback'],
            "recent_entries": len(feedback_data['feedback_entries'])
        }
