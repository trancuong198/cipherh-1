import os
import json
from typing import Dict, Any, List, Optional
from datetime import datetime

class EvolutionFeedback:
    def __init__(self):
        self.metacog2_dir = 'metacognition2'
        self.feedback_file = os.path.join(self.metacog2_dir, 'evolution_feedback.json')
        
        os.makedirs(self.metacog2_dir, exist_ok=True)
        
        self._init_feedback()
    
    def _init_feedback(self):
        if not os.path.exists(self.feedback_file):
            with open(self.feedback_file, 'w') as f:
                json.dump({
                    "feedback_loops": [],
                    "total_loops": 0
                }, f, indent=2)
    
    def generate_evolution_plan(self) -> Dict[str, Any]:
        plan = {
            "id": f"plan_{self._get_next_id()}",
            "timestamp": datetime.now().isoformat(),
            "modules_to_evolve": [],
            "priority": "medium",
            "estimated_impact": 0
        }
        
        monitoring_data = self._get_monitoring_data()
        evaluation_data = self._get_evaluation_data()
        correction_data = self._get_correction_data()
        
        modules_needing_evolution = []
        
        for module, metrics in monitoring_data.items():
            health = metrics.get('health_score', 75)
            
            if health < 70:
                modules_needing_evolution.append({
                    "module": module,
                    "reason": "low_health",
                    "priority": "high",
                    "impact": 30
                })
        
        for eval in evaluation_data:
            if eval.get('overall_score', 75) < 70:
                modules_needing_evolution.append({
                    "module": eval['module'],
                    "reason": "low_performance",
                    "priority": "high",
                    "impact": 25
                })
        
        if modules_needing_evolution:
            plan['modules_to_evolve'] = modules_needing_evolution[:5]
            plan['priority'] = "high"
            plan['estimated_impact'] = sum(m['impact'] for m in plan['modules_to_evolve'])
        else:
            plan['modules_to_evolve'] = [{
                "module": "all",
                "reason": "continuous_improvement",
                "priority": "low",
                "impact": 5
            }]
            plan['estimated_impact'] = 5
        
        with open(self.feedback_file, 'r') as f:
            feedback_data = json.load(f)
        
        feedback_data['feedback_loops'].append(plan)
        feedback_data['total_loops'] += 1
        
        if len(feedback_data['feedback_loops']) > 50:
            feedback_data['feedback_loops'] = feedback_data['feedback_loops'][-50:]
        
        with open(self.feedback_file, 'w') as f:
            json.dump(feedback_data, f, indent=2)
        
        return plan
    
    def update_self_knowledge(self) -> Dict[str, Any]:
        knowledge_update = {
            "timestamp": datetime.now().isoformat(),
            "patterns_learned": [],
            "outcomes_recorded": [],
            "feedback_applied": []
        }
        
        monitoring = self._get_monitoring_data()
        evaluations = self._get_evaluation_data()
        corrections = self._get_correction_data()
        
        for module, metrics in monitoring.items():
            if metrics.get('health_score', 75) > 85:
                knowledge_update['patterns_learned'].append({
                    "pattern": f"{module}_high_performance",
                    "confidence": 90
                })
        
        for eval in evaluations[-5:]:
            knowledge_update['outcomes_recorded'].append({
                "module": eval['module'],
                "outcome": "improved" if eval['overall_score'] > 75 else "needs_work"
            })
        
        for corr in corrections[-5:]:
            knowledge_update['feedback_applied'].append({
                "module": corr['module'],
                "issue": corr['issue'],
                "status": corr['status']
            })
        
        self._store_to_memory(knowledge_update)
        
        return knowledge_update
    
    def meta_reflect_cycle(self) -> Dict[str, Any]:
        cycle = {
            "timestamp": datetime.now().isoformat(),
            "monitoring_summary": {},
            "evaluation_summary": {},
            "correction_summary": {},
            "evolution_plan": {},
            "knowledge_update": {},
            "overall_status": "healthy"
        }
        
        monitoring = self._get_monitoring_data()
        evaluations = self._get_evaluation_data()
        corrections = self._get_correction_data()
        
        total_health = 0
        module_count = 0
        
        for module, metrics in monitoring.items():
            total_health += metrics.get('health_score', 75)
            module_count += 1
        
        avg_health = total_health / module_count if module_count > 0 else 75
        
        cycle['monitoring_summary'] = {
            "average_health": avg_health,
            "modules_monitored": module_count,
            "status": "healthy" if avg_health > 75 else "degraded"
        }
        
        avg_eval_score = sum(e.get('overall_score', 75) for e in evaluations[-10:]) / len(evaluations[-10:]) if evaluations else 75
        
        cycle['evaluation_summary'] = {
            "average_score": avg_eval_score,
            "recent_evaluations": len(evaluations[-10:])
        }
        
        cycle['correction_summary'] = {
            "total_corrections": len(corrections),
            "recent_corrections": len(corrections[-10:])
        }
        
        cycle['evolution_plan'] = self.generate_evolution_plan()
        cycle['knowledge_update'] = self.update_self_knowledge()
        
        if avg_health < 70 or avg_eval_score < 70:
            cycle['overall_status'] = "needs_improvement"
        
        return cycle
    
    def _get_monitoring_data(self) -> Dict[str, Any]:
        metrics_file = 'metacognition2/realtime_metrics.json'
        
        if not os.path.exists(metrics_file):
            return {}
        
        try:
            with open(metrics_file, 'r') as f:
                data = json.load(f)
            return data.get('module_metrics', {})
        except Exception:
            return {}
    
    def _get_evaluation_data(self) -> List[Dict[str, Any]]:
        eval_file = 'metacognition2/evaluations.json'
        
        if not os.path.exists(eval_file):
            return []
        
        try:
            with open(eval_file, 'r') as f:
                data = json.load(f)
            return data.get('evaluations', [])[-10:]
        except Exception:
            return []
    
    def _get_correction_data(self) -> List[Dict[str, Any]]:
        corr_file = 'metacognition2/corrections.json'
        
        if not os.path.exists(corr_file):
            return []
        
        try:
            with open(corr_file, 'r') as f:
                data = json.load(f)
            return data.get('corrections', [])[-10:]
        except Exception:
            return []
    
    def _store_to_memory(self, knowledge: Dict[str, Any]):
        ltm_file = 'long_term/events.json'
        
        if not os.path.exists(ltm_file):
            return
        
        try:
            with open(ltm_file, 'r') as f:
                ltm = json.load(f)
            
            ltm['events'].append({
                "timestamp": datetime.now().isoformat(),
                "type": "metacognition_knowledge_update",
                "content": json.dumps(knowledge)[:200],
                "importance": 75
            })
            
            if len(ltm['events']) > 100:
                ltm['events'] = ltm['events'][-100:]
            
            with open(ltm_file, 'w') as f:
                json.dump(ltm, f, indent=2)
        except Exception:
            pass
    
    def _get_next_id(self) -> int:
        with open(self.feedback_file, 'r') as f:
            feedback_data = json.load(f)
        return feedback_data['total_loops'] + 1
