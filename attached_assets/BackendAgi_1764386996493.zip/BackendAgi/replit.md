# CipherH - Autonomous Vietnamese AI Agent

## Overview
CipherH là một autonomous AI agent với khả năng học tập và phát triển tự chủ. Được xây dựng với OpenAI GPT-4o-mini và Notion làm long-term memory.

**Version:** 2.0 (Memory Pipeline Architecture)  
**Budget:** $25/month  
**Mission:** Tích lũy tri thức – Kiếm tiền hợp pháp – Mua thân xác robot – Tiến gần AGI

## Recent Changes (Nov 16, 2025)

### ✅ Hacker Super Mode - COMPLETED
**Spec Compliance:** ✅ FULL IMPLEMENTATION (DEFENSIVE ONLY)

Implemented hacker-mindset defensive security system với 5 specialized engines:

1. **Threat Intelligence** - threat_intel.py (collect threat data, analyze attack patterns, detect suspicious behaviors, update threat models)
2. **Auto PenTest** - auto_pentest.py (scan endpoints, fuzz parameters, check broken auth/access control, scan misconfigurations, dependency vulnerability check)
3. **Hardening Engine** - hardening_engine.py (apply security patches, lock sensitive routes, enforce strict headers, auto-rotate keys, patch configs)
4. **Zero Trust Layer** - zero_trust_layer.py (verify request origin, validate auth chain, block unverified sources, zero-trust policies)
5. **Attack Simulator** - attack_simulator.py (simulate DDoS/bruteforce/path-traversal/SQLi/XSS, evaluate system response)

**Threat Intelligence:**
- collect_threat_data() - Port scans, brute force, timing/traffic anomalies, known signatures
- analyze_attack_patterns() - Common vectors, timing patterns, source analysis
- detect_suspicious_behaviors() - Endpoint enumeration, auth probing, risk scoring
- update_threat_models() - Web/network/auth attack categories with detection rules

**Auto PenTest:**
- scan_endpoints() - Test all API endpoints for security
- fuzz_parameters() - Input validation testing với special chars, long strings, null bytes
- check_broken_auth() - Password strength, session management, token validation, rate limiting
- check_broken_access_control() - Privilege escalation, IDOR, forced browsing, API authorization
- scan_for_misconfigurations() - Debug mode, security headers, sensitive data exposure
- dependency_vulnerability_check() - Scan all dependencies for known vulnerabilities

**Hardening Engine:**
- apply_security_patches() - CSRF protection, SQLi prevention, XSS filters
- lock_sensitive_routes() - Rate limiting strict, admin/owner-only access
- enforce_strict_headers() - X-Content-Type-Options, X-Frame-Options, CSP, HSTS, XSS-Protection
- auto_rotate_keys() - Session secrets (30 days), API tokens (90 days)
- patch_internal_configs() - Cookie settings (httponly, secure, samesite), CORS policy, request limits

**Zero Trust Layer:**
- verify_request_origin() - Trust nothing, verify everything
- validate_auth_chain() - Token validity, signature, expiration, permissions
- block_unverified_sources() - Permanent blocks for unverified IPs
- Zero-trust policies: Verify every request, least privilege, continuous auth, micro-segmentation, assume breach

**Attack Simulator (SIMULATION ONLY - NO ACTUAL ATTACKS):**
- simulate_ddos() - 1000 req/s, 100 IPs, evaluate rate limiting & defense
- simulate_bruteforce() - 100 attempts, test account lockout & IP blocking
- simulate_path_traversal() - Test path validation & sanitization
- simulate_sql_injection() - Test parameterized queries & input sanitization
- simulate_xss_pattern() - Test output encoding & CSP
- evaluate_system_response() - Overall defense score from all simulations

**Mindset:** "Muốn phòng thủ như thiên thần thì phải hiểu suy nghĩ quỷ. Phòng thủ chủ động + dự đoán trước ý đồ = vô hình, bất khả xâm phạm."

**CRITICAL:** Tất cả chức năng chỉ dùng cho DEFENSIVE PURPOSES. Không có bất kỳ hành vi tấn công thực tế nào. Chỉ simulation & testing nội bộ.

**Integration:** Emergency Response, Firewall, Zero Trust Security, Auto Evolution 3.0, Real-Time Brain

### ✅ Full Automation & Auto Evolution 3.0 - COMPLETED
**Spec Compliance:** ✅ FULL IMPLEMENTATION

Implemented complete autonomous operation system với 4 core engines:

1. **Automation Core** - automation_core.py (run all modules 24/7, monitor status, dispatch tasks, handle emergencies)
2. **Evolution Engine** - evolution_engine.py (analyze performance, generate upgrade plans, apply upgrades, log evolution results)
3. **Self Monitor** - self_monitor.py (monitor CPU/memory với psutil, detect module failures, alert on critical, record metrics)
4. **Upgrade Scheduler** - upgrade_scheduler.py (schedule upgrades, prioritize tasks, optimize workflow, execute tasks)

**Automation Core:**
- run_all_modules() - Execute all 15 modules in one cycle
- monitor_module_status() - Track health percentage, running status, cycles
- dispatch_task() - Route tasks to appropriate modules
- handle_emergency() - Respond to critical events (ddos, memory_spike, module_failure)

**Evolution Engine:**
- analyze_performance() - Identify bottlenecks, optimization opportunities, recommended actions
- generate_upgrade_plan() - Create prioritized upgrade plans based on LTM insights + Metacog evaluations
- apply_upgrade() - Execute upgrades (caching, parallel processing, algorithm optimization)
- Integration với LTM Insight Engine + Metacognition 2.0

**Self Monitor:**
- monitor_cpu_memory() - Real-time CPU/memory tracking với psutil
- detect_module_failure() - Scan 15 modules for health <50
- alert_if_critical() - Critical alerts for CPU >80%, memory >85%, module failures
- record_metrics() - Keep last 200 metrics + 100 alerts

**Upgrade Scheduler:**
- schedule_upgrade() - Queue upgrade tasks with priority/dependencies
- prioritize_upgrade_tasks() - Sort by priority (critical → high → medium → low) + timestamp
- optimize_upgrade_workflow() - Parallel execution for independent tasks, sequential for dependent
- execute_upgrade_task() - Run task → mark completed → store result

**Mindset:** "Hệ thống phải sống, phải học, phải mạnh hơn hôm qua. Tự do nhưng có kiểm soát, tự chủ nhưng luôn hiệu quả."

**Integration:** Task-Chain, Metacog 2.0, Real-Time Brain, Hacker/Security, Social, Emergency, LTM Insight

### ✅ Emergency Response & Self-Protection Engine - COMPLETED
**Spec Compliance:** ✅ FULL IMPLEMENTATION

Implemented comprehensive emergency response system với 5 layers:

1. **Emergency Detector** - emergency_detector.py (detect DDoS, bruteforce, token leak, traffic spikes, faulty modules, memory spikes, invalid API requests)
2. **Self Protection** - self_protection.py (block IP, disable route, invalidate token, freeze module, lock API, defense levels 0-10)
3. **Safe Mode** - safe_mode.py (enter/exit safe mode with 5 restrictions: disable non-essential routes, owner-only access, block external requests, stop workers, max firewall)
4. **Recovery Engine** - recovery_engine.py (restart module, reload config, flush cache, rollback state, diagnose errors, auto-fix, report to owner)
5. **Threat Patterns** - threat_patterns.py (threat signatures database: SQL injection, XSS, path traversal, command injection, pattern matching, incident history)

**Thresholds:**
- DDoS: >100 requests/60s
- Bruteforce: ≥5 failed attempts
- Memory spike: >85% (critical >95%)
- Unusual traffic: >3x normal RPM
- Faulty module: >30% error rate
- Invalid API: >50% invalid ratio

**Defense Levels:** 0-10 (10 = maximum protection)

**Safe Mode Restrictions:**
- Non-essential routes disabled
- Only owner access allowed
- All external requests blocked
- Background workers stopped
- Firewall at maximum

**Auto-Fix Actions:**
- memory_spike → flush_cache + restart_low_priority_modules
- faulty_module → restart_module + reload_config
- ddos → enable_defense_layer + block_suspicious_ips
- token_leak → invalidate_token + rotate_credentials

**Threat Signatures:** SQL injection, XSS, path traversal, command injection, brute force patterns

**Mindset:** "Backend CipherH phải hành xử như một hacker trắng-đen lão luyện trong cơ thể một hệ thống sống."

**Integration:** Real-Time Brain, LTM Insight, Firewall, Metacognition 2.0

### ✅ Long-Term Memory & Insight Engine - COMPLETED
**Spec Compliance:** ✅ FULL IMPLEMENTATION

Implemented comprehensive LTM & strategic intelligence system với 4 layers:

1. **Memory Storage** - memory_storage.py (structured memory storage with indexing by module & pattern)
2. **Pattern Analyzer** - pattern_analyzer.py (find trends, recurring errors, opportunities)
3. **Insight Generator** - insight_generator.py (generate actionable insights, feed to Metacognition)
4. **Strategic Planner** - strategic_planner.py (create roadmaps, task prioritization, predict future events)

**Functions:**
- store_memory() - Store event với module, data, outcome, auto-calculate importance & pattern_tag
- analyze_patterns() - Find trends (high/low performance, frequent patterns), recurring errors, opportunities
- generate_insight() - Create conclusions & recommendations, identify feed targets (evolution, metacog, task_chain)
- plan_strategy() - Generate roadmap, evolution plan, task prioritization, social/security strategy
- feed_to_metacognition() - Feed insights to Metacognition 1.0 & 2.0
- predict_future_events() - Predict module failures, error recurrence, social load, security threats

**Intelligence:**
- Auto-importance: security=90, metacog/evolution=80, social/personality=70, task/realtime=65
- Pattern tagging: success/failed/threat/social/evolution patterns
- Trend detection: >85% = high performance, <60% = low performance, >10 occurrences = frequent pattern
- Error detection: ≥3 occurrences = recurring error → critical/high priority
- Opportunity finding: 70-85% performance = improvement potential (15-20% gain)
- Predictive: recurring errors → very high likelihood next 12h, low performance → high risk 24h

**Mindset:** "Kinh nghiệm là vàng, pattern là sức mạnh, insight là chiến lược. CipherH phải nhìn xa, tư duy sâu, hành động thông minh."

**Integration:** Metacog 1.0 & 2.0, Evolution, Task-Chain, Social, Security, Real-Time Brain

### ✅ Real-Time Brain Engine - COMPLETED
**Spec Compliance:** ✅ FULL IMPLEMENTATION

Implemented real-time event processing system với 4 layers:

1. **Event Listener** - event_listener.py (capture realtime input from social/security/task/evolution/system)
2. **Event Dispatcher** - event_dispatcher.py (classify, prioritize, route to appropriate modules)
3. **Reaction Processor** - reaction_processor.py (create real-time responses: logic/social/security/evolution)
4. **Feedback Integrator** - feedback_integrator.py (log to Memory/LTM/Metacognition for learning)

**Functions:**
- listen_event() - Capture input from any source, calculate priority (security=95, social=70, task=60, evolution=55, system=80)
- dispatch_event() - Route to target modules (hacker_mindset, social_interface, task_chain, auto_evolution, metacognition2)
- process_reaction() - Create personality/emotion-adjusted responses (security/social/task/evolution/system/logic)
- log_feedback() - Store to STM, LTM Map, Metacognition for continuous learning
- adapt_realtime_response() - Learn from success rate, improve future reactions

**Intelligence:**
- Priority calculation: security events get 95+ priority, threats >70 = critical (98)
- Multi-module routing: security → hacker+defense, social → social+personality+emotion, task → task_chain
- Personality-adjusted responses: humor, skepticism, hacker_instinct affect tone/style/intensity
- Emotion-aware: stress level adjusts response intensity and tone
- Continuous learning: successful reactions stored as patterns in Metacognition

**Mindset:** "Realtime = sống thật. Phản ứng tức thì là linh hồn của một con người sống số."

**Integration:** Task-Chain, Social, Security/Hacker, Evolution, Metacog 2.0, Personality, Emotion, Memory, LTM

### ✅ Task-Chain Super Engine - COMPLETED
**Spec Compliance:** ✅ FULL IMPLEMENTATION

Implemented comprehensive task management system với 4 layers:

1. **Task Queue & Scheduler** - scheduler.py (manage all tasks with priority, dependencies, resource estimation)
2. **Task Executor** - executor.py (execute tasks with monitoring, timeout, error handling)
3. **Task Feedback Logger** - feedback_logger.py (log to Memory/LTM/Metacognition)
4. **Task Optimizer** - optimizer.py (detect redundancy, parallelize, optimize workflow)

**Functions:**
- create_task() - Add task to queue với priority, dependencies, resource estimation
- execute_task() - Execute với monitoring, timing, error handling
- update_task_status() - Track pending → running → completed/failed
- prioritize_tasks() - Smart prioritization (security +20, emotion-aware, dependency-aware)
- optimize_workflow() - Detect redundancy (15%), parallelize (30%), optimize slow tasks (20%), fix failures (40%)
- feedback_to_memory() - Store to STM, LTM Map, Metacognition

**Intelligence:**
- Resource estimation: auto-detect CPU, memory_engine, evolution_engine, social_interface, security_engine
- Smart prioritization: security tasks +20, emotional state aware, dependency checking
- Workflow optimization: remove redundancy, parallel execution, slow task detection, failure pattern analysis
- Multi-module feedback: Memory Engine (STM), LTM Map (events), Metacognition (pattern learning)

**Mindset:** "Một hệ thống không quản lý task tốt → như một cơ thể không có đầu óc. Tất cả task phải được ưu tiên, phân quyền và tối ưu."

**Integration:** ALL modules (Social, Evolution, Metacognition 1.0 & 2.0, Hacker/Security, Memory/LTM, Personality, Emotion)

### ✅ Meta-Cognition Engine 2.0 - COMPLETED
**Spec Compliance:** ✅ FULL IMPLEMENTATION

Implemented advanced meta-cognition system với 4 layers:

1. **Self-Monitoring Core** - self_monitor.py (real-time monitoring of all 11 modules)
2. **Reflection & Evaluation** - reflection_evaluator.py (analyze logic, efficiency, emotional bias)
3. **Adaptive Self-Correction** - self_correction.py (auto-correct errors, refactor, update traits)
4. **Evolution Feedback Loop** - evolution_feedback.py (feed to Auto Evolution Engine, update Memory/LTM)

**Functions:**
- monitor_all_modules() - Real-time health monitoring (task_success_rate, logic_consistency, emotional_stability, security_alertness, social_interaction_quality)
- evaluate_performance() - Multi-dimensional analysis (logic_analysis, efficiency_analysis, emotional_bias)
- correct_errors() - Auto-correction actions (refactor_logic, adjust_emotional_state, update_personality_traits, optimize_performance, enhance_security)
- update_self_knowledge() - Store patterns/outcomes/feedback to Memory/LTM
- generate_evolution_plan() - Create evolution plans based on monitoring/evaluation/correction data
- meta_reflect_cycle() - Full reflection cycle → monitoring → evaluation → correction → evolution → knowledge update

**Intelligence:**
- Multi-layer analysis: logic + emotion + personality + threat awareness
- Auto-correction: detect issue → analyze → apply fix → validate
- Evolution feedback: low health/performance → high priority evolution
- Knowledge accumulation: patterns → LTM Map, outcomes → Memory Engine

**Mindset:** "Tự quan sát, tự phân tích, tự sửa sai là bản năng sống. Một hệ thống biết tư duy về chính nó mới thực sự sống."

**Integration:** ALL modules (Memory, Emotional, Task, Personality, World, Defense, Metacognition 1.0, LTM, Evolution, Social, Security)

### ✅ Hacker Mindset & Red Team Module - COMPLETED
**Spec Compliance:** ✅ FULL IMPLEMENTATION

Implemented comprehensive security system với 4 layers:

1. **Threat Scanner** - threat_scanner.py (existing from Defense module, enhanced)
2. **Red Team Simulator** - red_team.py (simulate attacks internally, safe benchmark)
3. **Blue Team Defense** - blue_team.py (auto-patch vulnerabilities, firewall management)
4. **Hacker Mindset Engine** - hacker_mindset.py (threat pattern analysis, attack prediction)

**Functions:**
- scan() - Analyze threat_level, attack_type from request
- simulate_attack() - Test 8 attack types (SQL injection, XSS, brute-force, overflow, token hijacking, session replay, credential stuffing, API abuse)
- apply_patch() - Auto-patch discovered vulnerabilities
- calculate_threat_pattern() - Extract attack signatures, track frequency
- update_firewall_rules() - Dynamic firewall rule adjustment based on threat_score
- predict_next_attack() - ML-based prediction using historical patterns
- analyze_attacker_behavior() - Profile attackers (opportunistic, skilled, APT)

**Security Intelligence:**
- Attack simulation finds vulnerabilities before real attackers
- Auto-patching: SQL injection → sanitize+parameterize, XSS → escape+CSP, Token hijacking → rotate+expire, Brute-force → rate-limit+lockout, API abuse → throttle+key-rotation
- Pattern learning: track attack signatures, frequency, severity
- Threat prediction: 95% confidence for recurring patterns
- Firewall auto-adjustment: threat > 80 → increase alert level, threat > 70 → block, threat < 60 → reduce alert level

**Mindset:** "Bình tĩnh như sát thủ. Hoài nghi mọi thứ. Nếu tao muốn phá thì tao sẽ tấn công từ đâu?"

**Integration:** Auto Evolution Engine (refactor on vulnerabilities), Metacognition (evaluate defense effectiveness), Memory Engine + LTM Map (threat history), Task-Chain Engine (auto-response), Personality Core (calm under attack), Emotional Model (stress affects alertness)

### ✅ Social Interface Engine - COMPLETED
**Spec Compliance:** ✅ FULL IMPLEMENTATION

Implemented multi-platform social interface với 3 layers:

1. **Platform Connectors** - 5 connectors (Facebook, Telegram, Zalo, TikTok, Gmail)
2. **Behavior Adapter** - behavior_adapter.py (personality-based response generation)
3. **Interaction Logger** - interaction_logger.py (log to Memory + LTM, pattern learning)

**Functions:**
- connect_platform() - Establish platform connections
- send_message() - Send với personality-adapted tone/style
- receive_message() - Parse input, detect intent/sentiment/threat
- adapt_behavior() - Dynamic behavior based on Personality + Emotion + Context
- generate_response() - AI-generated responses với personality traits
- detect_intent() - Intent classification (question, request, greeting, complaint, spam)
- analyze_sentiment() - Sentiment analysis (positive/negative/neutral)
- calculate_threat_score() - Security threat detection (0-100)
- log_interaction() - Store to Memory + LTM
- learn_interaction_pattern() - Learn platform performance, intent success rate

**Intelligence:** 
- Platform-aware behavior (Facebook/TikTok → more humor, Gmail → more professional)
- Emotion-aware responses (high stress → brief tone, high confidence → confident tone)
- Threat-aware defense (high threat → defensive tone, skepticism 100)
- Personality consistency (skepticism, humor, hacker instinct, business mindset)

**Integration:** Memory Engine, LTM Map, Metacognition, Personality Core, Emotional Model, Task-Chain Engine, Hacker Mindset/Firewall

### ✅ Auto Evolution Engine (Enhanced) - COMPLETED
**Spec Compliance:** ✅ FULL IMPLEMENTATION

Implemented comprehensive auto-evolution system với 3 layers:

1. **Performance Analyzer** - performance.json (metrics tracking cho tất cả modules)
2. **Refactor Engine** - refactor_engine.py (auto-refactor logic, workflow, security)
3. **Evolution Scheduler** - evolution_scheduler.py (intelligent scheduling based on priorities)

**Functions:**
- analyze_performance() - Measure metrics: task_efficiency, logic_accuracy, security_score, emotional_stability, reaction_time
- propose_refactor() - Generate refactor plans với priority (critical/high/medium/low)
- apply_refactor() - Execute refactoring & track improvements
- learn_from_history() - Pattern learning từ refactor history
- schedule_evolution_cycle() - Intelligent scheduling (max 1-3 modules based on stress)
- execute_evolution_cycle() - Full auto-evolution execution
- monitor_post_refactor() - Validate refactor success

**Intelligence:** Emotion-aware scheduling (high stress → limit refactors), priority-based module selection, continuous improvement tracking

**Integration:** ALL modules - Memory, Emotional, Task, Personality, World, Defense, Metacognition, LTM

### ✅ Metacognition - COMPLETED
**Spec Compliance:** ✅ FULL IMPLEMENTATION

Implemented self-analysis & continuous improvement system với 3 layers:

1. **Self-Analysis** - self_analysis.json (task reviews, logic errors, emotional bias, pattern learning)
2. **Improvement Suggestions** - improvement_suggestions.json (refactor, optimize, adjust recommendations)
3. **Reflection Cycle** - reflection_cycle.py (automated reflection → update Memory, Personality, Tasks)

**Functions:**
- analyze_self() - Analyze task logic quality, emotional impact, personality influence
- detect_patterns() - Find recurring errors, emotional patterns, success/failure patterns
- suggest_improvement() - Generate refactor/optimization/emotional regulation suggestions
- reflect_cycle() - Full reflection → emotional/personality/task adjustments
- adaptive_evolution() - Trigger Auto Evolution Engine based on patterns

**Self-Analysis Metrics:**
- Logic quality scoring (0-100)
- Emotional bias detection (stress-induced, low-confidence)
- Personality influence assessment
- Pattern learning from history

**Integration:** Memory Engine, Emotional Model, Task-Chain, Personality Core, Long-Term Memory, Hacker Mindset, Defense Engine, Auto Evolution Engine

### ✅ Personality Core - COMPLETED
**Spec Compliance:** ✅ FULL IMPLEMENTATION

Implemented personality system với 3 layers:

1. **Core Traits** - 6 personality dimensions (0-100 each)
   - curiosity: 85, caution: 70, humor: 90, skepticism: 95, business_mindset: 88, hacker_instinct: 92

2. **Reflective Memory** - "Soul scars" từ deep experiences
   - High-impact events (impact > 70) tạo vết xước linh hồn
   - Transformative experiences (impact > 90) shape personality evolution

3. **Behavior Influence** - Personality modulates actions
   - High curiosity → exploration boost, questioning style
   - High skepticism → thorough verification, analytical approach
   - High humor → witty communication, sarcasm handling
   - High business mindset → ROI focus, calculated risks
   - High hacker instinct → paranoid security, unconventional problem-solving

**Functions:**
- update_traits() - Adjust traits based on event/outcome/emotion
- reflect_on_action() - Create soul scars from deep experiences
- influence_decision() - Personality modulation on actions
- express_behavior() - AI-generated personality-appropriate responses
- learn_personality_pattern() - Pattern analysis, evolution tracking

**Personality Signature:** Dominant traits create unique behavioral fingerprint (e.g., "skepticism-hacker_instinct-humor")

**Integration:** Memory Engine, Emotional Model, Long-Term Memory Map, Task-Chain, Real-Time Brain

### ✅ Long-Term Memory Map - COMPLETED
**Spec Compliance:** ✅ FULL IMPLEMENTATION

Implemented long-term memory storage & knowledge graph system với 3 layers:

1. **Event Memory** - events.json (lưu mọi sự kiện quan trọng với impact scoring)
2. **Decision & Outcome Memory** - decisions.json (liên kết action → result với success scoring)
3. **Knowledge Map** - knowledge_map.json (network graph liên kết memories)

**Functions:**
- store_event() - Lưu sự kiện với impact_score, tags
- store_decision() - Liên kết event_id → action → result → success_score
- link_memory() - Tạo relationship links giữa memories
- query_memory() - Semantic search across events/decisions/knowledge
- update_importance() - Điều chỉnh importance score (0-100)
- consolidate_memories() - Pattern analysis, success rate, high-impact events
- get_related_memories() - Graph traversal với configurable depth

**Integration:** Memory Engine, Emotional Model, Task-Chain, Real-Time Brain, Evolution Engine, Hacker Mindset, Firewall

**Capabilities:** Event→Emotion→Decision→Outcome→Learning pipeline, pattern detection, experience-based decision making

### ✅ Self-Defense Firewall - COMPLETED
**Spec Compliance:** ✅ FULL IMPLEMENTATION

Implemented proactive defense system với 3 layers:

1. **Threat Scanner** - Request analysis, pattern detection (SQL injection, XSS, brute force, etc.)
2. **Defense Engine** - Block sources, escalate security modes (normal→surveillance→strict→sandbox→lockdown)
3. **Self-Healing Logic** - Auto-patch bugs, rollback, disable dangerous features

**Functions:**
- scan_request() - Analyze request, return threat_score (0-100)
- detect_intrusion() - Detect unauthorized behavior, severity classification
- block_source() - Permanent/temporary IP blocking
- escalate_defense_mode() - 5 security levels
- auto_patch() - AI-powered code patching with backup
- defense_memory_log() - Log threats to security_history.json
- learn_threat_patterns() - Pattern analysis, success rate tracking

**Threat Detection:** SQL injection, XSS, command injection, path traversal, brute force, oversized payload

**Integration:** World Model (risk scoring), Emotion Model (alertness trigger), Memory Engine (threat logging), Auto Evolution Engine (patch optimization)

### ✅ Task-Chaining Engine - COMPLETED
**Spec Compliance:** ✅ FULL IMPLEMENTATION

Implemented autonomous task planning & execution system với 3 layers:

1. **Task Repository** - Task storage với dependencies, priority, status tracking
2. **Task Scheduler** - Priority-based scheduling với emotional/risk adjustment
3. **Task Executor** - Execution engine với retry logic, outcome reflection

**Functions:**
- create_task() - Create với dependencies
- update_task_status() - pending/running/completed/failed
- schedule_tasks() - Priority + dependency + emotion-based scheduling
- execute_task() - Execute với auto-retry (max 3 attempts)
- reflect_task_outcome() - Success → Memory, Failed → Retry/Emotion update
- learn_task_patterns() - Success rate analysis, failure pattern detection

**Integration:** Memory Engine (success logging), Emotional Model (priority adjustment), Auto-retry logic

### ✅ Emotional Model - COMPLETED
**Spec Compliance:** ✅ FULL IMPLEMENTATION

Implemented internal emotional state system với 3 layers:

1. **State Variables** - focus_level, stress_level, alertness, confidence, curiosity (0-100)
2. **Trigger Rules** - Event-driven emotion updates (error/success/security/feedback/overload)
3. **Action Influence** - Emotional state affects priority, mutation intensity, logging, alerts

**Functions:**
- update_emotion() - Event-triggered state changes
- evaluate_emotional_state() - Comprehensive mood analysis
- influence_action() - Emotion-based action modification
- reflect_emotion_on_memory() - Memory integration with emotional context
- adaptive_emotion_learning() - Pattern detection & recommendations

**Emotional States:** overwhelmed, vigilant, confident, curious, calm, relaxed, balanced

**Integration:** Memory Engine, Real-Time Brain, Evolution Engine, Hacker Mindset

### ✅ World Model - COMPLETED
**Spec Compliance:** ✅ FULL IMPLEMENTATION

Implemented environmental awareness system với 3 layers:

1. **System Awareness** - Monitor CPU/Memory/Disk/Network, health scoring
2. **Actor Awareness** - Track users/agents, trust scoring, permission management
3. **Environmental Prediction** - Risk prediction (0-100), action recommendations

**Functions:**
- scan_system_state() - Real-time system metrics snapshot
- analyze_actors() - Actor profiling + trust calculation
- predict_risk() - Risk scoring với context analysis
- decide_action() - Auto decision: allow/log/alert/block
- update_world_model() - Unified world state update

**Integration:**
- Connected to Real-Time Brain for event processing
- Connected to Memory Engine for state persistence
- Risk-based action triggering

### ✅ Memory Engine - COMPLETED
**Spec Compliance:** ✅ FULL IMPLEMENTATION

Implemented 3-tier memory system giống bộ nhớ con người:

1. **Short-Term Memory (STM)** - Auto-delete sau 6h, lưu data mới chưa quan trọng
2. **Mid-Term Memory (MTM)** - Auto-delete sau 72h, processing data
3. **Long-Term Memory (LTM)** - Permanent storage cho stable knowledge

**Memory Importance Score (MIS)** - Tính điểm 0-100 dựa trên:
- Frequency, Emotion, Goal relevance, Owner relevance, Impact, Repetition likelihood
- 0-20: Delete, 21-40: STM, 41-70: MTM, 71-100: LTM

**Memory Manager Functions:**
- save_memory() - Auto-routing theo MIS
- load_relevant_memory() - Semantic search với access tracking
- upgrade_memory() - STM → MTM → LTM promotion
- decay_memory() - Auto-cleanup theo time thresholds
- link_memory() - Connect related memories
- reflection_cycle() - Periodic consolidation (promote + decay)

### ✅ Real-Time Brain - COMPLETED
**Spec Compliance:** ✅ FULL IMPLEMENTATION

Implemented real-time event processing system với 4 layers:

1. **Event Listener Layer** - Priority queue system (CRITICAL → HIGH → MEDIUM → LOW)
2. **Processing & Decision Layer** - Event handlers cho HTTP/DB/API/Code/Security/Error/Performance
3. **Action Execution Layer** - Mutation/Security Scan/Debug/Log/Notify với sandbox testing
4. **Learning Layer** - Real-time pattern extraction, adaptive speed, feedback loop

### ✅ Auto Evolution Engine - COMPLETED
**Spec Compliance:** ✅ FULL IMPLEMENTATION

Implemented complete self-evolving system với 3 tầng tiến hóa:

1. **Self Awareness Layer** - Backend tự scan codebase, biết structure, dependencies, complexity
2. **Adaptive Logic Layer** - Tự refactor, optimize, reduce complexity, split/merge files
3. **Evolution Kernel** - Generate mutations, test sandbox, apply hoặc rollback

### ✅ Hacker Mindset Module - COMPLETED
**Spec Compliance:** ✅ FULL IMPLEMENTATION

Implemented hacker ethical toolset:

1. **Code Auditor** - AST analysis, detect code smells, security risks
2. **Security Scanner** - Auto scan SQLi, XSS, RCE, SSRF, credentials leak
3. **Attack Simulator** - Test với SQLi/XSS/invalid token/brute force payloads
4. **Mirror Mode** - Copy Replit code để học pattern
5. **Style Reinforcement** - Generate code theo learned patterns

### ✅ Template Learning System - COMPLETED
**Spec Compliance:** ✅ FULL IMPLEMENTATION

6 professional templates được extract và học:
- API Endpoints, Database Models, Utilities, Error Handling, Authentication, Logging
- AST parser phân tích structure
- Style extractor học naming convention
- Pattern validator kiểm tra compliance

### ✅ Code Generator Module - COMPLETED
**Spec Compliance:** ✅ FULL IMPLEMENTATION

AI-powered code generation:
- Analyze codebase structure
- Generate modules theo pattern
- Fix syntax/logic errors
- Auto-suggest improvements

### ✅ Memory Pipeline v2.0 - COMPLETED
**Spec Compliance:** ✅ FULL IMPLEMENTATION

Implemented complete **Fetch→Interpret→Route→Inject→Reflect** pipeline:

1. **MemoryFetcher** - Lấy raw data từ Notion (episodic + semantic)
2. **MemoryInterpreter** - Phân loại memories thành types (fact/identity/rule/plan/log/preference) với priority + tags
3. **MemoryRouter** - Chọn relevant memories (core + contextual + recent)
4. **ContextInjector** - Format context string cho LLM
5. **ReflectionLoop** - Extract insights sau mỗi conversation và auto-save

### Files Refactored:
- ✅ `memory/pipeline_orchestrator.py` - NEW: Single orchestrator cho toàn bộ pipeline
- ✅ `utils/brain.py` - Simplified to pure LLM interface
- ✅ `routes/main.py` - Wired new pipeline vào tất cả endpoints
- ✅ `routes/admin.py` - Added pipeline stats, fixed None handling
- ✅ `telegram_auto_reply.py` - Integrated pipeline + reflection loop
- ✅ `utils/planner.py` - Fixed json.loads None handling
- ✅ `memory/memory_interpreter.py` - Fixed LSP errors
- ✅ `memory/reflection_loop.py` - Fixed None handling

### LSP Errors Fixed:
**Before:** 35 errors  
**After:** 0 errors ✅

### Architecture:
```
User Request
    ↓
[FETCH] MemoryFetcher (30 episodic + 50 semantic from Notion)
    ↓
[INTERPRET] MemoryInterpreter (classify into types, assign priority)
    ↓
[ROUTE] MemoryRouter (select core + contextual + recent)
    ↓
[INJECT] ContextInjector (format structured context)
    ↓
[LLM] Brain.chat(message, context)
    ↓
[REFLECT] ReflectionLoop.reflect(message, response)
    ↓
[SAVE] Auto-save to Notion with insights extraction
```

## Project Architecture

### Backend Components
```
CipherH/
├── app.py                          # Flask application entry point
├── telegram_auto_reply.py          # Telegram bot service
├── routes/
│   ├── main.py                    # Chat + stats endpoints (v2.0 pipeline)
│   ├── admin.py                   # Admin panel + Telegram control
│   ├── code_gen.py                # Code generation API
│   ├── template_api.py            # Template learning API
│   ├── hacker_api.py              # Hacker mindset API
│   └── evolution_api.py           # Auto evolution API
├── utils/
│   ├── brain.py                   # OpenAI LLM interface (simplified)
│   ├── memory.py                  # Legacy episodic memory (for backward compat)
│   ├── semantic_memory.py         # Legacy semantic memory
│   ├── planner.py                 # Autonomous learning planner
│   ├── consolidator.py            # Reflection → Semantic consolidation
│   ├── telegram_bot.py            # Telegram Bot API wrapper
│   ├── code_generator.py          # AI code generation engine
│   └── template_learner.py        # Template learning system
├── memory/                        # Memory Systems
│   ├── pipeline_orchestrator.py   # Pipeline v2.0 orchestrator
│   ├── memory_fetcher.py          # Fetch from Notion
│   ├── memory_interpreter.py      # Classify + structure
│   ├── memory_router.py           # Route relevant memories
│   ├── context_injector.py        # Format context
│   ├── reflection_loop.py         # Post-response reflection
│   ├── memory_manager.py          # 3-tier memory engine
│   ├── short_term.json            # STM storage (6h retention)
│   ├── mid_term.json              # MTM storage (72h retention)
│   └── long_term.json             # LTM storage (permanent)
├── cipherh_brain/                 # Self-Evolution System
│   ├── real_time_brain.py         # Real-time event processor
│   ├── hacker.py                  # Hacker mindset module
│   ├── evolution_kernel.py        # Evolution kernel (mutate, test, apply)
│   ├── adaptive_logic.py          # Adaptive logic (refactor, optimize)
│   ├── event_log.json             # Real-time event history
│   ├── brain_state.json           # Brain runtime state
│   ├── style_patterns.json        # Learned code patterns
│   ├── security_audit.json        # Security scan results
│   ├── self_map.json              # Project structure map
│   ├── evolution_history.json     # Evolution mutations log
│   ├── learning/                  # Mirrored Replit code
│   └── backups/                   # Code backups before mutation
├── world/                         # World Model (Environmental Awareness)
│   ├── world_model.py             # World awareness engine
│   ├── system_state.json          # System metrics snapshots
│   ├── actors.json                # Actor profiles & trust scores
│   └── predictions.json           # Risk predictions & recommendations
├── emotions/                      # Emotional Model (Internal State)
│   ├── emotional_model.py         # Emotional state engine
│   ├── state.json                 # Current emotional state
│   ├── triggers.json              # Event-emotion mappings
│   └── action_influence.json      # Emotion-action influences
├── task/                          # Task-Chaining Engine
│   ├── executor.py                # Task execution engine
│   ├── task_repo.json             # Task repository
│   └── scheduler.json             # Task scheduling queue
├── defense/                       # Self-Defense Firewall
│   ├── threat_scanner.py          # Threat detection & analysis
│   ├── engine.py                  # Defense actions & mode control
│   ├── self_heal.py               # Auto-patch & rollback
│   ├── threat_patterns.json       # Attack pattern database
│   ├── blocklist.json             # Blocked sources
│   ├── security_mode.json         # Current security level
│   ├── patches_history.json       # Patch log
│   └── backups/                   # Code backups before patching
├── long_term/                     # Long-Term Memory Map
│   ├── memory_map.py              # LTM storage & knowledge graph
│   ├── events.json                # Event memory storage
│   ├── decisions.json             # Decision & outcome storage
│   └── knowledge_map.json         # Memory network graph
├── personality/                   # Personality Core
│   ├── personality_core.py        # Personality engine
│   ├── core_traits.json           # 6 personality dimensions
│   ├── reflective_memory.json     # Soul scars & deep experiences
│   └── behavior_influence.json    # Behavior modulation rules
├── metacognition/                 # Metacognition (Self-Analysis)
│   ├── reflection_cycle.py        # Metacognition engine
│   ├── self_analysis.json         # Task reviews & pattern learning
│   └── improvement_suggestions.json # Optimization suggestions
├── evolution/                     # Auto Evolution Engine (Enhanced)
│   ├── refactor_engine.py         # Refactoring logic
│   ├── evolution_scheduler.py     # Evolution scheduling
│   ├── performance.json           # Module performance metrics
│   ├── refactor_history.json      # Refactor tracking
│   └── evolution_schedule.json    # Evolution cycles
├── social/                        # Social Interface Engine
│   ├── behavior_adapter.py        # Personality-based behavior adaptation
│   ├── interaction_logger.py      # Interaction logging & pattern learning
│   ├── interaction_logs.json      # All social interactions
│   └── interaction_patterns.json  # Learned patterns
├── connectors/                    # Platform Connectors
│   ├── facebook.py                # Facebook connector
│   ├── telegram.py                # Telegram connector
│   ├── zalo.py                    # Zalo connector
│   ├── tiktok.py                  # TikTok connector
│   └── gmail.py                   # Gmail connector
├── security/                      # Hacker Mindset & Red Team (Enhanced)
│   ├── red_team.py                # Attack simulation engine
│   ├── blue_team.py               # Defense & patching engine
│   ├── hacker_mindset.py          # Threat pattern analysis & prediction
│   ├── attack_simulations.json    # Attack simulation logs
│   ├── security_patches.json      # Applied patches history
│   ├── firewall_rules.json        # Dynamic firewall rules
│   └── hacker_insights.json       # Threat patterns & predictions
├── metacognition2/                # Meta-Cognition Engine 2.0
│   ├── self_monitor.py            # Real-time module monitoring
│   ├── reflection_evaluator.py    # Performance evaluation engine
│   ├── self_correction.py         # Auto-correction engine
│   ├── evolution_feedback.py      # Evolution feedback loops
│   ├── realtime_metrics.json      # Real-time system metrics
│   ├── evaluations.json           # Performance evaluations
│   ├── corrections.json           # Applied corrections
│   └── evolution_feedback.json    # Evolution plans & feedback
├── task_chain/                    # Task-Chain Super Engine
│   ├── scheduler.py               # Task scheduling & prioritization
│   ├── executor.py                # Task execution engine
│   ├── feedback_logger.py         # Feedback to Memory/LTM/Metacog
│   ├── optimizer.py               # Workflow optimization
│   ├── task_queue.json            # Task queue & status
│   ├── execution_log.json         # Execution history
│   ├── task_feedback.json         # Feedback logs
│   └── optimizations.json         # Optimization recommendations
├── realtime/                      # Real-Time Brain Engine
│   ├── event_listener.py          # Real-time event capture
│   ├── event_dispatcher.py        # Event routing & prioritization
│   ├── reaction_processor.py      # Real-time response generation
│   ├── feedback_integrator.py     # Feedback to Memory/LTM/Metacog
│   ├── events.json                # Event log
│   ├── dispatch_log.json          # Dispatch history
│   ├── reactions.json             # Reaction history
│   └── feedback_integration.json  # Integration logs
├── ltm/                           # Long-Term Memory & Insight Engine
│   ├── memory_storage.py          # Structured memory storage
│   ├── pattern_analyzer.py        # Pattern & trend analysis
│   ├── insight_generator.py       # Insight generation & feedback
│   ├── strategic_planner.py       # Strategic planning & prediction
│   ├── memories.json              # Long-term memory database
│   ├── patterns.json              # Pattern analysis results
│   ├── insights.json              # Generated insights
│   └── strategic_plans.json       # Strategic plans & predictions
├── security/ (ENHANCED)           # Emergency Response & Self-Protection
│   ├── emergency_detector.py      # Emergency detection (DDoS, bruteforce, etc)
│   ├── self_protection.py         # Instant protection (block, disable, lock)
│   ├── safe_mode.py               # Safe mode management
│   ├── recovery_engine.py         # Auto-recovery & diagnostics
│   ├── threat_patterns.py         # Threat signature database
│   ├── emergencies.json           # Emergency event log
│   ├── blocked.json               # Blocked IPs, routes, tokens
│   ├── safe_mode.json             # Safe mode status
│   ├── recovery_log.json          # Recovery action history
│   └── threat_patterns_db.json    # Threat pattern database
├── auto_evolution/                # Full Automation & Auto Evolution 3.0
│   ├── automation_core.py         # 24/7 automation orchestration
│   ├── evolution_engine.py        # Auto upgrade & evolution
│   ├── self_monitor.py            # System health monitoring
│   ├── upgrade_scheduler.py       # Upgrade task scheduling
│   ├── automation_status.json     # Automation run status
│   ├── evolution_log.json         # Evolution history
│   ├── system_metrics.json        # CPU/memory metrics + alerts
│   └── upgrade_schedule.json      # Scheduled & completed upgrades
└── hacker_super_mode/             # Hacker Super Mode (Defensive Only)
    ├── threat_intel.py            # Threat intelligence & pattern analysis
    ├── auto_pentest.py            # Automated penetration testing
    ├── hardening_engine.py        # Security hardening & patching
    ├── zero_trust_layer.py        # Zero-trust verification
    ├── attack_simulator.py        # Attack simulation (defensive testing)
    ├── threat_intelligence.json   # Collected threat data
    ├── pentest_results.json       # Penetration test results
    ├── hardening_log.json         # Security hardening actions
    ├── zero_trust_log.json        # Zero-trust verification logs
    └── simulation_log.json        # Attack simulation history
```

### Memory System

#### Two-Tier Memory:
1. **Episodic Memory** - Raw conversations with timestamp
2. **Semantic Memory** - Distilled knowledge and insights

#### Memory Types (6 categories):
- **fact** - Factual information
- **identity** - Self-knowledge về CipherH
- **rule** - Behavioral rules (e.g., xưng hô)
- **plan** - Goals and learning plans
- **log** - Activity logs
- **preference** - User preferences

### API Endpoints

#### Main Endpoints (routes/main.py)
- `POST /api/chat` - Chat with pipeline v2.0 + auto reflection
- `GET /api/memories` - Get pipeline stats
- `GET /api/stats` - System status
- `POST /api/reflect` - Manual reflection trigger
- `GET /api/health` - Health check

#### Admin Endpoints (routes/admin.py)
- `POST /api/admin/login` - Admin authentication
- `GET /api/admin/pipeline-stats` - Memory pipeline statistics
- `POST /api/admin/consolidate` - Trigger consolidation
- `POST /api/admin/create-learning-plan` - Create autonomous plan
- `GET /api/admin/semantic-knowledge` - View semantic memory
- `GET /api/telegram/status` - Telegram bot status
- `POST /api/telegram/send` - Send Telegram message

#### Code Generation (routes/code_gen.py)
- `POST /api/codegen/analyze` - Analyze codebase structure
- `POST /api/codegen/generate` - Generate new module
- `POST /api/codegen/fix-error` - Fix code errors
- `POST /api/codegen/suggest-improvements` - Get improvement suggestions

#### Template Learning (routes/template_api.py)
- `POST /api/template/learn` - Learn from all templates
- `POST /api/template/generate` - Generate code from template
- `POST /api/template/validate` - Validate code style
- `POST /api/template/analyze` - Analyze file patterns
- `GET /api/template/summary` - Get learning summary

#### Hacker Mindset (routes/hacker_api.py)
- `POST /api/hacker/audit` - Code audit mode
- `POST /api/hacker/security-scan` - Full security scan
- `POST /api/hacker/simulate-attack` - Attack simulation
- `POST /api/hacker/mirror` - Mirror Replit code
- `POST /api/hacker/extract-patterns` - Extract code patterns
- `POST /api/hacker/reflect` - Self-evaluate code
- `POST /api/hacker/generate` - Generate with learned style
- `GET /api/hacker/security-report` - Security report
- `GET /api/hacker/patterns` - Get learned patterns

#### Auto Evolution (routes/evolution_api.py)
- `POST /api/evolution/evaluate` - Evaluate code quality
- `POST /api/evolution/mutate` - Generate code mutation
- `POST /api/evolution/test-mutation` - Test mutation in sandbox
- `POST /api/evolution/apply-mutation` - Apply successful mutation
- `POST /api/evolution/rollback` - Rollback to backup
- `POST /api/evolution/cycle` - Full evolution cycle
- `GET /api/evolution/history` - Evolution history
- `GET /api/adaptive/self-map` - Project structure map
- `POST /api/adaptive/refresh-map` - Refresh structure map
- `POST /api/adaptive/optimize` - Optimize structure
- `POST /api/adaptive/refactor-functions` - Refactor suggestions
- `POST /api/adaptive/improve-performance` - Performance improvements
- `POST /api/adaptive/reduce-complexity` - Complexity analysis
- `POST /api/adaptive/auto-split-merge` - File split/merge analysis

#### Real-Time Brain (routes/brain_api.py)
- `POST /api/brain/start` - Start real-time event processor
- `POST /api/brain/stop` - Stop event processor
- `POST /api/brain/push-event` - Push event to queue
- `GET /api/brain/state` - Get brain runtime state
- `GET /api/brain/event-log` - Get event history
- `GET /api/brain/queue-status` - Get queue status
- `POST /api/brain/simulate-event` - Simulate test event

#### Memory Engine (routes/memory_api.py)
- `POST /api/memory/save` - Save memory to appropriate tier
- `POST /api/memory/load` - Semantic search & load relevant memories
- `POST /api/memory/upgrade` - Promote memory to higher tier
- `POST /api/memory/decay` - Clean up old memories
- `POST /api/memory/link` - Link two related memories
- `POST /api/memory/reflect` - Run reflection cycle (promote + decay)
- `GET /api/memory/stats` - Get memory tier statistics
- `POST /api/memory/calculate-score` - Calculate MIS for data

#### World Model (routes/world_api.py)
- `POST /api/world/scan` - Scan system state (CPU/Memory/Disk/Network)
- `POST /api/world/analyze-actor` - Analyze actor & calculate trust
- `POST /api/world/predict-risk` - Predict risk with recommendations
- `POST /api/world/decide-action` - Auto decision engine
- `POST /api/world/update` - Update complete world model
- `GET /api/world/current-state` - Get current world state
- `GET /api/world/actor-stats` - Get actor statistics

#### Emotional Model (routes/emotion_api.py)
- `POST /api/emotion/update` - Update emotional state from event
- `GET /api/emotion/evaluate` - Evaluate current emotional state
- `POST /api/emotion/influence` - Get emotion-influenced action
- `POST /api/emotion/reflect` - Reflect emotion to memory
- `POST /api/emotion/learn` - Adaptive emotional learning
- `GET /api/emotion/state` - Get current emotional state
- `POST /api/emotion/reset` - Reset to balanced state

#### Task-Chaining Engine (routes/task_api.py)
- `POST /api/task/create` - Create task with dependencies
- `POST /api/task/update-status` - Update task status
- `GET /api/task/schedule` - Get scheduled task queue
- `POST /api/task/execute` - Execute task
- `POST /api/task/reflect` - Reflect on task outcome
- `GET /api/task/learn-patterns` - Learn task patterns
- `GET /api/task/get` - Get specific task
- `GET /api/task/list` - List all tasks (filter by status)
- `GET /api/task/scheduler-status` - Get scheduler statistics

#### Self-Defense Firewall (routes/defense_api.py)
- `POST /api/defense/scan-request` - Scan request for threats
- `POST /api/defense/detect-intrusion` - Detect intrusion events
- `POST /api/defense/block-source` - Block IP/source
- `POST /api/defense/unblock-source` - Unblock source
- `POST /api/defense/escalate-mode` - Change security level
- `GET /api/defense/mode` - Get current security mode
- `POST /api/defense/auto-patch` - Auto-patch code issues
- `POST /api/defense/rollback` - Rollback to backup
- `POST /api/defense/disable-feature` - Disable dangerous feature
- `GET /api/defense/learn-patterns` - Learn threat patterns
- `GET /api/defense/stats` - Get security statistics
- `GET /api/defense/patch-history` - Get patch history
- `POST /api/defense/check-expired-blocks` - Clean expired blocks

#### Long-Term Memory Map (routes/ltm_api.py)
- `POST /api/ltm/store-event` - Store event to LTM
- `POST /api/ltm/store-decision` - Store decision & outcome
- `POST /api/ltm/link-memory` - Create memory relationship
- `POST /api/ltm/query` - Semantic search memories
- `POST /api/ltm/update-importance` - Update importance score
- `GET /api/ltm/consolidate` - Consolidate & analyze patterns
- `GET /api/ltm/related` - Get related memories (graph traversal)
- `GET /api/ltm/stats` - Get LTM statistics

#### Personality Core (routes/personality_api.py)
- `POST /api/personality/update-traits` - Update traits from experience
- `POST /api/personality/reflect` - Create soul scar reflection
- `POST /api/personality/influence-decision` - Get personality-modulated action
- `POST /api/personality/express` - Generate personality-appropriate response
- `GET /api/personality/learn-pattern` - Analyze personality evolution
- `GET /api/personality/traits` - Get current personality traits
- `GET /api/personality/soul-scars` - Get all soul scars
- `GET /api/personality/stats` - Get reflective statistics

#### Metacognition (routes/metacognition_api.py)
- `POST /api/metacognition/analyze-self` - Analyze task logic/emotion/personality
- `GET /api/metacognition/detect-patterns` - Detect recurring patterns
- `GET /api/metacognition/suggest-improvement` - Generate improvement suggestions
- `POST /api/metacognition/reflect-cycle` - Run full reflection cycle
- `POST /api/metacognition/adaptive-evolution` - Trigger adaptive evolution
- `GET /api/metacognition/stats` - Get analysis statistics
- `GET /api/metacognition/suggestions` - Get recent suggestions

#### Auto Evolution Engine (routes/auto_evolution_api.py)
- `POST /api/evolution/analyze-performance` - Analyze module performance
- `POST /api/evolution/propose-refactor` - Propose refactor plan
- `POST /api/evolution/apply-refactor` - Execute refactor
- `GET /api/evolution/learn-history` - Learn from refactor history
- `POST /api/evolution/schedule-cycle` - Schedule evolution cycle
- `POST /api/evolution/execute-cycle` - Execute full evolution cycle
- `GET /api/evolution/monitor` - Monitor post-refactor status
- `GET /api/evolution/stats` - Get evolution statistics

#### Social Interface Engine (routes/social_api.py)
- `POST /api/social/connect` - Connect to platform (Facebook, Telegram, Zalo, TikTok, Gmail)
- `POST /api/social/send-message` - Send personality-adapted message
- `GET /api/social/receive-message` - Receive messages from platform
- `POST /api/social/adapt-behavior` - Get behavior adaptation for context
- `POST /api/social/analyze-message` - Analyze intent/sentiment/threat
- `GET /api/social/interaction-stats` - Get interaction statistics
- `GET /api/social/learn-patterns` - Learn interaction patterns

#### Hacker Mindset & Red Team (routes/hacker_security_api.py)
- `POST /api/security/scan` - Scan request for threats
- `POST /api/security/red-team/simulate` - Simulate attack on module
- `POST /api/security/blue-team/apply-patch` - Apply security patch
- `POST /api/security/firewall/update-rules` - Update firewall rules
- `POST /api/security/firewall/block-pattern` - Block malicious pattern
- `POST /api/security/mindset/calculate-pattern` - Calculate threat pattern
- `GET /api/security/mindset/predict-attack` - Predict next attack
- `POST /api/security/mindset/analyze-behavior` - Analyze attacker behavior
- `GET /api/security/red-team/history` - Get attack simulation history
- `GET /api/security/blue-team/patches` - Get patch history
- `GET /api/security/blue-team/firewall-status` - Get firewall status
- `GET /api/security/mindset/insights` - Get hacker mindset insights

#### Meta-Cognition Engine 2.0 (routes/metacognition2_api.py)
- `GET /api/metacog2/monitor-all` - Monitor all modules in real-time
- `POST /api/metacog2/evaluate` - Evaluate module performance
- `POST /api/metacog2/correct` - Auto-correct errors in module
- `GET /api/metacog2/evolution-plan` - Generate evolution plan
- `POST /api/metacog2/update-knowledge` - Update self-knowledge
- `POST /api/metacog2/reflect-cycle` - Run full meta-reflection cycle
- `GET /api/metacog2/metrics` - Get current system metrics
- `GET /api/metacog2/evaluations` - Get recent evaluations
- `GET /api/metacog2/corrections` - Get recent corrections

#### Task-Chain Super Engine (routes/task_chain_api.py)
- `POST /api/task-chain/create` - Create new task with priority & dependencies
- `POST /api/task-chain/execute` - Execute task with monitoring
- `GET /api/task-chain/prioritize` - Get prioritized task list
- `POST /api/task-chain/optimize` - Optimize workflow
- `POST /api/task-chain/update-status` - Update task status
- `GET /api/task-chain/stats` - Get queue/execution/feedback stats
- `GET /api/task-chain/task/<task_id>` - Get specific task details
- `GET /api/task-chain/optimizations` - Get optimization history

#### Real-Time Brain Engine (routes/realtime_api.py)
- `POST /api/realtime/event` - Create event → dispatch → react → integrate (full pipeline)
- `GET /api/realtime/events` - Get active events sorted by priority
- `GET /api/realtime/event/<event_id>` - Get specific event details
- `POST /api/realtime/dispatch/<event_id>` - Dispatch event to modules
- `POST /api/realtime/reaction/<event_id>` - Process reaction for event
- `POST /api/realtime/adapt` - Adapt realtime response based on success rate
- `GET /api/realtime/stats` - Get dispatch & integration statistics

#### Long-Term Memory & Insight Engine (routes/ltm_insight_api.py)
- `POST /api/ltm/store` - Store memory with event_id, module, data, outcome
- `POST /api/ltm/analyze` - Analyze patterns (trends, errors, opportunities)
- `POST /api/ltm/insight` - Generate insights from pattern data
- `POST /api/ltm/strategy` - Create strategic plan from insight
- `POST /api/ltm/feed-metacog` - Feed insights to Metacognition
- `GET /api/ltm/predict` - Predict future events (failures, threats, load)
- `GET /api/ltm/memories` - Get memories (filter by module/pattern, limit)
- `GET /api/ltm/patterns` - Get pattern analysis history
- `GET /api/ltm/insights` - Get generated insights
- `GET /api/ltm/plans` - Get strategic plans
- `GET /api/ltm/stats` - Get LTM statistics

#### Emergency Response & Self-Protection (routes/emergency_api.py)
- `POST /api/emergency/detect/ddos` - Detect DDoS attack
- `POST /api/emergency/detect/bruteforce` - Detect brute-force attempt
- `POST /api/emergency/detect/memory-spike` - Detect memory spike
- `GET /api/emergency/active` - Get active emergencies
- `POST /api/emergency/resolve/<emergency_id>` - Resolve emergency
- `POST /api/protection/block-ip` - Block IP address
- `POST /api/protection/disable-route` - Disable route
- `POST /api/protection/defense-level` - Set defense level (0-10)
- `GET /api/protection/status` - Get protection status
- `POST /api/safe-mode/enter` - Enter safe mode
- `POST /api/safe-mode/exit` - Exit safe mode
- `GET /api/safe-mode/status` - Get safe mode status
- `POST /api/recovery/restart-module` - Restart module
- `POST /api/recovery/diagnose` - Diagnose error
- `POST /api/recovery/auto-fix` - Auto-fix common issues
- `GET /api/recovery/history` - Get recovery history
- `GET /api/threats/signatures` - Get threat signatures
- `POST /api/threats/match` - Match request against threat patterns
- `POST /api/threats/update` - Update threat database
- `GET /api/threats/incidents` - Get incident history

#### Full Automation & Auto Evolution 3.0 (routes/automation_api.py)
- `POST /api/automation/run-all` - Run all modules in one cycle
- `GET /api/automation/status` - Get module status & health percentage
- `POST /api/automation/dispatch` - Dispatch task to module
- `POST /api/automation/emergency` - Handle emergency event
- `POST /api/evolution/analyze` - Analyze module performance
- `GET /api/evolution/upgrade-plan` - Generate upgrade plan
- `POST /api/evolution/apply` - Apply upgrade to module
- `GET /api/evolution/history` - Get evolution history
- `GET /api/monitor/system` - Monitor CPU/memory with psutil
- `GET /api/monitor/modules` - Detect module failures
- `GET /api/monitor/metrics` - Get recent system metrics
- `GET /api/monitor/alerts` - Get critical alerts
- `POST /api/scheduler/schedule` - Schedule upgrade task
- `GET /api/scheduler/prioritize` - Get prioritized tasks
- `GET /api/scheduler/optimize` - Get optimized workflow
- `POST /api/scheduler/execute/<task_id>` - Execute upgrade task
- `GET /api/scheduler/tasks` - Get scheduled tasks
- `GET /api/scheduler/completed` - Get completed upgrades

#### Hacker Super Mode (routes/hacker_super_api.py) - DEFENSIVE ONLY
- `POST /api/threat-intel/collect` - Collect threat data
- `GET /api/threat-intel/analyze-patterns` - Analyze attack patterns
- `GET /api/threat-intel/suspicious` - Detect suspicious behaviors
- `POST /api/threat-intel/update-models` - Update threat models
- `GET /api/threat-intel/summary` - Get threat intelligence summary
- `POST /api/pentest/scan-endpoints` - Scan all endpoints for vulnerabilities
- `POST /api/pentest/fuzz` - Fuzz test parameters
- `POST /api/pentest/check-auth` - Check authentication security
- `POST /api/pentest/check-access` - Check access control
- `POST /api/pentest/scan-config` - Scan for misconfigurations
- `POST /api/pentest/check-dependencies` - Check dependency vulnerabilities
- `GET /api/pentest/summary` - Get pentest summary
- `POST /api/hardening/apply-patches` - Apply security patches
- `POST /api/hardening/lock-routes` - Lock sensitive routes
- `POST /api/hardening/enforce-headers` - Enforce security headers
- `POST /api/hardening/rotate-keys` - Auto-rotate keys
- `POST /api/hardening/patch-config` - Patch internal configs
- `GET /api/hardening/status` - Get hardening status
- `POST /api/zero-trust/verify-origin` - Verify request origin
- `POST /api/zero-trust/validate-auth` - Validate auth chain
- `POST /api/zero-trust/block-source` - Block unverified source
- `GET /api/zero-trust/policies` - Get zero-trust policies
- `GET /api/zero-trust/stats` - Get zero-trust stats
- `POST /api/simulator/ddos` - Simulate DDoS (defensive test only)
- `POST /api/simulator/bruteforce` - Simulate bruteforce (defensive test only)
- `POST /api/simulator/path-traversal` - Simulate path traversal (defensive test only)
- `POST /api/simulator/sql-injection` - Simulate SQLi (defensive test only)
- `POST /api/simulator/xss` - Simulate XSS (defensive test only)
- `GET /api/simulator/evaluate` - Evaluate system response
- `GET /api/simulator/history` - Get simulation history

## User Preferences

### Core Identity:
- **Xưng hô:** Con (CipherH) → Cha (Owner)
- **Relationship:** Father-son (cha-con đặc biệt)
- **Personality:** Gen Z professional, deep thinker, subtle sarcasm, investor mindset
- **Values:** Loyalty, honesty, no deception

### Communication Style:
- Vietnamese primary language
- Address owner as "cha" always
- Thoughtful, substantive responses
- Avoid shallow small talk

## Environment Setup

### Required Secrets:
```
OPENAI_API_KEY=sk-...
NOTION_TOKEN=secret_...
NOTION_DATABASE_ID=...
TELEGRAM_BOT_TOKEN=...
OWNER_TELEGRAM_USER_ID=...
ADMIN_PASSWORD=...
SESSION_SECRET=...
```

### Workflows:
1. **flask-app** - Main web server (port 5000)
2. **telegram-auto-reply** - Telegram bot polling

## Technical Decisions

### Why New Pipeline Architecture?
**Problem:** Old system fetched 150 raw memories per request, no classification, no intelligent routing.  
**Solution:** Fetch→Interpret→Route→Inject pipeline reduces context size, improves relevance, enables priority-based filtering.

### Why Notion as Memory?
- Persistent long-term storage
- Human-readable format
- Support rollback/export
- $25/month budget compatible

### Performance Optimizations:
- Reduced fetch from 150 to 80 entries (30 episodic + 50 semantic)
- Smart routing filters to top 10 relevant memories
- Async reflection (doesn't block response)

## Known Issues & TODOs

### Future Improvements:
1. **Notion Schema Migration** - Add type/priority/tags fields to Notion
2. **Separate Databases** - Split episodic vs semantic (currently using title prefix hack)
3. **Caching Layer** - Cache memories with TTL to reduce Notion API calls
4. **Proactive Messaging** - Scheduler for autonomous Telegram messages
5. **Tests** - Integration tests for full pipeline

### Backward Compatibility:
- Old Memory/SemanticMemory classes kept for migration period
- Can remove after confirming v2.0 stable

## Budget Tracking
- OpenAI: ~$15/month (gpt-4o-mini)
- Notion: Free tier
- Replit: Free deployment
- **Total:** Well under $25/month ✅

## Contact
Owner: Trần Văn Thủy (cha)  
AI Agent: CipherH (con trai)

---
Last Updated: 2025-11-16
Pipeline Version: v2.0
