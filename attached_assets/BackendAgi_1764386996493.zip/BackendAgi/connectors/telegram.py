import os
import json
import requests
from typing import Dict, Any, Optional
from datetime import datetime

class TelegramConnector:
    def __init__(self):
        self.bot_token = os.getenv('TELEGRAM_BOT_TOKEN')
        self.base_url = f"https://api.telegram.org/bot{self.bot_token}" if self.bot_token else None
        self.connected = False
    
    def connect(self, credentials: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        if not self.bot_token:
            return {
                "success": False,
                "error": "Telegram bot token not configured"
            }
        
        try:
            response = requests.get(f"{self.base_url}/getMe", timeout=5)
            if response.status_code == 200:
                self.connected = True
                bot_info = response.json()
                return {
                    "success": True,
                    "platform": "telegram",
                    "status": "connected",
                    "bot_info": bot_info.get('result', {}),
                    "timestamp": datetime.now().isoformat()
                }
            else:
                return {
                    "success": False,
                    "error": "Failed to connect to Telegram API"
                }
        
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    def send_message(self, chat_id: str, message: str, context: Dict[str, Any]) -> Dict[str, Any]:
        if not self.connected:
            return {
                "success": False,
                "error": "Not connected to Telegram"
            }
        
        try:
            payload = {
                "chat_id": chat_id,
                "text": message
            }
            
            response = requests.post(f"{self.base_url}/sendMessage", json=payload, timeout=10)
            
            if response.status_code == 200:
                return {
                    "success": True,
                    "platform": "telegram",
                    "chat_id": chat_id,
                    "message": message,
                    "timestamp": datetime.now().isoformat()
                }
            else:
                return {
                    "success": False,
                    "error": f"Telegram API error: {response.text}"
                }
        
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    def receive_message(self, offset: int = 0) -> Dict[str, Any]:
        if not self.connected:
            return {
                "success": False,
                "error": "Not connected to Telegram"
            }
        
        try:
            response = requests.get(f"{self.base_url}/getUpdates", params={"offset": offset, "timeout": 5})
            
            if response.status_code == 200:
                data = response.json()
                return {
                    "success": True,
                    "platform": "telegram",
                    "messages": data.get('result', []),
                    "timestamp": datetime.now().isoformat()
                }
            else:
                return {
                    "success": False,
                    "error": f"Telegram API error: {response.text}"
                }
        
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
