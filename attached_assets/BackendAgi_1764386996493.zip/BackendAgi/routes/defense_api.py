from flask import Blueprint, request, jsonify
from defense.threat_scanner import ThreatScanner
from defense.engine import DefenseEngine
from defense.self_heal import SelfHeal

defense_bp = Blueprint('defense', __name__)
scanner = ThreatScanner()
engine = DefenseEngine()
healer = SelfHeal()

@defense_bp.route('/api/defense/scan-request', methods=['POST'])
def scan_request():
    try:
        data = request.json
        if not data:
            return jsonify({"error": "request data required"}), 400
        
        result = scanner.scan_request(data)
        
        if result['action'] in ['block', 'quarantine']:
            engine.defense_memory_log({
                "type": "threat_detected",
                "threat_score": result['threat_score'],
                "threats": result['threats'],
                "source": result.get('source'),
                "severity": "high" if result['action'] == 'block' else "medium"
            })
        
        return jsonify({
            "success": True,
            "scan_result": result
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@defense_bp.route('/api/defense/detect-intrusion', methods=['POST'])
def detect_intrusion():
    try:
        data = request.json
        if not data:
            return jsonify({"error": "event data required"}), 400
        
        result = scanner.detect_intrusion(data)
        
        if result['intrusion_detected']:
            engine.defense_memory_log({
                "type": "intrusion_detected",
                "intrusion_type": result['intrusion_type'],
                "severity": result['severity'],
                "source": result.get('source')
            })
            
            if result['severity'] == 'critical':
                engine.escalate_defense_mode('lockdown')
        
        return jsonify({
            "success": True,
            "intrusion": result
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@defense_bp.route('/api/defense/block-source', methods=['POST'])
def block_source():
    try:
        data = request.json
        if not data or 'source' not in data or 'reason' not in data:
            return jsonify({"error": "source and reason required"}), 400
        
        source = data['source']
        reason = data['reason']
        duration = data.get('duration')
        
        result = engine.block_source(source, reason, duration)
        
        engine.defense_memory_log({
            "type": "source_blocked",
            "source": source,
            "reason": reason,
            "severity": "high"
        })
        
        return jsonify({
            "success": True,
            "result": result
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@defense_bp.route('/api/defense/unblock-source', methods=['POST'])
def unblock_source():
    try:
        data = request.json
        if not data or 'source' not in data:
            return jsonify({"error": "source required"}), 400
        
        source = data['source']
        
        result = engine.unblock_source(source)
        
        return jsonify({
            "success": True,
            "result": result
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@defense_bp.route('/api/defense/escalate-mode', methods=['POST'])
def escalate_mode():
    try:
        data = request.json
        if not data or 'level' not in data:
            return jsonify({"error": "level required"}), 400
        
        level = data['level']
        
        result = engine.escalate_defense_mode(level)
        
        if 'error' not in result:
            engine.defense_memory_log({
                "type": "defense_mode_changed",
                "old_mode": result['old_mode'],
                "new_mode": result['new_mode'],
                "severity": "medium"
            })
        
        return jsonify({
            "success": 'error' not in result,
            "result": result
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@defense_bp.route('/api/defense/mode', methods=['GET'])
def get_mode():
    try:
        mode = engine.get_defense_mode()
        
        return jsonify({
            "success": True,
            "mode": mode
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@defense_bp.route('/api/defense/auto-patch', methods=['POST'])
def auto_patch():
    try:
        data = request.json
        if not data:
            return jsonify({"error": "issue data required"}), 400
        
        result = healer.auto_patch(data)
        
        engine.defense_memory_log({
            "type": "auto_patch",
            "issue_type": data.get('type'),
            "success": result['success'],
            "severity": "low" if result['success'] else "medium"
        })
        
        return jsonify({
            "success": True,
            "patch_result": result
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@defense_bp.route('/api/defense/rollback', methods=['POST'])
def rollback():
    try:
        data = request.json
        if not data or 'backup_path' not in data or 'target_path' not in data:
            return jsonify({"error": "backup_path and target_path required"}), 400
        
        result = healer.rollback_patch(data['backup_path'], data['target_path'])
        
        return jsonify({
            "success": result.get('success', False),
            "result": result
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@defense_bp.route('/api/defense/disable-feature', methods=['POST'])
def disable_feature():
    try:
        data = request.json
        if not data or 'feature_name' not in data:
            return jsonify({"error": "feature_name required"}), 400
        
        result = healer.disable_dangerous_feature(data['feature_name'])
        
        return jsonify({
            "success": True,
            "result": result
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@defense_bp.route('/api/defense/learn-patterns', methods=['GET'])
def learn_patterns():
    try:
        patterns = healer.learn_threat_patterns()
        
        return jsonify({
            "success": True,
            "patterns": patterns
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@defense_bp.route('/api/defense/stats', methods=['GET'])
def get_stats():
    try:
        stats = engine.get_security_stats()
        
        return jsonify({
            "success": True,
            "stats": stats
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@defense_bp.route('/api/defense/patch-history', methods=['GET'])
def patch_history():
    try:
        history = healer.get_patch_history()
        
        return jsonify({
            "success": True,
            "history": history
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@defense_bp.route('/api/defense/check-expired-blocks', methods=['POST'])
def check_expired():
    try:
        result = engine.check_expired_blocks()
        
        return jsonify({
            "success": True,
            "result": result
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500
