from flask import Blueprint, request, jsonify
from memory.memory_manager import MemoryManager

memory_bp = Blueprint('memory_engine', __name__)
manager = MemoryManager()

@memory_bp.route('/api/memory/save', methods=['POST'])
def save_memory():
    try:
        data = request.json
        if not data or 'data' not in data:
            return jsonify({"error": "data required"}), 400
        
        memory_data = data['data']
        importance_score = data.get('importance_score')
        
        result = manager.save_memory(memory_data, importance_score)
        
        return jsonify({
            "success": True,
            "result": result
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@memory_bp.route('/api/memory/load', methods=['POST'])
def load_memory():
    try:
        data = request.json
        if not data or 'query' not in data:
            return jsonify({"error": "query required"}), 400
        
        query = data['query']
        tier = data.get('tier')
        limit = data.get('limit', 10)
        
        memories = manager.load_relevant_memory(query, tier, limit)
        
        return jsonify({
            "success": True,
            "memories": memories,
            "count": len(memories)
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@memory_bp.route('/api/memory/upgrade', methods=['POST'])
def upgrade_memory():
    try:
        data = request.json
        if not data or 'memory_id' not in data:
            return jsonify({"error": "memory_id required"}), 400
        
        memory_id = data['memory_id']
        
        result = manager.upgrade_memory(memory_id)
        
        return jsonify({
            "success": True,
            "result": result
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@memory_bp.route('/api/memory/decay', methods=['POST'])
def decay_memory():
    try:
        result = manager.decay_memory()
        
        return jsonify({
            "success": True,
            "result": result
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@memory_bp.route('/api/memory/link', methods=['POST'])
def link_memory():
    try:
        data = request.json
        if not data or 'memory_id_a' not in data or 'memory_id_b' not in data:
            return jsonify({"error": "memory_id_a and memory_id_b required"}), 400
        
        memory_id_a = data['memory_id_a']
        memory_id_b = data['memory_id_b']
        
        result = manager.link_memory(memory_id_a, memory_id_b)
        
        return jsonify({
            "success": True,
            "result": result
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@memory_bp.route('/api/memory/reflect', methods=['POST'])
def reflection_cycle():
    try:
        result = manager.reflection_cycle()
        
        return jsonify({
            "success": True,
            "result": result
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@memory_bp.route('/api/memory/stats', methods=['GET'])
def get_stats():
    try:
        stats = manager.get_memory_stats()
        
        return jsonify({
            "success": True,
            "stats": stats
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@memory_bp.route('/api/memory/calculate-score', methods=['POST'])
def calculate_score():
    try:
        data = request.json
        if not data:
            return jsonify({"error": "data required"}), 400
        
        score = manager.calculate_importance_score(data)
        
        return jsonify({
            "success": True,
            "importance_score": score,
            "tier": "STM" if score <= 40 else "MTM" if score <= 70 else "LTM"
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500
