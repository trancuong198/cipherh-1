from flask import Blueprint, request, jsonify
from world.world_model import WorldModel

world_bp = Blueprint('world', __name__)
world_model = WorldModel()

@world_bp.route('/api/world/scan', methods=['POST'])
def scan_system():
    try:
        snapshot = world_model.scan_system_state()
        
        return jsonify({
            "success": True,
            "snapshot": snapshot
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@world_bp.route('/api/world/analyze-actor', methods=['POST'])
def analyze_actor():
    try:
        data = request.json
        if not data:
            return jsonify({"error": "event data required"}), 400
        
        actor = world_model.analyze_actors(data)
        
        return jsonify({
            "success": True,
            "actor": actor
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@world_bp.route('/api/world/predict-risk', methods=['POST'])
def predict_risk():
    try:
        data = request.json or {}
        
        prediction = world_model.predict_risk(data)
        
        return jsonify({
            "success": True,
            "prediction": prediction
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@world_bp.route('/api/world/decide-action', methods=['POST'])
def decide_action():
    try:
        data = request.json
        if not data:
            return jsonify({"error": "event data required"}), 400
        
        decision = world_model.decide_action(data)
        
        return jsonify({
            "success": True,
            "decision": decision
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@world_bp.route('/api/world/update', methods=['POST'])
def update_world():
    try:
        data = request.json
        if not data:
            return jsonify({"error": "event data required"}), 400
        
        result = world_model.update_world_model(data)
        
        return jsonify({
            "success": True,
            "result": result
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@world_bp.route('/api/world/current-state', methods=['GET'])
def get_current_state():
    try:
        state = world_model.get_current_state()
        
        return jsonify({
            "success": True,
            "state": state
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@world_bp.route('/api/world/actor-stats', methods=['GET'])
def get_actor_stats():
    try:
        stats = world_model.get_actor_stats()
        
        return jsonify({
            "success": True,
            "stats": stats
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500
