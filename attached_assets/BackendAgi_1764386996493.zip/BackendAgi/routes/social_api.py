from flask import Blueprint, request, jsonify
from social.behavior_adapter import BehaviorAdapter
from social.interaction_logger import InteractionLogger
from connectors.facebook import FacebookConnector
from connectors.telegram import TelegramConnector
from connectors.zalo import ZaloConnector
from connectors.tiktok import TikTokConnector
from connectors.gmail import GmailConnector

social_bp = Blueprint('social', __name__)
behavior_adapter = BehaviorAdapter()
interaction_logger = InteractionLogger()

connectors = {
    'facebook': FacebookConnector(),
    'telegram': TelegramConnector(),
    'zalo': ZaloConnector(),
    'tiktok': TikTokConnector(),
    'gmail': GmailConnector()
}

@social_bp.route('/api/social/connect', methods=['POST'])
def connect_platform():
    try:
        data = request.json
        if not data or 'platform' not in data:
            return jsonify({"error": "platform required"}), 400
        
        platform = data['platform']
        credentials = data.get('credentials')
        
        if platform not in connectors:
            return jsonify({"error": f"Unknown platform: {platform}"}), 400
        
        result = connectors[platform].connect(credentials)
        
        return jsonify(result)
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@social_bp.route('/api/social/send-message', methods=['POST'])
def send_message():
    try:
        data = request.json
        if not data or 'platform' not in data or 'message' not in data:
            return jsonify({"error": "platform and message required"}), 400
        
        platform = data['platform']
        message = data['message']
        context = data.get('context', {})
        
        if platform not in connectors:
            return jsonify({"error": f"Unknown platform: {platform}"}), 400
        
        context['platform'] = platform
        
        behavior = behavior_adapter.adapt_behavior(context)
        
        adapted_message = behavior_adapter.generate_response(message, context)
        
        if platform == 'gmail':
            result = connectors[platform].send_message(
                data.get('recipient', ''),
                data.get('subject', 'Message from CipherH'),
                adapted_message,
                context
            )
        else:
            result = connectors[platform].send_message(
                data.get('recipient_id', ''),
                adapted_message,
                context
            )
        
        interaction_logger.log_interaction({
            "platform": platform,
            "input": message,
            "output": adapted_message,
            "behavior": behavior,
            "intent": behavior_adapter.detect_intent(message)['primary_intent'],
            "sentiment": behavior_adapter.analyze_sentiment(message),
            "threat_score": behavior_adapter.calculate_threat_score(message, context),
            "success": result.get('success', False)
        })
        
        return jsonify({
            "success": True,
            "result": result,
            "behavior": behavior,
            "adapted_message": adapted_message
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@social_bp.route('/api/social/receive-message', methods=['GET'])
def receive_message():
    try:
        platform = request.args.get('platform')
        if not platform:
            return jsonify({"error": "platform required"}), 400
        
        if platform not in connectors:
            return jsonify({"error": f"Unknown platform: {platform}"}), 400
        
        offset = int(request.args.get('offset', 0))
        
        if platform == 'telegram':
            result = connectors[platform].receive_message(offset)
        else:
            result = connectors[platform].receive_message()
        
        return jsonify(result)
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@social_bp.route('/api/social/adapt-behavior', methods=['POST'])
def adapt_behavior():
    try:
        data = request.json
        if not data:
            return jsonify({"error": "input_context required"}), 400
        
        behavior = behavior_adapter.adapt_behavior(data)
        
        return jsonify({
            "success": True,
            "behavior": behavior
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@social_bp.route('/api/social/analyze-message', methods=['POST'])
def analyze_message():
    try:
        data = request.json
        if not data or 'message' not in data:
            return jsonify({"error": "message required"}), 400
        
        message = data['message']
        context = data.get('context', {})
        
        analysis = {
            "intent": behavior_adapter.detect_intent(message),
            "sentiment": behavior_adapter.analyze_sentiment(message),
            "threat_score": behavior_adapter.calculate_threat_score(message, context)
        }
        
        return jsonify({
            "success": True,
            "analysis": analysis
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@social_bp.route('/api/social/interaction-stats', methods=['GET'])
def interaction_stats():
    try:
        stats = interaction_logger.get_interaction_stats()
        
        return jsonify({
            "success": True,
            "stats": stats
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@social_bp.route('/api/social/learn-patterns', methods=['GET'])
def learn_patterns():
    try:
        patterns = interaction_logger.learn_interaction_pattern()
        
        return jsonify({
            "success": True,
            "patterns": patterns
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500
