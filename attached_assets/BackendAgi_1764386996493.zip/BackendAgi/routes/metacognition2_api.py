from flask import Blueprint, request, jsonify
from metacognition2.self_monitor import SelfMonitor
from metacognition2.reflection_evaluator import ReflectionEvaluator
from metacognition2.self_correction import SelfCorrection
from metacognition2.evolution_feedback import EvolutionFeedback

metacog2_bp = Blueprint('metacognition2', __name__)
monitor = SelfMonitor()
evaluator = ReflectionEvaluator()
corrector = SelfCorrection()
feedback = EvolutionFeedback()

@metacog2_bp.route('/api/metacog2/monitor-all', methods=['GET'])
def monitor_all():
    try:
        report = monitor.monitor_all_modules()
        
        return jsonify({
            "success": True,
            "report": report
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@metacog2_bp.route('/api/metacog2/evaluate', methods=['POST'])
def evaluate():
    try:
        data = request.json
        if not data or 'module' not in data:
            return jsonify({"error": "module name required"}), 400
        
        evaluation = evaluator.evaluate_performance(data['module'])
        
        return jsonify({
            "success": True,
            "evaluation": evaluation
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@metacog2_bp.route('/api/metacog2/correct', methods=['POST'])
def correct():
    try:
        data = request.json
        if not data or 'module' not in data or 'issue' not in data:
            return jsonify({"error": "module and issue required"}), 400
        
        correction = corrector.correct_errors(data['module'], data['issue'])
        
        return jsonify({
            "success": True,
            "correction": correction
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@metacog2_bp.route('/api/metacog2/evolution-plan', methods=['GET'])
def evolution_plan():
    try:
        plan = feedback.generate_evolution_plan()
        
        return jsonify({
            "success": True,
            "plan": plan
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@metacog2_bp.route('/api/metacog2/update-knowledge', methods=['POST'])
def update_knowledge():
    try:
        knowledge = feedback.update_self_knowledge()
        
        return jsonify({
            "success": True,
            "knowledge": knowledge
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@metacog2_bp.route('/api/metacog2/reflect-cycle', methods=['POST'])
def reflect_cycle():
    try:
        cycle = feedback.meta_reflect_cycle()
        
        return jsonify({
            "success": True,
            "cycle": cycle
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@metacog2_bp.route('/api/metacog2/metrics', methods=['GET'])
def get_metrics():
    try:
        metrics = monitor.get_current_metrics()
        
        return jsonify({
            "success": True,
            "metrics": metrics
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@metacog2_bp.route('/api/metacog2/evaluations', methods=['GET'])
def get_evaluations():
    try:
        evaluations = evaluator.get_evaluations()
        
        return jsonify({
            "success": True,
            "evaluations": evaluations,
            "count": len(evaluations)
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@metacog2_bp.route('/api/metacog2/corrections', methods=['GET'])
def get_corrections():
    try:
        corrections = corrector.get_corrections()
        
        return jsonify({
            "success": True,
            "corrections": corrections,
            "count": len(corrections)
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500
