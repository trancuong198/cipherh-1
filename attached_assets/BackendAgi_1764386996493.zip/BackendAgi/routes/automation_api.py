from flask import Blueprint, request, jsonify
from auto_evolution.automation_core import AutomationCore
from auto_evolution.evolution_engine import EvolutionEngine
from auto_evolution.self_monitor import SelfMonitor
from auto_evolution.upgrade_scheduler import UpgradeScheduler

automation_bp = Blueprint('automation', __name__)
automation = AutomationCore()
evolution = EvolutionEngine()
monitor = SelfMonitor()
scheduler = UpgradeScheduler()

@automation_bp.route('/api/automation/run-all', methods=['POST'])
def run_all_modules():
    try:
        result = automation.run_all_modules()
        
        return jsonify(result)
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@automation_bp.route('/api/automation/status', methods=['GET'])
def get_module_status():
    try:
        status = automation.monitor_module_status()
        
        return jsonify({
            "success": True,
            "status": status
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@automation_bp.route('/api/automation/dispatch', methods=['POST'])
def dispatch_task():
    try:
        data = request.json
        if not data or 'module' not in data or 'task' not in data:
            return jsonify({"error": "module and task required"}), 400
        
        result = automation.dispatch_task(data['module'], data['task'])
        
        return jsonify(result)
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@automation_bp.route('/api/automation/emergency', methods=['POST'])
def handle_emergency():
    try:
        data = request.json
        if not data:
            return jsonify({"error": "event data required"}), 400
        
        result = automation.handle_emergency(data)
        
        return jsonify(result)
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@automation_bp.route('/api/evolution/analyze', methods=['POST'])
def analyze_performance():
    try:
        data = request.json
        if not data or 'module' not in data:
            return jsonify({"error": "module name required"}), 400
        
        analysis = evolution.analyze_performance(data['module'])
        
        return jsonify({
            "success": True,
            "analysis": analysis
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@automation_bp.route('/api/evolution/upgrade-plan', methods=['GET'])
def generate_upgrade_plan():
    try:
        plan = evolution.generate_upgrade_plan()
        
        return jsonify({
            "success": True,
            "plan": plan
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@automation_bp.route('/api/evolution/apply', methods=['POST'])
def apply_upgrade():
    try:
        data = request.json
        if not data or 'module' not in data:
            return jsonify({"error": "module name required"}), 400
        
        result = evolution.apply_upgrade(data['module'])
        
        return jsonify(result)
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@automation_bp.route('/api/evolution/history', methods=['GET'])
def get_evolution_history():
    try:
        history = evolution.get_evolution_history()
        
        return jsonify({
            "success": True,
            "history": history,
            "count": len(history)
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@automation_bp.route('/api/monitor/system', methods=['GET'])
def monitor_system():
    try:
        metrics = monitor.monitor_cpu_memory()
        
        return jsonify({
            "success": True,
            "metrics": metrics
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@automation_bp.route('/api/monitor/modules', methods=['GET'])
def detect_failures():
    try:
        failures = monitor.detect_module_failure()
        
        return jsonify({
            "success": True,
            "failures": failures
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@automation_bp.route('/api/monitor/metrics', methods=['GET'])
def get_metrics():
    try:
        metrics = monitor.get_recent_metrics()
        
        return jsonify({
            "success": True,
            "metrics": metrics,
            "count": len(metrics)
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@automation_bp.route('/api/monitor/alerts', methods=['GET'])
def get_alerts():
    try:
        alerts = monitor.get_alerts()
        
        return jsonify({
            "success": True,
            "alerts": alerts,
            "count": len(alerts)
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@automation_bp.route('/api/scheduler/schedule', methods=['POST'])
def schedule_upgrade():
    try:
        data = request.json
        if not data:
            return jsonify({"error": "task data required"}), 400
        
        result = scheduler.schedule_upgrade(data)
        
        return jsonify(result)
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@automation_bp.route('/api/scheduler/prioritize', methods=['GET'])
def prioritize_tasks():
    try:
        tasks = scheduler.prioritize_upgrade_tasks()
        
        return jsonify({
            "success": True,
            "tasks": tasks,
            "count": len(tasks)
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@automation_bp.route('/api/scheduler/optimize', methods=['GET'])
def optimize_workflow():
    try:
        workflow = scheduler.optimize_upgrade_workflow()
        
        return jsonify({
            "success": True,
            "workflow": workflow
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@automation_bp.route('/api/scheduler/execute/<task_id>', methods=['POST'])
def execute_task(task_id):
    try:
        result = scheduler.execute_upgrade_task(task_id)
        
        return jsonify(result)
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@automation_bp.route('/api/scheduler/tasks', methods=['GET'])
def get_scheduled():
    try:
        tasks = scheduler.get_scheduled_tasks()
        
        return jsonify({
            "success": True,
            "tasks": tasks,
            "count": len(tasks)
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@automation_bp.route('/api/scheduler/completed', methods=['GET'])
def get_completed():
    try:
        completed = scheduler.get_completed_upgrades()
        
        return jsonify({
            "success": True,
            "completed": completed,
            "count": len(completed)
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500
