from flask import Blueprint, request, jsonify
from ltm.memory_storage import MemoryStorage
from ltm.pattern_analyzer import PatternAnalyzer
from ltm.insight_generator import InsightGenerator
from ltm.strategic_planner import StrategicPlanner

ltm_insight_bp = Blueprint('ltm_insight', __name__)
storage = MemoryStorage()
analyzer = PatternAnalyzer()
generator = InsightGenerator()
planner = StrategicPlanner()

@ltm_insight_bp.route('/api/ltm/store', methods=['POST'])
def store_memory():
    try:
        data = request.json
        if not data or 'event_id' not in data or 'module' not in data or 'data' not in data or 'outcome' not in data:
            return jsonify({"error": "event_id, module, data, and outcome required"}), 400
        
        memory = storage.store_memory(
            data['event_id'],
            data['module'],
            data['data'],
            data['outcome']
        )
        
        return jsonify({
            "success": True,
            "memory": memory
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@ltm_insight_bp.route('/api/ltm/analyze', methods=['POST'])
def analyze_patterns():
    try:
        analysis = analyzer.analyze_patterns()
        
        return jsonify({
            "success": True,
            "analysis": analysis
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@ltm_insight_bp.route('/api/ltm/insight', methods=['POST'])
def generate_insight():
    try:
        data = request.json
        if not data or 'pattern_data' not in data:
            patterns = analyzer.get_patterns()
            if not patterns:
                return jsonify({"error": "No pattern data available"}), 400
            pattern_data = patterns[-1]
        else:
            pattern_data = data['pattern_data']
        
        insight = generator.generate_insight(pattern_data)
        
        return jsonify({
            "success": True,
            "insight": insight
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@ltm_insight_bp.route('/api/ltm/strategy', methods=['POST'])
def plan_strategy():
    try:
        data = request.json
        if not data or 'insight' not in data:
            insights = generator.get_insights()
            if not insights:
                return jsonify({"error": "No insight data available"}), 400
            insight = insights[-1]
        else:
            insight = data['insight']
        
        plan = planner.plan_strategy(insight)
        
        return jsonify({
            "success": True,
            "plan": plan
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@ltm_insight_bp.route('/api/ltm/feed-metacog', methods=['POST'])
def feed_metacognition():
    try:
        feedback = generator.feed_to_metacognition()
        
        return jsonify({
            "success": True,
            "feedback": feedback
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@ltm_insight_bp.route('/api/ltm/predict', methods=['GET'])
def predict_events():
    try:
        prediction = planner.predict_future_events()
        
        return jsonify({
            "success": True,
            "prediction": prediction
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@ltm_insight_bp.route('/api/ltm/memories', methods=['GET'])
def get_memories():
    try:
        module = request.args.get('module')
        pattern = request.args.get('pattern')
        limit = int(request.args.get('limit', 50))
        
        memories = storage.get_memories(module, pattern, limit)
        
        return jsonify({
            "success": True,
            "memories": memories,
            "count": len(memories)
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@ltm_insight_bp.route('/api/ltm/patterns', methods=['GET'])
def get_patterns():
    try:
        patterns = analyzer.get_patterns()
        
        return jsonify({
            "success": True,
            "patterns": patterns,
            "count": len(patterns)
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@ltm_insight_bp.route('/api/ltm/insights', methods=['GET'])
def get_insights():
    try:
        insights = generator.get_insights()
        
        return jsonify({
            "success": True,
            "insights": insights,
            "count": len(insights)
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@ltm_insight_bp.route('/api/ltm/plans', methods=['GET'])
def get_plans():
    try:
        plans = planner.get_plans()
        
        return jsonify({
            "success": True,
            "plans": plans,
            "count": len(plans)
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@ltm_insight_bp.route('/api/ltm/stats', methods=['GET'])
def get_stats():
    try:
        stats = storage.get_stats()
        
        return jsonify({
            "success": True,
            "stats": stats
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500
