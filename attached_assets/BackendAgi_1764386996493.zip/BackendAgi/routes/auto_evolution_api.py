from flask import Blueprint, request, jsonify
from evolution.refactor_engine import RefactorEngine
from evolution.evolution_scheduler import EvolutionScheduler

auto_evo_bp = Blueprint('auto_evolution', __name__)
refactor_engine = RefactorEngine()
scheduler = EvolutionScheduler()

@auto_evo_bp.route('/api/evolution/analyze-performance', methods=['POST'])
def analyze_performance():
    try:
        data = request.json
        if not data or 'module' not in data:
            return jsonify({"error": "module name required"}), 400
        
        analysis = refactor_engine.analyze_performance(data['module'])
        
        return jsonify({
            "success": True,
            "analysis": analysis
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@auto_evo_bp.route('/api/evolution/propose-refactor', methods=['POST'])
def propose_refactor():
    try:
        data = request.json
        if not data or 'module' not in data:
            return jsonify({"error": "module name required"}), 400
        
        plan = refactor_engine.propose_refactor(data['module'])
        
        return jsonify({
            "success": True,
            "refactor_plan": plan
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@auto_evo_bp.route('/api/evolution/apply-refactor', methods=['POST'])
def apply_refactor():
    try:
        data = request.json
        if not data or 'module' not in data or 'refactor_plan' not in data:
            return jsonify({"error": "module and refactor_plan required"}), 400
        
        result = refactor_engine.apply_refactor(data['module'], data['refactor_plan'])
        
        return jsonify({
            "success": True,
            "result": result
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@auto_evo_bp.route('/api/evolution/learn-history', methods=['GET'])
def learn_history():
    try:
        learning = refactor_engine.learn_from_history()
        
        return jsonify({
            "success": True,
            "learning": learning
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@auto_evo_bp.route('/api/evolution/schedule-cycle', methods=['POST'])
def schedule_cycle():
    try:
        plan = scheduler.schedule_evolution_cycle()
        
        return jsonify({
            "success": True,
            "evolution_plan": plan
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@auto_evo_bp.route('/api/evolution/execute-cycle', methods=['POST'])
def execute_cycle():
    try:
        results = scheduler.execute_evolution_cycle()
        
        return jsonify({
            "success": True,
            "results": results
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@auto_evo_bp.route('/api/evolution/monitor', methods=['GET'])
def monitor_refactor():
    try:
        refactor_id = request.args.get('refactor_id')
        if not refactor_id:
            return jsonify({"error": "refactor_id required"}), 400
        
        monitoring = refactor_engine.monitor_post_refactor(refactor_id)
        
        return jsonify({
            "success": True,
            "monitoring": monitoring
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@auto_evo_bp.route('/api/evolution/stats', methods=['GET'])
def get_stats():
    try:
        stats = scheduler.get_evolution_stats()
        
        return jsonify({
            "success": True,
            "stats": stats
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500
