from flask import Blueprint, request, jsonify
from long_term.memory_map import LongTermMemoryMap

ltm_bp = Blueprint('ltm', __name__)
ltm = LongTermMemoryMap()

@ltm_bp.route('/api/ltm/store-event', methods=['POST'])
def store_event():
    try:
        data = request.json
        if not data:
            return jsonify({"error": "event data required"}), 400
        
        event = ltm.store_event(data)
        
        return jsonify({
            "success": True,
            "event": event
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@ltm_bp.route('/api/ltm/store-decision', methods=['POST'])
def store_decision():
    try:
        data = request.json
        if not data or 'event_id' not in data or 'action' not in data or 'result' not in data:
            return jsonify({"error": "event_id, action, and result required"}), 400
        
        decision = ltm.store_decision(
            data['event_id'],
            data['action'],
            data['result']
        )
        
        return jsonify({
            "success": True,
            "decision": decision
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@ltm_bp.route('/api/ltm/link-memory', methods=['POST'])
def link_memory():
    try:
        data = request.json
        if not data or 'memory_id_1' not in data or 'memory_id_2' not in data:
            return jsonify({"error": "memory_id_1 and memory_id_2 required"}), 400
        
        relationship = data.get('relationship', 'related')
        
        result = ltm.link_memory(
            data['memory_id_1'],
            data['memory_id_2'],
            relationship
        )
        
        return jsonify({
            "success": True,
            "link": result
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@ltm_bp.route('/api/ltm/query', methods=['POST'])
def query_memory():
    try:
        data = request.json
        if not data or 'query' not in data:
            return jsonify({"error": "query required"}), 400
        
        query = data['query']
        limit = data.get('limit', 10)
        
        results = ltm.query_memory(query, limit)
        
        return jsonify({
            "success": True,
            "results": results
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@ltm_bp.route('/api/ltm/update-importance', methods=['POST'])
def update_importance():
    try:
        data = request.json
        if not data or 'memory_id' not in data or 'score_delta' not in data:
            return jsonify({"error": "memory_id and score_delta required"}), 400
        
        result = ltm.update_importance(
            data['memory_id'],
            data['score_delta']
        )
        
        return jsonify({
            "success": result.get('status') == 'updated',
            "result": result
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@ltm_bp.route('/api/ltm/consolidate', methods=['GET'])
def consolidate():
    try:
        patterns = ltm.consolidate_memories()
        
        return jsonify({
            "success": True,
            "patterns": patterns
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@ltm_bp.route('/api/ltm/related', methods=['GET'])
def get_related():
    try:
        memory_id = request.args.get('memory_id')
        if not memory_id:
            return jsonify({"error": "memory_id required"}), 400
        
        depth = int(request.args.get('depth', 2))
        
        result = ltm.get_related_memories(memory_id, depth)
        
        return jsonify({
            "success": result.get('status') != 'not_found',
            "result": result
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@ltm_bp.route('/api/ltm/stats', methods=['GET'])
def get_stats():
    try:
        stats = ltm.get_statistics()
        
        return jsonify({
            "success": True,
            "stats": stats
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500
