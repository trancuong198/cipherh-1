from flask import Blueprint, jsonify, request, session
from functools import wraps
from utils.consolidator import KnowledgeConsolidator
from utils.planner import AutonomousPlanner
from utils.semantic_memory import SemanticMemory
from utils.telegram_bot import TelegramBot
from utils.brain import Brain
from memory import MemoryPipeline
import os

admin_bp = Blueprint('admin', __name__)

ADMIN_PASSWORD = os.getenv('ADMIN_PASSWORD', 'cipherh-admin-2025')

def require_admin_auth(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get('admin_authenticated'):
            return jsonify({"error": "Unauthorized. Set ADMIN_PASSWORD and authenticate first."}), 401
        return f(*args, **kwargs)
    return decorated_function

@admin_bp.route('/api/admin/login', methods=['POST'])
def admin_login():
    data = request.json if request.is_json else {}
    password = data.get('password', '')
    
    if password == ADMIN_PASSWORD:
        session['admin_authenticated'] = True
        return jsonify({"success": True, "message": "Admin authenticated"})
    else:
        return jsonify({"error": "Invalid password"}), 401

@admin_bp.route('/api/admin/logout', methods=['POST'])
def admin_logout():
    session.pop('admin_authenticated', None)
    return jsonify({"success": True, "message": "Logged out"})

@admin_bp.route('/api/admin/pipeline-stats', methods=['GET'])
@require_admin_auth
def get_pipeline_stats():
    try:
        pipeline = MemoryPipeline()
        stats = pipeline.get_stats()
        
        return jsonify({
            "success": True,
            "pipeline_version": "v2.0",
            "stats": stats
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@admin_bp.route('/api/admin/consolidate', methods=['POST'])
@require_admin_auth
def consolidate_knowledge():
    try:
        consolidator = KnowledgeConsolidator()
        
        limit = 20
        if request.is_json and request.json:
            limit = request.json.get('limit', 20)
        
        created_knowledge = consolidator.consolidate_recent_reflections(limit=limit)
        
        return jsonify({
            "success": True,
            "knowledge_created": len(created_knowledge),
            "entries": created_knowledge
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@admin_bp.route('/api/admin/create-learning-plan', methods=['POST'])
@require_admin_auth
def create_learning_plan():
    try:
        planner = AutonomousPlanner()
        
        assessment = planner.assess_current_state()
        plan = planner.create_learning_plan(assessment)
        
        return jsonify({
            "success": True,
            "assessment": assessment,
            "plan": plan
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@admin_bp.route('/api/admin/semantic-knowledge', methods=['GET'])
@require_admin_auth
def get_semantic_knowledge():
    try:
        semantic_memory = SemanticMemory()
        
        topic = request.args.get('topic')
        limit = int(request.args.get('limit', 20))
        
        knowledge = semantic_memory.retrieve_knowledge(topic=topic, limit=limit)
        topics = semantic_memory.get_all_topics()
        
        return jsonify({
            "total_entries": len(knowledge),
            "topics": topics,
            "knowledge": knowledge
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@admin_bp.route('/api/admin/active-plan', methods=['GET'])
@require_admin_auth
def get_active_plan():
    try:
        planner = AutonomousPlanner()
        
        plan = planner.get_active_plan()
        
        if not plan:
            return jsonify({
                "active_plan": None,
                "message": "No active plan. Create one using /api/admin/create-learning-plan"
            })
        
        return jsonify({
            "active_plan": plan
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@admin_bp.route('/api/admin/next-action', methods=['GET'])
@require_admin_auth
def suggest_next_action():
    try:
        planner = AutonomousPlanner()
        
        suggestion = planner.suggest_next_action()
        
        return jsonify({
            "suggestion": suggestion
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@admin_bp.route('/api/admin/stats', methods=['GET'])
@require_admin_auth
def get_system_stats():
    try:
        consolidator = KnowledgeConsolidator()
        
        summary = consolidator.get_consolidation_summary()
        
        return jsonify({
            "semantic_memory": summary,
            "status": "Autonomous learning system active"
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@admin_bp.route('/api/telegram/status', methods=['GET'])
@require_admin_auth
def telegram_status():
    try:
        bot = TelegramBot()
        result = bot.get_me()
        
        if result.get('ok'):
            bot_info = result.get('result', {})
            return jsonify({
                "configured": True,
                "bot_username": bot_info.get('username'),
                "bot_name": bot_info.get('first_name'),
                "bot_id": bot_info.get('id')
            })
        else:
            error = result.get('error', 'Unknown error')
            if 'not configured' in error.lower():
                return jsonify({
                    "configured": False,
                    "setup_instructions": "Add TELEGRAM_BOT_TOKEN to Replit Secrets"
                })
            return jsonify({"configured": False, "error": error}), 400
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@admin_bp.route('/api/telegram/send', methods=['POST'])
@require_admin_auth
def telegram_send_message():
    try:
        data = request.form if request.form else request.json
        if not data:
            return jsonify({"error": "No data provided"}), 400
        
        chat_id = data.get('chat_id')
        message = data.get('message', '')
        use_ai = data.get('use_ai', False)
        prompt = data.get('prompt', '')
        
        if not chat_id:
            return jsonify({"error": "Missing chat_id"}), 400
        
        if use_ai and prompt:
            safe_prompt = (prompt[:300]
                .replace("\n", " ")
                .replace("\r", " ")
                .replace("```", "")
                .strip())
            
            brain = Brain()
            ai_response = brain.chat(
                f"""Viết tin nhắn Telegram ngắn gọn (max 100 từ) về:

{safe_prompt}

Message:""",
                ""
            )
            message = ai_response[:4000]
        
        if not message:
            return jsonify({"error": "Missing message"}), 400
        
        bot = TelegramBot()
        result = bot.send_message(int(chat_id), message)
        
        if result.get('ok'):
            result_data = result.get('result', {})
            return jsonify({
                "success": True,
                "message_id": result_data.get('message_id')
            })
        else:
            return jsonify({"error": result.get('error')}), 400
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@admin_bp.route('/api/telegram/updates', methods=['GET'])
@require_admin_auth
def telegram_get_updates():
    try:
        bot = TelegramBot()
        offset = request.args.get('offset', type=int)
        limit = request.args.get('limit', 10, type=int)
        
        result = bot.get_updates(offset=offset, limit=limit)
        
        if result.get('ok'):
            updates = result.get('result', [])
            formatted_updates = []
            
            for update in updates:
                if 'message' in update:
                    msg = update['message']
                    formatted_updates.append({
                        'update_id': update.get('update_id'),
                        'message_id': msg.get('message_id'),
                        'chat_id': msg.get('chat', {}).get('id'),
                        'chat_type': msg.get('chat', {}).get('type'),
                        'from_name': msg.get('from', {}).get('first_name'),
                        'from_username': msg.get('from', {}).get('username'),
                        'text': msg.get('text', ''),
                        'date': msg.get('date')
                    })
            
            return jsonify({
                "success": True,
                "updates": formatted_updates
            })
        else:
            return jsonify({"error": result.get('error')}), 400
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@admin_bp.route('/api/telegram/reply', methods=['POST'])
@require_admin_auth
def telegram_reply_message():
    try:
        data = request.form if request.form else request.json
        if not data:
            return jsonify({"error": "No data provided"}), 400
        
        chat_id = data.get('chat_id')
        reply_to_id = data.get('reply_to_message_id')
        message = data.get('message', '')
        use_ai = data.get('use_ai', False)
        original_text = data.get('original_text', '')
        
        if not chat_id:
            return jsonify({"error": "Missing chat_id"}), 400
        
        if use_ai and original_text:
            safe_text = (original_text[:300]
                .replace("\n", " ")
                .replace("\r", " ")
                .replace("```", "")
                .strip())
            
            brain = Brain()
            ai_response = brain.chat(
                f"""Trả lời tin nhắn Telegram này ngắn gọn (max 80 từ):

{safe_text}

Reply:""",
                ""
            )
            message = ai_response[:1000]
        
        if not message:
            return jsonify({"error": "Missing message"}), 400
        
        bot = TelegramBot()
        result = bot.send_message(
            int(chat_id),
            message,
            reply_to_message_id=int(reply_to_id) if reply_to_id else None
        )
        
        if result.get('ok'):
            result_data = result.get('result', {})
            return jsonify({
                "success": True,
                "message_id": result_data.get('message_id')
            })
        else:
            return jsonify({"error": result.get('error')}), 400
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500
