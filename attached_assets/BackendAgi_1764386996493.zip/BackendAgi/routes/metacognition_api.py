from flask import Blueprint, request, jsonify
from metacognition.reflection_cycle import Metacognition

metacog_bp = Blueprint('metacognition', __name__)
metacog = Metacognition()

@metacog_bp.route('/api/metacognition/analyze-self', methods=['POST'])
def analyze_self():
    try:
        data = request.json
        if not data or 'task_id' not in data:
            return jsonify({"error": "task_id required"}), 400
        
        analysis = metacog.analyze_self(data['task_id'])
        
        return jsonify({
            "success": True,
            "analysis": analysis
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@metacog_bp.route('/api/metacognition/detect-patterns', methods=['GET'])
def detect_patterns():
    try:
        patterns = metacog.detect_patterns()
        
        return jsonify({
            "success": True,
            "patterns": patterns
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@metacog_bp.route('/api/metacognition/suggest-improvement', methods=['GET'])
def suggest_improvement():
    try:
        suggestions = metacog.suggest_improvement()
        
        return jsonify({
            "success": True,
            "suggestions": suggestions
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@metacog_bp.route('/api/metacognition/reflect-cycle', methods=['POST'])
def reflect_cycle():
    try:
        reflection = metacog.reflect_cycle()
        
        return jsonify({
            "success": True,
            "reflection": reflection
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@metacog_bp.route('/api/metacognition/adaptive-evolution', methods=['POST'])
def adaptive_evolution():
    try:
        evolution = metacog.adaptive_evolution()
        
        return jsonify({
            "success": True,
            "evolution": evolution
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@metacog_bp.route('/api/metacognition/stats', methods=['GET'])
def get_stats():
    try:
        stats = metacog.get_analysis_stats()
        
        return jsonify({
            "success": True,
            "stats": stats
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@metacog_bp.route('/api/metacognition/suggestions', methods=['GET'])
def get_suggestions():
    try:
        suggestions = metacog.get_suggestions()
        
        return jsonify({
            "success": True,
            "suggestions": suggestions,
            "count": len(suggestions)
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500
