import os
import json
from typing import Dict, Any, List, Optional
from datetime import datetime

class StrategicPlanner:
    def __init__(self):
        self.ltm_dir = 'ltm'
        self.plans_file = os.path.join(self.ltm_dir, 'strategic_plans.json')
        
        os.makedirs(self.ltm_dir, exist_ok=True)
        
        self._init_plans()
    
    def _init_plans(self):
        if not os.path.exists(self.plans_file):
            with open(self.plans_file, 'w') as f:
                json.dump({
                    "plans": [],
                    "total_plans": 0
                }, f, indent=2)
    
    def plan_strategy(self, insight: Dict[str, Any]) -> Dict[str, Any]:
        plan = {
            "id": f"plan_{self._get_next_id()}",
            "timestamp": datetime.now().isoformat(),
            "based_on_insight": insight.get('id', 'unknown'),
            "roadmap": [],
            "task_prioritization": [],
            "evolution_plan": [],
            "social_strategy": [],
            "security_strategy": []
        }
        
        recommendations = insight.get('recommendations', [])
        conclusions = insight.get('conclusions', [])
        
        for rec in recommendations:
            action = rec.get('action', '')
            target = rec.get('target', 'general')
            priority = rec.get('priority', 'medium')
            
            if 'evolution' in action:
                plan['evolution_plan'].append({
                    "action": action,
                    "target": target,
                    "priority": priority,
                    "estimated_impact": "high"
                })
                plan['roadmap'].append(f"Evolve {target} module")
            
            elif 'optimize' in action:
                plan['task_prioritization'].append({
                    "task": f"optimize_{target}",
                    "priority": 75,
                    "deadline": "48h"
                })
                plan['roadmap'].append(f"Optimize {target}")
            
            elif 'fix' in action:
                plan['task_prioritization'].append({
                    "task": f"fix_{rec.get('pattern', 'error')}",
                    "priority": 90,
                    "deadline": "24h"
                })
                plan['roadmap'].append(f"Fix recurring issue: {rec.get('pattern', 'unknown')}")
        
        for conclusion in conclusions:
            ctype = conclusion.get('type', '')
            
            if ctype == 'social_activity':
                plan['social_strategy'].append({
                    "strategy": "enhance_engagement",
                    "focus": "personality_adjustment",
                    "goal": "improve_interaction_quality"
                })
            
            elif ctype == 'security_activity':
                plan['security_strategy'].append({
                    "strategy": "strengthen_defense",
                    "focus": "proactive_monitoring",
                    "goal": "reduce_threat_exposure"
                })
        
        if not plan['social_strategy']:
            plan['social_strategy'].append({
                "strategy": "maintain_current",
                "focus": "consistency",
                "goal": "stable_interactions"
            })
        
        if not plan['security_strategy']:
            plan['security_strategy'].append({
                "strategy": "routine_monitoring",
                "focus": "threat_detection",
                "goal": "early_warning"
            })
        
        with open(self.plans_file, 'r') as f:
            plans_data = json.load(f)
        
        plans_data['plans'].append(plan)
        plans_data['total_plans'] += 1
        
        if len(plans_data['plans']) > 100:
            plans_data['plans'] = plans_data['plans'][-100:]
        
        with open(self.plans_file, 'w') as f:
            json.dump(plans_data, f, indent=2)
        
        return plan
    
    def predict_future_events(self) -> Dict[str, Any]:
        memories = self._get_memories()
        patterns = self._get_patterns()
        
        prediction = {
            "timestamp": datetime.now().isoformat(),
            "predictions": [],
            "confidence": 70
        }
        
        if patterns:
            latest_pattern = patterns[-1]
            
            for trend in latest_pattern.get('trends', []):
                if trend['type'] == 'low_performance':
                    prediction['predictions'].append({
                        "type": "module_failure_risk",
                        "module": trend['module'],
                        "likelihood": "high",
                        "timeframe": "next_24h",
                        "recommendation": "preemptive_fix"
                    })
            
            for error in latest_pattern.get('recurring_errors', []):
                prediction['predictions'].append({
                    "type": "error_recurrence",
                    "pattern": error['pattern'],
                    "likelihood": "very_high",
                    "timeframe": "next_12h",
                    "recommendation": "immediate_investigation"
                })
        
        social_count = len([m for m in memories[-50:] if 'social' in m.get('module_origin', '')])
        if social_count > 15:
            prediction['predictions'].append({
                "type": "high_social_load",
                "likelihood": "medium",
                "timeframe": "next_6h",
                "recommendation": "prepare_response_templates"
            })
        
        security_count = len([m for m in memories[-50:] if 'security' in m.get('module_origin', '') or 'threat' in m.get('pattern_tag', '')])
        if security_count > 10:
            prediction['predictions'].append({
                "type": "security_threat",
                "likelihood": "high",
                "timeframe": "next_12h",
                "recommendation": "increase_alertness"
            })
        
        return prediction
    
    def _get_memories(self) -> List[Dict[str, Any]]:
        storage_file = 'ltm/memories.json'
        
        if not os.path.exists(storage_file):
            return []
        
        try:
            with open(storage_file, 'r') as f:
                storage = json.load(f)
            return storage.get('memories', [])
        except Exception:
            return []
    
    def _get_patterns(self) -> List[Dict[str, Any]]:
        patterns_file = 'ltm/patterns.json'
        
        if not os.path.exists(patterns_file):
            return []
        
        try:
            with open(patterns_file, 'r') as f:
                patterns_data = json.load(f)
            return patterns_data.get('patterns', [])
        except Exception:
            return []
    
    def _get_next_id(self) -> int:
        with open(self.plans_file, 'r') as f:
            plans_data = json.load(f)
        return plans_data['total_plans'] + 1
    
    def get_plans(self) -> List[Dict[str, Any]]:
        with open(self.plans_file, 'r') as f:
            plans_data = json.load(f)
        return plans_data.get('plans', [])[-20:]
