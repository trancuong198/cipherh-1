import os
import json
from typing import Dict, Any, List, Optional
from datetime import datetime

class InsightGenerator:
    def __init__(self):
        self.ltm_dir = 'ltm'
        self.insights_file = os.path.join(self.ltm_dir, 'insights.json')
        
        os.makedirs(self.ltm_dir, exist_ok=True)
        
        self._init_insights()
    
    def _init_insights(self):
        if not os.path.exists(self.insights_file):
            with open(self.insights_file, 'w') as f:
                json.dump({
                    "insights": [],
                    "total_insights": 0
                }, f, indent=2)
    
    def generate_insight(self, pattern_data: Dict[str, Any]) -> Dict[str, Any]:
        insight = {
            "id": f"insight_{self._get_next_id()}",
            "timestamp": datetime.now().isoformat(),
            "source_pattern": pattern_data.get('id', 'unknown'),
            "conclusions": [],
            "recommendations": [],
            "feed_targets": []
        }
        
        trends = pattern_data.get('trends', [])
        errors = pattern_data.get('recurring_errors', [])
        opportunities = pattern_data.get('opportunities', [])
        
        for trend in trends:
            if trend['type'] == 'high_performance':
                insight['conclusions'].append({
                    "type": "success_pattern",
                    "module": trend['module'],
                    "message": f"{trend['module']} performing excellently ({trend['success_rate']}%)",
                    "confidence": trend['confidence']
                })
                insight['recommendations'].append({
                    "action": "maintain_strategy",
                    "target": trend['module']
                })
            
            elif trend['type'] == 'low_performance':
                insight['conclusions'].append({
                    "type": "performance_issue",
                    "module": trend['module'],
                    "message": f"{trend['module']} needs improvement ({trend['success_rate']}%)",
                    "confidence": trend['confidence']
                })
                insight['recommendations'].append({
                    "action": "trigger_evolution",
                    "target": trend['module'],
                    "priority": "high"
                })
                insight['feed_targets'].append("auto_evolution")
        
        for error in errors:
            insight['conclusions'].append({
                "type": "recurring_error",
                "pattern": error['pattern'],
                "message": f"Recurring error pattern: {error['pattern']} ({error['occurrences']} times)",
                "severity": error['severity']
            })
            insight['recommendations'].append({
                "action": "fix_recurring_issue",
                "pattern": error['pattern'],
                "priority": "critical" if error['severity'] == 'high' else "high"
            })
            insight['feed_targets'].extend(["metacognition2", "auto_evolution"])
        
        for opp in opportunities:
            if opp['type'] == 'improvement_potential':
                insight['conclusions'].append({
                    "type": "optimization_opportunity",
                    "module": opp['module'],
                    "message": f"{opp['module']} can improve by {opp['potential_gain']}",
                    "current": opp['current_performance']
                })
                insight['recommendations'].append({
                    "action": "optimize_module",
                    "target": opp['module'],
                    "priority": "medium"
                })
                insight['feed_targets'].append("task_chain")
            
            elif opp['type'] == 'social_engagement':
                insight['conclusions'].append({
                    "type": "social_activity",
                    "message": "High social engagement detected",
                    "action": opp['action']
                })
                insight['feed_targets'].append("social")
            
            elif opp['type'] == 'security_awareness':
                insight['conclusions'].append({
                    "type": "security_activity",
                    "message": "Frequent security events detected",
                    "action": opp['action']
                })
                insight['feed_targets'].append("security")
        
        insight['feed_targets'] = list(set(insight['feed_targets']))
        
        with open(self.insights_file, 'r') as f:
            insights_data = json.load(f)
        
        insights_data['insights'].append(insight)
        insights_data['total_insights'] += 1
        
        if len(insights_data['insights']) > 100:
            insights_data['insights'] = insights_data['insights'][-100:]
        
        with open(self.insights_file, 'w') as f:
            json.dump(insights_data, f, indent=2)
        
        return insight
    
    def feed_to_metacognition(self) -> Dict[str, Any]:
        insights = self.get_insights()[-10:]
        
        feedback = {
            "timestamp": datetime.now().isoformat(),
            "insights_fed": len(insights),
            "targets": [],
            "success": False
        }
        
        metacog_file = 'metacognition/self_analysis.json'
        
        if os.path.exists(metacog_file):
            try:
                with open(metacog_file, 'r') as f:
                    metacog = json.load(f)
                
                if 'ltm_insights' not in metacog:
                    metacog['ltm_insights'] = []
                
                for insight in insights:
                    metacog['ltm_insights'].append({
                        "timestamp": insight['timestamp'],
                        "conclusions": insight['conclusions'][:3],
                        "recommendations": insight['recommendations'][:3]
                    })
                
                if len(metacog['ltm_insights']) > 50:
                    metacog['ltm_insights'] = metacog['ltm_insights'][-50:]
                
                with open(metacog_file, 'w') as f:
                    json.dump(metacog, f, indent=2)
                
                feedback['targets'].append('metacognition')
                feedback['success'] = True
            except Exception:
                pass
        
        metacog2_file = 'metacognition2/evaluations.json'
        
        if os.path.exists(metacog2_file):
            feedback['targets'].append('metacognition2')
        
        return feedback
    
    def _get_next_id(self) -> int:
        with open(self.insights_file, 'r') as f:
            insights_data = json.load(f)
        return insights_data['total_insights'] + 1
    
    def get_insights(self) -> List[Dict[str, Any]]:
        with open(self.insights_file, 'r') as f:
            insights_data = json.load(f)
        return insights_data.get('insights', [])
