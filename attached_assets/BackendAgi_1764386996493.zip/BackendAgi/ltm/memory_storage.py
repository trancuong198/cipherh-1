import os
import json
from typing import Dict, Any, List, Optional
from datetime import datetime

class MemoryStorage:
    def __init__(self):
        self.ltm_dir = 'ltm'
        self.storage_file = os.path.join(self.ltm_dir, 'memories.json')
        
        os.makedirs(self.ltm_dir, exist_ok=True)
        
        self._init_storage()
    
    def _init_storage(self):
        if not os.path.exists(self.storage_file):
            with open(self.storage_file, 'w') as f:
                json.dump({
                    "memories": [],
                    "total_memories": 0,
                    "indexed_by_module": {},
                    "indexed_by_pattern": {}
                }, f, indent=2)
    
    def store_memory(self, event_id: str, module: str, data: Dict[str, Any], outcome: str) -> Dict[str, Any]:
        with open(self.storage_file, 'r') as f:
            storage = json.load(f)
        
        pattern_tag = self._generate_pattern_tag(module, data, outcome)
        
        memory = {
            "event_id": event_id,
            "module_origin": module,
            "data": data,
            "timestamp": datetime.now().isoformat(),
            "outcome": outcome,
            "pattern_tag": pattern_tag,
            "importance": self._calculate_importance(module, outcome)
        }
        
        storage['memories'].append(memory)
        storage['total_memories'] += 1
        
        if module not in storage['indexed_by_module']:
            storage['indexed_by_module'][module] = []
        storage['indexed_by_module'][module].append(event_id)
        
        if pattern_tag not in storage['indexed_by_pattern']:
            storage['indexed_by_pattern'][pattern_tag] = []
        storage['indexed_by_pattern'][pattern_tag].append(event_id)
        
        if len(storage['memories']) > 1000:
            storage['memories'] = storage['memories'][-1000:]
        
        with open(self.storage_file, 'w') as f:
            json.dump(storage, f, indent=2)
        
        return memory
    
    def _generate_pattern_tag(self, module: str, data: Dict[str, Any], outcome: str) -> str:
        if outcome == 'success':
            return f"{module}_success"
        elif outcome == 'failed':
            return f"{module}_failed"
        elif 'threat' in str(data).lower():
            return f"{module}_threat"
        elif 'social' in module:
            return f"social_interaction"
        elif 'evolution' in module:
            return f"evolution_event"
        else:
            return f"{module}_general"
    
    def _calculate_importance(self, module: str, outcome: str) -> int:
        importance = 50
        
        if module in ['security', 'hacker_mindset', 'defense']:
            importance = 90
        elif module in ['metacognition2', 'auto_evolution']:
            importance = 80
        elif module in ['social', 'personality']:
            importance = 70
        elif module in ['task_chain', 'realtime']:
            importance = 65
        
        if outcome == 'failed':
            importance = min(95, importance + 15)
        elif outcome == 'critical':
            importance = 98
        
        return importance
    
    def get_memories(self, module: Optional[str] = None, pattern: Optional[str] = None, limit: int = 50) -> List[Dict[str, Any]]:
        with open(self.storage_file, 'r') as f:
            storage = json.load(f)
        
        memories = storage['memories']
        
        if module:
            memories = [m for m in memories if m['module_origin'] == module]
        
        if pattern:
            memories = [m for m in memories if m['pattern_tag'] == pattern]
        
        return sorted(memories, key=lambda m: m['importance'], reverse=True)[-limit:]
    
    def get_by_event_id(self, event_id: str) -> Optional[Dict[str, Any]]:
        with open(self.storage_file, 'r') as f:
            storage = json.load(f)
        
        for memory in storage['memories']:
            if memory['event_id'] == event_id:
                return memory
        
        return None
    
    def get_stats(self) -> Dict[str, Any]:
        with open(self.storage_file, 'r') as f:
            storage = json.load(f)
        
        return {
            "total_memories": storage['total_memories'],
            "current_stored": len(storage['memories']),
            "modules": list(storage['indexed_by_module'].keys()),
            "patterns": list(storage['indexed_by_pattern'].keys())
        }
